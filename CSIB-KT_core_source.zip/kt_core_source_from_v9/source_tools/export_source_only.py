#!/usr/bin/env python3
"""Export code/configuration from a verified v9 archive; never alter the archive or project."""
from __future__ import annotations
import argparse,hashlib,io,json,os,stat,sys,tarfile,zipfile
from pathlib import Path,PurePosixPath

PREFIX='kt_core_full_v9/'
OUT_ROOT='kt_core_source_from_v9'
META={'FILE_MANIFEST.json','ENVIRONMENT.json','BUNDLE_STATUS.json'}
class ExportError(RuntimeError):pass
def digest(b):return hashlib.sha256(b).hexdigest()
def jsonbytes(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def relative(s):
 if not s or '\\' in s or PurePosixPath(s).is_absolute() or any(x in ('','..','.') for x in s.split('/')):
  raise ExportError('Invalid archive path: '+repr(s))
 return s
def source_path(s):
 p=PurePosixPath(s)
 if any(x in ('.git','__pycache__') for x in p.parts):return False
 if s in {'core.py','report_rq1.py','report_rq2.py','verify_results.py'}:return True
 if s=='supplement/tools/entry_index_v6.json':return True
 if s.startswith('supplement/tools/') and p.suffix in ('.py','.pyi'):return True
 if not s.startswith('kt_main/'):return False
 if p.suffix in ('.py','.pyi','.sh','.bash'):return True
 if s.startswith('kt_main/configs/') and p.suffix in ('.json','.yaml','.yml','.toml','.ini','.cfg'):return True
 if len(p.parts)==2 and (p.name in {'pyproject.toml','setup.cfg','environment.yml','environment.yaml'} or (p.name.startswith('requirements') and p.suffix=='.txt')):return True
 return False
def signature(p):
 s=p.stat();return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
class HashingReader:
 def __init__(self,f):self.f=f;self.h=hashlib.sha256()
 def read(self,n=-1):
  b=self.f.read(n);self.h.update(b);return b

def read_archive(path):
 """One sequential decompression; hash ALL files, retain only source bytes."""
 before=signature(path);observed={};chosen={};metadata={};seen=set()
 with path.open('rb') as raw:
  stream=HashingReader(raw)
  with tarfile.open(fileobj=stream,mode='r|gz') as tar:
   for member in tar:
    relative(member.name)
    if not member.name.startswith(PREFIX):raise ExportError('Unexpected archive root')
    name=relative(member.name[len(PREFIX):])
    if name in seen:raise ExportError('Duplicate archive member: '+name)
    seen.add(name)
    if not member.isfile():raise ExportError('Non-regular archive member: '+name)
    keep=source_path(name) or name in META
    if keep and member.size>32*1024**2:raise ExportError('Source/metadata unexpectedly large: '+name)
    h=hashlib.sha256();n=0;parts=[];f=tar.extractfile(member)
    for data in iter(lambda:f.read(1024**2),b''):
     n+=len(data);h.update(data)
     if keep:parts.append(data)
    if n!=member.size:raise ExportError('Truncated member: '+name)
    if name in META:metadata[name]=json.loads(b''.join(parts))
    else:
     observed[name]={'sha256':h.hexdigest(),'bytes':n}
     if keep:chosen[name]=b''.join(parts)
    if len(seen)%50==0:print('CHECKED',len(seen),'members',flush=True)
  # Include any remaining gzip trailer/padding in the compressed archive digest.
  for unused in iter(lambda:stream.read(1024**2),b''):pass
  archive_sha=stream.h.hexdigest()
 if signature(path)!=before:raise ExportError('Input archive changed while reading')
 if set(metadata)!=META:raise ExportError('Required v9 archive metadata missing')
 if metadata['BUNDLE_STATUS.json'].get('status')!='ARCHIVE_COMPLETE_BYTES_VERIFIED':raise ExportError('Archive not marked complete')
 expected={}
 for row in metadata['FILE_MANIFEST.json']:
  name=relative(row['path'])
  if name in expected:raise ExportError('Duplicate manifest path')
  expected[name]={'sha256':row['sha256'],'bytes':row['size']}
 if observed!=expected:raise ExportError('Archive files do not match FILE_MANIFEST.json')
 if 'kt_main/analysis/kt_ch4_followup_v4/measurement.py' not in chosen:raise ExportError('Core measurement source missing')
 # This template is empty in the supplied source; do not publish a live credential.
 for name,data in chosen.items():
  if name.endswith('/configs/wandb.json'):
   conf=json.loads(data)
   if conf.get('api_key') or conf.get('uid'):raise ExportError('Non-empty tracking credentials; make a sanitized public copy before export')
 print('FULL_ARCHIVE_CONTENTS_PASS',len(observed),'files',flush=True)
 return chosen,{'archive_name':path.name,'archive_sha256':archive_sha,'full_archive_payload_files_checked':len(observed)}

README='''KT paper source exported from the verified v9 core archive

This ZIP contains source files, runtime configuration and navigation metadata only.
It excludes student/item tables, synthetic responses, predictions, fitted parameters,
training logs, result tables/figures, checkpoints, LLM assets and environment binaries.
The three shared_scorer.py files under kt_main/data/ are source, not experiment data.

Original source bytes and relative paths are preserved. SOURCE_MANIFEST.json records
every delivered payload hash. SOURCE_STATUS.json binds this export to the compressed
v9 archive SHA256. All original archive payload files were checked before export.

Data and weights must be obtained separately to reproduce experiments. Original
scripts/configuration may contain original absolute paths and historical report
scopes. In particular, use the v9 report_rq1.py/report_rq2.py with the separate current
report inputs for the 522/235/57-item report scope. No report data is in this ZIP.
An exported code ZIP is not a replacement for the private full-result backup.

No original project files were moved or removed. No experiment was run or refitted.
'''

def verify_zip(path):
 with zipfile.ZipFile(path) as z:
  names=z.namelist()
  if len(names)!=len(set(names)):raise ExportError('Duplicate ZIP member')
  for s in names:relative(s)
  roots={s.split('/')[0] for s in names}
  if len(roots)!=1:raise ExportError('Unexpected ZIP root')
  root=next(iter(roots));manifest=json.loads(z.read(root+'/SOURCE_MANIFEST.json'))
  expected={relative(x['path']):x for x in manifest}
  if len(expected)!=len(manifest):raise ExportError('Duplicate source manifest path')
  allowed={root+'/'+x for x in expected}|{root+'/SOURCE_MANIFEST.json',root+'/SOURCE_STATUS.json'}
  if set(names)!=allowed:raise ExportError('Unlisted source ZIP member')
  for name,row in expected.items():
   data=z.read(root+'/'+name)
   if len(data)!=row['bytes'] or digest(data)!=row['sha256']:raise ExportError('Source checksum mismatch: '+name)
  if z.testzip() is not None:raise ExportError('ZIP CRC failed')
 print('SOURCE_ZIP_CONTENTS_PASS',len(expected),'files',flush=True)
 return len(expected)

def export(archive,out):
 archive=Path(archive).expanduser().resolve(strict=True);out=Path(out).expanduser().absolute()
 if out.suffix.lower()!='.zip':raise ExportError('Output must end in .zip')
 partial=out.with_name(out.name+'.partial')
 if out==archive or out.exists() or partial.exists():raise ExportError('Refusing to overwrite an existing path')
 chosen,origin=read_archive(archive)
 chosen['README_SOURCE.txt']=README.encode()
 chosen['source_tools/export_source_only.py']=Path(__file__).read_bytes()
 rows=[{'path':n,'sha256':digest(b),'bytes':len(b)} for n,b in sorted(chosen.items())]
 status={'status':'SOURCE_ONLY_EXPORTED','origin':origin,'source_payload_files':len(rows),'original_archive_modified':False,
  'data_weights_results_included':False,'experiments_rerun':False,'cross_machine_reproduction_verified':False}
 out.parent.mkdir(parents=True,exist_ok=True)
 with partial.open('xb') as raw:
  with zipfile.ZipFile(raw,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   for name,data in sorted(chosen.items()):z.writestr(OUT_ROOT+'/'+name,data)
   z.writestr(OUT_ROOT+'/SOURCE_MANIFEST.json',jsonbytes(rows))
   z.writestr(OUT_ROOT+'/SOURCE_STATUS.json',jsonbytes(status))
  raw.flush();os.fsync(raw.fileno())
 verify_zip(partial)
 os.link(partial,out);partial.unlink()
 print('SOURCE_ONLY_EXPORT_PASS',out,'bytes',out.stat().st_size,flush=True)
 return status

def main():
 ap=argparse.ArgumentParser(description=__doc__);sp=ap.add_subparsers(dest='command',required=True)
 p=sp.add_parser('export');p.add_argument('--archive',required=True);p.add_argument('--out',required=True)
 p=sp.add_parser('verify');p.add_argument('--zip',required=True)
 a=ap.parse_args()
 try:
  if a.command=='export':export(a.archive,a.out)
  else:verify_zip(Path(a.zip))
 except (ExportError,OSError,ValueError,KeyError,tarfile.TarError,zipfile.BadZipFile) as e:
  print('ERROR:',str(e),file=sys.stderr);return 2
 return 0
if __name__=='__main__':raise SystemExit(main())
