#!/usr/bin/env python3
"""Summarize supplied frozen OOF predictions on 522/235/57 report items.
No KT, channel, IRT, mapper or MAP fitting is run.
"""
import argparse,json
from pathlib import Path

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',required=True);a=ap.parse_args()
 import numpy as np,pandas as pd
 from scipy.stats import rankdata,spearmanr
 here=Path(__file__).resolve().parent;assets=here if (here/'report_inputs').exists() else here/'supplement'
 out=Path(a.out)
 if out.exists():raise FileExistsError('Use a new output directory')
 pts=pd.read_csv(assets/'report_outputs/figure4_all_items.csv',dtype={'target_kc_key':str},float_precision='round_trip')
 def logit(p):
  p=np.clip(p,1e-6,1-1e-6);return np.log(p)-np.log1p(-p)
 rows=[]
 for key,title,want in [('xes','XES3G5M',522),('fa','FoundationalASSIST',235),('dbe','DBE-KT22',57)]:
  g=pd.read_csv(assets/f'report_inputs/{key}/group.csv',dtype={'target_kc_key':str})
  e=pd.read_csv(assets/f'report_inputs/{key}/events.csv.gz')
  stats=e.groupby('target_qid').agg(y=('label','sum'),n=('label','size'),p=('teacher_kc_uniform','mean'))
  stats['criterion']=logit((stats.y+8*stats.p)/(stats.n+8))-logit(stats.p)
  ids=set(g.target_qid)&set(stats.index[stats.n>=30]);z=pts[pts.dataset==title].reset_index(drop=True)
  if len(z)!=want or set(z.target_qid)!=ids or z.target_qid.duplicated().any():raise ValueError('Unexpected report points '+title)
  full=g.merge(stats[['criterion']],left_on='target_qid',right_index=True,validate='one_to_one')
  check=z.merge(full[['target_qid','criterion','content_group_fold']],on='target_qid',suffixes=('','_input'),validate='one_to_one')
  if not np.allclose(check.criterion,check.criterion_input,rtol=0,atol=1e-10):raise ValueError('Frozen criterion mismatch '+title)
  references=[full[full.content_group_fold!=f].criterion.mean() for f in check.content_group_fold_input]
  if not np.allclose(check.reference_mean,references,rtol=0,atol=1e-10):raise ValueError('Frozen source-mean mismatch '+title)
  x=z.prior_mean.to_numpy();y=z.criterion.to_numpy();ref=z.reference_mean.to_numpy();d=(y-ref)**2-(y-x)**2
  info=dict(dataset=title,item_n=len(z),spearman=float(spearmanr(x,y).statistic),delta_mse=float(d.mean()),relative_mse_improvement_pct=float(100*d.mean()/np.mean((y-ref)**2)))
  for level in ['item','kc_set']:
   rng=np.random.default_rng(42031 if level=='item' else 42032);rs=[];ms=[]
   blocks=[v.index.to_numpy() for _,v in z.groupby('target_kc_key')]
   for _ in range(5000):
    ix=rng.integers(len(z),size=len(z)) if level=='item' else np.concatenate([blocks[j] for j in rng.integers(len(blocks),size=len(blocks))])
    r1=rankdata(x[ix]);r2=rankdata(y[ix]);rs.append(np.corrcoef(r1,r2)[0,1] if np.std(r1)>0 and np.std(r2)>0 else np.nan);ms.append(d[ix].mean())
   info[level+'_rho_low'],info[level+'_rho_high']=map(float,np.nanquantile(rs,[.025,.975]));info[level+'_mse_low'],info[level+'_mse_high']=map(float,np.quantile(ms,[.025,.975]))
  rows.append(info)
 out.mkdir(parents=True);pd.DataFrame(rows).to_csv(out/'table3_report_scope.csv',index=False)
 (out/'scope.json').write_text(json.dumps({'counts':[522,235,57],'bootstrap_draws':5000,'item_seed':42031,'kc_seed':42032,'predictions':'provided fixed out-of-fold predictions','new_model_fitting':False},ensure_ascii=False,indent=2))
 print('RQ2_REPORT_SCOPE_PASS',out)
if __name__=='__main__':main()
