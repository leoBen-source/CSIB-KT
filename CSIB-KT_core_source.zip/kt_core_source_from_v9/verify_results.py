#!/usr/bin/env python3
"""Read-only consistency check of the 14 retained result suites. No training."""
import argparse,importlib.util,json,sys
from pathlib import Path

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--project',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
 root=Path(a.project).resolve(strict=True);out=Path(a.out)
 if out.exists():raise FileExistsError('Use a new output file')
 if out.resolve().is_relative_to(root):raise ValueError('Write check report outside source project')
 here=Path(__file__).resolve().parent;assets=here if (here/'tools').exists() else here/'supplement'
 spec=importlib.util.spec_from_file_location('kt_readonly_verify',assets/'tools/retained_verify_v6.py')
 mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 policy=json.loads((assets/'provenance/v6_policy.json').read_text())
 runs=mod.validate_results(root,policy)
 if len(runs)!=14:raise ValueError('Expected 14 retained result suites')
 report={'status':'RESULT_NUMERIC_CHECKS_PASS','checked_suites':runs,'new_model_training':False,'model_inference_probes_run':False}
 out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('x',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)
 print('RESULT_NUMERIC_CHECKS_PASS',len(runs),out)
if __name__=='__main__':main()
