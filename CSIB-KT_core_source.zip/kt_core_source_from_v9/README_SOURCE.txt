KT paper source exported from the verified v9 core archive

This ZIP contains source files, runtime configuration and navigation metadata only.
It excludes student/item tables, synthetic responses, predictions, fitted parameters,
training logs, result tables/figures, checkpoints, LLM assets and environment binaries.
The three shared_scorer.py files under kt_main/data/ are source, not experiment data.

Original source bytes and relative paths are preserved. SOURCE_MANIFEST.json records
every delivered payload hash. SOURCE_STATUS.json binds this export to the compressed
v9 archive SHA256. All original archive payload files were checked before export.

Data and weights must be obtained separately to reproduce experiments. Original
scripts/configuration may contain original absolute paths and historical report
scopes. In particular, use the v9 report_rq1.py/report_rq2.py with the separate current
report inputs for the 522/235/57-item report scope. No report data is in this ZIP.
An exported code ZIP is not a replacement for the private full-result backup.

No original project files were moved or removed. No experiment was run or refitted.
