#!/usr/bin/env python3
"""Reaggregate the fixed 522/235/57-item report scope; no model fitting."""
import argparse,hashlib,json
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--inputs');ap.add_argument('--out',required=True);a=ap.parse_args()
    here=Path(__file__).resolve().parent
    default=here/'report_inputs'
    if not default.exists():default=here/'supplement/report_inputs'
    root=Path(a.inputs) if a.inputs else default
    out=Path(a.out)
    if out.exists():raise FileExistsError('Use a new output directory: '+str(out))
    import pandas as pd
    summaries=[];frames=[];audit=[]
    for key,name,want in [('xes','XES3G5M',522),('fa','FoundationalASSIST',235),('dbe','DBE-KT22',57)]:
        folder=root/key;g=pd.read_csv(folder/'group.csv',dtype={'target_kc_key':str});e=pd.read_csv(folder/'events.csv.gz');r=pd.read_csv(folder/'responses.csv')
        if g.target_qid.duplicated().any():raise ValueError('Duplicate group item')
        if not e.label.isin([0,1]).all():raise ValueError('Nonbinary student score')
        n=e.groupby('target_qid').size();ids=set(g.target_qid)&set(n[n>=30].index)
        if len(ids)!=want:raise ValueError(f'Unexpected report count {key}: {len(ids)}')
        if 'scoring_valid' in r:r=r[r.scoring_valid.astype(int)==1]
        r=r[r.qid.isin(ids)]
        if not r.correct.isin([0,1]).all():raise ValueError('Nonbinary synthetic score')
        if (r.groupby('qid').size()!=20).any():raise ValueError('Expected 20 synthetic channels')
        h=e[e.target_qid.isin(ids)].groupby('target_qid').label.mean().rename('human_rate')
        s=r.groupby('qid').correct.mean().rename('synthetic_rate')
        z=pd.concat([h,s],axis=1).loc[sorted(ids)].rename_axis('target_qid').reset_index()
        if z.isna().any().any():raise ValueError('Unpaired item')
        z['dataset']=name;delta=z.synthetic_rate-z.human_rate;frames.append(z)
        summaries.append(dict(dataset=name,item_n=len(z),kc_set_n=g[g.target_qid.isin(ids)].target_kc_key.nunique(),
            event_n=int(e.target_qid.isin(ids).sum()),synthetic_mean_pct=float(z.synthetic_rate.mean()*100),human_mean_pct=float(z.human_rate.mean()*100),
            bias_pp=float(delta.mean()*100),mae_pp=float(delta.abs().mean()*100),medae_pp=float(delta.abs().median()*100)))
        audit.append({'dataset':name,'reference_bank_items':len(g),'report_items':len(ids),'unreported_reference_items':sorted(set(g.target_qid)-ids)})
    out.mkdir(parents=True)
    pd.DataFrame(summaries).to_csv(out/'table2_report_scope.csv',index=False)
    pd.concat(frames,ignore_index=True).to_csv(out/'figure3_items.csv',index=False)
    (out/'report_scope.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    print('REPORT_SCOPE_PASS',out)
if __name__=='__main__':main()
