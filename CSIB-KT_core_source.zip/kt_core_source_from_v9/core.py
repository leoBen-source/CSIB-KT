#!/usr/bin/env python3
"""One navigation entry. list never starts training or changes results."""
import argparse,json,os,subprocess,sys
from pathlib import Path

def main():
 here=Path(__file__).resolve().parent;assets=here if (here/'tools').is_dir() else here/'supplement'
 default=here/'kt_main'
 if not default.exists():default=Path('/home/dell/KT/KT_LLM_experiments/kt_main')
 index=json.loads((assets/'tools/entry_index_v6.json').read_text())
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--project',default=str(default));ap.add_argument('entry');ap.add_argument('args',nargs=argparse.REMAINDER);a=ap.parse_args()
 root=Path(a.project).resolve();rest=a.args
 if rest and rest[0]=='--':rest=rest[1:]
 if a.entry=='list':
  print('rq1\tCurrent report-scope raw correctness (522/235/57), no fitting')
  print('rq2\tCurrent fixed OOF prediction summaries (522/235/57), no fitting')
  print('verify-results\tRead-only consistency checks for 14 existing result suites')
  for key,val in index['entries'].items():
   if key not in ['rq1']:print(key+'\t'+val['role']+'\t'+val['path'])
  return
 if a.entry=='rq1':cmd=[sys.executable,str(here/'report_rq1.py')]+rest
 elif a.entry=='rq2':cmd=[sys.executable,str(here/'report_rq2.py')]+rest
 elif a.entry=='verify-results':cmd=[sys.executable,str(here/'verify_results.py'),'--project',str(root)]+rest
 else:
  if a.entry not in index['entries']:ap.error('Unknown entry: '+a.entry)
  item=index['entries'][a.entry];target=root/item['path']
  if not target.is_file():raise FileNotFoundError(target)
  cmd=[sys.executable,str(target)]+item.get('prefix_args',[])+rest
 env=dict(os.environ);env['KT_PROJECT']=str(root);env['PYTHONDONTWRITEBYTECODE']='1'
 env['PYTHONPATH']=os.pathsep.join([str(root/'analysis/kt_ch4_followup_v4'),str(root/'examples'),str(root),env.get('PYTHONPATH','')])
 raise SystemExit(subprocess.call(cmd,env=env,cwd=root/'examples' if (root/'examples').exists() else here))
if __name__=='__main__':main()
