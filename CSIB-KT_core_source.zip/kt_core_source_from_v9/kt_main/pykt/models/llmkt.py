import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast 
from transformers import AutoModel, AutoConfig, AutoTokenizer

# Try import PEFT (LoRA)
try:
    from peft import get_peft_model, LoraConfig, TaskType
    PEFT_AVAILABLE = True
except Exception:
    PEFT_AVAILABLE = False

class DynamicConceptMemory(nn.Module):
    """
    Sample-wise dynamic concept memory for KT.
    state is NOT stored as model parameter.
    Instead, it is created per-batch inside forward:
        state: [B, num_concepts, hidden_size]
    """

    def __init__(self, num_concepts, hidden_size, dropout=0.1):
        super().__init__()
        self.num_concepts = num_concepts
        self.hidden_size = hidden_size

        # static concept prior, used to initialize per-sample memory state
        self.concept_prior = nn.Embedding(num_concepts, hidden_size, padding_idx=0)

        # read/fusion
        self.read_fuse = nn.Sequential(
            nn.Linear(hidden_size * 2, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        # update gate
        self.update_gate = nn.Sequential(
            nn.Linear(hidden_size * 3 + 1, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size, hidden_size),
            nn.Sigmoid()
        )

        # candidate state
        self.update_cand = nn.Sequential(
            nn.Linear(hidden_size * 3 + 1, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh()
        )

        # query fusion for next concept
        self.query_fuse = nn.Sequential(
            nn.Linear(hidden_size * 2, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def init_state(self, batch_size, device):
        """
        Initialize sample-wise concept state from static concept prior.
        Returns:
            state: [B, K, D]
        """
        base = self.concept_prior.weight.unsqueeze(0).expand(batch_size, -1, -1)
        return base.clone()

    def read(self, state, concept_ids):
        """
        state: [B, K, D]
        concept_ids: [B]
        return: [B, D]
        """
        concept_ids = concept_ids.long().clamp(min=0, max=self.num_concepts - 1)
        idx = concept_ids.unsqueeze(-1).unsqueeze(-1).expand(-1, 1, state.size(-1))
        mem = state.gather(1, idx).squeeze(1)   # [B,D]
        return mem

    def fuse_student(self, h_t, m_t):
        """
        h_t: [B,D] semantic interaction state
        m_t: [B,D] current concept memory
        """
        return self.read_fuse(torch.cat([h_t, m_t], dim=-1))

    def fuse_query(self, q_t, m_next):
        """
        q_t: [B,D] next-question semantic query
        m_next: [B,D] next-concept memory
        """
        return self.query_fuse(torch.cat([q_t, m_next], dim=-1))

    def update(self, state, concept_ids, h_t, m_t, r_t):
        """
        Update only the current concept slot.
        state: [B,K,D]
        concept_ids: [B]
        h_t: [B,D]
        m_t: [B,D]
        r_t: [B]
        """
        r_t = r_t.float().unsqueeze(-1)  # [B,1]

        x = torch.cat([h_t, m_t, h_t - m_t, r_t], dim=-1)  # [B,3D+1]

        z = self.update_gate(x)        # [B,D]
        cand = self.update_cand(x)     # [B,D]

        new_m = (1.0 - z) * m_t + z * cand

        new_state = state.clone()
        batch_idx = torch.arange(state.size(0), device=state.device)
        concept_ids = concept_ids.long().clamp(min=0, max=self.num_concepts - 1)

        # do not update padding concept 0
        valid = concept_ids > 0
        if valid.any():
            new_state[batch_idx[valid], concept_ids[valid]] = new_m[valid]

        return new_state, new_m

class LLMKT(nn.Module):
    """
    C1-style LLM-KT:
      - concept/question are NEW tokens in GPT2 vocab
      - build history as token sequence (C,Q,R) per timestep
      - use GPT2 hidden state as student state
      - predict next response using (h_t, q_{t+1}) -> logit

    Output:
      logit [B, L] aligned with rshft/smasks logic in PyKT
    """

    def __init__(
        self,
        num_c: int,
        llm_path: str = "gpt2",
        use_lora: int = 1,
        unfreeze_last_n: int = 3,
        lora_r: int = 16,
        lora_alpha: int = 32,
        lora_dropout: float = 0.05,
        prefix_len: int = 20,
        dropout: float = 0.1,
        cl_weight: float = 0.0,
        emb_type: str = "qid",
        # ### MODIFIED / ADDED: 引入 KT 专属参数 ###
        ut_bins: int = 512, 
        gap_bins: int = 512, 
        n_heads: int = 8, 
        cl_temp: float = 0.05,
        time_gap_clip: int = 1_000_000,
        # ### END MODIFIED / ADDED ###
        **kwargs
    ):
        super().__init__()
        self.model_name = "llmkt"
        self.num_c = int(num_c)
        self.num_q = int(kwargs.get("num_q", 0))
        self.use_q_tokens = int(kwargs.get("use_q_tokens", 1)) == 1
      
        self.prefix_len = int(prefix_len)
        self.dropout = nn.Dropout(dropout)
        self.unfreeze_last_n = int(unfreeze_last_n)
        self.qcons_weight = float(kwargs.get("qcons_weight", 0.02))
        self.lambda_auc = float(kwargs.get("lambda_auc", 0.0))
        self.pair_sample_size = int(kwargs.get("pair_sample_size", 512))


        # aux_loss hook (PyKT train_model.py may read it)
        self.aux_loss = None
        self.cl_weight = float(cl_weight) if cl_weight is not None else 0.0
        self.cl_temp = float(cl_temp) ### ADDED: contrastive learning temperature
        self.q_gate_reg = float(kwargs.get("q_gate_reg", 0.0))
        # ### ADDED: 引入 KT 专属参数到 self ###
        self.ut_bins = int(kwargs.get("ut_bins", ut_bins)) 
        self.gap_bins = int(kwargs.get("gap_bins", gap_bins)) 
        self.n_heads = int(kwargs.get("n_heads", n_heads))
        self.time_gap_clip = int(kwargs.get("time_gap_clip", time_gap_clip))
        # ### END ADDED ###
        # ---- ablation switches ----
        self.use_spacing = int(kwargs.get("use_spacing", 1)) == 1
        self.use_monotonic = int(kwargs.get("use_monotonic", 1)) == 1
        self.use_forget_gate = int(kwargs.get("use_forget_gate", 1)) == 1
        self.use_irt_head = int(kwargs.get("use_irt_head", 1)) == 1
        self.use_ut = int(kwargs.get("use_ut", 1)) == 1        
        self.use_gap = int(kwargs.get("use_gap", 1)) == 1 
        # ---------------- 1) Load LLM + Tokenizer ----------------
        print(f"🤖 [LLMKT-C1] Loading Backbone from: {llm_path}")
        config = AutoConfig.from_pretrained(llm_path)
        self.llm_dim = int(config.hidden_size)
         # ---------------- Explicit Concept Memory ----------------
        self.use_concept_memory = int(kwargs.get("use_concept_memory", 1)) == 1
        self.memory_weight = float(kwargs.get("memory_weight", 1.0))
        self.memory_init_from_token = int(kwargs.get("memory_init_from_token", 1)) == 1
        self.mem_alpha = float(kwargs.get("mem_alpha", 0.1))
        self.use_dynamic_memory_update = int(kwargs.get("use_dynamic_memory_update", 1)) == 1

        if self.use_concept_memory:
            self.concept_memory = DynamicConceptMemory(
                num_concepts=self.num_c,
                hidden_size=self.llm_dim,
                dropout=dropout
            )

            # state-anchor: inject next concept memory into prediction backbone
            self.state_anchor_beta = float(kwargs.get("state_anchor_beta", 0.2))

            # project memory-conditioned anchor
            self.state_anchor_proj = nn.Sequential(
                nn.Linear(self.llm_dim, self.llm_dim),
                nn.LayerNorm(self.llm_dim),
                nn.GELU(),
                nn.Dropout(dropout),
            )

            # NEW: gated anchor, element-wise control for memory injection
            self.use_gated_anchor = int(kwargs.get("use_gated_anchor", 1)) == 1
            self.state_anchor_gate = nn.Sequential(
                nn.Linear(self.llm_dim * 2, self.llm_dim),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(self.llm_dim, self.llm_dim),
                nn.Sigmoid()
            )

            # optional scale calibration to prevent memory branch from being too weak
            self.state_anchor_gain = float(kwargs.get("state_anchor_gain", 1.0))
            
             # NEW: direct supervision on concept memory
            self.memory_aux_weight = float(kwargs.get("memory_aux_weight", 0.0))
            self.use_memory_direct = int(kwargs.get("use_memory_direct", 0)) == 1

            self.memory_readout_head = nn.Sequential(
                nn.Linear(self.llm_dim * 2, self.llm_dim),
                nn.LayerNorm(self.llm_dim),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(self.llm_dim, 1),
            )

            # optional lightweight memory residual branch (keep OFF for now)
            self.use_memory_residual = int(kwargs.get("use_memory_residual", 1)) == 1
            self.next_memory_head = nn.Sequential(
                nn.Linear(self.llm_dim * 2, self.llm_dim),
                nn.LayerNorm(self.llm_dim),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(self.llm_dim, 1),
            )



        self.v4_proj = nn.Linear(384, self.llm_dim, bias=False)
        self.tokenizer = AutoTokenizer.from_pretrained(llm_path, use_fast=True)
        self.step_pool = nn.Parameter(torch.tensor([0.2, 0.3, 0.5]))  # init偏向R
        self.cur_weight = float(kwargs.get("cur_weight", 0.0))  # 0.1~0.4 sweep
        self.cur_head = nn.Sequential(
            nn.Linear(self.llm_dim, self.llm_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(self.llm_dim // 2, 1),
        )
        # GPT2 has no pad by default; set pad = eos to make attention_mask work cleanly
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        self.llm = AutoModel.from_pretrained(llm_path, config=config)
        
        self.llm.gradient_checkpointing_enable()
        self.llm.config.use_cache = False


        # Freeze original LLM weights first
        for p in self.llm.parameters():
            p.requires_grad = False

        # ---------------- 2) Add NEW tokens for C/Q/R (C1) ----------------
        # Token naming: stable, no need for natural language
        concept_tokens = [f"<C{i}>" for i in range(self.num_c)]
        question_tokens = [f"<Q{i}>" for i in range(self.num_q)] if (self.num_q > 0 and self.use_q_tokens) else []
        response_tokens = ["<R0>", "<R1>"]

        special_tokens = concept_tokens + question_tokens + response_tokens
        added = self.tokenizer.add_tokens(special_tokens, special_tokens=True)
        print(f"🧩 [LLMKT-C1] Added tokens = {added}  (C={len(concept_tokens)}, Q={len(question_tokens)}, R=2)")

        # Resize model embeddings to match new vocab
        self.llm.resize_token_embeddings(len(self.tokenizer))
        self.wte = self.llm.get_input_embeddings()  # nn.Embedding

        # Precompute token-id maps (register_buffer to move with .to(device))
        concept_ids = torch.tensor(self.tokenizer.convert_tokens_to_ids(concept_tokens), dtype=torch.long)
        self.register_buffer("concept_token_ids", concept_ids, persistent=False)

        if self.num_q > 0:
            q_ids = torch.tensor(self.tokenizer.convert_tokens_to_ids(question_tokens), dtype=torch.long)
            self.register_buffer("question_token_ids", q_ids, persistent=False)
        else:
            self.question_token_ids = None

        r_ids = torch.tensor(self.tokenizer.convert_tokens_to_ids(response_tokens), dtype=torch.long)
        self.register_buffer("response_token_ids", r_ids, persistent=False)

        self.pad_id = int(self.tokenizer.pad_token_id)
        # 1) allow embedding matrix to receive grads
        self.wte.weight.requires_grad = True

        # 2) mask grads so ONLY <C*>/<Q*>/<R*> rows update
        def _mask_wte_grad(grad):
            mask = torch.zeros_like(grad)
            c_ids = self.concept_token_ids
            if c_ids.numel() > 0:
                mask[c_ids[1:]] = 1 
            if self.question_token_ids is not None and self.question_token_ids.numel() > 0:
                mask[self.question_token_ids[1:]] = 1
            mask[self.response_token_ids] = 1
            return grad * mask

        self.wte.weight.register_hook(_mask_wte_grad)
        # ---------------- 3) LoRA (optional) ----------------
        def _selective_unfreeze_after_wrap(m):
            # Unfreeze LayerNorms + last block (robust to PEFT wrappers)
            ln_cnt = 0
            for name, p in m.named_parameters():
                lname = name.lower()
                if ("ln_" in lname) or ("layernorm" in lname) or ("layer_norm" in lname) or (".ln" in lname):
                    p.requires_grad = True
                    ln_cnt += 1

            max_idx = -1
            for name, _ in m.named_parameters():
                if ".h." in name:
                    parts = name.split(".h.")
                    if len(parts) > 1:
                        idx_str = parts[1].split(".")[0]
                        if idx_str.isdigit():
                            max_idx = max(max_idx, int(idx_str))
                if "transformer.h." in name:
                    try:
                        idx = int(name.split("transformer.h.")[1].split(".")[0])
                        max_idx = max(max_idx, idx)
                    except:
                        pass

            blk_cnt = 0
            if max_idx >= 0:
                key1 = f".h.{max_idx}."
                key2 = f"transformer.h.{max_idx}."
                for name, p in m.named_parameters():
                    if (key1 in name) or (key2 in name):
                        p.requires_grad = True
                        blk_cnt += 1

            trainable = sum(p.numel() for p in m.parameters() if p.requires_grad)
            print(f"✅ [LLMKT-C1] Unfroze LN params={ln_cnt}, last_block_params={blk_cnt}, trainable_elems_in_llm={trainable}")

        if PEFT_AVAILABLE and int(use_lora) == 1:
            target_modules = ["c_attn", "c_proj", "c_fc"]
            peft_config = LoraConfig(
                task_type=TaskType.FEATURE_EXTRACTION,
                r=int(lora_r),
                lora_alpha=int(lora_alpha),
                lora_dropout=float(lora_dropout),
                target_modules=target_modules
            )
            self.llm = get_peft_model(self.llm, peft_config)
            self.wte = self.llm.get_input_embeddings()
            print(f"🚀 [LLMKT-C1] LoRA Enabled (r={lora_r}, targets={target_modules})")
            _selective_unfreeze_after_wrap(self.llm)
        else:
            print("⚠️ [LLMKT-C1] LoRA Disabled or PEFT not installed.")
            _selective_unfreeze_after_wrap(self.llm)
        try:
            self.wte = self.llm.get_input_embeddings()
            self.wte.weight.requires_grad_(True)
            print("✅ [EMB] wte.weight set trainable:", self.wte.weight.requires_grad)
        except Exception as e:
            print("⚠️ [EMB] failed to unfreeze wte:", e)
        # ---- MUST: force unfreeze last transformer block(s) ----
        self._force_unfreeze_last_gpt2_blocks(self.unfreeze_last_n)

        # ---------------- 4) Soft prefix prompt (still allowed) ----------------
        self.prefix_emb = nn.Parameter(torch.randn(self.prefix_len, self.llm_dim) * 0.01)
        # E(Q) = E(C) + Delta(Q), where Delta is low-rank (q_low) then projected to llm_dim.
        self.use_q_residual = int(kwargs.get("use_q_residual", 1)) == 1
        self.q_low = int(kwargs.get("q_low", 64))  # 32/64 recommended
        self.q_delta_weight = float(kwargs.get("q_delta_weight", 1e-4))  # 1e-5~5e-4 sweep

        if (self.num_q > 0) and self.use_q_tokens and self.use_q_residual:
            self.q_delta = nn.Embedding(self.num_q + 1, self.q_low, padding_idx=0)
            self.q_delta_proj = nn.Linear(self.q_low, self.llm_dim, bias=False)
            nn.init.normal_(self.q_delta.weight, mean=0.0, std=0.02)
            nn.init.zeros_(self.q_delta_proj.weight)
            self.q_gate = nn.Sequential(
                nn.Linear(self.llm_dim * 2, self.llm_dim // 4),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(self.llm_dim // 4, 1),
                nn.Sigmoid()
            )
        else:
            self.q_delta = None
            self.q_delta_proj = None
        # ### ADDED: KT Specific Embeddings (从旧版本恢复) ###
        _spacing_bins = int(kwargs.get("spacing_bins", 256))
        self.spacing_emb = nn.Embedding(_spacing_bins + 1, self.llm_dim, padding_idx=0)
        self.ut_emb = nn.Embedding(self.ut_bins + 1, self.llm_dim, padding_idx=0)
        self.gap_emb = nn.Embedding(self.gap_bins + 1, self.llm_dim, padding_idx=0)
        
        # ==================== 【修改 1】：R 专属轻量级 Embedding ====================
                # ==================== 【终极修复 1】：强信号与零初始化融合 ====================
        # 1. 增大 r_emb 的初始权重，让 LLM 无法忽视它的存在
        self.r_emb = nn.Embedding(3, self.llm_dim, padding_idx=0)
        nn.init.normal_(self.r_emb.weight, mean=0.0, std=0.1) 

        # 2. 专门用于融合 Q 和 R 的投影层
        self.fusion_proj = nn.Sequential(
            nn.Linear(self.llm_dim * 2, self.llm_dim),
            nn.LayerNorm(self.llm_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(self.llm_dim, self.llm_dim)
        )
        # 【关键魔法】：将最后一层初始化为0。
        # 这样在 Epoch 1，fusion的输出完全为0，模型 100% 依赖 V4 语义；
        # 随着训练，模型会平滑地学会把 R 的信号注入进去，绝不会破坏预训练空间！
        nn.init.zeros_(self.fusion_proj[-1].weight)
        nn.init.zeros_(self.fusion_proj[-1].bias)

        # 3. 同样的零初始化魔法应用于 Adapter
        self.adapter = nn.Sequential(
            nn.Linear(self.llm_dim, self.llm_dim),
            nn.LayerNorm(self.llm_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(self.llm_dim, self.llm_dim)
        )
        nn.init.zeros_(self.adapter[-1].weight)
        nn.init.zeros_(self.adapter[-1].bias)
        # =========================================================================

        # ### END ADDED ###
        # ---- simple baseline head: concat([h_step, q_next_emb]) -> logit ----
        self.simple_head = nn.Sequential(
            nn.Linear(self.llm_dim * 2, self.llm_dim),
            nn.LayerNorm(self.llm_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(self.llm_dim, self.llm_dim // 2),
            nn.GELU(),
            nn.Linear(self.llm_dim // 2, 1),
        )

        # ---------------- 5) Prediction head (query-aware, SIMPLE) ----------------
        # ### MODIFIED: 替换 Prediction Head，引入 IRT-like 结构 ###
        self.theta_head = nn.Sequential(
            nn.Linear(self.llm_dim, self.llm_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(self.llm_dim // 2, 1)
        )

        if self.num_q > 0:
            self.q_disc = nn.Embedding(self.num_q + 1, 1, padding_idx=0)
        else:
            self.q_disc = None
        
        if self.num_q > 0:
            self.q_bias = nn.Embedding(self.num_q + 1, 1, padding_idx=0)
        else:
            self.q_bias = None

        self.res_head = nn.Sequential(
            nn.Linear(self.llm_dim * 2, self.llm_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(self.llm_dim, 1)
        )

        # ### ADDED: Forgetting gate & Monotonic Attention (从旧版本恢复) ###
        assert self.llm_dim % self.n_heads == 0
        self.head_dim = self.llm_dim // self.n_heads

        self.attn_q = nn.Linear(self.llm_dim, self.llm_dim, bias=False)
        self.attn_k = nn.Linear(self.llm_dim, self.llm_dim, bias=False)
        self.attn_v = nn.Linear(self.llm_dim, self.llm_dim, bias=False)
        self.attn_out = nn.Linear(self.llm_dim, self.llm_dim, bias=False)
        print(f"✅ [LLMKT] monotonic attn heads={self.n_heads}, head_dim={self.head_dim}")

        self.gamma = nn.Parameter(torch.tensor(0.10))
        self.gamma_t = nn.Parameter(torch.tensor(0.05))

        self.attn_drop = nn.Dropout(dropout)
        self._dist_cache = None
        self._dist_cache_L = None

        self.decay_mlp = nn.Sequential(
            nn.Linear(self.llm_dim, self.llm_dim // 2),
            nn.GELU(),
            nn.Linear(self.llm_dim // 2, 1),
            nn.Sigmoid()
        )
        self.forget_gate = nn.Sequential(
            nn.Linear(self.llm_dim * 2, self.llm_dim),
            nn.GELU(),
            nn.Linear(self.llm_dim, self.llm_dim),
            nn.Sigmoid()
        )
        # ### END ADDED ###

        # ---------------- 6) (Optional) V4 hook: MiniLM init place-holder ----------------
        self._v4_inited = False
        self.use_amp = kwargs.get('use_amp', True)
        print(f"🔥 [LLMKT] AMP enabled: {self.use_amp}")
    
    def init_concept_memory_prior_from_tokens(self):
        if (not hasattr(self, "concept_memory")) or (self.concept_memory is None):
            return
        if (not hasattr(self, "concept_token_ids")) or (self.concept_token_ids is None):
            return

        c_ids = self.concept_token_ids.to(self.wte.weight.device)
        c_emb = self.wte(c_ids).detach()

        num_copy = min(c_emb.size(0), self.concept_memory.concept_prior.weight.size(0))
        self.concept_memory.concept_prior.weight.data[:num_copy].copy_(c_emb[:num_copy])
        print("✅ [ConceptMemory] concept_prior initialized from concept token embeddings.")

    def _force_unfreeze_last_gpt2_blocks(self, n_last: int = 1):
        """
        Robustly unfreeze last n GPT2 blocks, compatible with (plain HF) and PEFT wrappers.
        """
        if n_last <= 0:
            print("✅ [LLMKT] unfreeze_last_n <= 0, skip.")
            return 0

        # Try multiple paths to find transformer.h
        candidates = []

        # 1) plain model
        candidates.append(self.llm)

        # 2) common wrapper attrs
        for a in ["base_model", "model"]:
            if hasattr(self.llm, a):
                candidates.append(getattr(self.llm, a))

        # 3) nested wrappers
        for obj in list(candidates):
            for a in ["base_model", "model"]:
                if hasattr(obj, a):
                    candidates.append(getattr(obj, a))

        tr = None
        for obj in candidates:
            if hasattr(obj, "transformer") and hasattr(obj.transformer, "h"):
                tr = obj.transformer
                break
            if hasattr(obj, "h"):  # extremely rare variant
                tr = obj
                break

        if tr is None or (not hasattr(tr, "h")):
            print("⚠️ [LLMKT] cannot find transformer.h ; last blocks NOT unfrozen.")
            return 0

        blocks = tr.h
        n_last = min(int(n_last), len(blocks))

        trainable_elems = 0
        for blk in blocks[-n_last:]:
            for p in blk.parameters():
                p.requires_grad = True
                trainable_elems += p.numel()

        any_grad = any(p.requires_grad for p in blocks[-1].parameters())
        print(f"✅ [LLMKT] Force-unfroze last {n_last} GPT2 block(s), elems={trainable_elems}, last_block_grad={any_grad}")
        return trainable_elems


    # ---------------- utilities  ----------------
    def _align_seq_len(self, x, L, fill_value=0):
        if x is None:
            return None
        if not torch.is_tensor(x):
            return None
        if x.numel() == 0:
            return None
        if x.dim() != 2:
            return None
        B, Lx = x.shape
        if Lx == L:
            return x
        if Lx > L:
            return x[:, :L]
        pad = x.new_full((B, L - Lx), fill_value)
        return torch.cat([x, pad], dim=1)

    def _get_spacing(self, c, bins):
        B, L = c.shape
        steps = torch.arange(L, device=c.device).unsqueeze(0).expand(B, L)
        return steps.clamp(0, bins)

    def _bucketize(self, x, bins):
        if x is None:
            return None
        x = x.clamp(min=0)
        return x.clamp(max=bins).long()

    def _log_bucketize(self, x, bins, clip=1_000_000):
        if x is None:
            return None
        x = x.clamp(min=0, max=clip).float()
        lx = torch.log1p(x)
        lx = lx / torch.log1p(torch.tensor(float(clip), device=lx.device))
        return (lx * bins).long().clamp(0, bins)

    def _monotonic_attend(self, q_emb, h, valid_mask, gapb=None):
        """
        Multi-head monotonic attention.
        q_emb: [B,L,D] (Query for next step)
        h:     [B,L,D] (Student state history)
        valid_mask: [B,L] (Mask for valid history steps)
        gapb: [B,L] (optional, bucketized time gap for decay)
        Return: ctx [B,L,D]
        """
        B, L, D = h.shape
        device = h.device
        H = self.n_heads
        Dh = self.head_dim

        if (self._dist_cache is None) or (self._dist_cache_L != L) or (self._dist_cache.device != device):
            idx = torch.arange(L, device=device)
            dist = idx.unsqueeze(1) - idx.unsqueeze(0)  # [L,L]
            dist = dist.clamp(min=0).float()
            self._dist_cache = dist
            self._dist_cache_L = L
        dist = self._dist_cache  # [L,L]

        Q = self.attn_q(q_emb).view(B, L, H, Dh).transpose(1, 2)  # [B,H,L,Dh]
        K = self.attn_k(h).view(B, L, H, Dh).transpose(1, 2)      # [B,H,L,Dh]
        V = self.attn_v(h).view(B, L, H, Dh).transpose(1, 2)      # [B,H,L,Dh]

        scale = (Dh ** 0.5)
        scores = torch.matmul(Q, K.transpose(-2, -1)) / scale

        causal = torch.tril(torch.ones(L, L, device=device, dtype=torch.bool))
        scores = scores.masked_fill(~causal.unsqueeze(0).unsqueeze(0), float("-inf"))

        g_step = F.softplus(self.gamma)
        scores = scores - g_step * dist.unsqueeze(0).unsqueeze(0)

        if gapb is not None:
            g_t = F.softplus(self.gamma_t)
            gap_scale = gapb.float() / max(float(self.gap_bins), 1.0)
            scores = scores - (g_t * gap_scale).unsqueeze(1).unsqueeze(-1) * dist.unsqueeze(0).unsqueeze(0)

        scores = scores.masked_fill(~valid_mask.unsqueeze(1).unsqueeze(1).bool(), float("-inf"))

        all_inf = torch.isinf(scores).all(dim=-1)
        scores_safe = scores.clone()
        if all_inf.any():
            scores_safe[all_inf] = 0.0

        attn = torch.softmax(scores_safe, dim=-1)
        attn = self.attn_drop(attn)

        ctx = torch.matmul(attn, V)
        if all_inf.any():
            ctx = ctx.masked_fill(all_inf.unsqueeze(-1), 0.0)

        ctx = ctx.transpose(1, 2).contiguous().view(B, L, D)
        ctx = self.attn_out(ctx)
        ctx = torch.nan_to_num(ctx, nan=0.0, posinf=0.0, neginf=0.0)
        return ctx

    # ---------------- Token Builders ----------------
    def _build_history_token_ids(self, c, q, r):
        """
        Build history token ids as (C, Q, R) per timestep:
          ids shape: [B, 3L]
        For padding positions (c==0), set all tokens to pad_id and mask 0.
        """
        B, L = c.shape
        device = c.device

        c = c.long()
        r = r.clamp(0, 1).long()

        valid = (c > 0) 
        c_safe = c.clamp(min=1, max=self.num_c - 1) 
        c_tok = self.concept_token_ids[c_safe]         
        r_tok = self.response_token_ids[r]            

        if self.use_q_tokens and self.num_q > 0 and q is not None:
            q = q.long()
            q_safe = q.clamp(min=1, max=self.num_q - 1)  
            q_tok = self.question_token_ids[q_safe]      
        else:
            q_tok = c_tok
        pad = torch.full_like(c_tok, self.pad_id)

        c_tok = torch.where(valid, c_tok, pad)
        q_tok = torch.where(valid, q_tok, pad)
        r_tok = torch.where(valid, r_tok, pad)

        # interleave: [C0,Q0,R0,C1,Q1,R1,...]
        ids = torch.stack([c_tok, q_tok, r_tok], dim=-1).view(B, 3 * L)  # [B,3L]
        attn = torch.stack([valid, valid, valid], dim=-1).view(B, 3 * L).long()  # [B,3L]
        return ids, attn, valid
    

    def _get_base_and_delta_q(self, cshft, qshft):
        """
        Return:
          base_c:  [B,L,D]
          delta_q: [B,L,D] or zeros if q residual disabled
        """
        cshft = cshft.long()
        c_safe = cshft.clamp(min=1, max=self.num_c - 1)

        # concept base embedding
        c_ids = self.concept_token_ids[c_safe]   # [B,L]
        base_c = self.wte(c_ids)                 # [B,L,D]

        # no q residual
        if (not self.use_q_tokens) or (self.num_q <= 0) or (qshft is None):
            delta_q = torch.zeros_like(base_c)
            return base_c, delta_q

        # no residual trick
        if (self.q_delta is None) or (not getattr(self, "use_q_residual", False)):
            qshft = qshft.long().clamp(min=0, max=self.num_q - 1)
            q_ids = self.question_token_ids[qshft]
            q_emb = self.wte(q_ids)
            delta_q = q_emb - base_c
            return base_c, delta_q

        # residual mode
        q_idx = qshft.long().clamp(min=0, max=self.num_q)   # [B,L]
        delta_q = self.q_delta_proj(self.q_delta(q_idx))    # [B,L,D]
        return base_c, delta_q

    def _get_next_query_emb(self, cshft, qshft, h_step=None):
        """
        Next-step query embedding:
          default: concept prior + gated question residual
        Return: [B,L,D]
        """
        base_c, delta_q = self._get_base_and_delta_q(cshft, qshft)

        # if no q branch, just return concept embedding
        if (self.q_gate is None) or (h_step is None):
            return base_c + delta_q

        # scalar gate: [B,L,1]
        gate_in = torch.cat([h_step, base_c], dim=-1)
        gate = self.q_gate(gate_in)

        return base_c + gate * delta_q



    # ---------------- V4: MiniLM init (integration hook) ----------------
    @torch.no_grad()
    def init_new_tokens_with_minilm(
        self,
        concept_texts=None,
        question_texts=None,
        minilm_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        device: str = "cpu",
        local_files_only: bool = True,
        proj_hidden: int = None,
        normalize: bool = True,
        alpha: float = 0.5,
        alpha_q: float = None,
        proj_mode: str = "learnable",   # "learnable" | "fixed_seed"
        fixed_seed: int = 42,
    ):
        """
        Correct V4:
          - MiniLM encode -> d_m
          - project -> d_g (GPT2 dim) using a STABLE projection
          - mix into token embeddings with alpha:
              w_new = (1-alpha)*w_old + alpha*w_v4

        Requirements:
          concept_texts: list[str] length == self.num_c
          question_texts: optional list[str] length == self.num_q
        """

        try:
            from transformers import AutoTokenizer as _AT, AutoModel as _AM
        except Exception as e:
            raise RuntimeError("Transformers not available for MiniLM init.") from e

        if concept_texts is None:
            raise ValueError("concept_texts must be provided for V4 init.")
        if len(concept_texts) != self.num_c:
            raise ValueError(f"concept_texts length must be num_c={self.num_c}, got {len(concept_texts)}")

        if self.num_q > 0 and question_texts is not None and (len(question_texts) != self.num_q):
            raise ValueError(f"question_texts length must be num_q={self.num_q}, got {len(question_texts)}")

        # ---- load MiniLM offline ----
        tok = _AT.from_pretrained(minilm_name, local_files_only=local_files_only)
        enc = _AM.from_pretrained(minilm_name, local_files_only=local_files_only).to(device)
        enc.eval()

        def encode_texts(texts, batch_size=64):
            out = []
            for i in range(0, len(texts), batch_size):
                bt = texts[i:i + batch_size]
                inp = tok(bt, padding=True, truncation=True, return_tensors="pt").to(device)
                hid = enc(**inp).last_hidden_state  # [B,T,d_m]
                mask = inp["attention_mask"].unsqueeze(-1).float()
                pooled = (hid * mask).sum(dim=1) / (mask.sum(dim=1).clamp_min(1.0))  # mean-pool
                if normalize:
                    pooled = F.normalize(pooled, dim=-1)
                out.append(pooled.detach())
            return torch.cat(out, dim=0)  # [N, d_m] on device

        c_vec = encode_texts(concept_texts)  # [num_c, d_m] on device
        q_vec = encode_texts(question_texts) if (self.num_q > 0 and question_texts is not None) else None

        d_m = c_vec.size(-1)
        d_g = self.llm_dim
        a = float(alpha)
        aq = a if (alpha_q is None) else float(alpha_q)

        # ------------------------------------------------------------------
        # Build a STABLE projection:
        #   Option 1) learnable: create self.v4_proj once, reuse forever
        #   Option 2) fixed_seed: deterministic random proj (same seed -> same mapping)
        # ------------------------------------------------------------------
        if proj_mode == "learnable":
            if (not hasattr(self, "v4_proj")) or (self.v4_proj is None):
                if proj_hidden is None:
                    self.v4_proj = nn.Linear(d_m, d_g, bias=False).to(device)
                else:
                    self.v4_proj = nn.Sequential(
                        nn.Linear(d_m, proj_hidden),
                        nn.GELU(),
                        nn.Linear(proj_hidden, d_g, bias=False),
                    ).to(device)
    
                torch.manual_seed(fixed_seed)
                for p in self.v4_proj.parameters():
                    if p.dim() > 1:
                        nn.init.xavier_uniform_(p)

            proj = self.v4_proj
            proj.eval()

        elif proj_mode == "fixed_seed":
            g = torch.Generator(device=device)
            g.manual_seed(fixed_seed)
            W = torch.empty(d_m, d_g, device=device)
            nn.init.xavier_uniform_(W, gain=1.0)
            def proj(x):
                return x @ W
        else:
            raise ValueError(f"Unknown proj_mode={proj_mode}, choose from ['learnable','fixed_seed']")
        
        c_emb = proj(c_vec) if callable(proj) else proj(c_vec)
        if normalize:
            c_emb = F.normalize(c_emb, dim=-1)

        if q_vec is not None:
            q_emb = proj(q_vec) if callable(proj) else proj(q_vec)
            if normalize:
                q_emb = F.normalize(q_emb, dim=-1)

        # ------------------------------------------------------------------
        # Apply alpha MIXING into GPT2 token embeddings (IN-PLACE, no CPU copy)
        # ------------------------------------------------------------------
        wte = self.wte.weight.data
        c_emb = c_emb.to(wte.device)

        self.register_buffer("concept_sem_emb", c_emb.detach().to(self.wte.weight.device), persistent=False)

        c_ids = self.concept_token_ids.to(wte.device)
        w_old = wte.index_select(0, c_ids)
        wte.index_copy_(0, c_ids, (1.0 - a) * w_old + a * c_emb)

        if (
            q_vec is not None
            and hasattr(self, "question_token_ids")
            and self.question_token_ids is not None
            and self.question_token_ids.numel() > 0
        ):
            q_emb = q_emb.to(wte.device)
            q_ids = self.question_token_ids.to(wte.device)

            if q_emb.size(0) != q_ids.size(0):
                print(f"⚠️ [V4] Skip question init: q_emb={q_emb.size(0)} vs q_ids={q_ids.size(0)}")
            else:
                wq_old = wte.index_select(0, q_ids)
                wte.index_copy_(0, q_ids, (1.0 - aq) * wq_old + aq * q_emb)


        self._v4_inited = True
        print(f"✅ [LLMKT-C1] V4 MiniLM init applied: alpha_c={a}, alpha_q={aq}, proj_mode={proj_mode}.")
        with torch.no_grad():
            cid = self.concept_token_ids[1].item()
            v = self.wte.weight[cid]
            print("✅ [V4 CHECK] <C1> emb norm:", float(v.norm().cpu()))


    # ---------------- forward ----------------
    def forward(
        self,
        c, r,
        tcur=None, tshft=None,
        cshft=None,
        q=None, qshft=None,
        ut=None, utshft=None,
        **kwargs
    ):
        """
        Return:
          logit [B,L] aligned with rshft & smasks
        """
        # ### MODIFIED: 确保 rshft 从 kwargs 中提取并传递 ###
        _rshft_from_kwargs = kwargs.get('rshft', None)

        if self.training and self.use_amp:
            with autocast():
                return self._forward_impl(c, r, tcur, tshft, cshft, q, qshft, ut, utshft, rshft=_rshft_from_kwargs)
        else:
            return self._forward_impl(c, r, tcur, tshft, cshft, q, qshft, ut, utshft, rshft=_rshft_from_kwargs)
        # ### END MODIFIED ###

    def _forward_impl(
        self,
        c, r,
        tcur=None, tshft=None,
        cshft=None,
        q=None, qshft=None,
        ut=None, utshft=None,
        rshft=None, ### MODIFIED: rshft 作为参数传入 ###
    ):
        device = c.device
        c = c.long()
        r = r.clamp(0, 1).long()
        B, L = c.shape
        if not getattr(self, "use_ut", True):
            ut = None
            utshft = None
        if not getattr(self, "use_gap", True):
            tcur = None
            tshft = None
        if not hasattr(self, "_pos_checked"):
            self._pos_checked = True
            max_pos = int(getattr(self.llm.config, "n_positions", 1024))
            total = int(self.prefix_len + 3 * L)
            print(f"[LLMKT POS] prefix={self.prefix_len}, L={L}, total_tokens={total}, max_pos={max_pos}")
            if total > max_pos:
                raise RuntimeError(
                    f"LLMKT sequence too long: prefix_len + 3*L = {total} > n_positions={max_pos}. "
                    f"Reduce seq_len or change tokenization (e.g., 2 tokens/step)."
                )
        # ### ADDED: Align sequence lengths for time features ###
        tcur  = self._align_seq_len(tcur,  L, fill_value=0)
        tshft = self._align_seq_len(tshft, L, fill_value=0)
        ut    = self._align_seq_len(ut,    L, fill_value=0)
        utshft= self._align_seq_len(utshft,L, fill_value=0)
        # ### END ADDED ###

        # reset aux_loss
        self.aux_loss = torch.tensor(0.0, device=device)

        valid_step = (c > 0)  # [B, L]
        
        # 1. 获取 C Embedding (其实 Q 里面如果开了 residual 就包含了 C，但稳妥起见我们取出来)
        c_safe = c.long().clamp(min=1, max=self.num_c - 1)
        c_ids = self.concept_token_ids[c_safe]
        c_emb = self.wte(c_ids)  # [B, L, D]

        # 2. 获取 Q Embedding
        if self.use_q_tokens and self.num_q > 0 and q is not None:
            q_safe = q.long().clamp(min=1, max=self.num_q - 1)
            q_ids = self.question_token_ids[q_safe]
            base_q_emb = self.wte(q_ids)
            
            if self.q_delta is not None:
                q_idx = q.long().clamp(min=0, max=self.num_q)
                delta = self.q_delta_proj(self.q_delta(q_idx))
                q_emb = base_q_emb + delta
                
                if self.training and (self.q_delta_weight > 0):
                    m = valid_step & (q_idx > 0)
                    if m.any():
                        reg = (delta[m].pow(2).sum(dim=-1)).mean()
                        self.aux_loss = self.aux_loss + self.q_delta_weight * reg
            else:
                q_emb = base_q_emb
        else:
            q_emb = c_emb

                # ==================== 【终极修复 2】：残差注入 R 信号 ====================
        # 3. 获取 R Embedding 
        r_safe = r.clamp(0, 1).long() + 1 
        r_safe = torch.where(valid_step, r_safe, torch.zeros_like(r_safe))
        r_emb = self.r_emb(r_safe)  # [B, L, D]

        # 4. 拼接后投影，并通过残差加回 Q
        # 这样既保证了基础空间是 q_emb (保护语义)，又让 R 强势介入
        interaction_cat = torch.cat([q_emb, r_emb], dim=-1)  # [B, L, 2D]
        _tok_emb_fused = q_emb + self.fusion_proj(interaction_cat) # [B, L, D]

        # 5. 注入时间与位置特征 (使用相同残差思想)
        if self.use_spacing and (tcur is not None):
            t_in = self._get_spacing(c, bins=self.spacing_emb.num_embeddings - 1)
            t_in = t_in.long().clamp(0, self.spacing_emb.num_embeddings - 1)
            _tok_emb_fused = _tok_emb_fused + self.spacing_emb(t_in)

        if self.use_ut and (ut is not None):
            utb = self._bucketize(ut.long(), self.ut_bins)
            _tok_emb_fused = _tok_emb_fused + self.ut_emb(utb)

        # 6. 过 Adapter 并加入残差连接
        tok_emb = _tok_emb_fused + self.adapter(_tok_emb_fused)
        tok_emb = torch.where(valid_step.unsqueeze(-1), tok_emb, torch.zeros_like(tok_emb))
        # =========================================================================

        # ----------- 2) Soft prefix + LLM forward -----------
        prefix = self.prefix_emb.unsqueeze(0).expand(B, -1, -1)  # [B, p, D]
        inputs_embeds = torch.cat([prefix, tok_emb], dim=1)      # [B, p+L, D]

        # 构建 Attention Mask (Prefix全为1，后续依据valid_step)
        prefix_mask = torch.ones(B, self.prefix_len, device=device, dtype=torch.long)
        hist_attn = valid_step.long()
        attn_mask = torch.cat([prefix_mask, hist_attn], dim=1)

        # 前向传播 LLM
        outputs = self.llm(inputs_embeds=inputs_embeds, attention_mask=attn_mask)
        # 取出 L 步对应的隐状态 (抛弃 Prefix 部分)
        h_step = outputs.last_hidden_state[:, self.prefix_len:, :]  # [B, L, D]
        h_step = self.dropout(h_step)
        
        # ----------- 3) Optional contrastive smoothing (kept but default cl_weight=0) -----------
        if self.training and self.cl_weight > 0:
            h_norm = F.normalize(h_step, dim=-1)
            # ### MODIFIED: 加上 / self.cl_temp ###
            cos_sim = (h_norm[:, :-1, :] * h_norm[:, 1:, :]).sum(dim=-1) / self.cl_temp

            same_c = (c[:, :-1] == c[:, 1:]) & (c[:, :-1] > 0)
            flip = (r[:, :-1] != r[:, 1:])
            # ### ADDED: no_flip for pos_mask ###
            no_flip = ~flip
            pos_mask = same_c & no_flip
            # ### END ADDED ###
            neg_mask = same_c & flip

            loss_parts = []
            if pos_mask.any():
                loss_parts.append((1.0 - cos_sim)[pos_mask].mean())
            if neg_mask.any():
                margin = 0.2
                loss_parts.append(F.relu(cos_sim[neg_mask] - margin).mean())
            if len(loss_parts) > 0:
                self.aux_loss = self.aux_loss + self.cl_weight * sum(loss_parts) / len(loss_parts)

        # ----------- 4) Next-step query embedding -----------
        if cshft is None:
            cshft = c
        cshft = cshft.long().clamp(min=0)

        _q_next_emb_base = self._get_next_query_emb(cshft, qshft, h_step=h_step)

        
        # ### MODIFIED: 将时间特征 Embedding 融合到 `q_next_emb` ###
        q_next_emb = _q_next_emb_base # Initialize q_next_emb
        # 1) ut embedding
        if self.use_ut and (utshft is not None):
            utshftb = self._bucketize(utshft.long(), self.ut_bins)
            q_next_emb = q_next_emb + self.ut_emb(utshftb)

        # 2) gap embedding
        _decay_mlp_output = None
        _gapb_for_attention = None
        if self.use_gap and (tcur is not None) and (tshft is not None):
            gap = (tshft.long() - tcur.long()).clamp(min=0)
            gapb = self._log_bucketize(gap, self.gap_bins, clip=self.time_gap_clip)
            gap_vec = self.gap_emb(gapb)
            q_next_emb = q_next_emb + gap_vec

            _decay_mlp_output = self.decay_mlp(gap_vec).clamp(0.0, 1.0)
            _gapb_for_attention = gapb

        # ✅ 无论是否 use_gap，都统一过 adapter
        q_next_emb = self.adapter(q_next_emb)
        q_next_emb = self.dropout(q_next_emb)
     
        # ----------- 5) Explicit Concept Memory rollout (only next-concept residual) -----------
        if self.use_concept_memory:
            state = self.concept_memory.init_state(B, device=device)  # [B, K, D]

            current_memory_states = []
            next_memory_states = []

            for t_idx in range(L):
                c_t = c[:, t_idx]                 # [B]
                r_t = r[:, t_idx]                 # [B]
                h_t = h_step[:, t_idx, :]         # [B, D]

                # read current concept state BEFORE update
                m_cur_t = self.concept_memory.read(state, c_t)   # [B, D]
                current_memory_states.append(m_cur_t)

                # dynamic update using current interaction
                if self.use_dynamic_memory_update:
                    state, _ = self.concept_memory.update(state, c_t, h_t, m_cur_t, r_t)

                # read next concept state AFTER current-step update
                c_next_t = cshft[:, t_idx] if cshft is not None else c_t
                m_next_t = self.concept_memory.read(state, c_next_t)   # [B, D]
                next_memory_states.append(m_next_t)

            current_memory_states = torch.stack(current_memory_states, dim=1)  # [B,L,D]
            next_memory_states = torch.stack(next_memory_states, dim=1)        # [B,L,D]
        else:
            current_memory_states = None
            next_memory_states = None

 
        if self.use_concept_memory and (not hasattr(self, "_cmem_debug_printed")):
            self._cmem_debug_printed = True
            with torch.no_grad():
                print("✅ [CMEM] next_memory_states:", next_memory_states.shape)
                print("✅ [CMEM] h_step norm:", float(h_step.norm(dim=-1).mean().detach().cpu()))
                print("✅ [CMEM] q_next_emb norm:", float(q_next_emb.norm(dim=-1).mean().detach().cpu()))
                if current_memory_states is not None:
                    print("✅ [CMEM] current_memory norm:",
                          float(current_memory_states.norm(dim=-1).mean().detach().cpu()))
                print("✅ [CMEM] next_memory norm:",
                      float(next_memory_states.norm(dim=-1).mean().detach().cpu()))

                # ----------- 5.5) Direct supervision on current concept memory (memory-only) -----------
                # ----------- 5.5) Direct supervision on current concept memory -----------
        if (
            self.use_concept_memory
            and self.use_memory_direct
            and (current_memory_states is not None)
            and (self.memory_aux_weight > 0)
        ):
            mem_cur_logit = self.memory_readout_head(
                torch.cat([h_step, current_memory_states], dim=-1)
            ).squeeze(-1)   # [B,L]

            mem_mask = (c > 0)
            if mem_mask.any():
                memory_aux_loss = F.binary_cross_entropy_with_logits(
                    mem_cur_logit[mem_mask],
                    r.float()[mem_mask]
                )
                self.aux_loss = self.aux_loss + self.memory_aux_weight * memory_aux_loss

                if not hasattr(self, "_memory_aux_debug_printed"):
                    self._memory_aux_debug_printed = True
                    with torch.no_grad():
                        print("✅ [MEM-AUX] use_memory_direct:", self.use_memory_direct)
                        print("✅ [MEM-AUX] memory_aux_weight:", self.memory_aux_weight)
                        print("✅ [MEM-AUX] current_memory norm:",
                              float(current_memory_states.norm(dim=-1).mean().detach().cpu()))
                        print("✅ [MEM-AUX] mem_cur_logit mean/std:",
                              float(mem_cur_logit.mean().detach().cpu()),
                              float(mem_cur_logit.std().detach().cpu()))
                        print("✅ [MEM-AUX] raw memory_aux_loss:",
                              float(memory_aux_loss.detach().cpu()))



 
        # ----------- 6) Build semantic main path -----------
        if not self.use_monotonic:
            h_final = h_step
        else:
            _hist_valid_mask = (c > 0)

            _ctx_from_monotonic_attn = self._monotonic_attend(
                q_emb=q_next_emb,
                h=h_step,
                valid_mask=_hist_valid_mask,
                gapb=_gapb_for_attention
            )

            if not self.use_forget_gate:
                h_final = F.layer_norm(h_step + _ctx_from_monotonic_attn, (self.llm_dim,))
            else:
                gate_in = torch.cat([_ctx_from_monotonic_attn, q_next_emb], dim=-1)
                _gate_factor = self.forget_gate(gate_in)
                if _decay_mlp_output is not None:
                    _gate_factor = _gate_factor * _decay_mlp_output
                h_final = _ctx_from_monotonic_attn * _gate_factor + q_next_emb * (1.0 - _gate_factor)


        # ----------- 6) Prediction head ----------

         # inject concept memory into the prediction backbone
        if self.use_concept_memory:
            gate_in = torch.cat([h_final, next_memory_states], dim=-1)     # [B,L,2D]

            # payload comes from memory only
            state_anchor = self.state_anchor_proj(next_memory_states)       # [B,L,D]
            state_anchor = self.state_anchor_gain * state_anchor

            if self.use_gated_anchor:
                anchor_gate = self.state_anchor_gate(gate_in)               # [B,L,D]
                anchor_delta = anchor_gate * state_anchor
            else:
                anchor_gate = None
                anchor_delta = state_anchor

            h_pred = F.layer_norm(
                h_final + self.state_anchor_beta * anchor_delta,
                (self.llm_dim,)
            )
        else:
            state_anchor = None
            anchor_gate = None
            anchor_delta = None
            h_pred = h_final


        if not self.use_irt_head:
            # ----- base semantic KT path with state-anchored backbone -----
            base_logit = self.simple_head(
                torch.cat([h_pred, q_next_emb], dim=-1)
            ).squeeze(-1)

            if self.use_concept_memory and self.use_memory_residual:
                mem_logit = self.next_memory_head(
                    torch.cat([q_next_emb, next_memory_states], dim=-1)
                ).squeeze(-1)
                logit = base_logit + self.mem_alpha * mem_logit
            else:
                mem_logit = None
                logit = base_logit



            if self.use_concept_memory and (not hasattr(self, "_cmem_logit_debug_printed")):
                self._cmem_logit_debug_printed = True
                with torch.no_grad():
                    print("✅ [CMEM MODE] use_dynamic_memory_update:", self.use_dynamic_memory_update)
                    print("✅ [CMEM MODE] state_anchor_beta:", self.state_anchor_beta)
                    print("✅ [CMEM MODE] state_anchor_gain:", self.state_anchor_gain)
                    print("✅ [CMEM MODE] use_gated_anchor:", self.use_gated_anchor)
                    print("✅ [CMEM MODE] use_memory_residual:", self.use_memory_residual)

                    print("✅ [CMEM STAT] h_final norm:",
                          float(h_final.norm(dim=-1).mean().detach().cpu()))
                    print("✅ [CMEM STAT] next_memory norm:",
                          float(next_memory_states.norm(dim=-1).mean().detach().cpu()))
                    print("✅ [CMEM STAT] state_anchor norm:",
                          float(state_anchor.norm(dim=-1).mean().detach().cpu()))
                    if anchor_delta is not None:
                        print("✅ [CMEM STAT] anchor_delta norm:",
                              float(anchor_delta.norm(dim=-1).mean().detach().cpu()))
                    if anchor_gate is not None:
                        print("✅ [CMEM STAT] anchor_gate mean:",
                              float(anchor_gate.mean().detach().cpu()))
                        print("✅ [CMEM STAT] anchor_gate std:",
                              float(anchor_gate.std().detach().cpu()))
                        print("✅ [CMEM STAT] anchor_gate min/max:",
                              float(anchor_gate.min().detach().cpu()),
                              float(anchor_gate.max().detach().cpu()))

                    delta_norm = (h_pred - h_final).norm(dim=-1).mean()
                    print("✅ [CMEM STAT] |h_pred - h_final| norm:",
                          float(delta_norm.detach().cpu()))

                    print("✅ [CMEM LOGIT] base_logit mean/std:",
                          float(base_logit.mean().detach().cpu()),
                          float(base_logit.std().detach().cpu()))
                    if mem_logit is not None:
                        print("✅ [CMEM LOGIT] mem_logit mean/std:",
                              float(mem_logit.mean().detach().cpu()),
                              float(mem_logit.std().detach().cpu()))
                    print("✅ [CMEM LOGIT] final_logit mean/std:",
                          float(logit.mean().detach().cpu()),
                          float(logit.std().detach().cpu()))


            # ===================== [NEW] q-consistency regularizer =====================
            if self.training and (self.qcons_weight > 0) and (qshft is not None):
               # concept-only next query embedding (no question id info)
                c_only_next_emb = self._get_next_query_emb(cshft, qshft=None, h_step=h_step)  # [B,L,D]
                c_only_next_emb = self.adapter(c_only_next_emb)
                c_only_next_emb = self.dropout(c_only_next_emb)
                logit_c = self.simple_head(torch.cat([h_pred, c_only_next_emb], dim=-1)).squeeze(-1)

                p_q = torch.sigmoid(logit)
                p_c = torch.sigmoid(logit_c)

                mask = (cshft > 0) & (qshft > 0)
                if mask.any():
                    qcons_loss = ((p_q[mask] - p_c[mask]) ** 2).mean()
                    self.aux_loss = self.aux_loss + self.qcons_weight * qcons_loss
            # ==========================================================================

            return logit

        # ----------- IRT-like head + residual -----------
        theta = self.theta_head(h_pred).squeeze(-1)


        if self.q_bias is not None and qshft is not None:
            _qshft_idx = qshft.long().clamp(0, self.num_q)
            b = self.q_bias(_qshft_idx).squeeze(-1)
        else:
            b = 0.0

        if self.q_disc is not None and qshft is not None:
            _qshft_idx = qshft.long().clamp(0, self.num_q)
            a = F.softplus(self.q_disc(_qshft_idx).squeeze(-1)) + 1e-3
        else:
            a = 1.0

        irt_score = a * (theta - b)
        res_contrib = self.res_head(torch.cat([h_pred, q_next_emb], dim=-1)).squeeze(-1)
        if self.use_irt_head:
            theta = self.theta_head(h_pred).squeeze(-1)
            # 获取下一题的 a, b (题目偏置)
            _qshft_idx = qshft.long().clamp(0, self.num_q)
            b = self.q_bias(_qshft_idx).squeeze(-1)
            a = F.softplus(self.q_disc(_qshft_idx).squeeze(-1)) + 1.0
            irt_score = a * (theta - b)
            
            logit = irt_score + res_contrib # 👈 语义 + 统计双路并行
        else:
            logit = res_contrib

        # ===================== [NEW] q-consistency regularizer (IRT branch) =====================
        if self.training and (self.qcons_weight > 0) and (qshft is not None):
            c_only_next_emb = self._get_next_query_emb(cshft, qshft=None, h_step=h_step)  # [B,L,D]
            c_only_next_emb = self.adapter(c_only_next_emb)
            c_only_next_emb = self.dropout(c_only_next_emb)

            # IRT 分支里，概念级预测时不要用题偏置/题区分度（否则又把 q 信息引回来了）
            # 所以 logit_c 用同一个 theta + “concept residual”
            res_contrib_c = self.res_head(torch.cat([h_pred, c_only_next_emb], dim=-1)).squeeze(-1)
            logit_c = theta + res_contrib_c

            p_q = torch.sigmoid(logit)
            p_c = torch.sigmoid(logit_c)

            mask = (cshft > 0) & (qshft > 0)
            if mask.any():
                qcons_loss = ((p_q[mask] - p_c[mask]) ** 2).mean()
                self.aux_loss = self.aux_loss + self.qcons_weight * qcons_loss
        # =======================================================================================

        return logit