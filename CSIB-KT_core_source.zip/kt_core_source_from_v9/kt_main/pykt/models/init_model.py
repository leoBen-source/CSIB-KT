import torch
import numpy as np
import os

from .sqakt import SQAKT
from .llmkt import LLMKT
from .dkt import DKT
from .dkt_plus import DKTPlus
from .dkvmn import DKVMN
from .deep_irt import DeepIRT
from .sakt import SAKT
from .saint import SAINT
from .kqn import KQN
from .atkt import ATKT
from .dkt_forget import DKTForget
from .akt import AKT
from .gkt import GKT
from .gkt_utils import get_gkt_graph
from .lpkt import LPKT
from .lpkt_utils import generate_qmatrix
from .skvmn import SKVMN
from .hawkes import HawkesKT
from .iekt import IEKT
from .atdkt import ATDKT
from .simplekt import simpleKT
from .datakt import BAKTTime
from .qdkt import QDKT
from .qikt import QIKT
from .dimkt import DIMKT
from .sparsekt import sparseKT
from .rkt import RKT
from .folibikt import folibiKT
from .dtransformer import DTransformer
from .stablekt import stableKT
from .extrakt import extraKT
from .rekt import ReKT
from .cskt import CSKT
from .lefokt_akt import LEFOKT_AKT
from .ukt import UKT
from .hcgkt import HCGKT
from .robustkt import Robustkt

device = "cpu" if not torch.cuda.is_available() else "cuda"

def init_model(model_name, model_config, data_config, emb_type):
    if model_name == "dkt":
        model = DKT(data_config["num_c"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "dkt+":
        model = DKTPlus(data_config["num_c"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "llmkt":
        num_c = data_config["num_c"]
        num_q = data_config.get("num_q", data_config.get("num_questions", None))
        if num_q is None:
            num_q = data_config.get("n_questions", 0)
        model = LLMKT(num_c=num_c, num_q=int(num_q), **model_config).to(device)
    elif model_name == "sqakt":
        model = SQAKT(num_c=data_config["num_c"], num_q=data_config["num_q"], **model_config, emb_type=emb_type).to(device)
    elif model_name == "dkvmn":
        model = DKVMN(data_config["num_c"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "deep_irt":
        model = DeepIRT(data_config["num_c"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "sakt":
        model = SAKT(data_config["num_c"],  **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "saint":
        model = SAINT(data_config["num_q"], data_config["num_c"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "dkt_forget":
        model = DKTForget(data_config["num_c"], data_config["num_rgap"], data_config["num_sgap"], data_config["num_pcount"], **model_config).to(device)
    elif model_name == "akt":
        model = AKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "lefokt_akt":
        model = LEFOKT_AKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "extrakt":
        model = extraKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "folibikt":
        model = folibiKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "kqn":
        model = KQN(data_config["num_c"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "atkt":
        model = ATKT(data_config["num_c"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"], fix=False).to(device)
    elif model_name == "atktfix":
        model = ATKT(data_config["num_c"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"], fix=True).to(device)
    elif model_name == "gkt":
        graph_type = model_config['graph_type']
        fname = f"gkt_graph_{graph_type}.npz"
        graph_path = os.path.join(data_config["dpath"], fname)
        if os.path.exists(graph_path):
            graph = torch.tensor(np.load(graph_path, allow_pickle=True)['matrix']).float()
        else:
            graph = get_gkt_graph(data_config["num_c"], data_config["dpath"], 
                    data_config["train_valid_original_file"], data_config["test_original_file"], graph_type=graph_type, tofile=fname)
            graph = torch.tensor(graph).float()
        model = GKT(data_config["num_c"], **model_config,graph=graph,emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "lpkt":
        qmatrix_path = os.path.join(data_config["dpath"], "qmatrix.npz")
        if os.path.exists(qmatrix_path):
            q_matrix = np.load(qmatrix_path, allow_pickle=True)['matrix']
        else:
            q_matrix = generate_qmatrix(data_config)
        q_matrix = torch.tensor(q_matrix).float().to(device)
        model = LPKT(data_config["num_at"], data_config["num_it"], data_config["num_q"], data_config["num_c"], **model_config, q_matrix=q_matrix, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "skvmn":
        model = SKVMN(data_config["num_c"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)   
    elif model_name == "hawkes":
        if data_config["num_q"] == 0 or data_config["num_c"] == 0:
            print(f"model: {model_name} needs questions ans concepts! but the dataset has no both")
            return None
        model = HawkesKT(data_config["num_c"], data_config["num_q"], **model_config)
        model = model.double()
        # print("===before init weights"+"@"*100)
        # model.printparams()
        model.apply(model.init_weights)
        # print("===after init weights")
        # model.printparams()
        model = model.to(device)
    elif model_name == "iekt":
        model = IEKT(num_q=data_config['num_q'], num_c=data_config['num_c'],
                max_concepts=data_config['max_concepts'], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"],device=device).to(device)   
    elif model_name == "qdkt":
        model = QDKT(num_q=data_config['num_q'], num_c=data_config['num_c'],
                max_concepts=data_config['max_concepts'], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"],device=device).to(device)
    elif model_name == "qikt":
        model = QIKT(num_q=data_config['num_q'], num_c=data_config['num_c'],
                max_concepts=data_config['max_concepts'], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"],device=device).to(device)
    elif model_name == "atdkt":
        model = ATDKT(data_config["num_q"], data_config["num_c"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "datakt":
        model = BAKTTime(data_config["num_c"], data_config["num_q"], data_config["num_rgap"], data_config["num_sgap"], data_config["num_pcount"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "simplekt":
        model = simpleKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "rekt":
        model = ReKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type).to(device)
    elif model_name == "stablekt":
        model = stableKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "dimkt":
        model = DIMKT(data_config["num_q"],data_config["num_c"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "sparsekt":
        model = sparseKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "rkt":
        model = RKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device) 
    elif model_name == "cskt":
        model = CSKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device) 
    elif model_name == "ukt":
        model = UKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "hcgkt":
        model = HCGKT(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "robustkt":
        model = Robustkt(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type, emb_path=data_config["emb_path"]).to(device)
    elif model_name == "dtransformer":
        model = DTransformer(data_config["num_c"], data_config["num_q"], **model_config, emb_type=emb_type,
                     emb_path=data_config["emb_path"]).to(device)      
    else:
        print("The wrong model name was used...")
        return None
    if not hasattr(model, "emb_type"):
        model.emb_type = emb_type
    return model
def adapt_sqakt_semantic_modules_from_state_dict(model, state_dict):
    """
    让重新 init 的 SQAKT 能加载 structured semantic checkpoint。

    训练时 structured prior 会把：
      q_sem_raw.weight: [7653, 3207]
      sem_proj.weight: [128, 3207]

    但重新 init_model() 默认可能是：
      q_sem_raw.weight: [7653, 384]
      sem_proj.weight: [128, 384]

    因此 strict load 前必须根据 checkpoint shape 重建模块。
    """
    import torch
    import torch.nn as nn

    if getattr(model, "model_name", "") != "sqakt":
        return model

    try:
        target_device = next(model.parameters()).device
    except StopIteration:
        target_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # q_sem_raw
    if "q_sem_raw.weight" in state_dict:
        w = state_dict["q_sem_raw.weight"]
        n_emb, raw_dim = int(w.shape[0]), int(w.shape[1])

        cur = getattr(model, "q_sem_raw", None)
        cur_shape = tuple(cur.weight.shape) if cur is not None else None

        if cur_shape != tuple(w.shape):
            model.q_sem_raw = nn.Embedding(
                num_embeddings=n_emb,
                embedding_dim=raw_dim,
                padding_idx=0,
            ).to(target_device)

            # frozen semantic bank
            model.q_sem_raw.weight.requires_grad = False

            print(
                f"✅ [LOAD-ADAPT] rebuilt q_sem_raw: "
                f"{cur_shape} -> {tuple(w.shape)}, device={target_device}"
            )

    # q_sem_delta，如果 checkpoint 里有才处理
    if "q_sem_delta.weight" in state_dict:
        w = state_dict["q_sem_delta.weight"]
        n_emb, raw_dim = int(w.shape[0]), int(w.shape[1])

        cur = getattr(model, "q_sem_delta", None)
        cur_shape = tuple(cur.weight.shape) if cur is not None else None

        if cur_shape != tuple(w.shape):
            model.q_sem_delta = nn.Embedding(
                num_embeddings=n_emb,
                embedding_dim=raw_dim,
                padding_idx=0,
            ).to(target_device)

            print(
                f"✅ [LOAD-ADAPT] rebuilt q_sem_delta: "
                f"{cur_shape} -> {tuple(w.shape)}, device={target_device}"
            )

    # sem_proj
    if "sem_proj.weight" in state_dict:
        w = state_dict["sem_proj.weight"]
        out_dim, in_dim = int(w.shape[0]), int(w.shape[1])
        has_bias = "sem_proj.bias" in state_dict

        cur = getattr(model, "sem_proj", None)
        cur_shape = tuple(cur.weight.shape) if cur is not None else None

        if cur_shape != tuple(w.shape):
            model.sem_proj = nn.Linear(
                in_features=in_dim,
                out_features=out_dim,
                bias=has_bias,
            ).to(target_device)

            print(
                f"✅ [LOAD-ADAPT] rebuilt sem_proj: "
                f"{cur_shape} -> {tuple(w.shape)}, bias={has_bias}, device={target_device}"
            )

    # Phase-3 B3 refinement bank. During training this module is created lazily
    # after the structured tensor is loaded, so a fresh evaluation model must
    # rebuild it from checkpoint shapes before strict state_dict loading.
    if "q_ref_sem_raw.weight" in state_dict:
        w = state_dict["q_ref_sem_raw.weight"]
        n_emb, raw_dim = int(w.shape[0]), int(w.shape[1])
        cur = getattr(model, "q_ref_sem_raw", None)
        cur_shape = tuple(cur.weight.shape) if cur is not None else None

        if cur_shape != tuple(w.shape):
            model.q_ref_sem_raw = nn.Embedding(
                num_embeddings=n_emb,
                embedding_dim=raw_dim,
                padding_idx=0,
            ).to(target_device)
            model.q_ref_sem_raw.weight.requires_grad = False
            print(
                f"✅ [LOAD-ADAPT] rebuilt q_ref_sem_raw: "
                f"{cur_shape} -> {tuple(w.shape)}, device={target_device}"
            )

    # Shared-zero-adapter projection used by target_state_gate.
    if "q_ref_adapter_weight" in state_dict:
        w = state_dict["q_ref_adapter_weight"]
        cur = getattr(model, "q_ref_adapter_weight", None)
        cur_shape = tuple(cur.shape) if cur is not None else None

        if cur_shape != tuple(w.shape):
            model.q_ref_adapter_weight = nn.Parameter(
                torch.zeros(tuple(w.shape), dtype=w.dtype, device=target_device)
            )
            model.q_ref_sem_proj = None
            print(
                f"✅ [LOAD-ADAPT] rebuilt q_ref_adapter_weight: "
                f"{cur_shape} -> {tuple(w.shape)}, device={target_device}"
            )

    # Backward-compatible independent B3 projection.
    if "q_ref_sem_proj.weight" in state_dict:
        w = state_dict["q_ref_sem_proj.weight"]
        out_dim, in_dim = int(w.shape[0]), int(w.shape[1])
        has_bias = "q_ref_sem_proj.bias" in state_dict
        cur = getattr(model, "q_ref_sem_proj", None)
        cur_shape = tuple(cur.weight.shape) if cur is not None else None

        if cur_shape != tuple(w.shape):
            model.q_ref_sem_proj = nn.Linear(
                in_features=in_dim,
                out_features=out_dim,
                bias=has_bias,
            ).to(target_device)
            model.q_ref_adapter_weight = None
            print(
                f"✅ [LOAD-ADAPT] rebuilt q_ref_sem_proj: "
                f"{cur_shape} -> {tuple(w.shape)}, bias={has_bias}, device={target_device}"
            )

    return model

def load_model(model_name, model_config, data_config, emb_type, ckpt_path):
    model = init_model(model_name, model_config, data_config, emb_type)
    net = torch.load(os.path.join(ckpt_path, emb_type+"_model.ckpt"), map_location=device)
    if getattr(model, "model_name", "") == "sqakt":
        model = adapt_sqakt_semantic_modules_from_state_dict(model, net)
        current_state = model.state_dict()

        for k in ["q_support_counts", "q_support_max_log"]:
            if k in current_state and k not in net:
                print(f"[LOAD_MODEL][SQAKT] missing old checkpoint key: {k}; using current default buffer.")
                net[k] = current_state[k].clone()
    model.load_state_dict(net, strict=True)
    model = model.to(device)
    if model_name == "sqakt":
        print(
            "[LOAD_MODEL][SQAKT][DEVICE] "
            f"model={next(model.parameters()).device}, "
            f"q_sem_raw={model.q_sem_raw.weight.device}, "
            f"sem_proj={model.sem_proj.weight.device}"
        )
    return model
