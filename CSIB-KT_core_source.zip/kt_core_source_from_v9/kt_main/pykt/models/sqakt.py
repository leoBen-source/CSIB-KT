import math
import torch
import torch.nn as nn
import os
import json
import torch.nn.functional as F
from semantic_patch import encode_texts_to_tensor, apply_semantic_control

class DistanceForgettingAttention(nn.Module):
    """
    Question-centric retrieval with interaction-distance forgetting.
    Query at step t attends to history <= t.
    """
    def __init__(self, d_model: int, n_heads: int = 4, dropout: float = 0.1, gamma_init: float = -2.25):
        super().__init__()
        assert d_model % n_heads == 0
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads

        self.w_q = nn.Linear(d_model, d_model, bias=False)
        self.w_k = nn.Linear(d_model, d_model, bias=False)
        self.w_v = nn.Linear(d_model, d_model, bias=False)
        self.w_o = nn.Linear(d_model, d_model, bias=False)

        self.dropout = nn.Dropout(dropout)
        self.gamma = nn.Parameter(torch.tensor(float(gamma_init)))

        self._dist_cache = None
        self._dist_cache_L = None

    def _get_distance_matrix(self, L: int, device):
        if (
            self._dist_cache is None
            or self._dist_cache_L != L
            or self._dist_cache.device != device
        ):
            idx = torch.arange(L, device=device)
            dist = (idx.unsqueeze(1) - idx.unsqueeze(0)).clamp(min=0).float()
            self._dist_cache = dist
            self._dist_cache_L = L
        return self._dist_cache

    def forward(self, query, hist, hist_mask):
        B, L, D = hist.shape
        H = self.n_heads
        Dh = self.head_dim
        device = hist.device

        Q = self.w_q(query).view(B, L, H, Dh).transpose(1, 2)
        K = self.w_k(hist).view(B, L, H, Dh).transpose(1, 2)
        V = self.w_v(hist).view(B, L, H, Dh).transpose(1, 2)

        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(Dh)  # [B,H,L,L]

        causal = torch.tril(torch.ones(L, L, device=device, dtype=torch.bool))
        scores = scores.masked_fill(~causal.unsqueeze(0).unsqueeze(0), float("-inf"))

        dist = self._get_distance_matrix(L, device)
        gamma = F.softplus(self.gamma)
        scores = scores - gamma * dist.unsqueeze(0).unsqueeze(0)

        valid_hist = hist_mask.bool().unsqueeze(1).unsqueeze(1)
        scores = scores.masked_fill(~valid_hist, float("-inf"))

        # 防止某些行全是 -inf
        all_inf = torch.isinf(scores).all(dim=-1, keepdim=True)
        scores = scores.masked_fill(all_inf, 0.0)

        attn = torch.softmax(scores, dim=-1)
        attn = attn.masked_fill(all_inf, 0.0)
        attn = attn.masked_fill(~valid_hist, 0.0)
        attn = self.dropout(attn)

        ctx = torch.matmul(attn, V)
        ctx = ctx.transpose(1, 2).contiguous().view(B, L, D)
        ctx = self.w_o(ctx)
        ctx = torch.nan_to_num(ctx, nan=0.0, posinf=0.0, neginf=0.0)
        return ctx

class CausalTransformerEncoder(nn.Module):
    """
    NaN-safe causal transformer encoder.
    """
    def __init__(self, d_model, n_heads=4, n_layers=1, dropout=0.1, ffn_mult=4):
        super().__init__()
        self.layers = nn.ModuleList([
            nn.TransformerEncoderLayer(
                d_model=d_model,
                nhead=n_heads,
                dim_feedforward=d_model * ffn_mult,
                dropout=dropout,
                batch_first=True,
                activation="gelu",
                norm_first=False   # 比 norm_first=True 更稳
            )
            for _ in range(n_layers)
        ])
        self.final_norm = nn.LayerNorm(d_model)

    def forward(self, x, valid_mask):
        B, L, D = x.shape
        device = x.device

        causal_mask = torch.triu(
            torch.ones(L, L, device=device, dtype=torch.bool),
            diagonal=1
        )
        pad_mask = ~valid_mask.bool()

        out = x.masked_fill(pad_mask.unsqueeze(-1), 0.0)

        for layer in self.layers:
            out = layer(
                out,
                src_mask=causal_mask,
                src_key_padding_mask=pad_mask
            )
            out = out.masked_fill(pad_mask.unsqueeze(-1), 0.0)
            out = torch.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)

        out = self.final_norm(out)
        out = out.masked_fill(pad_mask.unsqueeze(-1), 0.0)
        out = torch.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)
        return out
class SQAKT(nn.Module):
    """
    Minimal controlled version:
      - keep original stable fusion
      - fixed sem_proj
      - optional q_irt
      - optional trans backbone
    """
    def __init__(
        self,
        num_c: int,
        num_q: int,
        d_model: int = 256,
        n_heads: int = 4,
        dropout: float = 0.2,
        gamma_init: float = -2.25,
        gru_layers: int = 1,
        sem_input_dim: int = 384,
        backbone_type: str = "gru",
        n_layers: int = 1,
        ffn_mult: int = 4,
        emb_type: str = "qid",
        use_c_sem: int = 1,
        use_q_sem: int = 1,
        **kwargs
    ):
        super().__init__()
        self.model_name = "sqakt"
        self.emb_type = emb_type

        self.num_c = int(num_c)
        self.num_q = int(num_q)
        self.d_model = int(d_model)
        self.sem_input_dim = int(sem_input_dim)
        self.backbone_type = str(backbone_type)
        self.use_c_sem = int(use_c_sem) == 1
        self.use_q_sem = int(use_q_sem) == 1
        # Canonical XES3G5M item-level setting: one interaction is one question,
        # while its concept channel is the complete unordered KC set.
        # Keep this opt-in so historical scalar-KC checkpoints remain loadable.
        self.kc_set_input = int(kwargs.get("kc_set_input", 0)) == 1
        self.kc_pooling = str(kwargs.get("kc_pooling", "mean")).lower()
        if self.kc_pooling not in {"mean"}:
            raise ValueError(f"Unsupported kc_pooling={self.kc_pooling}; canonical P0/P1 uses mean")


        # ID embeddings.  Under semantic_base_residual, q_id_embed is not an
        # independent item representation; it is a trainable item-specific
        # residual around the shared semantic anchor and is initialized to 0.
        self.c_id_embed = nn.Embedding(self.num_c + 1, d_model, padding_idx=0)
        self.q_id_embed = nn.Embedding(self.num_q + 1, d_model, padding_idx=0) if self.num_q > 0 else None
        self.r_embed = nn.Embedding(2, d_model)

        self.q_item_parameterization = str(
            kwargs.get("q_item_parameterization", "legacy_independent")
        ).lower()
        self.q_sem_anchor_scale = float(kwargs.get("q_sem_anchor_scale", 1.0))
        self.q_id_gate_type = str(kwargs.get("q_id_gate_type", "sqrt_reliability")).lower()
        self.q_id_tau = float(kwargs.get("q_id_tau", 20.0))
        self.q_id_residual_zero_init = int(kwargs.get("q_id_residual_zero_init", 1)) == 1
        self.q_id_residual_dropout = float(kwargs.get("q_id_residual_dropout", 0.0))
        self.q_item_norm = nn.LayerNorm(d_model)

        if self.q_item_parameterization == "semantic_base_residual":
            if not self.use_q_sem:
                raise ValueError(
                    "semantic_base_residual requires use_q_sem=1 and a B1 semantic bank"
                )
            if self.q_id_embed is not None and self.q_id_residual_zero_init:
                nn.init.zeros_(self.q_id_embed.weight)
        elif self.q_item_parameterization not in {
            "legacy_independent", "id_only_cold_mask"
        }:
            raise ValueError(
                f"Unknown q_item_parameterization={self.q_item_parameterization}"
            )

        # frozen semantic banks in encoder space
        self.c_sem_raw = nn.Embedding(self.num_c + 1, self.sem_input_dim, padding_idx=0)
        self.q_sem_raw = nn.Embedding(self.num_q + 1, self.sem_input_dim, padding_idx=0) if self.num_q > 0 else None

        # B3 dual-view refinement bank.  The anchor bank above stores B1 raw
        # content; this second bank stores KC-aware LLM refinement only.
        self.use_q_ref_sem = int(kwargs.get("use_q_ref_sem", 0)) == 1
        # Delay creation of the refinement bank/projection until the precomputed
        # tensor is loaded.  This avoids consuming RNG during __init__, so the
        # B3-zero configuration can reproduce B1 initialization exactly.
        self.q_ref_sem_raw = None
        self.q_ref_sem_proj = None
        self.q_ref_sem_norm = nn.LayerNorm(d_model)
        self.q_ref_sem_scale = float(kwargs.get("q_ref_sem_scale", 0.05))
        self.q_ref_gate_type = str(kwargs.get("q_ref_gate_type", "seen_inv_sqrt"))
        self.q_ref_gate_floor = float(kwargs.get("q_ref_gate_floor", 0.0))
        self.q_ref_fusion_mode = str(
            kwargs.get("q_ref_fusion_mode", "static_legacy")
        ).lower()
        self.q_ref_projection_mode = str(
            kwargs.get("q_ref_projection_mode", "shared_zero_adapter")
        ).lower()
        self.q_ref_detach_shared_projection = int(
            kwargs.get("q_ref_detach_shared_projection", 1)
        ) == 1
        self.q_ref_cap_to_anchor_ratio = float(
            kwargs.get("q_ref_cap_to_anchor_ratio", 0.50)
        )
        self.q_ref_band_on = float(kwargs.get("q_ref_band_on", 2.0))
        self.q_ref_band_off = float(kwargs.get("q_ref_band_off", 50.0))
        self.q_ref_band_slope_on = float(kwargs.get("q_ref_band_slope_on", 4.0))
        self.q_ref_band_slope_off = float(kwargs.get("q_ref_band_slope_off", 4.0))
        self.q_ref_cold_scale = float(kwargs.get("q_ref_cold_scale", 0.0))
        self.q_ref_adapter_weight = None

        # In target_state_gate mode, B3 does not alter history encoding or the
        # retrieval query.  It refines only the final target representation after
        # the KT state has been computed.  q_ref_out is zero-initialized, making
        # the initial model exactly equivalent to B1+ID.
        if self.use_q_ref_sem and self.q_ref_fusion_mode == "target_state_gate":
            self.q_ref_state_gate = nn.Sequential(
                nn.Linear(d_model * 3, d_model),
                nn.GELU(),
                nn.Linear(d_model, 1),
            )
            self.q_ref_out = nn.Linear(d_model, d_model, bias=False)
            nn.init.zeros_(self.q_ref_out.weight)
            self.q_ref_query_norm = nn.LayerNorm(d_model)
        else:
            self.q_ref_state_gate = None
            self.q_ref_out = None
            self.q_ref_query_norm = None

        # Important for clean controls:
        # default = 0 means frozen LLM prior only, no trainable per-question semantic delta.
        self.use_q_sem_delta = int(kwargs.get("use_q_sem_delta", 0)) == 1
        self.use_c_sem_delta = int(kwargs.get("use_c_sem_delta", 0)) == 1

        self.c_sem_delta = (
            nn.Embedding(self.num_c + 1, d_model, padding_idx=0)
            if self.use_c_sem_delta else None
        )

        self.q_sem_delta = (
            nn.Embedding(self.num_q + 1, d_model, padding_idx=0)
            if (self.num_q > 0 and self.use_q_sem_delta) else None
        )

        self.sem_proj = nn.Linear(self.sem_input_dim, d_model, bias=False)
        nn.init.xavier_uniform_(self.sem_proj.weight)

        self.sem_norm = nn.LayerNorm(d_model)

        self.align_proj = nn.Linear(d_model * 2, d_model)
        self.lambda_align_q = float(kwargs.get("lambda_align_q", kwargs.get("lambda_align", 0.02)))
        self.lambda_align_c = float(kwargs.get("lambda_align_c", 0.0))

        self.lambda_same = float(kwargs.get("lambda_same", 0.01))
        self.lambda_smooth = float(kwargs.get("lambda_smooth", 1e-4))
        self.aux_loss = None
        
        self.q_inject_mode = str(kwargs.get("q_inject_mode", "medium"))
        # semantic residual scale
        self.q_sem_scale = float(kwargs.get("q_sem_scale", 0.05))
        self.c_sem_scale = float(kwargs.get("c_sem_scale", 0.05))
        # support-adaptive semantic gate
        self.use_q_support_gate = int(kwargs.get("use_q_support_gate", 0)) == 1
        self.q_support_gate_type = str(kwargs.get("q_support_gate_type", "inv_sqrt"))
        self.q_support_gate_floor = float(kwargs.get("q_support_gate_floor", 0.0))
        self.q_support_path = str(kwargs.get("q_support_path", ""))
        # ---------- contribution-3 / stage-1: support-adaptive ID-content arbitration ----------
        # Old support gate only scales the semantic residual:
        #   q = q_id + g(s_q) * q_sem
        # This switch enables a cleaner arbitration form:
        #   q = LN(alpha(s_q) * q_id + beta(s_q) * q_sem)
        # where alpha increases with train-fold item support and beta decreases with support.
        self.use_q_content_arbitration = int(kwargs.get("use_q_content_arbitration", 0)) == 1
        self.q_content_tau = float(kwargs.get("q_content_tau", 20.0))
        # eps/floor are retained only for backward-compatible ablations.  The
        # scientifically preferred strict-cold protocol uses both equal to 0.
        self.q_content_eps = float(kwargs.get("q_content_eps", 0.0))
        self.q_content_id_floor = float(kwargs.get("q_content_id_floor", 0.0))
        self.q_strict_cold_zero_id = int(kwargs.get("q_strict_cold_zero_id", 1)) == 1
        # If negative, reuse q_sem_scale. This keeps backward compatibility with existing sweeps.
        self.q_content_sem_scale = float(kwargs.get("q_content_sem_scale", -1.0))
        self.q_content_sem_floor = float(kwargs.get("q_content_sem_floor", 0.0))
        self.q_content_norm = nn.LayerNorm(d_model)
        self._q_support_loaded = False
        self.register_buffer(
            "q_support_counts",
            torch.zeros(self.num_q + 1, dtype=torch.float32)
        )
        self.register_buffer(
            "q_support_max_log",
            torch.tensor(1.0, dtype=torch.float32)
        )
        # ---------- fold-specific calibrated / residual LLM prior ----------
        # This is a scalar question-side prior loaded from a fold-specific CSV.
        # For residual LLM prior, value_col should be "llm_residual_delta".
        self.use_q_calib_prior = int(kwargs.get("use_q_calib_prior", 0)) == 1
        self.q_calib_prior_path = str(kwargs.get("q_calib_prior_path", ""))
        self.q_calib_value_col = str(kwargs.get("q_calib_value_col", "calibrated_value"))

        # modes:
        # - "incorrect_rate": value is calibrated incorrect rate d_q, converted to logit(correct)
        # - "incorrect_delta": value is residual delta on incorrect rate; correct-logit prior = -delta
        # - "correct_logit": value is already a correct-logit prior
        self.q_calib_prior_mode = str(kwargs.get("q_calib_prior_mode", "incorrect_rate"))

        # CSV qid base:
        # - "auto": infer from min/max qid
        # - "zero_based": CSV qid matches model q index, q=0 -> buffer row 1
        # - "one_based": CSV qid is 1..num_q, q=1 -> buffer row 1
        self.q_calib_qid_base = str(kwargs.get("q_calib_qid_base", "auto"))

        self.q_calib_scale_init = float(kwargs.get("q_calib_scale_init", 0.05))
        self.q_calib_learnable_scale = int(kwargs.get("q_calib_learnable_scale", 1)) == 1
        self.q_calib_use_support_gate = int(kwargs.get("q_calib_use_support_gate", 1)) == 1
        self.q_calib_normalize = int(kwargs.get("q_calib_normalize", 1)) == 1
        self.q_calib_clip = float(kwargs.get("q_calib_clip", 5.0))
        # ---------- contribution-3 / stage-2: separately gated reasoning residual ----------
        # Do NOT reuse the content gate for residual correction.  The residual prior lives at
        # the logit level and can over-correct tail items.  Keep it as an independent gate.
        # Supported types:
        #   none          : rho_q = 1
        #   sqrt_tau      : rho_q = sqrt(tau / (support + tau))
        #   inv_sqrt      : rho_q = 1 / sqrt(1 + support)
        #   inv_log       : rho_q = 1 - log1p(support) / max_log
        #   binary_tail   : rho_q = 1[support <= q_residual_tail_threshold]
        #   legacy_support: old behavior, reuse _get_q_support_weight only if use_q_support_gate=1
        self.q_residual_gate_type = str(kwargs.get("q_residual_gate_type", "legacy_support"))
        self.q_residual_tau = float(kwargs.get("q_residual_tau", 20.0))
        self.q_residual_gate_floor = float(kwargs.get("q_residual_gate_floor", 0.0))
        self.q_residual_tail_threshold = float(kwargs.get("q_residual_tail_threshold", 20.0))
        
        self.q_content_arbitration_mode = str(kwargs.get("q_content_arbitration_mode", "sqrt_replace"))
        self.q_content_id_mix_gamma = float(kwargs.get("q_content_id_mix_gamma", 0.25))
        self.q_content_use_layernorm = int(kwargs.get("q_content_use_layernorm", 1)) == 1

        self.register_buffer(
            "q_calib_logit_prior",
            torch.zeros(self.num_q + 1, dtype=torch.float32)
        )

        if self.q_calib_learnable_scale:
            self.q_calib_scale = nn.Parameter(
                torch.tensor(self.q_calib_scale_init, dtype=torch.float32)
            )
        else:
            self.register_buffer(
                "q_calib_scale",
                torch.tensor(self.q_calib_scale_init, dtype=torch.float32)
            )

        self.q_inter_gate = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.GELU(),
            nn.Linear(d_model, 1),
        )

        self.q_query_gate = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.GELU(),
            nn.Linear(d_model, 1),
        )

        # 保留你原来更稳定的融合方式
        self.q_fuse = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.LayerNorm(d_model),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.c_fuse = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.LayerNorm(d_model),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.input_norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

        # backbone
        if self.backbone_type == "gru":
            self.hist_gru = nn.GRU(
                input_size=d_model,
                hidden_size=d_model,
                num_layers=gru_layers,
                batch_first=True,
                dropout=dropout if gru_layers > 1 else 0.0,
            )
        elif self.backbone_type == "trans":
            self.hist_trans = CausalTransformerEncoder(
                d_model=d_model,
                n_heads=n_heads,
                n_layers=n_layers,
                dropout=dropout,
                ffn_mult=ffn_mult
            )
        else:
            raise ValueError(f"Unknown backbone_type={self.backbone_type}")

        # retrieval
        self.retrieve = DistanceForgettingAttention(
            d_model=d_model,
            n_heads=n_heads,
            dropout=dropout,
            gamma_init=gamma_init,
        )

        self.state_norm = nn.LayerNorm(d_model)

        # heads
        self.base_head = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, 1),
        )
        self.c_sem_gate = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.GELU(),
            nn.Linear(d_model, 1),
        )
        self.q_sem_gate = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.GELU(),
            nn.Linear(d_model, 1),
        )

        self._debug_printed = False
        self.c_sem_raw.weight.requires_grad_(False)
        if self.q_sem_raw is not None:
            self.q_sem_raw.weight.requires_grad_(False)
        if self.q_ref_sem_raw is not None:
            self.q_ref_sem_raw.weight.requires_grad_(False)
        if self.q_item_parameterization == "semantic_base_residual" and self.use_q_content_arbitration:
            raise ValueError(
                "Do not combine q_item_parameterization=semantic_base_residual with "
                "legacy use_q_content_arbitration=1. The new parameterization already "
                "implements B1 + support-gated ID residual."
            )
        if self.q_support_path:
            self.load_q_support_counts(self.q_support_path)
        if (
            self.use_q_content_arbitration
            or self.use_q_ref_sem
            or self.q_item_parameterization in {"semantic_base_residual", "id_only_cold_mask"}
        ) and not self.q_support_path:
            raise ValueError(
                "[SQAKT-CONTENT] support-routed item/refinement modeling requires a "
                "fold-specific outer-train-only q_support_path."
            )
        if self.use_q_calib_prior and self.q_calib_prior_path:
            self.init_q_calibrated_prior_from_csv(
                self.q_calib_prior_path,
                value_col=self.q_calib_value_col,
                mode=self.q_calib_prior_mode,
                qid_base=self.q_calib_qid_base,
            )

    def _safe_c(self, c):
        c = c.long()
        if not self.kc_set_input:
            # Legacy compatibility only. Canonical set-aware runs do not clamp.
            return c.clamp(min=0, max=self.num_c - 1)
        # In set-aware mode, -1 is the only allowed concept padding value.
        # Fail loudly on corrupted IDs instead of collapsing them to a boundary KC.
        bad = (c < -1) | (c >= self.num_c)
        if bool(bad.any().item()):
            vals = torch.unique(c[bad]).detach().cpu().tolist()[:20]
            raise RuntimeError(
                f"[SQAKT-KC-SET] concept IDs out of range: examples={vals}, num_c={self.num_c}"
            )
        return c

    def _safe_q(self, q):
        if self.num_q <= 0 or q is None:
            return None
        return q.long().clamp(min=0, max=self.num_q - 1)
    
    def _to_lookup_idx(self, x, size):
        if x is None:
            return None
        return x.long().clamp(min=0, max=size - 1) + 1
    def _apply_question_semantic_control(
        self,
        q_vec: torch.Tensor,
        mode: str = "real",
        seed: int = 0,
        same_kc_shuffle_map_path: str = "",
    ):
        """
        q_vec shape: [num_q, sem_input_dim]
        注意这里没有 padding row。
        question id q 对应 q_vec[q]。
        """
        mode = str(mode or "real").lower()

        if mode in ["real", "none", "identity"]:
            return q_vec

        if mode in ["zero", "zeros"]:
            return torch.zeros_like(q_vec)

        if mode in ["shuffle", "permute"]:
            g = torch.Generator(device=q_vec.device)
            g.manual_seed(int(seed))
            perm = torch.randperm(q_vec.size(0), generator=g, device=q_vec.device)
            return q_vec[perm]

        if mode in ["random", "gaussian"]:
            g = torch.Generator(device=q_vec.device)
            g.manual_seed(int(seed))

            rand = torch.randn(
                q_vec.shape,
                generator=g,
                device=q_vec.device,
                dtype=q_vec.dtype,
            )

            # 保持和真实 embedding 接近的 norm 尺度
            real_norm = q_vec.norm(dim=-1, keepdim=True).clamp(min=1e-6)
            rand = F.normalize(rand, p=2, dim=-1) * real_norm

            max_norm_diff = (rand.norm(dim=-1) - q_vec.norm(dim=-1)).abs().max().item()
            print(
                f"✅ [SQAKT-QCTRL] random semantic control applied: "
                f"shape={tuple(rand.shape)}, seed={seed}, "
                f"per_row_max_norm_diff={max_norm_diff:.8f}"
            )
            return rand

        if mode in ["same_kc_shuffle", "same-kc-shuffle", "samekc"]:
            if same_kc_shuffle_map_path is None or str(same_kc_shuffle_map_path).strip() == "":
                raise ValueError(
                    "[SQAKT-QCTRL] same_kc_shuffle requires same_kc_shuffle_map_path"
                )

            if not os.path.exists(same_kc_shuffle_map_path):
                raise FileNotFoundError(
                    f"[SQAKT-QCTRL] same_kc_shuffle_map_path not found: "
                    f"{same_kc_shuffle_map_path}"
                )

            with open(same_kc_shuffle_map_path, "r", encoding="utf-8") as f:
                mp = json.load(f)

            out = q_vec.clone()
            n = q_vec.size(0)

            copied = 0
            skipped = 0
            self_map = 0

            for q_str, src_str in mp.items():
                try:
                    q = int(float(str(q_str)))
                    src = int(float(str(src_str)))
                except Exception:
                    skipped += 1
                    continue

                if 0 <= q < n and 0 <= src < n:
                    out[q] = q_vec[src]
                    copied += 1
                    if q == src:
                        self_map += 1
                else:
                    skipped += 1

            print(
                f"✅ [SQAKT-QCTRL] same-KC shuffle applied: "
                f"copied={copied}, skipped={skipped}, self_map={self_map}, "
                f"path={same_kc_shuffle_map_path}"
            )

            return out

        # 兜底：兼容你原来的 semantic_patch 控制
        return apply_semantic_control(
            q_vec,
            mode=mode,
            seed=int(seed),
        )

    def load_q_support_counts(self, path: str):
        if path is None or str(path).strip() == "":
            return

        if not os.path.exists(path):
            raise FileNotFoundError(f"[SQAKT-SUPPORT] q_support_path not found: {path}")

        with open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)

        counts = torch.zeros(self.num_q + 1, dtype=torch.float32)

        loaded = 0
        skipped = 0

        for q_str, cnt in obj.items():
            try:
                q = int(float(str(q_str)))
                cnt = float(cnt)
            except Exception:
                skipped += 1
                continue

            row = q + 1
            if 1 <= row <= self.num_q:
                counts[row] = cnt
                loaded += 1
            else:
                skipped += 1

        if bool((counts < 0).any()):
            raise ValueError("[SQAKT-SUPPORT] support counts must be non-negative")
        self.q_support_counts.copy_(counts)
        max_log = torch.log1p(counts).max().clamp(min=1.0)
        self.q_support_max_log.copy_(max_log)
        self._q_support_loaded = True

        print(
            f"✅ [SQAKT-SUPPORT] loaded q support: "
            f"path={path}, loaded={loaded}, skipped={skipped}, "
            f"max_count={float(counts.max().item()):.1f}, "
            f"max_log={float(max_log.item()):.4f}"
        )


    def _get_q_support_weight(self, q_idx):
        """
        q_idx: original 0-based question ids, shape [B, L]
        return: [B, L, 1]

        inv_sqrt:
          support=0   -> 1.000
          support=1   -> 0.707
          support=5   -> 0.408
          support=20  -> 0.218
          support=100 -> 0.099
        """
        if q_idx is None:
            return None

        idx = self._to_lookup_idx(q_idx, self.num_q)
        cnt = self.q_support_counts.to(q_idx.device)[idx]

        if self.q_support_gate_type == "inv_sqrt":
            w = torch.rsqrt(1.0 + cnt)

        elif self.q_support_gate_type == "inv_log":
            max_log = self.q_support_max_log.to(q_idx.device).clamp(min=1.0)
            w = 1.0 - torch.log1p(cnt) / max_log
            w = w.clamp(min=0.0, max=1.0)

        elif self.q_support_gate_type == "binary_tail":
            w = (cnt <= 20).float()

        else:
            raise ValueError(f"Unknown q_support_gate_type={self.q_support_gate_type}")
   
        if self.q_support_gate_floor > 0:
            w = w.clamp(min=self.q_support_gate_floor, max=1.0)

        return w.unsqueeze(-1)

    def _get_q_id_residual_weight(self, q_idx):
        """Reliability gate for the trainable item-ID residual.

        q_idx uses the original 0-based item ids.  support is computed strictly
        from the outer-train fold.  For strict cold items support=0 always yields
        a zero residual, so no untrained random item vector can enter inference.
        """
        if q_idx is None:
            return None
        if not self._q_support_loaded:
            raise RuntimeError(
                "[SQAKT-ID-RESIDUAL] q_support_path was not loaded"
            )
        idx = self._to_lookup_idx(q_idx, self.num_q)
        cnt = self.q_support_counts.to(q_idx.device)[idx].float().clamp_min(0.0)
        seen = cnt > 0
        mode = self.q_id_gate_type

        if mode in {"none", "identity", "all"}:
            w = torch.ones_like(cnt)
        elif mode in {"cold_mask", "binary_seen"}:
            w = seen.to(cnt.dtype)
        elif mode in {"sqrt_reliability", "sqrt", "sqrt_tau"}:
            tau = torch.as_tensor(
                max(self.q_id_tau, 1e-6), device=cnt.device, dtype=cnt.dtype
            )
            w = torch.sqrt(cnt / (cnt + tau))
        elif mode in {"reliability", "linear_reliability"}:
            tau = torch.as_tensor(
                max(self.q_id_tau, 1e-6), device=cnt.device, dtype=cnt.dtype
            )
            w = cnt / (cnt + tau)
        else:
            raise ValueError(f"Unknown q_id_gate_type={self.q_id_gate_type}")

        if self.q_strict_cold_zero_id:
            w = torch.where(seen, w, torch.zeros_like(w))

        if self.training and self.q_id_residual_dropout > 0:
            keep = torch.rand_like(w) >= self.q_id_residual_dropout
            w = w * keep.to(w.dtype)

        return w.unsqueeze(-1)

    def _get_q_content_arbitration_weights(self, q_idx):
        """Return reliability-based ID/content weights from train-fold support.

        Preferred rule (``sqrt_replace``):

            m_q     = s_q / (s_q + tau)
            alpha_q = sqrt(m_q)                    # ID reliability
            beta_q  = semantic_gain * sqrt(1-m_q) # transferable content

        With strict cold enabled, s_q=0 forces alpha_q=0 exactly, regardless of
        legacy eps/floor settings.  Tail items retain a nonzero ID branch; they
        are sparse, not unseen.
        """
        if q_idx is None:
            return None, None
        if not self._q_support_loaded:
            raise RuntimeError(
                "[SQAKT-CONTENT] question support was not loaded. "
                "Provide the outer-train-only q_support_path."
            )

        idx = self._to_lookup_idx(q_idx, self.num_q)
        cnt = self.q_support_counts.to(q_idx.device)[idx].float().clamp_min(0.0)
        tau = torch.as_tensor(
            max(float(self.q_content_tau), 1e-6),
            device=q_idx.device,
            dtype=cnt.dtype,
        )
        sem_scale = self.q_sem_scale if self.q_content_sem_scale < 0 else self.q_content_sem_scale
        mode = str(self.q_content_arbitration_mode).lower()

        seen = cnt > 0
        reliability = cnt / (cnt + tau)
        content_need = 1.0 - reliability

        if mode in ["sqrt_replace", "hard", "replace", "reliability"]:
            alpha = torch.sqrt(reliability)
            beta = float(sem_scale) * torch.sqrt(content_need)
        elif mode in ["cold_mask_constant_sem", "cold_mask", "strict_cold_add"]:
            # Attribution control: preserve every seen-item ID exactly, remove only
            # unseen random IDs, and inject content with a constant global scale.
            # With sem_scale=0 this becomes a strict-cold ID-only baseline.
            alpha = seen.to(cnt.dtype)
            beta = float(sem_scale) * torch.ones_like(cnt)
        elif mode in ["soft", "soft_id", "soft_arbitration"]:
            # Legacy ablation only.  Prefer sqrt_replace for the main result.
            gamma = float(self.q_content_id_mix_gamma)
            g = torch.sqrt(content_need)
            alpha = 1.0 - gamma * g
            beta = float(sem_scale) * g
        else:
            raise ValueError(f"Unknown q_content_arbitration_mode={self.q_content_arbitration_mode}")

        if self.q_content_id_floor > 0:
            # Never let a floor resurrect an independent random ID for cold items.
            alpha = torch.where(
                seen,
                alpha.clamp(min=float(self.q_content_id_floor), max=1.0),
                alpha,
            )
        else:
            alpha = alpha.clamp(min=0.0, max=1.0)

        if self.q_strict_cold_zero_id:
            alpha = torch.where(seen, alpha, torch.zeros_like(alpha))

        if self.q_content_sem_floor > 0:
            beta = beta.clamp(min=float(self.q_content_sem_floor))

        return alpha.unsqueeze(-1), beta.unsqueeze(-1)

    def _get_q_residual_weight(self, q_idx):
        """
        Stage-2 residual gate for logit-level LLM reasoning correction.

        This is deliberately separate from _get_q_content_arbitration_weights():
        content prior and residual prior have different failure modes and should be
        ablated independently.
        """
        if q_idx is None:
            return None

        mode = str(self.q_residual_gate_type or "none").lower()

        if mode in ["none", "off", "identity"]:
            idx = self._to_lookup_idx(q_idx, self.num_q)
            cnt = self.q_support_counts.to(q_idx.device)[idx]
            w = torch.ones_like(cnt, dtype=torch.float32)

        elif mode in ["legacy_support", "legacy", "content"]:
            if self.use_q_support_gate:
                return self._get_q_support_weight(q_idx)
            idx = self._to_lookup_idx(q_idx, self.num_q)
            cnt = self.q_support_counts.to(q_idx.device)[idx]
            w = torch.ones_like(cnt, dtype=torch.float32)

        else:
            idx = self._to_lookup_idx(q_idx, self.num_q)
            cnt = self.q_support_counts.to(q_idx.device)[idx].float()

            if mode == "sqrt_tau":
                tau = torch.tensor(
                    max(float(self.q_residual_tau), 1e-6),
                    device=q_idx.device,
                    dtype=cnt.dtype,
                )
                w = torch.sqrt(tau / (cnt + tau))

            elif mode == "inv_sqrt":
                w = torch.rsqrt(1.0 + cnt)

            elif mode == "inv_log":
                max_log = self.q_support_max_log.to(q_idx.device).clamp(min=1.0)
                w = 1.0 - torch.log1p(cnt) / max_log
                w = w.clamp(min=0.0, max=1.0)

            elif mode == "binary_tail":
                w = (cnt <= float(self.q_residual_tail_threshold)).float()

            else:
                raise ValueError(f"Unknown q_residual_gate_type={self.q_residual_gate_type}")

        if self.q_residual_gate_floor > 0:
            w = w.clamp(min=float(self.q_residual_gate_floor), max=1.0)

        return w.unsqueeze(-1)
    def _get_q_ref_weight(self, q_idx):
        """Cold-safe gate for the B3 refinement branch.

        Main rule (seen_inv_sqrt):
            support=0 -> 0 exactly
            support=1 -> 1.000
            support=5 -> 0.447
            support=20 -> 0.224

        Thus B1 remains the sole semantic view for cold items, while the
        refinement branch is strongest on few-shot seen items and decays as ID
        evidence becomes reliable.
        """
        if q_idx is None:
            return None
        if not self._q_support_loaded:
            raise RuntimeError("[SQAKT-B3] q_support_path was not loaded")
        idx = self._to_lookup_idx(q_idx, self.num_q)
        cnt = self.q_support_counts.to(q_idx.device)[idx].float().clamp_min(0.0)
        seen = cnt > 0
        mode = str(self.q_ref_gate_type or "seen_inv_sqrt").lower()
        if mode in ["seen_inv_sqrt", "inv_sqrt_seen"]:
            w = torch.where(seen, torch.rsqrt(cnt.clamp_min(1.0)), torch.zeros_like(cnt))
        elif mode in ["all_inv_sqrt", "inv_sqrt"]:
            w = torch.rsqrt(1.0 + cnt)
        elif mode in ["seen_constant", "binary_seen"]:
            w = seen.to(cnt.dtype)
        elif mode in ["log_bandpass", "bandpass"]:
            if self.q_ref_band_off <= self.q_ref_band_on:
                raise ValueError("q_ref_band_off must be greater than q_ref_band_on")
            log_s = torch.log1p(cnt)
            log_on = math.log1p(max(self.q_ref_band_on, 0.0))
            log_off = math.log1p(max(self.q_ref_band_off, self.q_ref_band_on + 1e-6))
            rise = torch.sigmoid(self.q_ref_band_slope_on * (log_s - log_on))
            fall = torch.sigmoid(self.q_ref_band_slope_off * (log_off - log_s))
            w = rise * fall
            w = torch.where(
                seen,
                w,
                torch.full_like(w, max(self.q_ref_cold_scale, 0.0)),
            )
        elif mode in ["off", "zero", "none"]:
            w = torch.zeros_like(cnt)
        else:
            raise ValueError(f"Unknown q_ref_gate_type={self.q_ref_gate_type}")
        if self.q_ref_gate_floor > 0:
            w = torch.where(seen, w.clamp(min=self.q_ref_gate_floor, max=1.0), w)
        return w.unsqueeze(-1)

    def init_q_calibrated_prior_from_csv(
        self,
        path,
        value_col="calibrated_value",
        mode="incorrect_rate",
        qid_base="auto",
    ):
        """
        Load fold-specific calibrated question prior.

        Recommended for residual LLM prior:
          value_col = "llm_residual_delta"
          mode = "incorrect_delta"

        For mode="incorrect_delta":
          value > 0 means the item is harder than simple predicted,
          so correct-logit prior should be negative.
        """
        import pandas as pd
        import numpy as np

        if not os.path.exists(path):
            raise FileNotFoundError(f"[SQAKT-CALIB] q_calib_prior_path not found: {path}")

        df = pd.read_csv(path)

        if "qid" not in df.columns:
            raise ValueError(
                f"[SQAKT-CALIB] missing qid column in {path}, columns={list(df.columns)}"
            )
        if value_col not in df.columns:
            raise ValueError(
                f"[SQAKT-CALIB] missing value_col={value_col} in {path}, columns={list(df.columns)}"
            )

        def canon_qid(x):
            s = str(x).strip()
            if s.endswith(".0"):
                s = s[:-2]
            return s

        qids_raw = [canon_qid(x) for x in df["qid"].tolist()]
        numeric_qids = []
        for q in qids_raw:
            try:
                numeric_qids.append(int(q))
            except Exception:
                pass

        # Infer qid base.
        inferred_base = qid_base
        if qid_base == "auto":
            if len(numeric_qids) == 0:
                inferred_base = "zero_based"
            else:
                mn = min(numeric_qids)
                mx = max(numeric_qids)
                if mn == 0:
                    inferred_base = "zero_based"
                elif mn == 1 and mx <= self.num_q:
                    inferred_base = "one_based"
                else:
                    # Safer default for PyKT internal question indices.
                    inferred_base = "zero_based"

        prior = torch.zeros(self.num_q + 1, dtype=torch.float32)
        loaded = 0
        skipped = 0

        vals_for_stats = []

        for _, r in df.iterrows():
            qid = canon_qid(r["qid"])
            try:
                q_raw = int(qid)
            except Exception:
                skipped += 1
                continue

            # Map CSV qid to model lookup row.
            # model q index 0 -> lookup row 1.
            if inferred_base == "one_based":
                lookup_idx = q_raw
            elif inferred_base == "zero_based":
                lookup_idx = q_raw + 1
            else:
                raise ValueError(f"Unknown qid_base={qid_base}, inferred_base={inferred_base}")

            if lookup_idx <= 0 or lookup_idx > self.num_q:
                skipped += 1
                continue

            value = float(r[value_col])

            if mode == "incorrect_rate":
                # value = predicted incorrect rate d_q.
                d_incorrect = float(np.clip(value, 1e-4, 1.0 - 1e-4))
                p_correct = 1.0 - d_incorrect
                p_correct = float(np.clip(p_correct, 1e-4, 1.0 - 1e-4))
                prior_value = float(np.log(p_correct / (1.0 - p_correct)))

            elif mode == "incorrect_delta":
                # value = residual on incorrect rate.
                # positive delta => harder => correct logit should go down.
                prior_value = -float(value)

            elif mode == "correct_logit":
                prior_value = float(value)

            else:
                raise ValueError(
                    f"Unknown q_calib_prior_mode={mode}. "
                    f"Use incorrect_rate, incorrect_delta, or correct_logit."
                )

            prior[lookup_idx] = prior_value
            vals_for_stats.append(prior_value)
            loaded += 1

        # Normalize nonzero entries for stable optimization.
        nz = prior[1:] != 0
        if bool(nz.any()) and self.q_calib_normalize:
            x = prior[1:][nz]
            mu = x.mean()
            std = x.std().clamp(min=1e-6)
            prior[1:][nz] = (x - mu) / std

        if self.q_calib_clip > 0:
            prior = prior.clamp(min=-self.q_calib_clip, max=self.q_calib_clip)

        self.q_calib_logit_prior.data.copy_(
            prior.to(self.q_calib_logit_prior.device)
        )

        with torch.no_grad():
            nz_count = int((self.q_calib_logit_prior[1:] != 0).sum().detach().cpu())
            mean_val = float(self.q_calib_logit_prior[1:][self.q_calib_logit_prior[1:] != 0].mean().detach().cpu()) if nz_count > 0 else 0.0
            std_val = float(self.q_calib_logit_prior[1:][self.q_calib_logit_prior[1:] != 0].std().detach().cpu()) if nz_count > 1 else 0.0

        print(
            f"✅ [SQAKT-CALIB] loaded q prior: path={path}, "
            f"value_col={value_col}, mode={mode}, qid_base={qid_base}->{inferred_base}, "
            f"loaded={loaded}, skipped={skipped}, nonzero={nz_count}, "
            f"normalized={int(self.q_calib_normalize)}, mean={mean_val:.6f}, std={std_val:.6f}, "
            f"scale_init={self.q_calib_scale_init}, learnable={int(self.q_calib_learnable_scale)}, "
            f"use_support_gate={int(self.q_calib_use_support_gate)}"
        )

    def _lookup_q_calib_prior(self, q_idx):
        """
        Return scalar prior with shape [B, T].
        q_idx is PyKT internal question index, usually 0-based.
        """
        if not self.use_q_calib_prior or self.num_q <= 0 or q_idx is None:
            return None

        idx = self._to_lookup_idx(q_idx, self.num_q)
        prior = self.q_calib_logit_prior.to(q_idx.device)[idx]

        if self.q_calib_use_support_gate:
            w = self._get_q_residual_weight(q_idx).squeeze(-1)
            prior = w * prior

        return prior

    def _scale_q_sem_by_support(self, q_idx, q_sem):
        if q_sem is None:
            return None

        q_sem_eff = self.q_sem_scale * q_sem

        if self.use_q_support_gate:
            w = self._get_q_support_weight(q_idx)
            q_sem_eff = w * q_sem_eff

        return q_sem_eff

    def _project_sem(self, raw_bank, delta_bank, x_idx, size):
        idx = self._to_lookup_idx(x_idx, size)
        if idx.numel() > 0:
            idx_min = int(idx.min().detach().cpu())
            idx_max = int(idx.max().detach().cpu())
            n_emb = int(raw_bank.num_embeddings)

            if idx_min < 0 or idx_max >= n_emb:
                raise RuntimeError(
                    f"[SQAKT-SEM-IDX-OOB] idx_min={idx_min}, idx_max={idx_max}, "
                    f"num_embeddings={n_emb}, raw_dim={raw_bank.embedding_dim}. "
                    f"This usually means q indices are 1-based but semantic tensor is 0-based."
                )
        raw = raw_bank(idx)
        sem = self.sem_proj(raw)
        sem = self.sem_norm(sem)
        if delta_bank is not None:
            sem = sem + delta_bank(idx)
        return sem
   
    def _project_q_ref(self, q_idx):
        if not self.use_q_ref_sem or self.q_ref_sem_raw is None:
            return None
        idx = self._to_lookup_idx(q_idx, self.num_q)
        raw = self.q_ref_sem_raw(idx)
        mode = self.q_ref_projection_mode

        if mode in {"shared_zero_adapter", "shared", "shared_adapter"}:
            if self.q_ref_adapter_weight is None:
                raise RuntimeError("[SQAKT-B3] shared refinement adapter was not initialized")
            proj_weight = (
                self.sem_proj.weight.detach()
                if self.q_ref_detach_shared_projection
                else self.sem_proj.weight
            )
            base = F.linear(raw, proj_weight, bias=None)
            if self.q_ref_detach_shared_projection:
                base = F.layer_norm(
                    base,
                    (self.d_model,),
                    self.sem_norm.weight.detach(),
                    self.sem_norm.bias.detach(),
                    self.sem_norm.eps,
                )
            else:
                base = self.sem_norm(base)
            delta = F.linear(raw, self.q_ref_adapter_weight, bias=None)
            return base + delta

        if mode in {"independent_legacy", "independent"}:
            if self.q_ref_sem_proj is None:
                raise RuntimeError("[SQAKT-B3] independent projection was not initialized")
            return self.q_ref_sem_norm(self.q_ref_sem_proj(raw))

        raise ValueError(f"Unknown q_ref_projection_mode={self.q_ref_projection_mode}")

    def _get_q_id_sem(self, q_idx):
        if self.num_q <= 0 or q_idx is None or self.q_id_embed is None:
            return None, None, None

        q_lookup = self._to_lookup_idx(q_idx, self.num_q)
        q_id = self.q_id_embed(q_lookup)

        if self.use_q_sem and self.q_sem_raw is not None:
            q_sem = self._project_sem(self.q_sem_raw, self.q_sem_delta, q_idx, self.num_q)
        else:
            q_sem = torch.zeros_like(q_id)

        q_ref = self._project_q_ref(q_idx)
        if q_ref is None:
            q_ref = torch.zeros_like(q_id)
        return q_id, q_sem, q_ref

    def _fuse_q(self, q_idx):
        q_id, q_sem, q_ref = self._get_q_id_sem(q_idx)
        if q_id is None:
            return None, None

        mode = getattr(self, "q_inject_mode", "medium")

        if self.q_item_parameterization == "id_only_cold_mask":
            id_w = self._get_q_id_residual_weight(q_idx)
            return self.q_item_norm(id_w * q_id), torch.zeros_like(q_id)

        if self.q_item_parameterization == "semantic_base_residual":
            # B1 is the support-independent prior mean.  The item-ID branch is a
            # zero-initialized, support-gated residual that can correct B1 once
            # item-specific evidence exists.
            id_w = self._get_q_id_residual_weight(q_idx)
            q_sem_used = self.q_sem_anchor_scale * q_sem
            q_id_used = id_w * q_id
            semantic_contrib = q_sem_used

            # Legacy static B3 is retained only as an ablation.  The recommended
            # target_state_gate branch is applied after the KT state is formed.
            if self.use_q_ref_sem and self.q_ref_fusion_mode == "static_legacy":
                rho = self._get_q_ref_weight(q_idx)
                ref_coeff = self.q_ref_sem_scale * rho
                if self.q_ref_cap_to_anchor_ratio >= 0:
                    ref_cap = self.q_ref_cap_to_anchor_ratio * torch.full_like(
                        ref_coeff, abs(self.q_sem_anchor_scale)
                    )
                    ref_coeff = torch.minimum(ref_coeff, ref_cap)
                q_ref_used = ref_coeff * q_ref
                semantic_contrib = semantic_contrib + q_ref_used
            else:
                q_ref_used = torch.zeros_like(q_id)

            q_feat = self.q_item_norm(q_sem_used + q_id_used + q_ref_used)
            return q_feat, semantic_contrib

        if mode == "none" and not self.use_q_content_arbitration:
            return q_id, q_sem
        if self.use_q_content_arbitration:
            # Stage-1: explicit reliability arbitration.  For strict cold items
            # alpha=0, so their untrained independent ID vector cannot affect the
            # forward pass or the interpretation of semantic generalization.
            alpha, beta = self._get_q_content_arbitration_weights(q_idx)
            q_id_used = alpha * q_id
            q_sem_used = beta * q_sem
            q_ref_used = torch.zeros_like(q_id)
            if self.use_q_ref_sem:
                rho = self._get_q_ref_weight(q_idx)
                q_ref_used = self.q_ref_sem_scale * rho * q_ref
            q_feat = q_id_used + q_sem_used + q_ref_used
            if self.q_content_use_layernorm:
                q_feat = self.q_content_norm(q_feat)

            # Return the complete semantic contribution so strong-mode callers
            # do not silently drop the refinement branch.
            return q_feat, q_sem_used + q_ref_used

        q_sem_eff = self._scale_q_sem_by_support(q_idx, q_sem)

        if mode == "light":
            # 最干净的支持度自适应残差注入
            return q_id + q_sem_eff, q_sem_eff

        elif mode == "medium":
            # gate 用 raw q_sem 判断语义是否有用；
            # 真正注入时使用 support-scaled q_sem_eff
            q_gate = torch.sigmoid(
                self.q_sem_gate(torch.cat([q_id, q_sem], dim=-1))
            )
            q_sem_used = q_gate * q_sem_eff
            return self.q_fuse(torch.cat([q_id, q_sem_used], dim=-1)), q_sem_eff

        elif mode == "strong":
            q_gate = torch.sigmoid(
                self.q_sem_gate(torch.cat([q_id, q_sem], dim=-1))
            )
            q_sem_used = q_gate * q_sem_eff
            q_feat = self.q_fuse(torch.cat([q_id, q_sem_used], dim=-1))
            return q_feat, q_sem_eff

        else:
            raise ValueError(f"Unknown q_inject_mode={mode}")

    def _pool_last_concept_dim(self, x, mask):
        """Pool per-KC features over the last concept-set axis.

        x: [..., M, D], mask: [..., M]. Empty/padded sets map to the zero vector.
        """
        w = mask.to(dtype=x.dtype).unsqueeze(-1)
        denom = w.sum(dim=-2).clamp_min(1.0)
        return (x * w).sum(dim=-2) / denom

    def _project_c_sem_target(self, c_idx):
        """Return concept semantic target with the same event shape as _fuse_c."""
        if not self.kc_set_input:
            return self._project_sem(self.c_sem_raw, None, c_idx, self.num_c)
        mask = c_idx.ge(0)
        safe = c_idx.masked_fill(~mask, 0)
        sem_each = self._project_sem(self.c_sem_raw, None, safe, self.num_c)
        return self._pool_last_concept_dim(sem_each, mask)

    def _fuse_c(self, c_idx):
        if not self.kc_set_input:
            c_lookup = self._to_lookup_idx(c_idx, self.num_c)
            c_id = self.c_id_embed(c_lookup)

            if self.use_c_sem and self.c_sem_raw is not None:
                c_sem = self._project_sem(self.c_sem_raw, self.c_sem_delta, c_idx, self.num_c)
                c_gate = torch.sigmoid(self.c_sem_gate(torch.cat([c_id, c_sem], dim=-1)))
                c_sem_used = self.c_sem_scale * c_gate * c_sem
            else:
                c_sem_used = torch.zeros_like(c_id)
            return self.c_fuse(torch.cat([c_id, c_sem_used], dim=-1))

        # Set-aware mode expects a final M dimension containing all KCs of one item.
        # Examples: history [B,L,M], target batch [K,M].
        if c_idx.dim() < 2:
            raise RuntimeError(
                f"[SQAKT-KC-SET] expected c_idx with a final concept-set dimension, got {tuple(c_idx.shape)}"
            )
        mask = c_idx.ge(0)
        safe = c_idx.masked_fill(~mask, 0)
        c_lookup = safe + 1  # 0-based KC -> embedding row 1..num_c; row 0 stays reserved.
        c_id_each = self.c_id_embed(c_lookup)

        if self.use_c_sem and self.c_sem_raw is not None:
            c_sem_each = self._project_sem(self.c_sem_raw, self.c_sem_delta, safe, self.num_c)
            c_gate = torch.sigmoid(self.c_sem_gate(torch.cat([c_id_each, c_sem_each], dim=-1)))
            c_sem_used_each = self.c_sem_scale * c_gate * c_sem_each
        else:
            c_sem_used_each = torch.zeros_like(c_id_each)

        c_each = self.c_fuse(torch.cat([c_id_each, c_sem_used_each], dim=-1))
        return self._pool_last_concept_dim(c_each, mask)
    
    def _compute_aux_loss(self, state, query, cshft, qshft, valid, logit):
        losses = []

        # ---------- semantic alignment ----------
        h = self.align_proj(torch.cat([state, query], dim=-1))
        h = F.normalize(h, dim=-1)

        if self.use_q_sem and self.num_q > 0 and qshft is not None and self.q_sem_raw is not None:
            q_tgt = self._project_sem(self.q_sem_raw, None, qshft, self.num_q).detach()
            q_tgt = F.normalize(q_tgt, dim=-1)
            l_align_q = 1.0 - (h * q_tgt).sum(dim=-1)
            l_align_q = torch.masked_select(l_align_q, valid).mean()
            if self.lambda_align_q > 0:
                losses.append(self.lambda_align_q * l_align_q)

        if self.use_c_sem and self.c_sem_raw is not None and self.lambda_align_c > 0:
            c_tgt = self._project_c_sem_target(cshft).detach()
            c_tgt = F.normalize(c_tgt, dim=-1)
            l_align_c = 1.0 - (h * c_tgt).sum(dim=-1)
            l_align_c = torch.masked_select(l_align_c, valid).mean()
            losses.append(self.lambda_align_c * l_align_c)

        # ---------- same-concept / same-KC-set consistency ----------
        # Do not even materialize this term when lambda_same=0; in set-aware mode
        # cshft is 3-D and scalar torch.masked_select would be semantically wrong.
        if self.lambda_same > 0:
            pred = torch.sigmoid(logit)
            pred_v = torch.masked_select(pred, valid)
            same_losses = []
            if self.kc_set_input:
                c_v = cshft[valid]  # [N,M]
                # KTQueDataset canonicalizes each set (sorted unique + -1 padding),
                # therefore row equality means exact KC-set equality.
                unique_sets, inverse = torch.unique(c_v, dim=0, return_inverse=True)
                for sid in range(unique_sets.size(0)):
                    idx = torch.nonzero(inverse == sid, as_tuple=False).flatten()
                    if idx.numel() >= 2:
                        p = pred_v[idx[:8]]
                        diff = p.unsqueeze(1) - p.unsqueeze(0)
                        same_losses.append((diff ** 2).mean())
            else:
                c_v = torch.masked_select(cshft, valid)
                for cid in torch.unique(c_v):
                    idx = torch.nonzero(c_v == cid, as_tuple=False).flatten()
                    if idx.numel() >= 2:
                        p = pred_v[idx[:8]]
                        diff = p.unsqueeze(1) - p.unsqueeze(0)
                        same_losses.append((diff ** 2).mean())
            if same_losses:
                losses.append(self.lambda_same * torch.stack(same_losses).mean())

        # ---------- smoothness ----------
        pair_valid = valid[:, 1:] & valid[:, :-1]
        if pair_valid.any():
            dh = (state[:, 1:] - state[:, :-1]).pow(2).mean(dim=-1)
            l_smooth = torch.masked_select(dh, pair_valid).mean()
            losses.append(self.lambda_smooth * l_smooth)
 
        if len(losses) == 0:
            return None
        return sum(losses)

    @torch.no_grad()
    def init_semantic_from_encoder(
        self,
        concept_texts=None,
        question_texts=None,
        encoder_name="sentence-transformers/all-MiniLM-L6-v2",
        encoder_backend="sentence_transformers",
        device="cpu",
        local_files_only=True,
        normalize=True,
        batch_size=64,
        pooling="mean",
        trust_remote_code=True,
        semantic_control_mode="real",
        semantic_control_seed=0,
        q_semantic_control_mode=None,
        c_semantic_control_mode=None,
        same_kc_shuffle_map_path="",
        q_same_kc_shuffle_map_path=None,
        **kwargs
    ):
        need_c = bool(getattr(self, "use_c_sem", False)) and (self.c_sem_raw is not None)
        need_q = bool(getattr(self, "use_q_sem", False)) and (self.num_q > 0) and (self.q_sem_raw is not None)

        print(
            "[SQAKT INIT ENTER]",
            "need_c =", need_c,
            "need_q =", need_q,
            "encoder_backend =", encoder_backend,
            "encoder_name =", encoder_name,
            "concept_texts_is_none =", concept_texts is None,
            "question_texts_is_none =", question_texts is None,
            "len_concept_texts =", (len(concept_texts) if concept_texts is not None else -1),
            "len_question_texts =", (len(question_texts) if question_texts is not None else -1),
        )

        if not need_c and not need_q:
            print("✅ [SQAKT] semantic init skipped: both concept/question semantic priors are disabled.")
            return

        def encode_texts(texts, name):
            if texts is None:
                return None
            vec = encode_texts_to_tensor(
                texts=texts,
                encoder_name=encoder_name,
                device=device,
                local_files_only=local_files_only,
                normalize=normalize,
                batch_size=batch_size,
                encoder_backend=encoder_backend,
                pooling=pooling,
                trust_remote_code=trust_remote_code,
            )
            if vec is None:
                return None
            vec = vec.float()
            d_enc = int(vec.size(-1))

            if d_enc != self.sem_input_dim:
                raise ValueError(
                    f"[SQAKT] {name} encoder dim mismatch: got {d_enc}, "
                    f"expected sem_input_dim={self.sem_input_dim}. "
                    f"Please set --sem_input_dim {d_enc} or use a matching encoder."
                )
            return vec
        # ---------- concept semantic init ----------
        if need_c:
            if concept_texts is None:
                raise ValueError(
                    "[SQAKT] use_c_sem=1 but concept_texts is None. "
                    "Please provide concept_texts or set --use_c_sem 0."
                )
            c_vec = encode_texts(concept_texts, "concept")
            mode_c = c_semantic_control_mode or semantic_control_mode
            c_vec = apply_semantic_control(
                c_vec,
                mode=mode_c,
                seed=int(semantic_control_seed),
            )
            self.c_sem_raw.weight.data.zero_()

            nc = min(c_vec.size(0), self.c_sem_raw.weight.size(0) - 1)
            self.c_sem_raw.weight.data[1:1 + nc].copy_(
                c_vec[:nc].to(self.c_sem_raw.weight.device)
            )
            self.c_sem_raw.weight.data[0].zero_()
            self.c_sem_raw.weight.requires_grad_(False)

            print(
                f"✅ [SQAKT-CSEM] loaded concept semantic bank: "
                f"texts={len(concept_texts)}, used={nc}, dim={c_vec.size(-1)}"
            )
        else:
            if self.c_sem_raw is not None:
                self.c_sem_raw.weight.data.zero_()
                self.c_sem_raw.weight.requires_grad_(False)
            if self.c_sem_delta is not None:
                self.c_sem_delta.weight.data.zero_()
        # ---------- question semantic init ----------
        if need_q:
            if question_texts is None:
                raise ValueError(
                    "[SQAKT] use_q_sem=1 but question_texts is None. "
                    "Please provide question_texts or set --use_q_sem 0."
                )
            q_vec = encode_texts(question_texts, "question")
            mode_q = q_semantic_control_mode or semantic_control_mode

            same_kc_path = (
                q_same_kc_shuffle_map_path
                or same_kc_shuffle_map_path
                or kwargs.get("same_kc_shuffle_map_path", "")
                or kwargs.get("q_same_kc_shuffle_map_path", "")
            )

            q_vec = self._apply_question_semantic_control(
                q_vec=q_vec,
                mode=mode_q,
                seed=int(semantic_control_seed),
                same_kc_shuffle_map_path=same_kc_path,
            )
            self.q_sem_raw.weight.data.zero_()

            nq = min(q_vec.size(0), self.q_sem_raw.weight.size(0) - 1)
            self.q_sem_raw.weight.data[1:1 + nq].copy_(
                q_vec[:nq].to(self.q_sem_raw.weight.device)
            )
            self.q_sem_raw.weight.data[0].zero_()
            self.q_sem_raw.weight.requires_grad_(False)

            print(
                f"✅ [SQAKT-QSEM] loaded question semantic bank: "
                f"texts={len(question_texts)}, used={nq}, dim={q_vec.size(-1)}"
            )
        else:
            if self.q_sem_raw is not None:
                self.q_sem_raw.weight.data.zero_()
                self.q_sem_raw.weight.requires_grad_(False)
            if self.q_sem_delta is not None:
                self.q_sem_delta.weight.data.zero_()
        print(
            f"✅ [SQAKT] semantic banks initialized. "
            f"use_c_sem={int(need_c)}, use_q_sem={int(need_q)}, backend={encoder_backend}, control={semantic_control_mode}"
        )
    def init_semantic_from_precomputed_tensor(
        self,
        question_tensor=None,
        question_ref_tensor=None,
        concept_tensor=None,
        semantic_control_mode="real",
        semantic_control_seed=0,
        same_kc_shuffle_map_path="",
        qid_to_idx=None,
    ):
        device = next(self.parameters()).device
        if question_tensor is not None and getattr(self, "use_q_sem", False):
            question_tensor = question_tensor.float().to(device)

            model_num_q = int(getattr(self, "num_q", question_tensor.size(0)))
            q_dim = int(question_tensor.size(1))
        # structured builder 输出通常是 [num_q, dim]，对应 0-based item ids。
        # 但 SQAKT/PyKT batch 中 q_idx 通常是 1-based，0 为 padding。
        # 因此补一个 row0 padding，让 row1 对应原 row0。
            if question_tensor.size(0) == model_num_q:
                pad = torch.zeros(
                    1,
                    q_dim,
                    dtype=question_tensor.dtype,
                    device=question_tensor.device,
                )
                question_tensor = torch.cat([pad, question_tensor], dim=0)
                print(
                    f"✅ [SQAKT-STRUCT] added padding row: "
                    f"[{model_num_q},{q_dim}] -> {tuple(question_tensor.shape)}"
                )
            elif question_tensor.size(0) == model_num_q + 1:
                print(
                    f"✅ [SQAKT-STRUCT] structured tensor already padded: "
                    f"{tuple(question_tensor.shape)}"
                )
            else:
                raise RuntimeError(
                    f"[SQAKT-STRUCT] unexpected question_tensor rows={question_tensor.size(0)}, "
                    f"model_num_q={model_num_q}. Expected {model_num_q} or {model_num_q + 1}."
                )
            self.q_sem_raw = nn.Embedding.from_pretrained(
                question_tensor,
                freeze=True,
                padding_idx=0,
            ).to(device)
        # 你当前 _project_sem() 用的是 self.sem_proj，所以这里必须覆盖。
            self.sem_proj = nn.Linear(q_dim, self.d_model, bias=False).to(device)
            nn.init.xavier_uniform_(self.sem_proj.weight)
            print(
                f"✅ [SQAKT-STRUCT] loaded structured q prior: "
                f"num_embeddings={self.q_sem_raw.num_embeddings}, "
                f"feature_dim={q_dim}, d_model={self.d_model}, "
                f"sem_proj_in={self.sem_proj.in_features}"
            )
        if question_ref_tensor is not None:
            if not self.use_q_ref_sem:
                raise ValueError("question_ref_tensor provided but use_q_ref_sem=0")
            question_ref_tensor = question_ref_tensor.float().to(device)
            model_num_q = int(getattr(self, "num_q", question_ref_tensor.size(0)))
            ref_dim = int(question_ref_tensor.size(1))
            if question_ref_tensor.size(0) == model_num_q:
                pad = torch.zeros(1, ref_dim, dtype=question_ref_tensor.dtype, device=device)
                question_ref_tensor = torch.cat([pad, question_ref_tensor], dim=0)
            elif question_ref_tensor.size(0) != model_num_q + 1:
                raise RuntimeError(
                    f"[SQAKT-B3] refinement rows={question_ref_tensor.size(0)}, "
                    f"expected {model_num_q} or {model_num_q + 1}"
                )
            self.q_ref_sem_raw = nn.Embedding.from_pretrained(
                question_ref_tensor, freeze=True, padding_idx=0
            ).to(device)
            mode = self.q_ref_projection_mode
            if mode in {"shared_zero_adapter", "shared", "shared_adapter"}:
                anchor_dim = int(self.sem_proj.in_features)
                if ref_dim != anchor_dim:
                    raise RuntimeError(
                        f"[SQAKT-B3] shared projection requires equal encoder dimensions: "
                        f"anchor={anchor_dim}, refinement={ref_dim}"
                    )
                self.q_ref_adapter_weight = nn.Parameter(
                    torch.zeros(self.d_model, ref_dim, device=device)
                )
                self.q_ref_sem_proj = None
            elif mode in {"independent_legacy", "independent"}:
                self.q_ref_adapter_weight = None
                self.q_ref_sem_proj = nn.Linear(ref_dim, self.d_model, bias=False).to(device)
                nn.init.xavier_uniform_(self.q_ref_sem_proj.weight)
            else:
                raise ValueError(
                    f"Unknown q_ref_projection_mode={self.q_ref_projection_mode}"
                )
            print(
                f"✅ [SQAKT-B3] loaded refinement bank: rows={self.q_ref_sem_raw.num_embeddings}, "
                f"feature_dim={ref_dim}, scale={self.q_ref_sem_scale}, gate={self.q_ref_gate_type}, "
                f"fusion={self.q_ref_fusion_mode}, projection={self.q_ref_projection_mode}"
            )
        if concept_tensor is not None and getattr(self, "use_c_sem", False):
            raise NotImplementedError(
                "当前先只支持 question-side structured prior；concept-side structured prior 后续再做。"
            )
    def forward(self, c, r, cshft=None, q=None, qshft=None, valid_mask=None, **kwargs):
        c = self._safe_c(c)
        r = r.long().clamp(min=0, max=1)

        if q is None:
            if self.num_q > 0 and self.emb_type == "qid":
                raise ValueError("SQAKT with emb_type='qid' requires q/question ids.")
            q = c
        q = self._safe_q(q)

        if cshft is None:
            raise ValueError("SQAKT requires cshft for next-question prediction.")
        if self.num_q > 0 and qshft is None:
            raise ValueError("SQAKT requires qshft for question-level prediction.")

        if valid_mask is None:
            valid_mask = kwargs.get("mask", kwargs.get("seq_mask", None))
        if valid_mask is None:
            raise ValueError("SQAKT.forward requires valid_mask when qmap/kcmap are 0-based.")
        valid = valid_mask.bool()


        c_cur = self._fuse_c(c)
        q_cur, q_sem_cur = self._fuse_q(q) if self.num_q > 0 else (c_cur, None)
        x = c_cur + q_cur + self.r_embed(r)

        if self.num_q > 0 and self.q_inject_mode == "strong" and q_sem_cur is not None:
            gx = torch.sigmoid(self.q_inter_gate(torch.cat([x, q_sem_cur], dim=-1)))
            x = x + gx * q_sem_cur
        x = self.input_norm(x)
        x = self.dropout(x)
        x = x.masked_fill(~valid.unsqueeze(-1), 0.0)

        # backbone
        if self.backbone_type == "gru":
            hist, _ = self.hist_gru(x)
        else:
            hist = self.hist_trans(x, valid)
        hist = self.dropout(hist)
        hist = torch.nan_to_num(hist, nan=0.0, posinf=0.0, neginf=0.0)

        # next query
        c_next = self._fuse_c(cshft)
        q_next, q_sem_next = self._fuse_q(qshft) if self.num_q > 0 else (c_next, None)

        query = self.input_norm(c_next + q_next)
        
        if self.num_q > 0 and self.q_inject_mode == "strong" and q_sem_next is not None:
            gq = torch.sigmoid(self.q_query_gate(torch.cat([query, q_sem_next], dim=-1)))
            query = query + gq * q_sem_next
        query = self.dropout(query)
        query = query.masked_fill(~valid.unsqueeze(-1), 0.0)

        ctx = self.retrieve(query=query, hist=hist, hist_mask=valid)
        state = self.state_norm(hist + ctx)
        state = torch.nan_to_num(state, nan=0.0, posinf=0.0, neginf=0.0)

        query_for_head = query
        if self.use_q_ref_sem and self.q_ref_fusion_mode == "target_state_gate":
            if self.q_ref_state_gate is None or self.q_ref_out is None:
                raise RuntimeError("[SQAKT-B3] target_state_gate modules were not initialized")
            q_ref_next = self._project_q_ref(qshft)
            if q_ref_next is None:
                raise RuntimeError("[SQAKT-B3] refinement bank is unavailable")
            rho = self._get_q_ref_weight(qshft)
            state_gate = torch.sigmoid(
                self.q_ref_state_gate(
                    torch.cat([state, q_ref_next, state * q_ref_next], dim=-1)
                )
            )
            ref_delta = self.q_ref_out(q_ref_next)
            query_for_head = self.q_ref_query_norm(
                query + self.q_ref_sem_scale * rho * state_gate * ref_delta
            )
            query_for_head = query_for_head.masked_fill(~valid.unsqueeze(-1), 0.0)

        logit = self.base_head(torch.cat([state, query_for_head], dim=-1)).squeeze(-1)
        # ---------- fold-specific calibrated / residual LLM prior ----------
        # Recommended residual setting:
        #   q_calib_prior_mode = "incorrect_delta"
        #   q_calib_value_col = "llm_residual_delta"
        # Since llm_residual_delta is an incorrect-rate residual,
        # init_q_calibrated_prior_from_csv has already converted it to correct-logit direction.
        if self.use_q_calib_prior and self.num_q > 0 and qshft is not None:
            q_prior = self._lookup_q_calib_prior(qshft)
            if q_prior is not None:
                logit = logit + self.q_calib_scale * q_prior
        logit = torch.nan_to_num(logit, nan=0.0, posinf=0.0, neginf=0.0)

        
        self.aux_loss = self._compute_aux_loss(
            state=state,
            query=query_for_head,
            cshft=cshft,
            qshft=qshft if self.num_q > 0 else None,
            valid=valid,
            logit=logit,
        )
        if not self._debug_printed:
            self._debug_printed = True
            with torch.no_grad():
                print(f"✅ [SQAKT-min] backbone={self.backbone_type}")
                print("✅ [SQAKT-min] hist:", tuple(hist.shape))
                print("✅ [SQAKT-min] query:", tuple(query.shape))
                print("✅ [SQAKT-min] logit:", tuple(logit.shape))
                print("✅ [SQAKT-min] gamma:", float(F.softplus(self.retrieve.gamma).detach().cpu()))

        return logit
