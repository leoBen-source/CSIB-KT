#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
S12-v2 scorer, canonical-fold event-universe repair.

Key contract
------------
1) The full S12 target universe is the canonical-content-safe group (expected 522).
2) Each outer-fold teacher is evaluated ONLY on target_qids assigned to that
   canonical content_group_fold.
3) Legacy S5 event_id / row_index / target_position are used only as frozen
   event coordinates and outcomes. The legacy "|ofX" suffix is NOT treated as
   the current canonical fold assignment.
4) Under the canonical full-cold fold, some legacy S5 events may no longer have
   >= min_warm_history legal preceding interactions. Those events are
   deterministically excluded BEFORE scoring. This is label-free and exactly
   matches the fold-clean history contract used by S11.
5) Final scored event identities must equal the deterministically legal
   fold-clean event set exactly; no silent skipping is allowed.
6) Every current cold target must retain at least one legal scored event.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import sys
from pathlib import Path

import pandas as pd
import torch


def qi(x):
    return int(float(x))


def parse_seq(x):
    out = []
    for z in str(x).split(","):
        try:
            out.append(qi(z))
        except Exception:
            out.append(-1)
    return out


def stable_hash(values):
    s = "\n".join(map(str, sorted(set(map(int, values)))))
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def load_json(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def resolve_event_source(event_template_csv: Path, explicit: str | None) -> Path:
    if explicit:
        p = Path(explicit).expanduser().resolve()
        if not p.is_file():
            raise FileNotFoundError(f"--event_source_csv does not exist: {p}")
        return p

    # The original P3-D2 coordinates were created from:
    #   .../p3_strict_cold_v1/cold_dataset/train_valid_sequences.csv
    # Search upward from the frozen event template path.
    et = event_template_csv.expanduser().resolve()
    starts = [et.parent] + list(et.parents)
    tried = []
    for parent in starts:
        for rel in (
            Path("cold_dataset") / "train_valid_sequences.csv",
            Path("cold_dataset") / "train_valid.csv",
        ):
            cand = (parent / rel).resolve()
            tried.append(str(cand))
            if cand.is_file():
                return cand

    raise FileNotFoundError(
        "Cannot resolve the legacy P3-D2 event-coordinate source. "
        "Pass --event_source_csv explicitly. Tried sample: "
        + repr(tried[:12])
    )


def load_teacher(base, run_dir):
    base_path = Path(base).resolve()
    ex = (base_path / "examples").resolve()
    for p in [str(base_path), str(ex)]:
        if p not in sys.path:
            sys.path.insert(0, p)
    os.chdir(ex)

    import semantic_patch  # noqa: F401
    from pykt.models import load_model

    cfg = load_json(Path(run_dir) / "config.json")
    params = cfg["params"]
    mc = copy.deepcopy(cfg["model_config"])
    for k in ["use_wandb", "learning_rate", "add_uuid", "l2"]:
        mc.pop(k, None)

    allcfg = copy.deepcopy(load_json(base_path / "configs" / "data_config.json"))
    ds = params["dataset_name"]
    if "data_config" in cfg:
        allcfg[ds].update(cfg["data_config"])
    if params.get("dataset_dir_override"):
        allcfg[ds]["dpath"] = params["dataset_dir_override"]

    allcfg[ds]["sqakt_set_aware"] = int(mc.get("kc_set_input", 0))
    allcfg[ds]["sqakt_kc_pooling"] = str(mc.get("kc_pooling", "mean"))
    if int(mc.get("kc_set_max_concepts", 0)) > 0:
        allcfg[ds]["max_concepts"] = int(mc["kc_set_max_concepts"])

    model = load_model(
        params["model_name"], mc, allcfg[ds], params["emb_type"], run_dir
    )

    if getattr(model, "model_name", "") != "sqakt" or not bool(
        getattr(model, "kc_set_input", False)
    ):
        raise RuntimeError("teacher must be set-aware SQAKT")
    if str(getattr(model, "q_item_parameterization", "")) != "id_only_cold_mask":
        raise RuntimeError("teacher must use q_item_parameterization=id_only_cold_mask")
    if str(getattr(model, "q_id_gate_type", "")).lower() not in {
        "cold_mask",
        "binary_seen",
    }:
        raise RuntimeError("teacher must use q_id_gate_type=cold_mask/binary_seen")
    if not bool(getattr(model, "q_strict_cold_zero_id", False)):
        raise RuntimeError("q_strict_cold_zero_id must be enabled")
    if not bool(getattr(model, "_q_support_loaded", False)):
        raise RuntimeError("train-only q support was not loaded")

    for flag in [
        "use_q_sem",
        "use_c_sem",
        "use_q_ref_sem",
        "use_q_calib_prior",
        "use_q_content_arbitration",
        "use_q_support_gate",
        "use_q_sem_delta",
        "use_c_sem_delta",
    ]:
        if bool(getattr(model, flag, False)):
            raise RuntimeError(f"teacher not clean: {flag}=1")

    model.eval()
    return model, cfg


def encode_hist(model, q, c, r, valid):
    c = model._safe_c(c)
    q = model._safe_q(q)
    ccur = model._fuse_c(c)
    qcur, _ = model._fuse_q(q)
    x = model.input_norm(ccur + qcur + model.r_embed(r.long().clamp(0, 1)))
    x = model.dropout(x)
    x = x.masked_fill(~valid.unsqueeze(-1), 0.0)

    if model.backbone_type == "gru":
        hist, _ = model.hist_gru(x)
    else:
        # SQAKT's transformer implementation is causal.
        hist = model.hist_trans(x, valid)

    hist = model.dropout(hist)
    return torch.nan_to_num(hist, nan=0.0, posinf=0.0, neginf=0.0)


def score_one(model, hist, valid, pos, qid, kcset):
    device = hist.device
    B, L, D = hist.shape
    if L <= 0 or pos < 0 or pos >= L:
        raise RuntimeError(f"invalid compressed-history scoring position pos={pos}, L={L}")

    qids = torch.tensor([qid], dtype=torch.long, device=device)
    kct = torch.tensor([kcset], dtype=torch.long, device=device)
    cnext = model._fuse_c(model._safe_c(kct))
    qnext, _ = model._fuse_q(model._safe_q(qids))
    query = model.input_norm(cnext + qnext)

    qfull = torch.zeros(B, L, D, device=device, dtype=hist.dtype)
    qfull[:, pos, :] = query
    ctx = model.retrieve(qfull, hist, valid)
    state = model.state_norm(hist[:, pos, :] + ctx[:, pos, :])
    return model.base_head(torch.cat([state, query], dim=-1)).squeeze(-1)


def pad_kcs(kcs, maxc):
    vals = sorted(set(map(int, kcs)))
    if len(vals) > maxc:
        raise RuntimeError(f"KC set too large for model maxc={maxc}: {vals}")
    return vals + [-1] * (maxc - len(vals))


def main():
    ap = argparse.ArgumentParser()

    ap.add_argument("--base", required=True)
    ap.add_argument("--teacher_run_dir", required=True)
    ap.add_argument("--dataset_root", required=True)  # retained for shell compatibility
    ap.add_argument("--group_item_csv", required=True)
    ap.add_argument("--event_template_csv", required=True)
    ap.add_argument("--q_to_kc_set_json", required=True)
    ap.add_argument("--outer_fold", type=int, required=True)
    ap.add_argument("--out_csv", required=True)

    ap.add_argument("--dataset_name", default="xes3g5m")
    ap.add_argument("--min_warm_history", type=int, default=1)

    ap.add_argument("--event_source_csv", default=None)
    ap.add_argument("--event_source_user_fold", type=int, default=None)

    ap.add_argument(
        "--expected_target_n",
        type=int,
        default=None,
        help="Expected size of the FULL canonical-content-safe target universe.",
    )
    ap.add_argument(
        "--required_qid",
        type=int,
        default=None,
        help="QID that must exist in the FULL target universe (e.g. 277).",
    )

    args = ap.parse_args()

    base = Path(args.base).resolve()
    group_path = Path(args.group_item_csv).resolve()
    event_template_path = Path(args.event_template_csv).resolve()
    out_path = Path(args.out_csv).resolve()

    # ------------------------------------------------------------------
    # A. Full target-universe contract
    # ------------------------------------------------------------------
    group = pd.read_csv(group_path, low_memory=False)
    need_group = {"target_qid", "content_group_fold"}
    if not need_group.issubset(group.columns):
        raise RuntimeError(
            f"group_item_csv missing columns: {sorted(need_group - set(group.columns))}"
        )

    if group["target_qid"].duplicated().any():
        dup = (
            group.loc[group["target_qid"].duplicated(keep=False), "target_qid"]
            .astype(int)
            .head(20)
            .tolist()
        )
        raise RuntimeError(f"duplicate target_qid in full group sample={dup}")

    full_targets = set(group["target_qid"].astype(int))
    if args.expected_target_n is not None and len(full_targets) != int(
        args.expected_target_n
    ):
        raise RuntimeError(
            f"full target universe mismatch: got={len(full_targets)} "
            f"expected={int(args.expected_target_n)}"
        )
    if args.required_qid is not None and int(args.required_qid) not in full_targets:
        raise RuntimeError(
            f"required qid missing from full target universe: qid={int(args.required_qid)}"
        )

    cold = set(
        group.loc[
            group["content_group_fold"].astype(int) == int(args.outer_fold),
            "target_qid",
        ].astype(int)
    )
    if not cold:
        raise RuntimeError(f"empty canonical cold fold outer_fold={args.outer_fold}")

    # ------------------------------------------------------------------
    # B. Teacher / fold-clean training provenance
    # ------------------------------------------------------------------
    model, cfg = load_teacher(base, args.teacher_run_dir)
    dsroot = Path(cfg["params"].get("dataset_dir_override", "")).resolve()
    manp = dsroot / "foldclean_manifest_v2.json"
    if not manp.is_file():
        raise RuntimeError(f"teacher dataset lacks fold-clean manifest: {manp}")
    man = load_json(manp)

    if man.get("exclusion_scope") != "all_selected_items":
        raise RuntimeError("Shared teacher must exclude all selected items")
    if set(map(int, man["cold_qids"])) != full_targets:
        raise RuntimeError("Shared teacher exclusion set differs from full target bank")
    if man["cold_qid_sha256"] != stable_hash(full_targets):
        raise RuntimeError("Shared teacher cold hash mismatch")
    if int(man.get("cold_interactions_remaining", 0)) != 0:
        raise RuntimeError(
            f"teacher fold-clean manifest has cold interactions remaining: "
            f"{man.get('cold_interactions_remaining')}"
        )

    support = load_json(man["q_support_train_json"])
    bad_support = {
        q: int(support.get(str(q), 0))
        for q in sorted(cold)
        if int(support.get(str(q), 0)) != 0
    }
    if bad_support:
        raise RuntimeError(
            "target train support nonzero sample="
            + repr(list(bad_support.items())[:20])
        )

    device = next(model.parameters()).device
    maxc = int(
        getattr(model, "kc_set_max_concepts", 0)
        or cfg["model_config"].get("kc_set_max_concepts", 1)
    )

    qraw = load_json(args.q_to_kc_set_json)
    qkc = {
        qi(q): tuple(sorted(set(map(int, cs))))
        for q, cs in qraw.items()
    }
    missing_kc = sorted(cold - set(qkc))
    if missing_kc:
        raise RuntimeError(
            f"canonical cold targets missing official KC mapping sample={missing_kc[:20]}"
        )

    # Audit target-ID-free behavior.
    with torch.inference_mode():
        tq = torch.tensor(sorted(cold), dtype=torch.long, device=device)
        w = model._get_q_id_residual_weight(tq).detach().cpu()
        if float(w.abs().max()) > 1e-12:
            raise RuntimeError(
                f"cold q-ID residual gate is not zero: max={float(w.abs().max())}"
            )

        qfeat, _ = model._fuse_q(model._safe_q(tq))
        ref = qfeat[:1].expand_as(qfeat)
        id_invariance = float((qfeat - ref).abs().max().detach().cpu())
        if id_invariance > 1e-6:
            raise RuntimeError(
                "zero-support q representation is target-dependent: "
                f"maxdiff={id_invariance}"
            )

    # ------------------------------------------------------------------
    # C. Frozen event coordinates, filtered by CURRENT canonical target fold
    # ------------------------------------------------------------------
    ev_all = pd.read_csv(event_template_path, low_memory=False)
    need_ev = {
        "event_id",
        "target_qid",
        "student_key",
        "row_index",
        "target_position",
        "label",
        "target_kc_key",
    }
    if not need_ev.issubset(ev_all.columns):
        raise RuntimeError(
            f"event template missing columns: {sorted(need_ev - set(ev_all.columns))}"
        )

    # One event identity only. Do NOT use the legacy event outer_fold/ofX
    # as the current canonical fold assignment.
    ev_all = ev_all.drop_duplicates("event_id").copy()
    ev = ev_all[ev_all["target_qid"].astype(int).isin(cold)].copy()

    observed_targets = set(ev["target_qid"].astype(int))
    if observed_targets != cold:
        missing = sorted(cold - observed_targets)
        extra = sorted(observed_targets - cold)
        raise RuntimeError(
            f"frozen event template canonical target coverage mismatch "
            f"missing={missing[:20]} extra={extra[:20]}"
        )

    # ------------------------------------------------------------------
    # D. Resolve exact P3-D2 coordinate source
    # ------------------------------------------------------------------
    source_csv = resolve_event_source(event_template_path, args.event_source_csv)
    seq = pd.read_csv(source_csv, low_memory=False)

    if "fold" not in seq.columns:
        raise RuntimeError(
            f"{source_csv}: missing fold column required by original P3-D2 contract"
        )

    if args.event_source_user_fold is None:
        source_user_fold = int(cfg.get("params", {}).get("fold", -999))
        if source_user_fold < 0:
            raise RuntimeError(
                "Cannot infer event source user fold; pass --event_source_user_fold."
            )
    else:
        source_user_fold = int(args.event_source_user_fold)

    seq = seq[seq["fold"].astype(int) == source_user_fold].copy()
    if seq.empty:
        raise RuntimeError(
            f"no event-source rows for fold={source_user_fold}: {source_csv}"
        )

    # Keep ORIGINAL pandas indices after filtering: row_index is defined in
    # this coordinate system.
    rowmap = {int(i): r for i, r in seq.iterrows()}
    byrow = {
        int(k): g.copy()
        for k, g in ev.groupby(ev["row_index"].astype(int), sort=True)
    }

    # Fail before GPU scoring if any frozen coordinate/outcome is wrong.
    mismatch = []
    for ridx, eg in byrow.items():
        if ridx not in rowmap:
            mismatch.append(
                {"row_index": ridx, "reason": "row_index_absent"}
            )
            if len(mismatch) >= 20:
                break
            continue

        rr = rowmap[ridx]
        qs0 = parse_seq(rr["questions"])
        rs0 = parse_seq(rr["responses"])
        if len(qs0) != len(rs0):
            mismatch.append(
                {"row_index": ridx, "reason": "source_q_r_length_mismatch"}
            )
            if len(mismatch) >= 20:
                break
            continue

        for er in eg.itertuples(index=False):
            pos0 = int(er.target_position)
            tq0 = int(er.target_qid)
            y0 = int(er.label)
            if pos0 < 0 or pos0 >= len(qs0):
                mismatch.append(
                    {
                        "row_index": ridx,
                        "target_qid": tq0,
                        "target_position": pos0,
                        "reason": "target_position_out_of_range",
                    }
                )
            elif int(qs0[pos0]) != tq0 or int(rs0[pos0]) != y0:
                mismatch.append(
                    {
                        "row_index": ridx,
                        "target_qid": tq0,
                        "target_position": pos0,
                        "template_label": y0,
                        "source_qid": int(qs0[pos0]),
                        "source_label": int(rs0[pos0]),
                        "reason": "template_source_mismatch",
                    }
                )
            if len(mismatch) >= 20:
                break

        if len(mismatch) >= 20:
            break

    if mismatch:
        raise RuntimeError(
            "legacy event coordinates do not match ORIGINAL P3-D2 source; "
            f"source={source_csv} fold={source_user_fold} first={mismatch[:5]}"
        )

    print(
        f"[S12][EVENT_SOURCE_OK] source={source_csv} "
        f"user_fold={source_user_fold} event_rows={len(ev)} "
        f"unique_source_rows={len(byrow)}"
    )

    # ------------------------------------------------------------------
    # E. Build deterministic CANONICAL fold-clean legal event universe
    # ------------------------------------------------------------------
    legal_event_ids = set()
    warm_k_by_event = {}
    excluded_rows = []

    for ridx, eg in byrow.items():
        row = rowmap[ridx]
        qs = parse_seq(row["questions"])
        rs = parse_seq(row["responses"])

        warm_pos = []
        for pos, (q, y) in enumerate(zip(qs, rs)):
            q = int(q)
            y = int(y)
            if q < 0 or y not in (0, 1):
                continue
            if q in full_targets:
                continue
            if q not in qkc:
                continue
            warm_pos.append(pos)

        for er in eg.itertuples(index=False):
            eid = str(er.event_id)
            pos = int(er.target_position)
            tqid = int(er.target_qid)
            k = sum(1 for wp in warm_pos if wp < pos)

            if k < int(args.min_warm_history):
                excluded_rows.append(
                    {
                        "event_id": eid,
                        "row_index": int(ridx),
                        "target_position": pos,
                        "target_qid": tqid,
                        "canonical_outer_fold": int(args.outer_fold),
                        "legal_warm_history_len": int(k),
                        "required_min_warm_history": int(args.min_warm_history),
                        "reason": "no_legal_foldclean_warm_history",
                    }
                )
            else:
                legal_event_ids.add(eid)
                warm_k_by_event[eid] = int(k)

    frozen_event_ids = set(ev["event_id"].astype(str))
    excluded_event_ids = {str(x["event_id"]) for x in excluded_rows}

    if legal_event_ids & excluded_event_ids:
        raise RuntimeError("internal error: event both legal and excluded")
    if legal_event_ids | excluded_event_ids != frozen_event_ids:
        missing_partition = sorted(
            frozen_event_ids - legal_event_ids - excluded_event_ids
        )
        raise RuntimeError(
            f"event legality partition incomplete sample={missing_partition[:20]}"
        )

    legal_targets = set(
        ev.loc[
            ev["event_id"].astype(str).isin(legal_event_ids),
            "target_qid",
        ].astype(int)
    )
    if legal_targets != cold:
        lost = sorted(cold - legal_targets)
        raise RuntimeError(
            "canonical fold-clean history removes ALL evaluable events for some "
            f"targets; cannot preserve full target universe. lost={lost[:30]}"
        )

    excluded_df = pd.DataFrame(excluded_rows)
    excluded_path = Path(str(out_path) + ".excluded_no_legal_history.csv")
    excluded_path.parent.mkdir(parents=True, exist_ok=True)
    if excluded_df.empty:
        pd.DataFrame(
            columns=[
                "event_id",
                "row_index",
                "target_position",
                "target_qid",
                "canonical_outer_fold",
                "legal_warm_history_len",
                "required_min_warm_history",
                "reason",
            ]
        ).to_csv(excluded_path, index=False)
    else:
        excluded_df.to_csv(excluded_path, index=False)

    print(
        f"[S12][LEGAL_EVENT_UNIVERSE] outer={args.outer_fold} "
        f"frozen_events={len(frozen_event_ids)} "
        f"legal_events={len(legal_event_ids)} "
        f"excluded_no_history={len(excluded_event_ids)} "
        f"targets={len(legal_targets)}"
    )
    if excluded_rows:
        print(
            "[S12][LEGAL_EVENT_EXCLUSION_SAMPLE] "
            + repr([x["event_id"] for x in excluded_rows[:12]])
        )

    # ------------------------------------------------------------------
    # F. Score ONLY the deterministic legal fold-clean event set
    # ------------------------------------------------------------------
    rows = []

    with torch.inference_mode():
        for ridx, eg in byrow.items():
            row = rowmap[ridx]
            qs = parse_seq(row["questions"])
            rs = parse_seq(row["responses"])
            if len(qs) != len(rs):
                raise RuntimeError(f"source row {ridx}: q/r length mismatch")

            warm_pos = []
            qw, rw, cw = [], [], []
            for pos, (q, y) in enumerate(zip(qs, rs)):
                q = int(q)
                y = int(y)
                if q < 0 or y not in (0, 1):
                    continue
                if q in full_targets or q not in qkc:
                    continue
                warm_pos.append(pos)
                qw.append(q)
                rw.append(y)
                cw.append(pad_kcs(qkc[q], maxc))

            if not qw:
                # This is allowed only if this row has no legal target events.
                row_eids = set(eg["event_id"].astype(str))
                bad = row_eids & legal_event_ids
                if bad:
                    raise RuntimeError(
                        f"row={ridx} has legal target events but no warm sequence "
                        f"sample={sorted(bad)[:10]}"
                    )
                continue

            qt = torch.tensor(qw, dtype=torch.long, device=device)[None, :]
            rt = torch.tensor(rw, dtype=torch.long, device=device)[None, :]
            ct = torch.tensor(cw, dtype=torch.long, device=device)[None, :, :]
            valid_all = torch.ones(
                (1, len(qw)), dtype=torch.bool, device=device
            )
            hist_all = encode_hist(model, qt, ct, rt, valid_all)

            for er in eg.itertuples(index=False):
                eid = str(er.event_id)
                if eid not in legal_event_ids:
                    continue

                tqid = int(er.target_qid)
                pos = int(er.target_position)
                y = int(er.label)

                if int(qs[pos]) != tqid or int(rs[pos]) != y:
                    raise RuntimeError(
                        f"template/source mismatch row={ridx} pos={pos}: "
                        f"template={tqid}/{y} source={qs[pos]}/{rs[pos]}"
                    )

                k = sum(1 for wp in warm_pos if wp < pos)
                k_expected = int(warm_k_by_event[eid])
                if k != k_expected:
                    raise RuntimeError(
                        f"warm-history recomputation mismatch event={eid}: "
                        f"preflight={k_expected} scoring={k}"
                    )
                if k < int(args.min_warm_history):
                    raise RuntimeError(
                        f"legal event unexpectedly has insufficient history: "
                        f"event={eid} k={k}"
                    )

                kc = pad_kcs(qkc[tqid], maxc)
                logit = score_one(
                    model,
                    hist_all[:, :k],
                    valid_all[:, :k],
                    k - 1,
                    tqid,
                    kc,
                )[0]

                rows.append(
                    {
                        "event_id": eid,
                        "student_key": str(er.student_key),
                        "row_index": int(ridx),
                        "target_position": pos,
                        "target_qid": tqid,
                        # Current canonical fold, NOT legacy event-id suffix.
                        "outer_fold": int(args.outer_fold),
                        "target_kc_key": str(er.target_kc_key),
                        "label": y,
                        "warm_history_len": int(k),
                        "teacher_kc_uniform": float(
                            torch.sigmoid(logit).detach().cpu()
                        ),
                    }
                )

    z = pd.DataFrame(rows)
    if z.empty:
        raise RuntimeError("no target-ID-free scored events")
    if z["event_id"].duplicated().any():
        dup = (
            z.loc[z["event_id"].duplicated(keep=False), "event_id"]
            .head(20)
            .tolist()
        )
        raise RuntimeError(f"duplicate scored event identities sample={dup}")

    actual_ids = set(z["event_id"].astype(str))
    if actual_ids != legal_event_ids:
        missing = sorted(legal_event_ids - actual_ids)
        extra = sorted(actual_ids - legal_event_ids)
        raise RuntimeError(
            "S12 scored event identities differ from deterministic fold-clean "
            f"LEGAL set: expected={len(legal_event_ids)} actual={len(actual_ids)} "
            f"missing_sample={missing[:10]} extra_sample={extra[:10]}"
        )

    scored_targets = set(z["target_qid"].astype(int))
    if scored_targets != cold:
        missing = sorted(cold - scored_targets)
        extra = sorted(scored_targets - cold)
        raise RuntimeError(
            f"scored canonical target coverage mismatch "
            f"missing={missing[:20]} extra={extra[:20]}"
        )

    if set(z["outer_fold"].astype(int)) != {int(args.outer_fold)}:
        raise RuntimeError("output outer_fold column is not canonical current fold")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    z.to_csv(out_path, index=False)

    summary = {
        "schema_version": "s12a_shared_teacher_v1_canonical_event_repair",
        "outer_fold": int(args.outer_fold),
        "full_target_universe_n": int(len(full_targets)),
        "canonical_cold_target_n": int(len(cold)),
        "scored_target_n": int(z["target_qid"].nunique()),
        "frozen_template_event_n_current_canonical_fold": int(len(frozen_event_ids)),
        "legal_foldclean_event_n": int(len(legal_event_ids)),
        "excluded_no_legal_history_n": int(len(excluded_event_ids)),
        "scored_event_n": int(len(z)),
        "excluded_event_csv": str(excluded_path),
        "event_source_csv": str(source_csv),
        "event_source_user_fold": int(source_user_fold),
        "cold_qid_sha256": stable_hash(cold),
        "cold_qid_gate_max_abs": float(w.abs().max()),
        "cold_q_representation_max_pairdiff": float(id_invariance),
        "required_qid": (
            None if args.required_qid is None else int(args.required_qid)
        ),
        "required_qid_in_full_universe": (
            None
            if args.required_qid is None
            else bool(int(args.required_qid) in full_targets)
        ),
        "event_identity_contract": (
            "Legacy S5 event coordinates/outcomes are frozen, but the evaluable "
            "event universe is deterministically re-derived under the CURRENT "
            "canonical full-cold fold. Events with < min_warm_history legal "
            "preceding warm interactions are excluded label-free before scoring. "
            "Scored identities must exactly equal this legal set."
        ),
        "legacy_event_id_note": (
            "The '|ofX' suffix embedded in legacy event_id reflects the old "
            "pre-canonical fold assignment and is not used as the current "
            "canonical outer fold."
        ),
        "target_id_free_contract": (
            "target train support=0; target q-ID residual gate=0; all zero-support "
            "target q representations are identical; target official KC/KC-set "
            "remains the only target-specific KT query input."
        ),
    }

    manifest_path = Path(str(out_path) + ".manifest.json")
    manifest_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
