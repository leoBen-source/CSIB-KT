import json
import types
from collections import OrderedDict

import torch
import torch.nn as nn


def count_params(model):
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    frozen = total - trainable
    return {
        "total": int(total),
        "trainable": int(trainable),
        "frozen": int(frozen),
    }


def named_param_shapes(model):
    out = OrderedDict()
    for n, p in model.named_parameters():
        out[n] = {
            "shape": list(p.shape),
            "numel": int(p.numel()),
            "requires_grad": bool(p.requires_grad),
        }
    return out


def diff_added_params(before_param_dict, after_model):
    after_param_dict = named_param_shapes(after_model)
    added = OrderedDict()
    removed = OrderedDict()
    changed = OrderedDict()

    for n, meta in after_param_dict.items():
        if n not in before_param_dict:
            added[n] = meta
        else:
            if before_param_dict[n]["shape"] != meta["shape"] or \
               before_param_dict[n]["requires_grad"] != meta["requires_grad"]:
                changed[n] = {
                    "before": before_param_dict[n],
                    "after": meta,
                }

    for n, meta in before_param_dict.items():
        if n not in after_param_dict:
            removed[n] = meta

    return added, removed, changed


def optimizer_membership(model, opt):
    pid_to_group = {}
    for gi, group in enumerate(opt.param_groups):
        lr = group.get("lr", None)
        wd = group.get("weight_decay", None)
        for p in group["params"]:
            pid_to_group[id(p)] = {
                "group_idx": gi,
                "lr": float(lr) if lr is not None else None,
                "weight_decay": float(wd) if wd is not None else None,
            }

    rows = []
    for n, p in model.named_parameters():
        info = pid_to_group.get(id(p), None)
        rows.append({
            "name": n,
            "shape": list(p.shape),
            "requires_grad": bool(p.requires_grad),
            "in_optimizer": info is not None,
            "group_idx": None if info is None else info["group_idx"],
            "lr": None if info is None else info["lr"],
            "weight_decay": None if info is None else info["weight_decay"],
        })
    return rows


def infer_patch_behavior(model):
    meta = {
        "has_patch_meta": hasattr(model, "patch_meta"),
        "patch_meta": getattr(model, "patch_meta", None),
        "has_aux_loss": hasattr(model, "aux_loss"),
        "forward_name": None,
        "changes_forward_graph": False,
    }

    if hasattr(model, "forward"):
        f = model.forward
        if isinstance(f, types.MethodType):
            meta["forward_name"] = getattr(f.__func__, "__name__", str(f))
        else:
            meta["forward_name"] = getattr(f, "__name__", str(f))

    # heuristic
    if hasattr(model, "q_sem_fuser"):
        meta["changes_forward_graph"] = True
    if hasattr(model, "model") and hasattr(model.model, "que_emb") and \
       hasattr(model.model.que_emb, "q_sem_fuser"):
        meta["changes_forward_graph"] = True

    return meta


def audit_model_patch(before_param_dict, after_model, save_path=None):
    summary = {
        "param_count": count_params(after_model),
        "patch_behavior": infer_patch_behavior(after_model),
    }

    added, removed, changed = diff_added_params(before_param_dict, after_model)
    summary["added_params"] = added
    summary["removed_params"] = removed
    summary["changed_params"] = changed

    if save_path is not None:
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

    return summary


def print_patch_audit(summary, prefix="[PATCH-AUDIT]"):
    pc = summary["param_count"]
    print(f"{prefix} total={pc['total']}, trainable={pc['trainable']}, frozen={pc['frozen']}")
    pb = summary["patch_behavior"]
    print(f"{prefix} forward_name={pb['forward_name']}, changes_forward_graph={pb['changes_forward_graph']}")
    print(f"{prefix} has_aux_loss={pb['has_aux_loss']}")
    if pb["patch_meta"] is not None:
        print(f"{prefix} patch_meta={pb['patch_meta']}")

    print(f"{prefix} added_params={len(summary['added_params'])}")
    for n, meta in summary["added_params"].items():
        print(f"  + {n}: shape={meta['shape']}, numel={meta['numel']}, requires_grad={meta['requires_grad']}")
