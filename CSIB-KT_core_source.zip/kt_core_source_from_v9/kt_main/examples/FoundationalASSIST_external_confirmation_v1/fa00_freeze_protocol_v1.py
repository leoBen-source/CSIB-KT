#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Freeze FoundationalASSIST confirmatory protocol before any synthetic generation."""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
from fa_common import sha256_file
from fa04_generate_qwen_reasoning_ladder_v1 import POLICIES, SYSTEM

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--expected_audit_json",required=True)
    ap.add_argument("--contract_manifest",required=True)
    ap.add_argument("--contract_csv",required=True)
    ap.add_argument("--generation_bank",required=True)
    ap.add_argument("--scoring_bank",required=True)
    ap.add_argument("--prompt_audit",required=True)
    ap.add_argument("--model_name_or_path",required=True)
    ap.add_argument("--out_json",required=True)
    ap.add_argument("--acknowledge_no_synthetic_or_downstream_results_seen",required=True)
    args=ap.parse_args()
    if args.acknowledge_no_synthetic_or_downstream_results_seen!="YES":
        raise SystemExit("Refusing to freeze without explicit acknowledgement.")

    expected=json.load(open(args.expected_audit_json,encoding="utf-8"))
    manifest=json.load(open(args.contract_manifest,encoding="utf-8"))
    pa=json.load(open(args.prompt_audit,encoding="utf-8"))
    if manifest.get("selection_uses_human_correctness") is not False:
        raise RuntimeError("Target selection must be human-outcome-free.")
    if int(pa.get("items_over_limit",1)) != 0:
        raise RuntimeError("Prompt audit failed.")

    # Pin the exact locally audited dataset version.
    for name, expected_sha in expected["sha256"].items():
        actual=manifest["input_sha256"].get(name)
        if actual != expected_sha:
            raise RuntimeError(f"Dataset hash mismatch for {name}: expected {expected_sha}, got {actual}")

    policy_blob=json.dumps({"POLICIES":POLICIES,"SYSTEM":SYSTEM},sort_keys=True)
    policy_sha=hashlib.sha256(policy_blob.encode()).hexdigest()
    out=Path(args.out_json)
    out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists():
        raise RuntimeError(f"Frozen protocol already exists; refusing overwrite: {out}")

    protocol={
        "schema_version":"foundationalassist_external_confirmation_v1",
        "status":"FROZEN_BEFORE_QWEN_AND_DOWNSTREAM_RESULTS",
        "dataset_role":"independent external confirmatory dataset",
        "dataset_version":{
            "interactions_rows":expected["interactions_rows"],
            "unique_students":expected["unique_students"],
            "interaction_unique_problem_ids":expected["interaction_unique_problem_ids"],
            "input_sha256":expected["sha256"],
        },
        "target_contract":{
            "answer_type":"Multiple Choice; single-select only",
            "exact_duplicate_rows":"collapse",
            "ambiguous_same_problem_id_versions":"exclude entire problem_id",
            "visual_dependent":"exclude",
            "minimum_total_first_exposures":manifest["min_total_first_exposures"],
            "minimum_eval_first_exposures":manifest["min_eval_first_exposures"],
            "minimum_eval_strict_first_exposures":manifest["min_eval_strict_first_exposures"],
            "knowledge_requirement":"non-empty skill set; exact-skill-set peer outside held-out item fold",
            "content_grouping":"same Problem Set Id or canonical duplicate content never split across folds",
            "target_n":manifest["target_n"],
            "fold_sizes":manifest["fold_sizes"],
        },
        "student_split":{
            "train_pct":70,"valid_pct":15,"eval_pct":15,
            "seed":manifest["student_split_seed"],
        },
        "item_folds":{
            "n_folds":manifest["n_folds"],
            "seed":manifest["fold_seed"],
        },
        "scoring_interface":{
            "generation_bank_has_answer_key":False,
            "scoring_bank_physically_separate":True,
            "valid_surface":"one option letter A.. or exact option text",
            "readout_repair":"outcome-independent transcription only; unlabeled options + frozen solver outputs; no question text, answer key, or human response",
        },
        "synthetic_population":{
            "model_name_or_path":str(args.model_name_or_path),
            "policies":POLICIES,
            "replicas_per_policy":2,
            "population_size":20,
            "generation_seed":20260828,
            "max_input_tokens":int(pa["max_input_tokens_frozen"]),
            "policy_system_sha256":policy_sha,
        },
        "qualification_protocol":"measurement_qualification_final_v3; frozen on XES3G5M before ASSISTments downstream results",
        "guardrails":{
            "target_selection_uses_human_correctness":False,
            "qualification_PASS_does_not_guarantee_positive_NLL_or_HRS":True,
            "no_threshold_or_contract_changes_after_generation_or_downstream_inspection":True,
        },
        "artifact_sha256":{
            "contract_manifest":sha256_file(args.contract_manifest),
            "contract_csv":sha256_file(args.contract_csv),
            "generation_bank":sha256_file(args.generation_bank),
            "scoring_bank":sha256_file(args.scoring_bank),
            "prompt_audit":sha256_file(args.prompt_audit),
        },
    }
    out.write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(protocol,ensure_ascii=False,indent=2))
    print("FROZEN_PROTOCOL_SHA256",sha256_file(out))

if __name__=="__main__":
    main()
