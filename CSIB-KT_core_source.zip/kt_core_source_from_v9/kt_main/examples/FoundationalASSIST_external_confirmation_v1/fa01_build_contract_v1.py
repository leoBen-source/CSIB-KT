#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FoundationalASSIST confirmatory target-contract builder.

STRICT INFORMATION RULE:
- target selection/fold assignment never loads discrete_score, answer_text, hint_count,
  saw_answer, or any other human outcome.
- official answer metadata is used only to verify that a problem has a deterministic
  single-choice scoring interface; it is not used to rank/select by difficulty.
- exact duplicate rows are collapsed.
- if one problem_id maps to >1 distinct Problems-row version, that problem_id is
  excluded from all target and history use.
- items from the same Problem Set and exact/canonical duplicate items are kept in
  the same content fold.
"""
from __future__ import annotations
import argparse, json
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
from fa_common import (
    UnionFind, answer_type_is_single_mc, find_col, norm_for_hash, qid_str,
    resolve_official_single_mc_answer, sha_text, sha256_file, split_mc_options,
    user_bucket, visual_like
)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--n_folds", type=int, default=5)
    ap.add_argument("--fold_seed", type=int, default=20260828)
    ap.add_argument("--student_split_seed", type=int, default=20260828)
    ap.add_argument("--train_user_pct", type=int, default=70)
    ap.add_argument("--valid_user_pct", type=int, default=15)
    ap.add_argument("--min_total_first_exposures", type=int, default=100)
    ap.add_argument("--min_eval_first_exposures", type=int, default=30)
    ap.add_argument("--min_eval_strict_first_exposures", type=int, default=30)
    ap.add_argument("--min_targets", type=int, default=50)
    args = ap.parse_args()

    data = Path(args.data_dir).resolve()
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    p_problem = data / "Problems.csv"
    p_skill = data / "Skills.csv"
    p_inter = data / "Interactions.csv"
    for p in (p_problem, p_skill, p_inter):
        if not p.is_file():
            raise FileNotFoundError(p)

    P0 = pd.read_csv(p_problem, low_memory=False)
    S = pd.read_csv(p_skill, low_memory=False)

    pid = find_col(P0, ["problem_id"])
    body = find_col(P0, ["Problem Body", "problem_body"])
    atype = find_col(P0, ["Answer Types", "answer_type"])
    opts_col = find_col(P0, ["Multiple Choice Options", "multiple_choice_options"])
    ans_col = find_col(P0, ["Multiple Choice Answers", "multiple_choice_answers"])
    pset = find_col(P0, ["Problem Set Id", "problem_set_id"], required=False)
    ppart = find_col(P0, ["Problem Part", "problem_part"], required=False)

    spid = find_col(S, ["problem_id"])
    skill = find_col(S, ["skill_id"])

    # Collapse byte/value-identical rows first. Any remaining multi-version ID is ambiguous.
    P1 = P0.drop_duplicates().copy()
    P1["_qid"] = P1[pid].map(qid_str)
    version_n = P1.groupby("_qid").size()
    ambiguous = sorted(version_n[version_n > 1].index.astype(str))
    P = P1[~P1["_qid"].isin(ambiguous)].copy()
    if P["_qid"].duplicated().any():
        raise RuntimeError("Problems deduplication failed.")

    S = S.copy()
    S["_qid"] = S[spid].map(qid_str)
    S = S[~S["_qid"].isin(ambiguous)]
    skillmap = defaultdict(set)
    for r in S[["_qid", skill]].dropna().itertuples(index=False, name=None):
        skillmap[str(r[0])].add(str(r[1]))

    # Interactions: deliberately read ONLY identity and time; no correctness/outcome column is loaded.
    hdr = pd.read_csv(p_inter, nrows=0)
    iq = find_col(hdr, ["problem_id"])
    iu = find_col(hdr, ["user_xid", "user_id", "student_id"])
    it = find_col(hdr, ["end_time"], required=False)
    usecols = [iq, iu] + ([it] if it else [])
    I = pd.read_csv(p_inter, usecols=usecols, low_memory=False)
    I["_qid"] = I[iq].map(qid_str)
    I["_user"] = I[iu].astype(str)
    I["_row"] = np.arange(len(I), dtype=np.int64)
    I = I[~I["_qid"].isin(ambiguous)].copy()
    if it:
        I["_time"] = pd.to_datetime(I[it], errors="coerce", utc=True)
    else:
        I["_time"] = pd.NaT

    def usplit(u):
        b = user_bucket(u, args.student_split_seed)
        if b < args.train_user_pct:
            return "train"
        if b < args.train_user_pct + args.valid_user_pct:
            return "valid"
        return "eval"
    users = pd.DataFrame({"user_xid": sorted(I["_user"].unique())})
    users["user_split"] = users["user_xid"].map(usplit)
    users.to_csv(out / "foundationalassist_user_split.csv", index=False)
    split_map = dict(zip(users.user_xid, users.user_split))
    I["_split"] = I["_user"].map(split_map)

    first = I.sort_values(["_user", "_time", "_row"], kind="mergesort").drop_duplicates(["_user", "_qid"])
    total_support = first["_qid"].value_counts().to_dict()
    eval_support = first[first["_split"] == "eval"]["_qid"].value_counts().to_dict()

    records = []
    exclusion = Counter()
    scoring_exclusions = []
    for _, r in P.iterrows():
        q = str(r["_qid"])
        if not answer_type_is_single_mc(r[atype]):
            exclusion["not_single_multiple_choice"] += 1
            continue
        options = split_mc_options(r[opts_col])
        if len(options) < 2 or len(options) > 26:
            exclusion["invalid_option_count"] += 1
            continue
        answer_raw = "" if pd.isna(r[ans_col]) else str(r[ans_col])

        # Frozen-before-generation structural scoring-interface check.
        # This uses only official item metadata, never human outcomes.
        correct_index, scoring_reason = resolve_official_single_mc_answer(
            r[opts_col], answer_raw
        )
        if correct_index is None:
            exclusion["non_deterministic_mc_scoring_interface"] += 1
            scoring_exclusions.append({
                "target_qid": q,
                "reason": scoring_reason,
                "option_n": len(options),
                "official_answer_sha256": sha_text(answer_raw),
            })
            continue

        raw_visual = str(r[body]) + " " + str(r[opts_col])
        if visual_like(raw_visual):
            exclusion["visual_dependent"] += 1
            continue
        if not str(r[body]).strip() or str(r[body]).strip().lower() in {"nan", "none"}:
            exclusion["empty_problem_body"] += 1
            continue
        ks = tuple(sorted(skillmap.get(q, set())))
        if not ks:
            exclusion["no_skill"] += 1
            continue
        n_total = int(total_support.get(q, 0))
        n_eval = int(eval_support.get(q, 0))
        if n_total < args.min_total_first_exposures:
            exclusion["insufficient_total_first_exposure"] += 1
            continue
        if n_eval < args.min_eval_first_exposures:
            exclusion["insufficient_eval_first_exposure"] += 1
            continue
        canonical = sha_text(
            norm_for_hash(r[body]) + " || OPTIONS: " +
            " || ".join(norm_for_hash(x) for x in options)
        )
        problem_set = ""
        if pset and pd.notna(r[pset]):
            problem_set = str(r[pset]).strip()
        records.append({
            "target_qid": q,
            "target_kc_key": "|".join(ks),
            "kc_n": len(ks),
            "canonical_content_id": canonical,
            "problem_set_id": problem_set,
            "problem_part": "" if not ppart or pd.isna(r[ppart]) else str(r[ppart]),
            "response_support_total": n_total,
            "eval_first_exposure_support": n_eval,
            "question_type": "multiple_choice",
        })

    d = pd.DataFrame(records)
    if d.empty:
        raise RuntimeError("No eligible items after structural filters.")

    # Exact skill-set must occur at least twice before content grouping.
    keep = d.groupby("target_kc_key")["target_qid"].transform("count") >= 2
    exclusion["singleton_exact_skillset"] += int((~keep).sum())
    d = d[keep].copy().reset_index(drop=True)

    # Build leakage-safe content groups: union same Problem Set and same canonical content.
    qids = d["target_qid"].astype(str).tolist()
    uf = UnionFind(qids)
    for _, g in d.groupby("canonical_content_id", sort=True):
        xs = g["target_qid"].astype(str).tolist()
        for x in xs[1:]:
            uf.union(xs[0], x)
    nz = d[d["problem_set_id"].astype(str).str.len() > 0]
    for _, g in nz.groupby("problem_set_id", sort=True):
        xs = g["target_qid"].astype(str).tolist()
        for x in xs[1:]:
            uf.union(xs[0], x)
    comps = defaultdict(list)
    for q in qids:
        comps[uf.find(q)].append(q)
    group_id = {}
    for root, xs in comps.items():
        gid = sha_text("||".join(sorted(xs)))
        for q in xs:
            group_id[q] = gid
    d["content_group_id"] = d["target_qid"].map(group_id)

    # Deterministic, group-safe 5-fold assignment that also tries to distribute skill sets.
    fold_load = [0] * args.n_folds
    skill_load = defaultdict(int)
    assigned = {}
    groups = []
    for gid, g in d.groupby("content_group_id", sort=True):
        skill_counts = Counter(g["target_kc_key"].astype(str))
        groups.append((gid, g["target_qid"].astype(str).tolist(), skill_counts, len(g)))
    groups.sort(key=lambda z: sha_text(f"{args.fold_seed}|{z[0]}"))
    for gid, qs, skill_counts, n in groups:
        def cost(f):
            skill_cost = sum(skill_load[(sk, f)] * cnt for sk, cnt in skill_counts.items())
            return (skill_cost, fold_load[f], f)
        f = min(range(args.n_folds), key=cost)
        assigned[gid] = f
        fold_load[f] += n
        for sk, cnt in skill_counts.items():
            skill_load[(sk, f)] += cnt
    d["content_group_fold"] = d["content_group_id"].map(assigned).astype(int)

    # Strict first exposure: target can be evaluated only after >=1 legal warm event
    # when the entire target item fold is excluded from that student's history.
    fold_of = dict(zip(d.target_qid.astype(str), d.content_group_fold.astype(int)))
    cold_by_fold = {
        f: set(d.loc[d.content_group_fold == f, "target_qid"].astype(str))
        for f in range(args.n_folds)
    }
    valid_history_qids = set(skillmap.keys()) - set(ambiguous)
    strict_support = defaultdict(int)
    ez = I[I["_split"] == "eval"].sort_values(["_user", "_time", "_row"], kind="mergesort")
    for _, ug in ez.groupby("_user", sort=False):
        seen_targets = set()
        warm_count = {f: 0 for f in range(args.n_folds)}
        for rr in ug[["_qid"]].itertuples(index=False, name=None):
            q = str(rr[0])
            if q in fold_of and q not in seen_targets:
                f = fold_of[q]
                if warm_count[f] >= 1:
                    strict_support[q] += 1
                seen_targets.add(q)
            if q in valid_history_qids:
                for f in range(args.n_folds):
                    if q not in cold_by_fold[f]:
                        warm_count[f] += 1

    d["eval_strict_first_exposure_support"] = d["target_qid"].map(
        lambda q: int(strict_support.get(str(q), 0))
    )
    ok = d["eval_strict_first_exposure_support"] >= args.min_eval_strict_first_exposures
    exclusion["insufficient_strict_eval_first_exposure"] += int((~ok).sum())
    d = d[ok].copy().reset_index(drop=True)

    # Every target must retain an exact-skill-set peer outside its own held-out fold.
    changed = True
    while changed:
        changed = False
        bad = []
        for r in d.itertuples(index=False):
            peers = d[
                (d.target_kc_key == r.target_kc_key)
                & (d.content_group_fold.astype(int) != int(r.content_group_fold))
            ]
            if peers.empty:
                bad.append(str(r.target_qid))
        if bad:
            exclusion["no_exact_skill_peer_outside_fold"] += len(bad)
            d = d[~d.target_qid.astype(str).isin(bad)].copy().reset_index(drop=True)
            changed = True

    if len(d) < args.min_targets:
        raise RuntimeError(f"Only {len(d)} targets remain; min_targets={args.min_targets}. Do NOT relax after outcomes.")
    folds = sorted(d.content_group_fold.astype(int).unique())
    if folds != list(range(args.n_folds)):
        raise RuntimeError(f"Incomplete folds after filtering: {folds}")
    if (d.groupby("content_group_id").content_group_fold.nunique() > 1).any():
        raise RuntimeError("Content/problem-set group split across folds.")

    d = d.sort_values(["content_group_fold", "target_kc_key", "content_group_id", "target_qid"]).reset_index(drop=True)
    d.to_csv(out / "foundationalassist_strict_group_contract.csv", index=False)
    pd.DataFrame(
        scoring_exclusions,
        columns=["target_qid","reason","option_n","official_answer_sha256"]
    ).to_csv(out / "scoring_interface_exclusions.csv", index=False)

    manifest = {
        "schema_version": "foundationalassist_strict_contract_v1",
        "status": "CANDIDATE_CONTRACT_BEFORE_QWEN_GENERATION",
        "target_n": int(len(d)),
        "fold_sizes": {str(int(k)): int(v) for k, v in d.content_group_fold.value_counts().sort_index().items()},
        "exact_skillset_n": int(d.target_kc_key.nunique()),
        "content_group_n": int(d.content_group_id.nunique()),
        "ambiguous_problem_ids_excluded": ambiguous,
        "ambiguous_problem_id_n": len(ambiguous),
        "selection_uses_human_correctness": False,
        "interaction_columns_loaded_for_selection": usecols,
        "answer_type": "Multiple Choice only; single-select only",
        "scoring_interface_rule": (
            "official answer must map deterministically to exactly one displayed option; "
            "exact/raw then conservative exact normalization only; otherwise exclude before freeze"
        ),
        "scoring_interface_exclusion_n": int(len(scoring_exclusions)),
        "visual_dependent_items_excluded": True,
        "content_grouping": "same Problem Set Id OR exact/canonical duplicate content -> same fold",
        "n_folds": args.n_folds,
        "fold_seed": args.fold_seed,
        "student_split_seed": args.student_split_seed,
        "user_split_pct": {
            "train": args.train_user_pct,
            "valid": args.valid_user_pct,
            "eval": 100 - args.train_user_pct - args.valid_user_pct,
        },
        "min_total_first_exposures": args.min_total_first_exposures,
        "min_eval_first_exposures": args.min_eval_first_exposures,
        "min_eval_strict_first_exposures": args.min_eval_strict_first_exposures,
        "min_exact_skillset_size_before_folding": 2,
        "requires_exact_skillset_peer_outside_heldout_fold": True,
        "exclusion_counts": dict(exclusion),
        "input_sha256": {
            "Interactions.csv": sha256_file(p_inter),
            "Problems.csv": sha256_file(p_problem),
            "Skills.csv": sha256_file(p_skill),
        },
    }
    (out / "foundationalassist_contract_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
