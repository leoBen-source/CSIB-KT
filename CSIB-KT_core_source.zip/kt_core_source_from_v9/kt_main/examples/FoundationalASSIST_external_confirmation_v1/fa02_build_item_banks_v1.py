#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build physically separated generation/scoring banks for FoundationalASSIST."""
from __future__ import annotations
import argparse, json
from pathlib import Path
import pandas as pd
from fa_common import (
    answer_type_is_single_mc, clean_html_text, find_col,
    resolve_official_single_mc_answer, qid_str, sha256_file, split_mc_options
)

FORBIDDEN_GEN_KEYS = {
    "answer_spec","answer_raw","accepted","correct_answer","correct_index",
    "correct_letter","is_correct","explanation","hint","difficulty","difficulty_level"
}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", required=True)
    ap.add_argument("--contract_csv", required=True)
    ap.add_argument("--out_dir", required=True)
    args = ap.parse_args()
    data = Path(args.data_dir)
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    P0 = pd.read_csv(data / "Problems.csv", low_memory=False)
    g = pd.read_csv(args.contract_csv, dtype={"target_qid": str}, low_memory=False)
    pid = find_col(P0, ["problem_id"])
    body = find_col(P0, ["Problem Body","problem_body"])
    atype = find_col(P0, ["Answer Types","answer_type"])
    opts_col = find_col(P0, ["Multiple Choice Options","multiple_choice_options"])
    ans_col = find_col(P0, ["Multiple Choice Answers","multiple_choice_answers"])
    pset = find_col(P0, ["Problem Set Id","problem_set_id"], required=False)
    ppart = find_col(P0, ["Problem Part","problem_part"], required=False)

    P1 = P0.drop_duplicates().copy()
    P1["_qid"] = P1[pid].map(qid_str)
    multi = set(P1.groupby("_qid").size().loc[lambda s: s > 1].index.astype(str))
    P = P1[~P1["_qid"].isin(multi)].copy().set_index("_qid", drop=False)

    fg = (out / "fa_item_generation_bank.jsonl").open("w", encoding="utf-8")
    fs = (out / "fa_item_scoring_bank.jsonl").open("w", encoding="utf-8")
    rows = []
    try:
        for r in g.itertuples(index=False):
            q = str(r.target_qid)
            if q not in P.index:
                raise RuntimeError(f"Target qid={q} is absent/ambiguous in Problems.csv")
            m = P.loc[q]
            if not answer_type_is_single_mc(m[atype]):
                raise RuntimeError(f"Target qid={q} is no longer single-choice Multiple Choice")
            options = split_mc_options(m[opts_col])
            if len(options) < 2 or len(options) > 26:
                raise RuntimeError(f"qid={q} invalid options: n={len(options)}")
            answer = clean_html_text(m[ans_col])
            correct_index, scoring_reason = resolve_official_single_mc_answer(
                m[opts_col], m[ans_col]
            )
            if correct_index is None:
                raise RuntimeError(
                    f"qid={q}: contract/bank inconsistency: scoring interface became invalid; "
                    f"reason={scoring_reason}. Rebuild the contract with the patched fa01."
                )
            content = clean_html_text(m[body])
            if not content:
                raise RuntimeError(f"qid={q} empty cleaned content")

            gen = {
                "qid": q,
                "raw_qid": q,
                "content_group_fold": int(r.content_group_fold),
                "content_group_id": str(r.content_group_id),
                "canonical_content_id": str(r.canonical_content_id),
                "target_kc_key": str(r.target_kc_key),
                "question_type": "multiple_choice",
                "content": content,
                "options": options,
                "problem_set_id": "" if not pset or pd.isna(m[pset]) else str(m[pset]),
                "problem_part": "" if not ppart or pd.isna(m[ppart]) else str(m[ppart]),
            }
            bad = FORBIDDEN_GEN_KEYS & set(gen)
            if bad:
                raise RuntimeError(f"Forbidden answer-bearing generation keys: {bad}")
            score = dict(gen)
            score.update({
                "correct_index": correct_index,
                "correct_letter": "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[correct_index],
                "answer_raw": answer,
            })
            fg.write(json.dumps(gen, ensure_ascii=False) + "\n")
            fs.write(json.dumps(score, ensure_ascii=False) + "\n")
            rows.append({
                "qid": q,
                "option_n": len(options),
                "correct_index": correct_index,
                "scoring_resolution_method": scoring_reason,
                "content_chars": len(content),
                "fold": int(r.content_group_fold),
            })
    finally:
        fg.close(); fs.close()

    z = pd.DataFrame(rows)
    z.to_csv(out / "fa_item_bank_audit.csv", index=False)
    summary = {
        "schema_version": "foundationalassist_item_bank_v1",
        "item_n": int(len(z)),
        "generation_bank": "fa_item_generation_bank.jsonl",
        "scoring_bank": "fa_item_scoring_bank.jsonl",
        "generation_bank_contains_answer_keys": False,
        "scoring_rule": "single listed option; generator may emit option letter or exact option text",
        "sha256": {
            "generation_bank": sha256_file(out / "fa_item_generation_bank.jsonl"),
            "scoring_bank": sha256_file(out / "fa_item_scoring_bank.jsonl"),
        },
    }
    (out / "item_bank_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
