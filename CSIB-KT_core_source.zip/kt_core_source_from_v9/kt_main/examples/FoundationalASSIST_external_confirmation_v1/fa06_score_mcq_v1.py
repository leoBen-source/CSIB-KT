#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Strict single-choice scoring using the physically separate scoring bank."""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
import pandas as pd
from fa_common import LETTERS, normalize_choice_text

def resolve_choice(pred,options):
    s=str(pred or "").strip()
    if len(s)==1 and s.upper() in LETTERS[:len(options)]:
        return LETTERS.index(s.upper()),True,"letter"
    m=re.match(r"^\s*(?:option|choice|answer)?\s*([A-Za-z])(?:\s*[.)\]:：、\-]\s*|\s+).*$",s,re.I)
    if m and m.group(1).upper() in LETTERS[:len(options)]:
        return LETTERS.index(m.group(1).upper()),True,"letter_prefix"
    n=normalize_choice_text(s)
    hits=[i for i,x in enumerate(options) if normalize_choice_text(x)==n]
    if len(hits)==1: return hits[0],True,"option_text"
    return -1,False,"unresolved"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--scoring_bank",required=True)
    ap.add_argument("--responses_jsonl",required=True)
    ap.add_argument("--out_dir",required=True)
    ap.add_argument("--min_scoring_coverage",type=float,default=.98)
    args=ap.parse_args()
    out=Path(args.out_dir);out.mkdir(parents=True,exist_ok=True)
    bank={}
    for line in Path(args.scoring_bank).read_text(encoding="utf-8").splitlines():
        if line.strip():
            x=json.loads(line);bank[str(x["qid"])]=x
    rows=[];methods={}
    for line in Path(args.responses_jsonl).read_text(encoding="utf-8").splitlines():
        if not line.strip(): continue
        r=json.loads(line);q=str(r["qid"])
        if q not in bank: raise RuntimeError(f"qid={q} absent from scoring bank")
        item=bank[q]
        idx,valid,why=resolve_choice(r.get("final_answer",""),item["options"])
        correct=int(valid and idx==int(item["correct_index"]))
        methods[why]=methods.get(why,0)+1
        rows.append({
            "qid":q,"policy_id":r["policy_id"],"replica":int(r["replica"]),
            "synthetic_student_id":r["synthetic_student_id"],
            "final_answer":r.get("final_answer",""),
            "chosen_index":idx if valid else -1,
            "correct":correct,"scoring_valid":int(valid),"score_method":why,
            "attempts":int(r.get("attempts",1)),
            "reasoning_budget":int(r.get("reasoning_budget",0)),
            "thinking":int(bool(r.get("thinking",False))),
            "modal_vote_count":int(r.get("modal_vote_count",1)),
            "readout_repair_applied":int(r.get("readout_repair_applied",0)),
        })
    df=pd.DataFrame(rows)
    df.to_csv(out/"synthetic_response_matrix_v2.csv",index=False)
    item_valid=df.groupby("qid").scoring_valid.min()
    coverage=float(item_valid.mean()) if len(item_valid) else 0.0
    ps=df.groupby("synthetic_student_id").agg(
        accuracy=("correct","mean"),valid_fraction=("scoring_valid","mean"),response_n=("qid","count")
    ).reset_index()
    ps.to_csv(out/"synthetic_student_raw_accuracy.csv",index=False)
    summary={
        "schema_version":"foundationalassist_strict_mcq_scorer_v1",
        "item_n":len(bank),"response_n":int(len(df)),
        "item_scoring_coverage":coverage,
        "overall_accuracy":float(df.loc[df.scoring_valid==1,"correct"].mean()) if len(df) else None,
        "student_accuracy_min":float(ps.accuracy.min()) if len(ps) else None,
        "student_accuracy_max":float(ps.accuracy.max()) if len(ps) else None,
        "student_accuracy_sd":float(ps.accuracy.std(ddof=0)) if len(ps) else None,
        "score_method_counts":methods,
    }
    (out/"summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print(json.dumps(summary,indent=2))
    if coverage < args.min_scoring_coverage:
        raise RuntimeError(f"Scoring coverage {coverage:.4f} < {args.min_scoring_coverage:.4f}")
if __name__=="__main__": main()
