#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fail-closed population completeness check; does not impose an accuracy threshold."""
from __future__ import annotations
import argparse,json
from pathlib import Path
import pandas as pd

POLICY_IDS=[
"p00_direct_48","p10_direct_96","p20_reason_128","p30_reason_256","p40_reason_512",
"p50_verify_640","p60_sc3_reason256","p70_sc5_reason256","p80_sc3_verify512","p90_decompose768"
]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--contract_csv",required=True)
    ap.add_argument("--response_csv",required=True)
    ap.add_argument("--out_json",required=True)
    args=ap.parse_args()
    g=pd.read_csv(args.contract_csv,dtype={"target_qid":str})
    r=pd.read_csv(args.response_csv,dtype={"qid":str})
    exp={(str(q),p,rep) for q in g.target_qid for p in POLICY_IDS for rep in (0,1)}
    got={(str(x.qid),str(x.policy_id),int(x.replica)) for x in r.itertuples(index=False)}
    dup=int(r.duplicated(["qid","policy_id","replica"]).sum())
    missing=sorted(exp-got)[:100]
    extra=sorted(got-exp)[:100]
    valid=float(r.scoring_valid.mean()) if len(r) else 0.0
    ok=(len(got)==len(exp) and not missing and not extra and dup==0 and valid>=.98)
    z={
        "schema_version":"foundationalassist_population_completeness_v1",
        "status":"PASS" if ok else "FAIL_CLOSED",
        "target_n":int(len(g)),"expected_response_n":int(len(exp)),
        "actual_unique_response_keys":int(len(got)),"duplicate_identity_n":dup,
        "missing_first100":missing,"extra_first100":extra,
        "scoring_valid_fraction":valid,
        "accuracy_is_not_a_gate":True,
    }
    Path(args.out_json).write_text(json.dumps(z,indent=2),encoding="utf-8")
    print(json.dumps(z,indent=2))
    if not ok: raise SystemExit(3)
if __name__=="__main__": main()
