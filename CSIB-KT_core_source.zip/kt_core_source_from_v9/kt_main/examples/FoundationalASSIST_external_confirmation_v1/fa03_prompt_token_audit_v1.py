#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tokenizer-only prompt-length audit. No model generation and no answer key."""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
from transformers import AutoTokenizer
from fa04_generate_qwen_reasoning_ladder_v1 import POLICIES, SYSTEM, item_prompt, apply_template

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--generation_bank",required=True)
    ap.add_argument("--model_name_or_path",required=True)
    ap.add_argument("--out_json",required=True)
    ap.add_argument("--max_input_tokens",type=int,default=8192)
    ap.add_argument("--local_files_only",action="store_true")
    args=ap.parse_args()
    items=[json.loads(x) for x in Path(args.generation_bank).read_text(encoding="utf-8").splitlines() if x.strip()]
    tok=AutoTokenizer.from_pretrained(args.model_name_or_path,local_files_only=args.local_files_only,trust_remote_code=True)
    lengths=[]
    worst=[]
    for item in items:
        mx=0
        for p in POLICIES:
            chat=apply_template(tok,[{"role":"system","content":SYSTEM},{"role":"user","content":item_prompt(item,p)}],p["thinking"])
            n=len(tok.encode(chat,add_special_tokens=False))
            mx=max(mx,n)
        lengths.append(mx)
        worst.append((mx,str(item["qid"])))
    worst.sort(reverse=True)
    z={
        "schema_version":"foundationalassist_prompt_token_audit_v1",
        "item_n":len(items),
        "max_input_tokens_frozen":args.max_input_tokens,
        "max_observed":int(max(lengths) if lengths else 0),
        "p95_observed":float(np.quantile(lengths,.95)) if lengths else 0,
        "p99_observed":float(np.quantile(lengths,.99)) if lengths else 0,
        "items_over_limit":int(sum(n>args.max_input_tokens for n in lengths)),
        "worst_20":[{"qid":q,"tokens":int(n)} for n,q in worst[:20]],
        "uses_answer_key":False,
        "runs_generation":False,
    }
    Path(args.out_json).write_text(json.dumps(z,indent=2),encoding="utf-8")
    print(json.dumps(z,indent=2))
    if z["items_over_limit"]:
        raise SystemExit("FAIL-CLOSED: prompt limit exceeded before protocol freeze. Do not generate.")

if __name__=="__main__":
    main()
