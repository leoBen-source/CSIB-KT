#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import hashlib, html, json, re, unicodedata
from collections import defaultdict
from pathlib import Path

LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def sha256_file(path):
    p = Path(path)
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()

def sha_text(x):
    return hashlib.sha256(str(x).encode("utf-8")).hexdigest()

def find_col(df, names, required=True):
    low = {str(c).strip().lower(): c for c in df.columns}
    for n in names:
        k = str(n).strip().lower()
        if k in low:
            return low[k]
    if required:
        raise RuntimeError(f"None of columns {names} found in {list(df.columns)}")
    return None

def qid_str(x):
    s = str(x).strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s

def norm_space(x):
    return re.sub(r"\s+", " ", str(x or "")).strip()

def clean_html_text(x):
    s = html.unescape(str(x or ""))
    s = re.sub(r"<\s*br\s*/?\s*>", "\n", s, flags=re.I)
    s = re.sub(r"</\s*p\s*>", "\n", s, flags=re.I)
    s = re.sub(r"</\s*li\s*>", "\n", s, flags=re.I)
    s = re.sub(r"<\s*li\b[^>]*>", "- ", s, flags=re.I)
    s = re.sub(r"<[^>]+>", " ", s)
    s = s.replace("\xa0", " ")
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n\s*\n+", "\n", s)
    return s.strip()

def norm_for_hash(x):
    s = unicodedata.normalize("NFKC", clean_html_text(x)).lower()
    return re.sub(r"\s+", " ", s).strip()

def visual_like(x):
    s = str(x or "").lower()
    return int(bool(re.search(
        r"<\s*img\b|data:image|https?://\S+\.(?:png|jpg|jpeg|gif|svg|webp)"
        r"|\b(?:image|figure|diagram)\s*\d*\b\s*(?:below|above|shown)"
        r"|\[(?:image|figure|diagram)\]",
        s
    )))

def split_mc_options(x):
    if x is None:
        return []
    s = str(x)
    if not s.strip() or s.strip().lower() in {"nan", "none", "n/a"}:
        return []
    return [clean_html_text(v) for v in s.split("||") if clean_html_text(v)]

def normalize_choice_text(x):
    s = unicodedata.normalize("NFKC", clean_html_text(x)).strip().lower()
    s = re.sub(r"\s+", " ", s)
    return s.strip(" .。;；,，")


def resolve_official_single_mc_answer(options_raw, answer_raw):
    """
    Deterministically map FoundationalASSIST's official single-choice answer
    to exactly one displayed option.

    Resolution order is conservative:
      1) exact raw option-text match (closest to the dataset's documented format);
      2) exact HTML/whitespace-normalized match;
      3) exact NFKC/punctuation-normalized match.

    No substring/fuzzy/numeric-equivalence matching is used.
    If the mapping is absent or ambiguous, return (None, reason) so the item can
    be excluded BEFORE target-contract freeze and BEFORE any Qwen generation.
    """
    raw = "" if answer_raw is None else str(answer_raw)
    if not raw.strip() or raw.strip().lower() in {"nan", "none", "n/a"}:
        return None, "empty_official_answer"
    if "||" in raw:
        return None, "multiple_correct_surface"

    raw_opts = []
    if options_raw is not None:
        sx = str(options_raw)
        if sx.strip() and sx.strip().lower() not in {"nan", "none", "n/a"}:
            raw_opts = [v.strip() for v in sx.split("||") if v.strip()]

    if len(raw_opts) < 2:
        return None, "invalid_option_count"

    ans0 = raw.strip()

    hits = [i for i, x in enumerate(raw_opts) if x == ans0]
    if len(hits) == 1:
        return int(hits[0]), "exact_raw"
    if len(hits) > 1:
        return None, "ambiguous_exact_raw"

    ans1 = clean_html_text(ans0)
    opts1 = [clean_html_text(x) for x in raw_opts]
    hits = [i for i, x in enumerate(opts1) if x == ans1]
    if len(hits) == 1:
        return int(hits[0]), "exact_clean_html"
    if len(hits) > 1:
        return None, "ambiguous_clean_html"

    ans2 = normalize_choice_text(ans0)
    opts2 = [normalize_choice_text(x) for x in raw_opts]
    hits = [i for i, x in enumerate(opts2) if x == ans2]
    if len(hits) == 1:
        return int(hits[0]), "exact_normalized"
    if len(hits) > 1:
        return None, "ambiguous_normalized"

    return None, "official_answer_not_in_option_list"

def answer_type_is_single_mc(x):
    return norm_space(x).lower() == "multiple choice"

def user_bucket(user, seed):
    return int(sha_text(f"{seed}|{user}")[:12], 16) % 100

class UnionFind:
    def __init__(self, xs):
        self.p = {x: x for x in xs}
        self.r = {x: 0 for x in xs}
    def find(self, x):
        p = self.p[x]
        if p != x:
            self.p[x] = self.find(p)
        return self.p[x]
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return
        if self.r[ra] < self.r[rb]:
            ra, rb = rb, ra
        self.p[rb] = ra
        if self.r[ra] == self.r[rb]:
            self.r[ra] += 1
