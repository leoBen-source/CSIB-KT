#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Verify frozen protocol hashes before generation."""
from __future__ import annotations
import argparse, json
from fa_common import sha256_file
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--protocol",required=True)
    ap.add_argument("--contract_manifest",required=True)
    ap.add_argument("--contract_csv",required=True)
    ap.add_argument("--generation_bank",required=True)
    ap.add_argument("--scoring_bank",required=True)
    ap.add_argument("--prompt_audit",required=True)
    args=ap.parse_args()
    p=json.load(open(args.protocol,encoding="utf-8"))
    pairs={
        "contract_manifest":args.contract_manifest,
        "contract_csv":args.contract_csv,
        "generation_bank":args.generation_bank,
        "scoring_bank":args.scoring_bank,
        "prompt_audit":args.prompt_audit,
    }
    for k,path in pairs.items():
        got=sha256_file(path); exp=p["artifact_sha256"][k]
        if got!=exp: raise RuntimeError(f"Frozen artifact changed: {k}: {got} != {exp}")
    print("FROZEN_INPUTS_VERIFIED")
if __name__=="__main__": main()
