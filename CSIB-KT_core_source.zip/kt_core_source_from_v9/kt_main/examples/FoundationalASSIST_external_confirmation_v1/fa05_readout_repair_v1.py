#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Outcome-independent terminal-answer readout repair for FoundationalASSIST.

It never loads the scoring bank, answer key, human responses, or problem text.
It uses only unlabeled options plus the already completed solver outputs.
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from fa_common import LETTERS, normalize_choice_text

SYSTEM = """You are a strict answer-readout adapter, not a problem solver.
Do not solve a new question and do not add reasoning.
You receive unlabeled answer options and outputs from an already completed solver.
Infer which listed option the solver output most strongly supports.
Return exactly one JSON object such as {"final_answer":"B"} and nothing else.
"""

def surface_to_letter(text, options):
    s=str(text or "").strip()
    if len(s)==1 and s.upper() in LETTERS[:len(options)]:
        return s.upper(), True, "single_letter"
    m=re.match(r"^\s*(?:option|choice|answer)?\s*([A-Za-z])(?:\s*[.)\]:：、\-]\s*|\s+).*$",s,re.I)
    if m and m.group(1).upper() in LETTERS[:len(options)]:
        return m.group(1).upper(), True, "letter_prefix"
    n=normalize_choice_text(s)
    hits=[i for i,x in enumerate(options) if normalize_choice_text(x)==n]
    if len(hits)==1:
        return LETTERS[hits[0]], True, "exact_option_text"
    return "", False, "unresolved"

def parse_adapter(text,nopt):
    s=str(text or "")
    hits=re.findall(r'"final_answer"\s*:\s*"([A-Za-z])"',s)
    if hits and hits[-1].upper() in LETTERS[:nopt]:
        return hits[-1].upper(),True
    hits=re.findall(r'(?<![A-Za-z])([A-Za-z])(?![A-Za-z])',s)
    for x in reversed(hits):
        if x.upper() in LETTERS[:nopt]:
            return x.upper(),True
    return "",False

def build_prompt(item,rec):
    lines=["Options (labels are for transcription only):"]
    for i,x in enumerate(item.get("options",[]) or []):
        lines.append(f"{LETTERS[i]}. {x}")
    lines+=["","Existing candidate answer strings from the frozen solver:"]
    for i,x in enumerate(rec.get("candidate_answers",[]) or []):
        lines.append(f"candidate_{i+1}: {x}")
    fails=rec.get("raw_parse_failures",[]) or []
    if fails:
        lines+=["","Incomplete frozen solver traces:"]
        for i,x in enumerate(fails):
            lines += [f"trace_{i+1}:", str(x)[-12000:]]
    lines+=["","Transcribe the most supported option. JSON only."]
    return "\n".join(lines)

def chat(tok,text):
    return tok.apply_chat_template(
        [{"role":"system","content":SYSTEM},{"role":"user","content":text}],
        tokenize=False, add_generation_prompt=True
    )

def next_token_fallback(model,tok,prompt,nopt):
    prefix_text=prompt+"\nFinal option letter:"
    prefix=tok(prefix_text,return_tensors="pt",truncation=True,max_length=8180,add_special_tokens=False)
    prefix_ids=prefix["input_ids"][0].tolist()
    scores=[]
    for c in LETTERS[:nopt]:
        cand=tok.encode(" "+c,add_special_tokens=False) or tok.encode(c,add_special_tokens=False)
        ids=torch.tensor([prefix_ids+cand],dtype=torch.long,device=model.device)
        attn=torch.ones_like(ids)
        with torch.inference_mode():
            logits=model(input_ids=ids,attention_mask=attn).logits[0]
        lp=torch.log_softmax(logits,dim=-1)
        base=len(prefix_ids); score=0.0
        for j,tok_id in enumerate(cand):
            score += float(lp[base+j-1,int(tok_id)].item())
        scores.append(score)
    return LETTERS[int(torch.tensor(scores).argmax().item())]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--generation_bank",required=True)
    ap.add_argument("--solver_responses",required=True)
    ap.add_argument("--model_name_or_path",required=True)
    ap.add_argument("--out_jsonl",required=True)
    ap.add_argument("--audit_json",required=True)
    ap.add_argument("--local_files_only",action="store_true")
    ap.add_argument("--batch_size",type=int,default=8)
    args=ap.parse_args()

    bank={}
    for line in Path(args.generation_bank).read_text(encoding="utf-8").splitlines():
        if line.strip():
            x=json.loads(line); bank[str(x["qid"])]=x
    records=[json.loads(x) for x in Path(args.solver_responses).read_text(encoding="utf-8").splitlines() if x.strip()]
    if not records: raise RuntimeError("No solver responses.")

    # Resolve all already-valid surfaces without a model first.
    need_idx=[]
    for i,r in enumerate(records):
        q=str(r["qid"]); item=bank.get(q)
        if item is None: raise RuntimeError(f"qid={q} missing from generation bank")
        _,ok,_=surface_to_letter(r.get("final_answer",""),item["options"])
        if not ok:
            need_idx.append(i)

    tok=None; model=None
    decoded={}
    if need_idx:
        tok=AutoTokenizer.from_pretrained(args.model_name_or_path,local_files_only=args.local_files_only,trust_remote_code=True)
        if tok.pad_token_id is None: tok.pad_token=tok.eos_token
        tok.padding_side="left"
        dtype=torch.bfloat16 if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else (
            torch.float16 if torch.cuda.is_available() else torch.float32)
        model=AutoModelForCausalLM.from_pretrained(
            args.model_name_or_path,local_files_only=args.local_files_only,trust_remote_code=True,
            torch_dtype=dtype,device_map="auto")
        model.eval()
        for st in range(0,len(need_idx),args.batch_size):
            inds=need_idx[st:st+args.batch_size]
            prompts=[chat(tok,build_prompt(bank[str(records[i]["qid"])],records[i])) for i in inds]
            enc=tok(prompts,return_tensors="pt",padding=True,truncation=True,max_length=8192).to(model.device)
            with torch.inference_mode():
                y=model.generate(**enc,max_new_tokens=12,do_sample=False,
                                 pad_token_id=tok.pad_token_id,eos_token_id=tok.eos_token_id)
            plen=enc["input_ids"].shape[1]
            for i,yy in zip(inds,y):
                decoded[i]=tok.decode(yy[plen:],skip_special_tokens=True)

    repaired=0; fallback=0; direct=0; methods={}
    out=Path(args.out_jsonl); out.parent.mkdir(parents=True,exist_ok=True)
    tmp=out.with_suffix(out.suffix+".tmp")
    if tmp.exists(): tmp.unlink()
    with tmp.open("w",encoding="utf-8") as fo:
        for i,r in enumerate(records):
            q=str(r["qid"]); item=bank[q]; opts=item["options"]
            letter,ok,method=surface_to_letter(r.get("final_answer",""),opts)
            adapter_raw=""
            if ok:
                direct+=1
                final=letter
                method="surface_"+method
            else:
                repaired+=1
                adapter_raw=decoded.get(i,"")
                final,ok2=parse_adapter(adapter_raw,len(opts))
                if ok2:
                    method="greedy_json_readout"
                else:
                    final=next_token_fallback(model,tok,chat(tok,build_prompt(item,r)),len(opts))
                    fallback+=1
                    method="candidate_likelihood_fallback"
            z=dict(r)
            z["source_final_answer"]=r.get("final_answer","")
            z["final_answer"]=final
            z["readout_repair_applied"]=int(not ok)
            z["readout_method"]=method
            z["readout_raw"]=adapter_raw
            z["readout_valid"]=int(final in LETTERS[:len(opts)])
            if not z["readout_valid"]:
                raise RuntimeError(f"Invalid repaired readout qid={q}: {final!r}")
            methods[method]=methods.get(method,0)+1
            fo.write(json.dumps(z,ensure_ascii=False)+"\n")
    tmp.replace(out)
    audit={
        "schema_version":"foundationalassist_readout_repair_v1",
        "record_n":len(records),"direct_surface_n":direct,"repair_n":repaired,
        "fallback_n":fallback,"readout_valid_fraction":1.0,
        "method_counts":methods,
        "loads_answer_key":False,"loads_human_responses":False,"loads_question_text":False,
    }
    Path(args.audit_json).write_text(json.dumps(audit,indent=2),encoding="utf-8")
    print(json.dumps(audit,indent=2))

if __name__=="__main__": main()
