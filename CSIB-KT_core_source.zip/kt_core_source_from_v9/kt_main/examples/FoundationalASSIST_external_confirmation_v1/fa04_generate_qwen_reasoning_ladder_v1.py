#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Qwen synthetic-response generation for FoundationalASSIST.

Frozen design matches the XES/DBE 10-policy reasoning ladder:
10 policy slots x 2 replicas. Official answers are physically absent from input.
"""
from __future__ import annotations
import argparse, json, re
from collections import Counter
from pathlib import Path
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

POLICIES = [
    dict(id="p00_direct_48", thinking=False, max_new=48, temperature=.90, attempts=1,
         instruction="Answer directly with minimal computation. Do not double-check."),
    dict(id="p10_direct_96", thinking=False, max_new=96, temperature=.65, attempts=1,
         instruction="Solve directly and concisely. Use brief mental work if needed."),
    dict(id="p20_reason_128", thinking=True, max_new=160, temperature=.70, attempts=1,
         instruction="Reason through the necessary steps before committing to the final answer."),
    dict(id="p30_reason_256", thinking=True, max_new=300, temperature=.65, attempts=1,
         instruction="Work step by step and preserve intermediate quantities carefully."),
    dict(id="p40_reason_512", thinking=True, max_new=560, temperature=.55, attempts=1,
         instruction="Use a complete solution with enough scratch reasoning to avoid arithmetic and condition-tracking errors."),
    dict(id="p50_verify_640", thinking=True, max_new=700, temperature=.45, attempts=1,
         instruction="Solve carefully, then independently verify the final arithmetic/logic before answering."),
    dict(id="p60_sc3_reason256", thinking=True, max_new=320, temperature=.75, attempts=3,
         instruction="Solve the item independently. This response will be combined with other independent attempts by majority agreement."),
    dict(id="p70_sc5_reason256", thinking=True, max_new=320, temperature=.80, attempts=5,
         instruction="Solve independently with ordinary step-by-step reasoning. Multiple independent attempts will be aggregated."),
    dict(id="p80_sc3_verify512", thinking=True, max_new=580, temperature=.60, attempts=3,
         instruction="Solve carefully and verify. Multiple independent verified attempts will be aggregated."),
    dict(id="p90_decompose768", thinking=True, max_new=820, temperature=.40, attempts=2,
         instruction="Use a teacher-style decomposition: identify the mathematical structure, solve fully, then check the result with a second route or sanity check.")
]

SYSTEM = """Actually solve the educational multiple-choice item.
Never estimate difficulty or probability of correctness.
Do not intentionally make an error and do not use an official answer, explanation, hint, or instructor difficulty label.
You may use scratch reasoning according to the assigned compute policy.
At the very END, emit exactly one machine-readable object:
{"final_answer":"..."}
For multiple-choice return exactly one option letter (A, B, C, ...), or the exact option text.
"""

def normalize_vote_answer(x):
    return re.sub(r"\s+", "", str(x or "")).strip().lower()

def extract_final_answer(text):
    s = str(text or "").strip()
    hits = re.findall(r'\{[^{}]*"final_answer"\s*:\s*"([^"]*)"[^{}]*\}', s, flags=re.S)
    if hits:
        return hits[-1].strip(), True
    m = re.findall(r"(?:FINAL|Final|final)\s*[:：]\s*(.+)", s)
    if m:
        return m[-1].strip().splitlines()[0].strip(), False
    s2 = re.sub(r"<think>.*?</think>", "", s, flags=re.S|re.I).strip()
    lines = [x.strip() for x in s2.splitlines() if x.strip()]
    return (lines[-1] if lines else ""), False

def item_prompt(item, policy):
    lines = [
        f"Reasoning policy: {policy['instruction']}",
        "Question type: multiple choice",
        f"Question: {item.get('content','')}",
        "Options:",
    ]
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    for i, x in enumerate(item.get("options", []) or []):
        lines.append(f"{letters[i]}. {x}")
    return "\n".join(lines)

def apply_template(tok, messages, thinking):
    try:
        return tok.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True,
            enable_thinking=bool(thinking)
        )
    except TypeError:
        return tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

def vote(candidates):
    norm = [normalize_vote_answer(x) for x in candidates]
    cnt = Counter(norm)
    best_n = max(cnt.values())
    tied = {k for k, v in cnt.items() if v == best_n}
    for raw, n in zip(candidates, norm):
        if n in tied:
            return raw, best_n
    return candidates[0], best_n

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--item_bank_jsonl", required=True)
    ap.add_argument("--model_name_or_path", required=True)
    ap.add_argument("--out_jsonl", required=True)
    ap.add_argument("--replicas", type=int, default=2)
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--policy_ids", default="all")
    ap.add_argument("--local_files_only", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--seed", type=int, default=20260828)
    ap.add_argument("--max_input_tokens", type=int, default=8192)
    args = ap.parse_args()

    items = [json.loads(x) for x in Path(args.item_bank_jsonl).read_text(encoding="utf-8").splitlines() if x.strip()]
    forbidden = {"answer_spec","answer_raw","accepted","correct_answer","correct_index","correct_letter",
                 "is_correct","explanation","hint","difficulty","difficulty_level"}
    for item in items:
        bad = forbidden & set(item)
        if bad:
            raise RuntimeError(f"Generation bank leaks answer-side keys qid={item.get('qid')}: {sorted(bad)}")

    wanted = None if args.policy_ids == "all" else set(x.strip() for x in args.policy_ids.split(",") if x.strip())
    policies = [p for p in POLICIES if wanted is None or p["id"] in wanted]
    if not policies:
        raise RuntimeError("No policies selected.")

    out = Path(args.out_jsonl)
    out.parent.mkdir(parents=True, exist_ok=True)
    done = set()
    if args.resume and out.exists():
        for line in out.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                o = json.loads(line)
                done.add((str(o["qid"]), str(o["policy_id"]), int(o["replica"])))
            except Exception:
                pass

    tok = AutoTokenizer.from_pretrained(
        args.model_name_or_path, local_files_only=args.local_files_only, trust_remote_code=True
    )
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "left"
    dtype = torch.bfloat16 if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else (
        torch.float16 if torch.cuda.is_available() else torch.float32
    )
    model = AutoModelForCausalLM.from_pretrained(
        args.model_name_or_path, local_files_only=args.local_files_only, trust_remote_code=True,
        torch_dtype=dtype, device_map="auto"
    )
    model.eval()

    mode = "a" if args.resume and out.exists() else "w"
    with out.open(mode, encoding="utf-8") as fo:
        for pi, policy in enumerate(policies):
            for rep in range(args.replicas):
                pending = [
                    x for x in items
                    if (str(x["qid"]), policy["id"], rep) not in done
                ]
                print(
                    f"[FA-QWEN] {policy['id']} rep={rep} items={len(pending)} "
                    f"attempts={policy['attempts']} thinking={policy['thinking']} max_new={policy['max_new']}",
                    flush=True,
                )
                for st in range(0, len(pending), args.batch_size):
                    batch = pending[st:st+args.batch_size]
                    all_candidates = [[] for _ in batch]
                    all_parse = [[] for _ in batch]
                    all_raw = [[] for _ in batch]

                    for attempt in range(int(policy["attempts"])):
                        seed = args.seed + pi*100003 + rep*1009 + attempt*97 + st
                        torch.manual_seed(seed)
                        if torch.cuda.is_available():
                            torch.cuda.manual_seed_all(seed)
                        chats = []
                        for item in batch:
                            msgs = [
                                {"role":"system","content":SYSTEM},
                                {"role":"user","content":item_prompt(item, policy)},
                            ]
                            chats.append(apply_template(tok, msgs, policy["thinking"]))
                        enc = tok(
                            chats, return_tensors="pt", padding=True, truncation=False
                        ).to(model.device)
                        if int(enc["input_ids"].shape[1]) > args.max_input_tokens:
                            raise RuntimeError(
                                f"Frozen prompt-length limit exceeded: {enc['input_ids'].shape[1]} > {args.max_input_tokens}"
                            )
                        with torch.inference_mode():
                            y = model.generate(
                                **enc,
                                max_new_tokens=int(policy["max_new"]),
                                do_sample=True,
                                temperature=float(policy["temperature"]),
                                top_p=.90,
                                pad_token_id=tok.pad_token_id,
                                eos_token_id=tok.eos_token_id,
                            )
                        plen = enc["input_ids"].shape[1]
                        for bi, yy in enumerate(y):
                            raw = tok.decode(yy[plen:], skip_special_tokens=True)
                            ans, ok = extract_final_answer(raw)
                            all_candidates[bi].append(ans)
                            all_parse[bi].append(bool(ok))
                            all_raw[bi].append(raw if not ok else "")

                    for item, cands, oks, raws in zip(batch, all_candidates, all_parse, all_raw):
                        final, votes = vote(cands)
                        rec = {
                            "qid": str(item["qid"]),
                            "policy_id": policy["id"],
                            "replica": int(rep),
                            "synthetic_student_id": f"{policy['id']}::r{rep}",
                            "thinking": bool(policy["thinking"]),
                            "reasoning_budget": int(policy["max_new"]),
                            "attempts": int(policy["attempts"]),
                            "temperature": float(policy["temperature"]),
                            "final_answer": final,
                            "candidate_answers": cands,
                            "modal_vote_count": int(votes),
                            "parse_ok_all": bool(all(oks)),
                            "parse_ok_any": bool(any(oks)),
                            "raw_parse_failures": [x for x in raws if x],
                        }
                        fo.write(json.dumps(rec, ensure_ascii=False) + "\n")
                        fo.flush()
                    if (st // args.batch_size) % 10 == 0:
                        print(f"  progress {min(st+len(batch), len(pending))}/{len(pending)}", flush=True)

    print(f"[FA-QWEN DONE] {out}")

if __name__ == "__main__":
    main()
