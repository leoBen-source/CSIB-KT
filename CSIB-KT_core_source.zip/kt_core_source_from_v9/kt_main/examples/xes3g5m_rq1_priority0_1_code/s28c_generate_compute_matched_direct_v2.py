#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fair-S21 call/policy/max-token-cap-matched direct difficulty judgment.

Mirrors S7-v2's 10 policies, two replicas and attempt counts: 38 LLM calls/item.
It does NOT elicit individual synthetic student responses. It directly estimates
first-attempt human correctness for the XES3G5M target population.

v2.2 hotfix hardening:
- population is explicitly third-grade mathematics learners (public dataset metadata);
- the assistant turn is prefilled up to the first probability value, so every call emits
  an item-specific numeric estimate before optional rationale can consume the token cap;
- higher-budget policies may revise that provisional value with a terminal FINAL_ESTIMATE;
- parsing prefers FINAL_ESTIMATE but safely falls back to the anchored initial prefill;
- no extra retry LLM calls are introduced, preserving the frozen 38-call/item budget;
- parse failures are written to a diagnostic JSONL before fail-closed termination;
- resume configuration is immutable and hash-checks prompts/parser/BATCH_SIZE;
- existing raw rows are validated against the frozen variant/config;
- answer visibility remains physically controlled by the prepared view.

IMPORTANT: generation seeds are batch-index based to preserve the frozen batched
sampling contract. Therefore BATCH_SIZE must never change after a run starts; the
run-config guard enforces this and fails closed.
"""
from __future__ import annotations
import argparse, fcntl, hashlib, json, re
from collections import defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from s28_common_v2 import logit, sha256_file

POLICIES = [
    dict(id="p00_direct_48", thinking=False, max_new=48, temperature=.90, attempts=1,
         instruction="Estimate directly with minimal computation. Do not double-check."),
    dict(id="p10_direct_96", thinking=False, max_new=96, temperature=.65, attempts=1,
         instruction="Estimate directly and concisely. Use brief mental work if needed."),
    dict(id="p20_reason_128", thinking=True, max_new=160, temperature=.70, attempts=1,
         instruction="Reason through the factors that determine first-attempt success before estimating."),
    dict(id="p30_reason_256", thinking=True, max_new=300, temperature=.65, attempts=1,
         instruction="Work step by step through prerequisite skills, likely pitfalls, and item demands before estimating."),
    dict(id="p40_reason_512", thinking=True, max_new=560, temperature=.55, attempts=1,
         instruction="Use a complete analysis of item demands, prerequisite mastery, distractors, and likely error modes."),
    dict(id="p50_verify_640", thinking=True, max_new=700, temperature=.45, attempts=1,
         instruction="Estimate carefully, then independently verify that the predicted success rate is consistent with the item demands and learner population."),
    dict(id="p60_sc3_reason256", thinking=True, max_new=320, temperature=.75, attempts=3,
         instruction="Estimate independently using ordinary step-by-step item-demand reasoning. Multiple independent estimates will be averaged."),
    dict(id="p70_sc5_reason256", thinking=True, max_new=320, temperature=.80, attempts=5,
         instruction="Estimate independently using ordinary step-by-step item-demand reasoning. Five independent estimates will be averaged."),
    dict(id="p80_sc3_verify512", thinking=True, max_new=580, temperature=.60, attempts=3,
         instruction="Estimate carefully and verify. Multiple independently verified estimates will be averaged."),
    dict(id="p90_decompose768", thinking=True, max_new=820, temperature=.40, attempts=2,
         instruction="Use a teacher-style decomposition: identify prerequisite skills, cognitive steps, likely misconceptions and distractors, then sanity-check the population success estimate."),
]

SYSTEM = """You are estimating PRE-DEPLOYMENT first-attempt item performance for an ordinary mixed-mastery population of third-grade mathematics learners from the same curriculum setting as the XES3G5M target population.
Use only the supplied authoring information. Do not simulate individual students.
Do not output a solution or a proposed item answer.
Return an ITEM-SPECIFIC probability estimate; do not use a generic midpoint by default.

Your assistant response is already prefilled with:
INITIAL_ESTIMATE {"expected_correct_rate":

Immediately continue that JSON by writing your own probability value, then the numeric key "confidence", then close the object.
Do not put prose before completing this initial JSON object.
The initial estimate is a valid direct estimate and must be specific to the supplied item.

After the initial JSON object:
- if the compute policy is direct/minimal, you may stop immediately;
- if the compute policy asks for analysis or verification, use the remaining token budget for concise item-demand reasoning;
- if you revise the estimate after that reasoning, end with:
FINAL_ESTIMATE {"expected_correct_rate": <your revised probability>, "confidence": <your revised confidence>}
Do not put anything after FINAL_ESTIMATE.

No worked numeric example is provided. Both probabilities must be generated by you.
expected_correct_rate must be strictly between zero and one. confidence must be between zero and one.
"""

USER = """Estimate the fraction of the target learner population that would answer this item correctly on first attempt.
The supplied item may or may not include an official answer; if it is present, you are allowed to use it.
Do not answer the item itself.

COMPUTE POLICY:
{instruction}

ITEM:
{item}
"""

# This prefix is part of the model input, not a numeric example. It forces the
# first generated tokens to be the model's own probability value.
ASSISTANT_PREFIX = 'INITIAL_ESTIMATE {"expected_correct_rate":'



PARSER_SCHEMA_VERSION = "s28_direct_initial_prefill_plus_final_v2_2"

def _validate_estimate_obj(o):
    if not isinstance(o, dict):
        return None
    if set(o.keys()) != {"expected_correct_rate", "confidence"}:
        return None
    try:
        p0 = float(o["expected_correct_rate"])
        c0 = float(o["confidence"])
    except Exception:
        return None
    if not (np.isfinite(p0) and np.isfinite(c0)):
        return None
    if not (0.0 < p0 < 1.0 and 0.0 <= c0 <= 1.0):
        return None
    # Keep the original S28 numerical clipping convention away from exact 0/1.
    return float(np.clip(p0, .01, .99)), float(np.clip(c0, 0, 1))

def extract_obj(text):
    """Return the best estimate from one generation.

    Preferred: terminal FINAL_ESTIMATE {...}
    Fail-safe: anchored initial estimate produced immediately after ASSISTANT_PREFIX.
    """
    s = str(text or "")
    reconstructed = ASSISTANT_PREFIX + s

    # Prefer a terminal revision when present.
    m = re.search(
        r'FINAL_ESTIMATE\s*:?[ \t]*(\{[^{}]*\})[ \t\r\n`]*$',
        reconstructed, flags=re.I | re.S
    )
    if m:
        try:
            out = _validate_estimate_obj(json.loads(m.group(1)))
            if out is not None:
                return out[0], out[1], True, "final_marker"
        except Exception:
            pass

    # Otherwise parse only the initial object anchored at the start of the turn.
    m = re.match(
        r'INITIAL_ESTIMATE\s*\{\s*"expected_correct_rate"\s*:\s*'
        r'([-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?)\s*,\s*'
        r'"confidence"\s*:\s*'
        r'([-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?)\s*\}',
        reconstructed, flags=re.I | re.S
    )
    if m:
        try:
            out = _validate_estimate_obj({
                "expected_correct_rate": float(m.group(1)),
                "confidence": float(m.group(2)),
            })
            if out is not None:
                return out[0], out[1], True, "initial_prefill"
        except Exception:
            pass

    return np.nan, np.nan, False, "parse_failure"


def apply_template(tok, msgs, thinking):
    try:
        prompt = tok.apply_chat_template(
            msgs, tokenize=False, add_generation_prompt=True,
            enable_thinking=bool(thinking)
        )
    except TypeError:
        prompt = tok.apply_chat_template(
            msgs, tokenize=False, add_generation_prompt=True
        )
    return prompt + ASSISTANT_PREFIX


def seed_for(base, policy, rep, attempt, batch_id):
    h = hashlib.sha256(f"{base}|{policy}|{rep}|{attempt}|{batch_id}".encode()).digest()
    return int.from_bytes(h[:8], "big") % (2**31 - 1)


def canonical_policy_sha():
    txt = json.dumps(POLICIES, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(txt.encode("utf-8")).hexdigest()


def prompt_contract_sha():
    payload = {
        "system": SYSTEM,
        "user": USER,
        "assistant_prefix": ASSISTANT_PREFIX,
        "parser_schema_version": PARSER_SCHEMA_VERSION,
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def frozen_run_config(args, expected_visible):
    return {
        "schema_version": "s28c_direct_budgetmatched_run_config_v2_2_hotfix",
        "variant": args.variant,
        "answer_visible": bool(expected_visible),
        "replicas": int(args.replicas),
        "batch_size": int(args.batch_size),
        "seed": int(args.seed),
        "model_name_or_path": str(Path(args.model_name_or_path).resolve()),
        "view_sha256": sha256_file(args.view_jsonl),
        "policy_sha256": canonical_policy_sha(),
        "prompt_contract_sha256": prompt_contract_sha(),
        "parser_schema_version": PARSER_SCHEMA_VERSION,
        "policy_replica_n": len(POLICIES) * int(args.replicas),
        "llm_calls_per_item": int(sum(int(p["attempts"]) for p in POLICIES) * int(args.replicas)),
        "sampling_contract": "batched stochastic generation with seed keyed by base/policy/replica/attempt/batch_id; changing batch_size changes batch_id assignment and is forbidden on resume",
    }


def ensure_run_config(path, cfg, raw_exists):
    if path.exists():
        old = json.loads(path.read_text(encoding="utf-8"))
        if old != cfg:
            keys = sorted(set(old) | set(cfg))
            diff = {k: {"existing": old.get(k), "requested": cfg.get(k)} for k in keys if old.get(k) != cfg.get(k)}
            raise RuntimeError(f"resume config mismatch; refusing to mix stochastic contracts: {json.dumps(diff, ensure_ascii=False)}")
        return
    if raw_exists:
        raise RuntimeError("raw direct output exists without v2 run_config; refuse ambiguous legacy resume. Use a fresh output directory or archive/remove the old raw file.")
    path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def validate_existing_record(x, args, expected_visible):
    if str(x.get("variant")) != args.variant:
        raise RuntimeError("existing raw variant mismatch")
    if bool(x.get("answer_visible")) != bool(expected_visible):
        raise RuntimeError("existing raw answer visibility mismatch")
    pid = str(x.get("policy_id"))
    pmap = {p["id"]: p for p in POLICIES}
    if pid not in pmap:
        raise RuntimeError(f"unknown existing policy {pid}")
    p = pmap[pid]
    checks = {
        "attempts": int(p["attempts"]),
        "thinking": bool(p["thinking"]),
        "max_new": int(p["max_new"]),
        "temperature": float(p["temperature"]),
    }
    for k, v in checks.items():
        if k not in x:
            raise RuntimeError(f"existing raw row missing frozen field {k}")
        if isinstance(v, float):
            if abs(float(x[k]) - v) > 1e-12:
                raise RuntimeError(f"existing raw policy config mismatch {pid} field={k}")
        elif x[k] != v:
            raise RuntimeError(f"existing raw policy config mismatch {pid} field={k}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--view_jsonl", required=True)
    ap.add_argument("--model_name_or_path", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--variant", required=True, choices=["answerfree", "answeraware"])
    ap.add_argument("--replicas", type=int, default=2)
    ap.add_argument("--batch_size", type=int, default=4)
    ap.add_argument("--seed", type=int, default=20260905)
    ap.add_argument("--local_files_only", action="store_true")
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args()
    if args.replicas != 2:
        raise RuntimeError("frozen contract requires replicas=2")
    if args.batch_size < 1:
        raise RuntimeError("batch_size must be >=1")

    items = []
    with open(args.view_jsonl, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                items.append(json.loads(line))
    items = sorted(items, key=lambda x: int(x["qid"]))
    if len(items) != 522 or len({int(x["qid"]) for x in items}) != 522:
        raise RuntimeError("expected 522 items")

    expected_visible = args.variant == "answeraware"
    if any(bool(x.get("answer_visible")) != expected_visible for x in items):
        raise RuntimeError("answer visibility/view mismatch")

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    raw = out / f"direct_budgetmatched_{args.variant}_raw.jsonl"
    cfg_path = out / f"run_config_{args.variant}.json"
    fail_path = out / f"parse_failures_{args.variant}.jsonl"

    cfg = frozen_run_config(args, expected_visible)
    ensure_run_config(cfg_path, cfg, raw.exists())

    lock = Path(str(raw) + ".lock").open("w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise RuntimeError("another writer is active")

    done = set()
    if args.resume and raw.exists():
        with raw.open(encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                x = json.loads(line)
                validate_existing_record(x, args, expected_visible)
                k = (int(x["qid"]), str(x["policy_id"]), int(x["replica"]))
                if k in done:
                    raise RuntimeError(f"duplicate existing key {k}")
                done.add(k)
    elif raw.exists() and not args.resume:
        raise RuntimeError("raw output already exists; use --resume or a fresh out_dir")

    from transformers import AutoTokenizer, AutoModelForCausalLM
    tok = AutoTokenizer.from_pretrained(args.model_name_or_path, local_files_only=args.local_files_only, trust_remote_code=True)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "left"
    dtype = torch.bfloat16 if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else (torch.float16 if torch.cuda.is_available() else torch.float32)
    model_kwargs = dict(
        local_files_only=args.local_files_only,
        trust_remote_code=True,
        device_map="auto",
    )
    try:
        model = AutoModelForCausalLM.from_pretrained(
            args.model_name_or_path, dtype=dtype, **model_kwargs
        ).eval()
    except TypeError:
        # Compatibility with older Transformers releases.
        model = AutoModelForCausalLM.from_pretrained(
            args.model_name_or_path, torch_dtype=dtype, **model_kwargs
        ).eval()
    try:
        dev = model.get_input_embeddings().weight.device
    except Exception:
        dev = next(model.parameters()).device

    mode = "a" if args.resume and raw.exists() else "w"
    with raw.open(mode, encoding="utf-8") as fo:
        for p in POLICIES:
            for rep in range(args.replicas):
                for batch_id, st in enumerate(range(0, len(items), args.batch_size)):
                    batch = items[st:st + args.batch_size]
                    keys = [(int(x["qid"]), p["id"], rep) for x in batch]
                    missing = [i for i, k in enumerate(keys) if k not in done]
                    if not missing:
                        continue

                    vals = [[] for _ in batch]
                    conf = [[] for _ in batch]
                    oks = [[] for _ in batch]
                    toks = [[] for _ in batch]
                    parse_sources = [[] for _ in batch]
                    response_tails = [[] for _ in batch]

                    # Regenerate the entire fixed batch when resuming a partially completed batch;
                    # only missing qid/policy/replica rows are appended below.
                    for attempt in range(int(p["attempts"])):
                        seed = seed_for(args.seed, p["id"], rep, attempt, batch_id)
                        torch.manual_seed(seed)
                        if torch.cuda.is_available():
                            torch.cuda.manual_seed_all(seed)
                        chats = []
                        for x in batch:
                            msgs = [
                                {"role": "system", "content": SYSTEM},
                                {"role": "user", "content": USER.replace("{instruction}", str(p["instruction"])).replace("{item}", str(x["prompt_text"]))},
                            ]
                            chats.append(apply_template(tok, msgs, p["thinking"]))
                        enc = tok(chats, return_tensors="pt", padding=True, truncation=True, max_length=2048)
                        enc = {k: v.to(dev) for k, v in enc.items()}
                        with torch.inference_mode():
                            yy = model.generate(
                                **enc,
                                max_new_tokens=int(p["max_new"]),
                                do_sample=True,
                                temperature=float(p["temperature"]),
                                top_p=.90,
                                pad_token_id=tok.pad_token_id,
                                eos_token_id=tok.eos_token_id,
                            )
                        plen = int(enc["input_ids"].shape[1])
                        for bi, y in enumerate(yy):
                            new = y[plen:]
                            txt = tok.decode(new, skip_special_tokens=True)
                            e, c, ok, parse_source = extract_obj(txt)
                            vals[bi].append(e)
                            conf[bi].append(c)
                            oks[bi].append(ok)
                            toks[bi].append(int(len(new)))
                            parse_sources[bi].append(parse_source)
                            response_tails[bi].append(str(txt)[-1200:])

                    for bi in missing:
                        if not all(oks[bi]):
                            bad_attempts = [ai for ai, ok in enumerate(oks[bi]) if not ok]
                            diag = {
                                "qid": int(batch[bi]["qid"]),
                                "policy_id": p["id"],
                                "replica": int(rep),
                                "variant": args.variant,
                                "batch_id": int(batch_id),
                                "failed_attempts": bad_attempts,
                                "generated_tokens": [int(v) for v in toks[bi]],
                                "response_tails": response_tails[bi],
                                "prompt_contract_sha256": prompt_contract_sha(),
                            }
                            with fail_path.open("a", encoding="utf-8") as ff:
                                ff.write(json.dumps(diag, ensure_ascii=False) + "\n")
                            raise RuntimeError(
                                f"parse failure even after anchored-initial fallback q={batch[bi]['qid']} policy={p['id']} rep={rep}; "
                                f"diagnostic appended to {fail_path}. Do NOT change BATCH_SIZE on resume."
                            )
                        rec = {
                            "qid": int(batch[bi]["qid"]),
                            "policy_id": p["id"],
                            "replica": rep,
                            "variant": args.variant,
                            "answer_visible": expected_visible,
                            "attempts": int(p["attempts"]),
                            "thinking": bool(p["thinking"]),
                            "max_new": int(p["max_new"]),
                            "temperature": float(p["temperature"]),
                            "attempt_expected_correct": [float(v) for v in vals[bi]],
                            "attempt_confidence": [float(v) for v in conf[bi]],
                            "expected_correct_rate": float(np.mean(vals[bi])),
                            "confidence": float(np.mean(conf[bi])),
                            "generated_tokens": [int(v) for v in toks[bi]],
                            "generated_tokens_total": int(sum(toks[bi])),
                            "attempt_parse_source": [str(v) for v in parse_sources[bi]],
                            "attempt_response_tail": [str(v) for v in response_tails[bi]],
                        }
                        fo.write(json.dumps(rec, ensure_ascii=False) + "\n")
                        fo.flush()
                        done.add((rec["qid"], rec["policy_id"], rep))

                    # Fail fast on the exact failure mode found in the superseded prompt:
                    # a copied constant schema value for every item.  Check after 64 formal
                    # p00/rep0 estimates; a strong direct comparator must be item-varying.
                    if p["id"] == "p00_direct_48" and rep == 0 and batch_id == 15:
                        fo.flush()
                        vals64 = []
                        with raw.open(encoding="utf-8") as rf:
                            for line in rf:
                                if not line.strip():
                                    continue
                                xx = json.loads(line)
                                if xx.get("policy_id") == "p00_direct_48" and int(xx.get("replica", -1)) == 0:
                                    vals64.append(float(xx["expected_correct_rate"]))
                        if len(vals64) >= 64 and float(np.std(vals64[:64])) < 1e-8:
                            raise RuntimeError(
                                "degenerate direct estimates: first 64 p00/rep0 values are constant. "
                                "Stop; inspect prompt/model outputs before spending more compute."
                            )
                    if batch_id % 20 == 0:
                        print(f"[{args.variant}] {p['id']} rep={rep} batch={batch_id} completed={len(done)}/{522*10*2}", flush=True)

    expected = 522 * len(POLICIES) * args.replicas
    if len(done) != expected:
        raise RuntimeError(f"incomplete unique={len(done)} expected={expected}")

    recs = []
    with raw.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                x = json.loads(line)
                validate_existing_record(x, args, expected_visible)
                recs.append(x)

    by = defaultdict(list)
    for x in recs:
        by[int(x["qid"])].append(x)
    if set(by) != {int(x["qid"]) for x in items}:
        raise RuntimeError("raw output target universe mismatch")

    rows = []
    feature_cols = []
    for q in sorted(by):
        xs = sorted(by[q], key=lambda x: (x["policy_id"], int(x["replica"])))
        if len(xs) != 20:
            raise RuntimeError(f"q={q} has {len(xs)} respondent estimates")
        row = {"target_qid": q}
        logits = []
        for x in xs:
            col = f"cm_{x['policy_id']}_r{int(x['replica'])}_logit"
            v = float(logit([x["expected_correct_rate"]])[0])
            row[col] = v
            logits.append(v)
            if col not in feature_cols:
                feature_cols.append(col)
        arr = np.asarray(logits, float)
        row["cm_mean_logit"] = float(arr.mean())
        row["cm_std_logit"] = float(arr.std())
        row["cm_range_logit"] = float(arr.max() - arr.min())
        row["cm_q25_logit"] = float(np.quantile(arr, .25))
        row["cm_q75_logit"] = float(np.quantile(arr, .75))
        row["cm_mean_confidence"] = float(np.mean([x["confidence"] for x in xs]))
        row["cm_generated_tokens_total"] = int(sum(x["generated_tokens_total"] for x in xs))
        rows.append(row)

    feature_cols += ["cm_mean_logit", "cm_std_logit", "cm_range_logit", "cm_q25_logit", "cm_q75_logit", "cm_mean_confidence"]
    df = pd.DataFrame(rows)
    feat = out / f"direct_budgetmatched_{args.variant}_features.csv"
    df.to_csv(feat, index=False)

    man = {
        "schema_version": "s28c_direct_budgetmatched_v2_1_hotfix",
        "variant": args.variant,
        "target_n": 522,
        "policy_replica_n": 20,
        "llm_calls_per_item": 38,
        "population_contract": "ordinary mixed-mastery third-grade mathematics learners from the same curriculum setting as XES3G5M; public population metadata only",
        "matching_contract": "same 10 S7-v2 policy slots, two replicas, per-policy attempt counts, temperatures and max-new-token caps; Qwen3-4B-Instruct-2507 is a non-thinking-only model, so the historical thinking flag is only a policy-style label for this model. Actual generated token counts are recorded; this is call/policy/max-cap matched rather than exact-FLOP matched.",
        "resume_contract": "run_config hash-locks variant, answer visibility, model path, input view, policies, prompt/parser contract, seed, replicas and batch_size; BATCH_SIZE cannot change after the first row is generated.",
        "feature_cols": feature_cols,
        "run_config_sha256": sha256_file(cfg_path),
        "prompt_contract_sha256": prompt_contract_sha(),
        "parser_schema_version": PARSER_SCHEMA_VERSION,
        "view_sha256": sha256_file(args.view_jsonl),
        "raw_sha256": sha256_file(raw),
        "features_sha256": sha256_file(feat),
        "mean_generated_tokens_per_item": float(df.cm_generated_tokens_total.mean()),
    }
    (out / f"manifest_{args.variant}.json").write_text(json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(man, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
