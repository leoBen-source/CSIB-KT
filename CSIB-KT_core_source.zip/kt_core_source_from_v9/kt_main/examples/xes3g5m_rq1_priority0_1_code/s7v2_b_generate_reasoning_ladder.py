#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate an ability-support synthetic classroom using reasoning/compute diversity.

Key difference from S7-v1:
- policies differ in actual reasoning budget and self-consistency, not merely persona wording;
- high-compute agents can use longer reasoning and multiple independent attempts;
- self-consistency aggregates candidate answers WITHOUT official answers;
- official answers are never loaded here.
"""
from __future__ import annotations
import argparse, json, math, re
from collections import Counter
from pathlib import Path
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from s7v2_common import extract_final_answer, normalize_vote_answer

POLICIES = [
    dict(id="p00_direct_48", thinking=False, max_new=48, temperature=.90, attempts=1,
         instruction="Answer directly with minimal computation. Do not double-check."),
    dict(id="p10_direct_96", thinking=False, max_new=96, temperature=.65, attempts=1,
         instruction="Solve directly and concisely. Use brief mental work if needed."),
    dict(id="p20_reason_128", thinking=True, max_new=160, temperature=.70, attempts=1,
         instruction="Reason through the necessary steps before committing to the final answer."),
    dict(id="p30_reason_256", thinking=True, max_new=300, temperature=.65, attempts=1,
         instruction="Work step by step and preserve intermediate quantities carefully."),
    dict(id="p40_reason_512", thinking=True, max_new=560, temperature=.55, attempts=1,
         instruction="Use a complete solution with enough scratch reasoning to avoid arithmetic and condition-tracking errors."),
    dict(id="p50_verify_640", thinking=True, max_new=700, temperature=.45, attempts=1,
         instruction="Solve carefully, then independently verify the final arithmetic/logic before answering."),
    dict(id="p60_sc3_reason256", thinking=True, max_new=320, temperature=.75, attempts=3,
         instruction="Solve the item independently. This response will be combined with other independent attempts by majority agreement."),
    dict(id="p70_sc5_reason256", thinking=True, max_new=320, temperature=.80, attempts=5,
         instruction="Solve independently with ordinary step-by-step reasoning. Multiple independent attempts will be aggregated."),
    dict(id="p80_sc3_verify512", thinking=True, max_new=580, temperature=.60, attempts=3,
         instruction="Solve carefully and verify. Multiple independent verified attempts will be aggregated."),
    dict(id="p90_decompose768", thinking=True, max_new=820, temperature=.40, attempts=2,
         instruction="Use a teacher-style decomposition: identify the mathematical structure, solve fully, then check the result with a second route or sanity check.")
]

SYSTEM = """Actually solve the elementary-mathematics item.
Never estimate difficulty or probability of correctness.
Do not intentionally make an error and do not use an official answer.
You may use scratch reasoning according to the assigned compute policy.
At the very END, emit exactly one machine-readable object:
{"final_answer":"..."}
For multiple-choice use the option letter or option text.
For multiple blanks return all answers in order separated by semicolons, e.g. {"final_answer":"13;2"}.
"""

def item_prompt(item, policy):
    lines = [
        f"Reasoning policy: {policy['instruction']}",
        f"Question type: {item.get('question_type','unknown')}",
        f"Question: {item.get('content','')}"
    ]
    opts = item.get("options", []) or []
    if opts:
        letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        lines.append("Options:")
        for i, x in enumerate(opts):
            lines.append(f"{letters[i]}. {x}")
    return "\n".join(lines)

def apply_template(tok, messages, thinking):
    try:
        return tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True,
                                       enable_thinking=bool(thinking))
    except TypeError:
        return tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

def vote(candidates):
    norm = [normalize_vote_answer(x) for x in candidates]
    cnt = Counter(norm)
    best_n = max(cnt.values())
    # Stable tie break: earliest attempt among tied modal answers.
    tied = {k for k, v in cnt.items() if v == best_n}
    for raw, n in zip(candidates, norm):
        if n in tied:
            return raw, best_n
    return candidates[0], best_n

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--item_bank_jsonl", required=True)
    ap.add_argument("--model_name_or_path", required=True)
    ap.add_argument("--out_jsonl", required=True)
    ap.add_argument("--replicas", type=int, default=1)
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--policy_ids", default="all")
    ap.add_argument("--local_files_only", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--seed", type=int, default=20260826)
    args = ap.parse_args()

    items = []
    with open(args.item_bank_jsonl, encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                items.append(json.loads(line))
    wanted = None if args.policy_ids == "all" else set(x.strip() for x in args.policy_ids.split(",") if x.strip())
    policies = [p for p in POLICIES if wanted is None or p["id"] in wanted]
    if not policies:
        raise RuntimeError("no policies selected")

    out = Path(args.out_jsonl); out.parent.mkdir(parents=True, exist_ok=True)
    done = set()
    if args.resume and out.exists():
        with out.open(encoding="utf-8") as fh:
            for line in fh:
                if not line.strip():
                    continue
                try:
                    o = json.loads(line)
                    done.add((int(o["qid"]), str(o["policy_id"]), int(o["replica"])))
                except Exception:
                    pass

    tok = AutoTokenizer.from_pretrained(args.model_name_or_path, local_files_only=args.local_files_only,
                                        trust_remote_code=True)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "left"
    dtype = torch.bfloat16 if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else (
        torch.float16 if torch.cuda.is_available() else torch.float32)
    model = AutoModelForCausalLM.from_pretrained(args.model_name_or_path,
        local_files_only=args.local_files_only, trust_remote_code=True,
        torch_dtype=dtype, device_map="auto")
    model.eval()

    mode = "a" if args.resume and out.exists() else "w"
    with out.open(mode, encoding="utf-8") as fo:
        for pi, policy in enumerate(policies):
            for rep in range(args.replicas):
                pending = [x for x in items if (int(x["qid"]), policy["id"], rep) not in done]
                print(f"[S7v2-B] {policy['id']} rep={rep} items={len(pending)} attempts={policy['attempts']} "
                      f"thinking={policy['thinking']} max_new={policy['max_new']}", flush=True)

                for st in range(0, len(pending), args.batch_size):
                    batch = pending[st:st+args.batch_size]
                    all_candidates = [[] for _ in batch]
                    all_parse = [[] for _ in batch]
                    all_raw = [[] for _ in batch]

                    for attempt in range(int(policy["attempts"])):
                        seed = args.seed + pi*100003 + rep*1009 + attempt*97 + st
                        torch.manual_seed(seed)
                        if torch.cuda.is_available():
                            torch.cuda.manual_seed_all(seed)

                        chats = []
                        for item in batch:
                            msgs = [{"role":"system","content":SYSTEM},
                                    {"role":"user","content":item_prompt(item, policy)}]
                            chats.append(apply_template(tok, msgs, policy["thinking"]))
                        enc = tok(chats, return_tensors="pt", padding=True, truncation=True,
                                  max_length=1024).to(model.device)
                        with torch.inference_mode():
                            y = model.generate(**enc,
                                max_new_tokens=int(policy["max_new"]),
                                do_sample=True, temperature=float(policy["temperature"]),
                                top_p=.90, pad_token_id=tok.pad_token_id,
                                eos_token_id=tok.eos_token_id)
                        plen = enc["input_ids"].shape[1]
                        for bi, yy in enumerate(y):
                            raw = tok.decode(yy[plen:], skip_special_tokens=True)
                            ans, ok = extract_final_answer(raw)
                            all_candidates[bi].append(ans)
                            all_parse[bi].append(bool(ok))
                            all_raw[bi].append(raw if not ok else "")

                    for item, cands, oks, raws in zip(batch, all_candidates, all_parse, all_raw):
                        final, votes = vote(cands)
                        rec = {
                            "qid": int(item["qid"]),
                            "policy_id": policy["id"], "replica": rep,
                            "synthetic_student_id": f"{policy['id']}::r{rep}",
                            "thinking": bool(policy["thinking"]),
                            "reasoning_budget": int(policy["max_new"]),
                            "attempts": int(policy["attempts"]),
                            "temperature": float(policy["temperature"]),
                            "final_answer": final,
                            "candidate_answers": cands,
                            "modal_vote_count": int(votes),
                            "parse_ok_all": bool(all(oks)),
                            "parse_ok_any": bool(any(oks)),
                            "raw_parse_failures": [x for x in raws if x]
                        }
                        fo.write(json.dumps(rec, ensure_ascii=False) + "\n")
                        fo.flush()
                    if (st // args.batch_size) % 10 == 0:
                        print(f"  progress {min(st+len(batch),len(pending))}/{len(pending)}", flush=True)
    print(f"[S7v2-B DONE] {out}")

if __name__ == "__main__":
    main()
