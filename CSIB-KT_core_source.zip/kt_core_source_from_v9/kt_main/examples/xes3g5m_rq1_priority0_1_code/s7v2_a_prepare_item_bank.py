#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build scoring-only item bank with strict multi-blank answer structure."""
from __future__ import annotations
import argparse, json
from pathlib import Path
import pandas as pd
from s7v2_common import load_qid_map, load_questions, lookup_meta, option_list, qtype, build_answer_spec

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--group_item_csv", required=True)
    ap.add_argument("--questions_json", required=True)
    ap.add_argument("--qid_map_json", required=True)
    ap.add_argument("--out_dir", required=True)
    args = ap.parse_args()

    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    d = pd.read_csv(args.group_item_csv, low_memory=False)
    _, rev = load_qid_map(args.qid_map_json)
    qmeta = load_questions(args.questions_json)

    rows = []; missing = []
    kinds = {}
    with (out/"item_scoring_bank_v2.jsonl").open("w", encoding="utf-8") as fo:
        for r in d.itertuples(index=False):
            q = int(r.target_qid); raw = rev.get(q, str(q))
            meta = lookup_meta(qmeta, raw, q)
            if not meta:
                missing.append(q); continue
            spec = build_answer_spec(meta)
            kinds[spec["kind"]] = kinds.get(spec["kind"], 0) + 1
            rec = {
                "qid": q, "raw_qid": raw,
                "content_group_fold": int(r.content_group_fold),
                "canonical_content_id": str(r.canonical_content_id),
                "target_kc_key": str(r.target_kc_key),
                "question_type": qtype(meta),
                "content": str(meta.get("content", "") or ""),
                "options": option_list(meta),
                "answer_spec": spec,
                "answer_raw": meta.get("answer"),
            }
            fo.write(json.dumps(rec, ensure_ascii=False) + "\n")
            rows.append({
                "qid": q, "raw_qid": raw, "content_group_fold": int(r.content_group_fold),
                "canonical_content_id": str(r.canonical_content_id),
                "target_kc_key": str(r.target_kc_key),
                "question_type": rec["question_type"],
                "answer_kind": spec["kind"],
                "slot_n": int(spec.get("slot_n", 1)),
                "content_chars": len(rec["content"]),
                "option_n": len(rec["options"])
            })
    audit = pd.DataFrame(rows)
    audit.to_csv(out/"item_scoring_audit_v2.csv", index=False)
    summary = {
        "schema_version": "s7v2_item_bank",
        "requested_item_n": int(len(d)), "mapped_item_n": int(len(audit)),
        "missing_metadata_n": int(len(missing)), "missing_metadata_sample": missing[:30],
        "answer_kind_counts": kinds,
        "multi_blank_item_n": int((audit.answer_kind=="multi_blank_ordered").sum()) if len(audit) else 0,
        "contract": "official answers remain scoring-only; multi-blank items require ordered all-slot correctness"
    }
    (out/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
