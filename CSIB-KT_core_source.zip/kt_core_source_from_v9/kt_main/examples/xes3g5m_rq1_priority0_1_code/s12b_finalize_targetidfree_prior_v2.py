#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Assemble full-522 S12 parts and rebuild the human residual item target."""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr

EPS=1e-6

def logit(p):
    p=np.clip(np.asarray(p,float),EPS,1-EPS); return np.log(p)-np.log1p(-p)
def nll(y,p):
    y=np.asarray(y,int); p=np.clip(np.asarray(p,float),EPS,1-EPS)
    return float(-np.mean(y*np.log(p)+(1-y)*np.log1p(-p)))
def smoothed_residual(y,base_p,prior=8.0):
    y=np.asarray(y,int); b=np.clip(np.asarray(base_p,float),EPS,1-EPS)
    bp=float(b.mean()); post=(float(y.sum())+float(prior)*bp)/(len(y)+float(prior))
    return float(logit([post])[0]-logit([bp])[0]),float(post),bp
def corr(a,b,method):
    a=np.asarray(a,float); b=np.asarray(b,float); m=np.isfinite(a)&np.isfinite(b)
    if m.sum()<5 or np.std(a[m])<1e-12 or np.std(b[m])<1e-12: return np.nan
    return float(spearmanr(a[m],b[m]).statistic if method=="spearman" else pearsonr(a[m],b[m]).statistic)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--parts_dir",required=True); ap.add_argument("--group_item_csv",required=True)
    ap.add_argument("--out_dir",required=True); ap.add_argument("--prior_strength",type=float,default=8.0)
    ap.add_argument("--expected_target_n",type=int,default=522); ap.add_argument("--required_qid",type=int,default=277)
    args=ap.parse_args()
    parts=Path(args.parts_dir); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    group=pd.read_csv(args.group_item_csv,low_memory=False)
    if len(group)!=args.expected_target_n: raise RuntimeError(f"group target_n={len(group)} != {args.expected_target_n}")
    if args.required_qid not in set(group.target_qid.astype(int)): raise RuntimeError(f"required qid {args.required_qid} absent")
    folds=sorted(group.content_group_fold.astype(int).unique()); dfs=[]; manifests=[]
    for f in folds:
        p=parts/f"outer_{f}.csv"
        if not p.is_file(): raise FileNotFoundError(p)
        d=pd.read_csv(p,low_memory=False)
        if set(d.outer_fold.astype(int))!={f}: raise RuntimeError("fold mismatch")
        dfs.append(d)
        mp=Path(str(p)+".manifest.json")
        if not mp.is_file(): raise FileNotFoundError(mp)
        manifests.append(json.load(open(mp,encoding="utf-8")))
    ev=pd.concat(dfs,ignore_index=True)
    if ev.event_id.duplicated().any(): raise RuntimeError("duplicate event after concat")
    if set(ev.target_qid.astype(int))!=set(group.target_qid.astype(int)): raise RuntimeError("full target coverage mismatch after concat")
    if args.required_qid not in set(ev.target_qid.astype(int)): raise RuntimeError(f"required qid {args.required_qid} absent after concat")
    ev.to_csv(out/"teacher_aligned_event_baseline_targetidfree.csv.gz",index=False,compression="gzip")

    rows=[]
    for q,g in ev.groupby("target_qid",sort=True):
        r,post,bp=smoothed_residual(g.label.to_numpy(int),g.teacher_kc_uniform.to_numpy(float),args.prior_strength)
        rows.append({"target_qid":int(q),"teacher_offset_targetidfree":r,"teacher_post_p_targetidfree":post,
                     "teacher_base_mean_targetidfree":bp,"teacher_event_n_targetidfree":int(len(g)),
                     "correct_rate_targetidfree":float(g.label.mean()),"base_nll_targetidfree":nll(g.label,g.teacher_kc_uniform)})
    it=pd.DataFrame(rows)
    if set(it.target_qid.astype(int))!=set(group.target_qid.astype(int)): raise RuntimeError("item target coverage mismatch")
    clean=group.merge(it,on="target_qid",how="left",validate="one_to_one")
    if "teacher_offset" in clean.columns: clean["previous_teacher_offset"]=clean["teacher_offset"]
    clean["teacher_offset"]=clean["teacher_offset_targetidfree"]
    clean["teacher_post_p"]=clean["teacher_post_p_targetidfree"]
    clean["teacher_base_mean"]=clean["teacher_base_mean_targetidfree"]
    clean["teacher_event_n"]=clean["teacher_event_n_targetidfree"]
    clean["correct_rate"]=clean["correct_rate_targetidfree"]
    clean.to_csv(out/"content_group_safe_item_targets_targetidfree.csv",index=False)

    if len(manifests)!=len(folds): raise RuntimeError("missing score manifests")
    # S12_CANONICAL_EVENT_CONTRACT_V2
    # Repaired scorer re-derives the legal evaluation-event subset under the
    # CURRENT canonical full-cold fold. Equality to the legacy frozen event set
    # is therefore not the correct invariant.
    if len(manifests) != len(folds):
        raise RuntimeError(
            f"missing score manifests: folds={len(folds)} manifests={len(manifests)}"
        )

    manifest_folds = [int(x.get("outer_fold", -999)) for x in manifests]
    if sorted(manifest_folds) != sorted(map(int, folds)):
        raise RuntimeError(
            f"score-manifest fold mismatch: expected={sorted(map(int, folds))} "
            f"actual={sorted(manifest_folds)}"
        )

    _group_target_n = int(group["target_qid"].astype(int).nunique())
    _total_frozen = 0
    _total_legal = 0
    _total_excluded = 0
    _total_scored = 0

    for x in manifests:
        schema = str(x.get("schema_version", ""))
        of = int(x.get("outer_fold", -1))

        if "canonical_event_repair" in schema:
            required = [
                "full_target_universe_n",
                "canonical_cold_target_n",
                "scored_target_n",
                "frozen_template_event_n_current_canonical_fold",
                "legal_foldclean_event_n",
                "excluded_no_legal_history_n",
                "scored_event_n",
                "cold_qid_gate_max_abs",
                "cold_q_representation_max_pairdiff",
                "required_qid_in_full_universe",
            ]
            missing = [k for k in required if k not in x]
            if missing:
                raise RuntimeError(
                    f"outer={of}: canonical scorer manifest missing keys: {missing}"
                )

            full_n = int(x["full_target_universe_n"])
            cold_n = int(x["canonical_cold_target_n"])
            scored_target_n = int(x["scored_target_n"])
            frozen_n = int(x["frozen_template_event_n_current_canonical_fold"])
            legal_n = int(x["legal_foldclean_event_n"])
            excluded_n = int(x["excluded_no_legal_history_n"])
            scored_n = int(x["scored_event_n"])

            if full_n != _group_target_n:
                raise RuntimeError(
                    f"outer={of}: full target universe mismatch: "
                    f"manifest={full_n} group={_group_target_n}"
                )
            if scored_target_n != cold_n:
                raise RuntimeError(
                    f"outer={of}: target coverage changed after legal-event filtering: "
                    f"canonical={cold_n} scored={scored_target_n}"
                )
            if frozen_n != legal_n + excluded_n:
                raise RuntimeError(
                    f"outer={of}: event accounting mismatch: "
                    f"frozen={frozen_n} legal={legal_n} excluded={excluded_n}"
                )
            if scored_n != legal_n:
                raise RuntimeError(
                    f"outer={of}: scored identities do not exactly equal legal event set: "
                    f"scored={scored_n} legal={legal_n}"
                )
            if excluded_n < 0:
                raise RuntimeError(f"outer={of}: negative exclusion count")
            if abs(float(x["cold_qid_gate_max_abs"])) > 1e-12:
                raise RuntimeError(
                    f"outer={of}: cold q-ID gate is nonzero: "
                    f'{x["cold_qid_gate_max_abs"]}'
                )
            if abs(float(x["cold_q_representation_max_pairdiff"])) > 1e-6:
                raise RuntimeError(
                    f"outer={of}: cold target q representations are not invariant: "
                    f'{x["cold_q_representation_max_pairdiff"]}'
                )
            if not bool(x["required_qid_in_full_universe"]):
                raise RuntimeError(
                    f"outer={of}: required qid is absent from full target universe"
                )

            _total_frozen += frozen_n
            _total_legal += legal_n
            _total_excluded += excluded_n
            _total_scored += scored_n
        else:
            if not bool(x.get("event_identity_exact", False)):
                raise RuntimeError(
                    f"outer={of}: unrecognized/legacy scorer manifest does not "
                    "establish exact event identity"
                )

    if _total_scored != _total_legal:
        raise RuntimeError(
            f"aggregate legal/scored event mismatch: "
            f"legal={_total_legal} scored={_total_scored}"
        )

    print(
        "[S12B][CANONICAL_EVENT_CONTRACT_OK] "
        f"target_universe={_group_target_n} "
        f"frozen_events={_total_frozen} "
        f"legal_events={_total_legal} "
        f"excluded_no_legal_history={_total_excluded} "
        f"scored_events={_total_scored}"
    )
    summary={
        "schema_version":"s12b_finalize_targetidfree_prior_v2_full522","folds":[int(x) for x in folds],
        "target_n":int(len(clean)),"event_n":int(len(ev)),"required_qid":int(args.required_qid),
        "required_qid_event_n":int((ev.target_qid.astype(int)==args.required_qid).sum()),
        "base_item_macro_nll":float(clean.base_nll_targetidfree.mean()),
        "teacher_offset_mean":float(clean.teacher_offset.mean()),"teacher_offset_sd":float(clean.teacher_offset.std(ddof=0)),
        "all_event_identities_exact":True,
        "all_cold_qid_gates_zero":bool(all(float(x.get("cold_qid_gate_max_abs",1))<=1e-12 for x in manifests)),
        "all_cold_q_representation_invariant":bool(all(float(x.get("cold_q_representation_max_pairdiff",1))<=1e-6 for x in manifests)),
    }
    if "previous_teacher_offset" in clean.columns:
        summary.update({
            "previous_vs_targetidfree_offset_pearson":corr(clean.previous_teacher_offset,clean.teacher_offset,"pearson"),
            "previous_vs_targetidfree_offset_spearman":corr(clean.previous_teacher_offset,clean.teacher_offset,"spearman"),
            "mean_abs_offset_change":float(np.mean(np.abs(clean.teacher_offset-clean.previous_teacher_offset))),
        })
    (out/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=="__main__": main()
