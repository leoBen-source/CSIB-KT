#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build frozen 522-item English MathBERT views and Chinese Fair-S21 direct views.

Changes vs v1 (all made before any S28 target result was observed):
- English question-type normalization for MathBERT/direct prompts.
- Fair-direct prompt no longer exposes anonymous numeric KC IDs, which carry no
  human-readable semantics for the LLM and create an avoidable comparator artifact.
- Manifest explicitly separates published-compatible answer-free semantics from
  information-matched answer-aware semantics.

No target human responses are used. The answer-aware views append the official
answer from the pre-existing scoring-only item bank; answer-free views physically
exclude it.
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
import pandas as pd
from s28_common_v2 import sha256_file

QTYPE_MAP = {
    "填空": "fill-in-the-blank",
    "单选": "single-choice",
    "多选": "multiple-choice",
    "选择": "multiple-choice",
}


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def lookup(d, raw, q):
    keys = [str(raw), raw, str(q), q]
    for k in keys:
        if isinstance(d, dict) and k in d:
            return d[k]
    return None


def options_list(x):
    if x is None:
        return []
    if isinstance(x, list):
        return [str(v) for v in x if v is not None]
    if isinstance(x, dict):
        return [str(v) for _, v in sorted(x.items(), key=lambda z: str(z[0])) if v is not None]
    return [str(x)]


def answer_text(rec):
    a = rec.get("answer_raw")
    if isinstance(a, list):
        return " ; ".join(str(x) for x in a)
    if a is None:
        spec = rec.get("answer_spec", {})
        if isinstance(spec, dict):
            ac = spec.get("accepted")
            if isinstance(ac, list):
                return " ; ".join(str(x) for x in ac)
    return str(a or "")


def english_content(meta):
    if not isinstance(meta, dict):
        return ""
    for k in ["content", "question", "question_content", "text", "problem"]:
        v = meta.get(k)
        if v is not None and str(v).strip():
            return str(v).strip()
    return ""


def english_options(meta):
    if not isinstance(meta, dict):
        return []
    for k in ["options", "choices", "answer_options"]:
        if k in meta:
            return options_list(meta.get(k))
    return []


def normalize_qtype(qtype):
    s = str(qtype or "").strip()
    return QTYPE_MAP.get(s, s if s else "unspecified")


def format_semantic(content, opts, qtype, answer=None):
    # Keep the view intentionally simple: translated question + translated/original
    # options + normalized public question type. KC IDs are already in the frozen KT
    # state and are not duplicated into the semantic comparator.
    lines = [f"Question type: {qtype}", f"Question: {content}"]
    if opts:
        letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        lines.append("Options:")
        for i, x in enumerate(opts):
            label = letters[i] if i < len(letters) else str(i + 1)
            lines.append(f"{label}. {x}")
    if answer is not None:
        lines += ["Official answer:", str(answer)]
    return "\n".join(lines).strip()


def format_direct(content, opts, qtype, answer=None):
    # Deliberately omit anonymous target_kc_key (e.g. "23"). Supplying a numeric
    # identifier does not give the LLM meaningful curriculum semantics and can make
    # the direct comparator population prompt look more informed than it really is.
    lines = [f"[QUESTION_TYPE]\n{qtype}", f"[QUESTION]\n{content}"]
    if opts:
        letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        lines.append("[OPTIONS]")
        for i, x in enumerate(opts):
            label = letters[i] if i < len(letters) else str(i + 1)
            lines.append(f"{label}. {x}")
    if answer is not None:
        lines += ["[OFFICIAL_ANSWER]", str(answer)]
    return "\n".join(lines).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--group_csv", required=True)
    ap.add_argument("--item_bank_jsonl", required=True)
    ap.add_argument("--translated_questions_json", required=True)
    ap.add_argument("--out_dir", required=True)
    args = ap.parse_args()

    g = pd.read_csv(args.group_csv, low_memory=False)
    if g.target_qid.duplicated().any():
        raise RuntimeError("duplicate target qids")

    bank = {}
    with open(args.item_bank_jsonl, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                x = json.loads(line)
                bank[int(x["qid"])] = x
    if set(bank) != set(g.target_qid.astype(int)):
        raise RuntimeError("item bank != frozen target universe")

    trans = load_json(args.translated_questions_json)
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    paths = {
        "mathbert_answerfree": out / "mathbert_answerfree.jsonl",
        "mathbert_answeraware": out / "mathbert_answeraware.jsonl",
        "direct_answerfree": out / "direct_answerfree.jsonl",
        "direct_answeraware": out / "direct_answeraware.jsonl",
    }
    handles = {k: p.open("w", encoding="utf-8") for k, p in paths.items()}
    audit = []

    try:
        for r in g.itertuples(index=False):
            q = int(r.target_qid)
            b = bank[q]
            raw = b.get("raw_qid", str(q))
            tm = lookup(trans, raw, q)
            if tm is None:
                raise RuntimeError(f"translated question missing q={q} raw={raw}")

            ec = english_content(tm)
            if not ec:
                raise RuntimeError(f"empty translated content q={q} raw={raw}")
            eo = english_options(tm)
            if not eo:
                eo = options_list(b.get("options", []))

            qt_raw = str(b.get("question_type", "") or "")
            qt = normalize_qtype(qt_raw)
            ans = answer_text(b)
            if not ans:
                raise RuntimeError(f"official answer missing in scoring bank q={q}")

            sem_free = format_semantic(ec, eo, qt, None)
            sem_ans = format_semantic(ec, eo, qt, ans)

            cc = str(b.get("content", "") or "")
            if not cc.strip():
                raise RuntimeError(f"empty original content q={q}")
            co = options_list(b.get("options", []))
            dir_free = format_direct(cc, co, qt, None)
            dir_ans = format_direct(cc, co, qt, ans)

            kc = str(r.target_kc_key)  # retained as protocol metadata only, never placed in direct prompt text.
            base = {
                "qid": q,
                "raw_qid": str(raw),
                "content_group_fold": int(r.content_group_fold),
                "target_kc_key": kc,
            }
            handles["mathbert_answerfree"].write(json.dumps({**base, "prompt_text": sem_free, "answer_visible": False}, ensure_ascii=False) + "\n")
            handles["mathbert_answeraware"].write(json.dumps({**base, "prompt_text": sem_ans, "answer_visible": True}, ensure_ascii=False) + "\n")
            handles["direct_answerfree"].write(json.dumps({**base, "prompt_text": dir_free, "answer_visible": False}, ensure_ascii=False) + "\n")
            handles["direct_answeraware"].write(json.dumps({**base, "prompt_text": dir_ans, "answer_visible": True}, ensure_ascii=False) + "\n")

            audit.append({
                "target_qid": q,
                "raw_qid": str(raw),
                "question_type_raw": qt_raw,
                "question_type_normalized": qt,
                "english_chars": len(ec),
                "english_option_n": len(eo),
                "original_chars": len(cc),
                "answer_chars": len(ans),
                "direct_prompt_contains_kc_id": False,
                "image_marker": bool(re.search(r"(question_\d+-image_\d+|<img|\.png|\.jpg|\.jpeg)", ec, re.I)),
            })
    finally:
        for f in handles.values():
            f.close()

    aud = pd.DataFrame(audit)
    if len(aud) != 522 or aud.target_qid.nunique() != 522:
        raise RuntimeError("expected exactly 522 frozen targets")
    if aud.direct_prompt_contains_kc_id.any():
        raise RuntimeError("anonymous KC ID unexpectedly exposed in direct prompt")
    aud.to_csv(out / "view_audit.csv", index=False)

    man = {
        "schema_version": "s28a_translated_authoring_views_v2",
        "target_n": len(audit),
        "group_sha256": sha256_file(args.group_csv),
        "item_bank_sha256": sha256_file(args.item_bank_jsonl),
        "translated_questions_sha256": sha256_file(args.translated_questions_json),
        "mathbert_contract": "Published-compatible answer-free view uses public English translated question/options plus normalized public question type; answer-aware variant additionally receives the official answer. Numeric KC IDs are not embedded in the text view.",
        "direct_contract": "Original-language question/options plus normalized public question type; anonymous numeric KC IDs are omitted; answer-aware variant additionally receives the official answer. No human response/outcome statistics are exposed.",
        "question_type_map": QTYPE_MAP,
        "image_marker_n": int(aud.image_marker.sum()),
        "view_files": {k: {"path": str(p.resolve()), "sha256": sha256_file(p)} for k, p in paths.items()},
    }
    (out / "manifest.json").write_text(json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(man, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
