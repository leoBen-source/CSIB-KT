#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Frozen MathBERT CLS encoder matching the 2026 paper's representation choice."""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import torch
from s28_common_v2 import sha256_file

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--view_jsonl",required=True)
    ap.add_argument("--model_path",required=True)
    ap.add_argument("--out_npz",required=True)
    ap.add_argument("--manifest",required=True)
    ap.add_argument("--batch_size",type=int,default=32)
    ap.add_argument("--max_length",type=int,default=256)
    ap.add_argument("--device",default="cuda")
    ap.add_argument("--local_files_only",action="store_true")
    args=ap.parse_args()

    rows=[]
    with open(args.view_jsonl,encoding="utf-8") as f:
        for line in f:
            if line.strip(): rows.append(json.loads(line))
    qids=np.asarray([int(x["qid"]) for x in rows],dtype=np.int64)
    if len(qids)!=522 or len(set(qids.tolist()))!=522: raise RuntimeError("expected frozen 522 qids")
    texts=[str(x["prompt_text"]) for x in rows]

    from transformers import AutoTokenizer, AutoModel
    tok=AutoTokenizer.from_pretrained(args.model_path,local_files_only=args.local_files_only)
    model=AutoModel.from_pretrained(args.model_path,local_files_only=args.local_files_only)
    if int(getattr(model.config,"hidden_size",-1))!=768 or int(getattr(model.config,"num_hidden_layers",-1))!=12 or int(getattr(model.config,"num_attention_heads",-1))!=12:
        raise RuntimeError(f"unexpected MathBERT architecture hidden={getattr(model.config,'hidden_size',None)} layers={getattr(model.config,'num_hidden_layers',None)} heads={getattr(model.config,'num_attention_heads',None)}; frozen S28 expects tbs17/MathBERT BERT-base")
    dev=torch.device(args.device if torch.cuda.is_available() and str(args.device).startswith("cuda") else "cpu")
    model=model.to(dev).eval()

    lengths=[]; trunc=0
    for st in range(0,len(texts),128):
        e=tok(texts[st:st+128],padding=False,truncation=False,add_special_tokens=True)
        for ids in e["input_ids"]:
            lengths.append(len(ids)); trunc += int(len(ids)>args.max_length)

    embs=[]
    with torch.inference_mode():
        for st in range(0,len(texts),args.batch_size):
            batch=texts[st:st+args.batch_size]
            enc=tok(batch,return_tensors="pt",padding=True,truncation=True,max_length=args.max_length)
            enc={k:v.to(dev) for k,v in enc.items()}
            out=model(**enc)
            cls=out.last_hidden_state[:,0,:].detach().float().cpu().numpy()
            embs.append(cls)
            print(f"[MATHBERT] {min(st+len(batch),len(texts))}/{len(texts)}",flush=True)
    X=np.concatenate(embs,axis=0).astype(np.float32)
    if X.shape[0]!=522 or X.shape[1]!=768: raise RuntimeError(f"unexpected embedding shape {X.shape}")
    if not np.isfinite(X).all(): raise RuntimeError("nonfinite embedding")
    np.savez_compressed(args.out_npz,qids=qids,embedding=X)

    man={
      "schema_version":"s28b_mathbert_cls_v2",
      "model_path":str(Path(args.model_path).resolve()),
      "model_config_sha256":sha256_file(Path(args.model_path)/"config.json"),
      "model_architecture":{"hidden_size":768,"num_hidden_layers":12,"num_attention_heads":12},
      "view_sha256":sha256_file(args.view_jsonl),
      "output_sha256":sha256_file(args.out_npz),
      "target_n":522,"embedding_dim":768,"pooling":"last_hidden_state[:,0,:] ([CLS])",
      "max_length":int(args.max_length),"truncated_item_n":int(trunc),
      "max_untruncated_tokens":int(max(lengths)),
      "encoder_frozen":True,
      "paper_compatibility":"Frozen MathBERT, 256-token truncation, CLS representation. This is a strict-protocol comparator, not a reproduction of MLFBK training."
    }
    Path(args.manifest).write_text(json.dumps(man,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(man,ensure_ascii=False,indent=2))

if __name__=="__main__": main()
