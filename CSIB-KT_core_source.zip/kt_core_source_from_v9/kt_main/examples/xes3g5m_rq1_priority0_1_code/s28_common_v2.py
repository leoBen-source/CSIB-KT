#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize

EPS = 1e-6

def sha256_file(p):
    p = Path(p)
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def logit(p):
    p = np.clip(np.asarray(p, float), EPS, 1-EPS)
    return np.log(p/(1-p))

def sigmoid(x):
    x = np.clip(np.asarray(x, float), -35, 35)
    return 1/(1+np.exp(-x))

def nll_vec(y,p):
    y=np.asarray(y,float); p=np.clip(np.asarray(p,float),EPS,1-EPS)
    return -(y*np.log(p)+(1-y)*np.log(1-p))

def nll(y,p): return float(np.mean(nll_vec(y,p)))
def brier(y,p):
    y=np.asarray(y,float); p=np.asarray(p,float)
    return float(np.mean((y-p)**2))

def verify_frozen(baseline_manifest, group_csv, event_csv):
    bm=json.loads(Path(baseline_manifest).read_text(encoding="utf-8"))
    if bm.get("status")!="FROZEN" or bm.get("schema_version")!="s18a_s12_baseline_freeze_v1":
        raise RuntimeError("baseline manifest is not frozen S18/S12")
    gh=sha256_file(group_csv); eh=sha256_file(event_csv)
    if gh != bm.get("group_sha256"): raise RuntimeError("group hash mismatch")
    if eh != bm.get("event_sha256"): raise RuntimeError("event hash mismatch")
    return bm

def map_scalar_offset(cal_y, cal_base_p, prior_mean, prior_var, bound=8.0, max_iter=30, tol=1e-10):
    y=np.asarray(cal_y,float); base=logit(np.asarray(cal_base_p,float))
    m=float(prior_mean); v=max(float(prior_var),1e-8)
    if len(y)==0: return float(np.clip(m,-bound,bound))
    b=float(np.clip(m,-bound,bound))
    for _ in range(max_iter):
        p=sigmoid(base+b)
        grad=float(np.sum(p-y)+(b-m)/v)
        hess=float(np.sum(p*(1-p))+1.0/v)
        step=float(np.clip(grad/max(hess,1e-10),-2,2))
        nb=float(np.clip(b-step,-bound,bound))
        if abs(nb-b)<tol:
            b=nb; break
        b=nb
    return b

def fit_itemmacro_bridge(train_items,event_df,cols,l2=100.0):
    X=train_items[cols].to_numpy(float)
    if not np.isfinite(X).all(): raise RuntimeError(f"nonfinite bridge features {cols[:8]}")
    mu=X.mean(0); sd=X.std(0); sd=np.where(sd<1e-8,1.0,sd)
    Xs=(X-mu)/sd
    qids=train_items.target_qid.astype(int).to_numpy()
    q_to_i={q:i for i,q in enumerate(qids)}
    ee=event_df[event_df.target_qid.astype(int).isin(q_to_i)].copy()
    idx=ee.target_qid.astype(int).map(q_to_i).to_numpy(int)
    Xe=Xs[idx]; y=ee.label.to_numpy(float); base=logit(ee.teacher_kc_uniform.to_numpy(float))
    counts=ee.groupby(ee.target_qid.astype(int)).size().to_dict()
    nitem=len(train_items)
    sw=np.asarray([1.0/(nitem*counts[int(q)]) for q in ee.target_qid.astype(int)],float)
    def fg(z):
        eta=base+float(z[0])+Xe@z[1:]
        p=sigmoid(eta); r=sw*(p-y)
        loss=float(np.sum(sw*(np.logaddexp(0,eta)-y*eta))+l2*np.sum(z[1:]**2)/(2*nitem))
        grad=np.empty_like(z); grad[0]=r.sum(); grad[1:]=Xe.T@r+l2*z[1:]/nitem
        return loss,grad
    res=minimize(lambda zz:fg(zz),np.zeros(Xs.shape[1]+1),jac=True,method="L-BFGS-B")
    if not res.success: raise RuntimeError(f"bridge optimization failed: {res.message}")
    return {"coef":res.x,"mean":mu,"scale":sd,"cols":list(cols)}

def predict_bridge(model,items):
    X=(items[model["cols"]].to_numpy(float)-model["mean"])/model["scale"]
    return model["coef"][0]+X@model["coef"][1:]

def jsonable_model(m):
    out={}
    for k,v in m.items():
        if isinstance(v,np.ndarray): out[k]=v.tolist()
        elif isinstance(v,(np.integer,np.floating)): out[k]=v.item()
        else: out[k]=v
    return out

def boot_target(x,B,seed):
    x=np.asarray(x,float)
    rng=np.random.default_rng(seed)
    sims=x[rng.integers(0,len(x),size=(B,len(x)))].mean(1)
    return {"mean":float(x.mean()),"ci95":[float(np.quantile(sims,.025)),float(np.quantile(sims,.975))],
            "p_le_0":float(np.mean(sims<=0)),"positive_fraction":float(np.mean(x>0))}

def boot_kc(df,dcol,B,seed):
    groups=[g[dcol].to_numpy(float) for _,g in df.groupby("target_kc_key",sort=True)]
    rng=np.random.default_rng(seed); G=len(groups); sims=np.empty(B,float)
    for b in range(B):
        idx=rng.integers(0,G,size=G)
        sims[b]=float(np.concatenate([groups[i] for i in idx]).mean())
    return {"cluster_n":G,"ci95":[float(np.quantile(sims,.025)),float(np.quantile(sims,.975))],
            "p_le_0":float(np.mean(sims<=0))}

def monotone_envelope(y):
    return np.minimum.accumulate(np.asarray(y,float))

def crossing_budget(budgets,human_nll,target_nll):
    b=np.asarray(budgets,float); h=monotone_envelope(human_nll); t=float(target_nll)
    hit=np.where(h<=t)[0]
    if len(hit)==0: return None
    j=int(hit[0])
    if j==0: return float(b[0])
    b0,b1=float(b[j-1]),float(b[j]); y0,y1=float(h[j-1]),float(h[j])
    if abs(y0-y1)<1e-15: return b1
    frac=float(np.clip((y0-t)/(y0-y1),0,1))
    return b0+frac*(b1-b0)
