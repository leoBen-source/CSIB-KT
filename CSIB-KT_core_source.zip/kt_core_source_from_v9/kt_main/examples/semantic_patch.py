import types
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModel


@torch.no_grad()
def _mean_pool(last_hidden_state, attention_mask):
    mask = attention_mask.unsqueeze(-1).expand(last_hidden_state.size()).float()
    summed = torch.sum(last_hidden_state * mask, dim=1)
    counts = torch.clamp(mask.sum(dim=1), min=1e-9)
    return summed / counts


def _last_token_pool(last_hidden_state, attention_mask):
    # 兼容左/右 padding
    seq_lens = attention_mask.sum(dim=1) - 1
    batch_idx = torch.arange(last_hidden_state.size(0), device=last_hidden_state.device)
    return last_hidden_state[batch_idx, seq_lens]


def encode_texts_to_tensor(
    texts,
    encoder_name,
    device="cpu",
    local_files_only=True,
    normalize=True,
    batch_size=64,
    encoder_backend="sentence_transformers",
    pooling="mean",
    trust_remote_code=True,
):
    """
    返回: torch.FloatTensor [num_texts, dim]
    支持:
      1) sentence_transformers backend
      2) huggingface embedding backend
    """

    texts = ["" if x is None else str(x) for x in texts]

    if encoder_backend == "sentence_transformers":
        from sentence_transformers import SentenceTransformer

        model = SentenceTransformer(
            encoder_name,
            device=device,
            local_files_only=local_files_only,
            trust_remote_code=trust_remote_code,
        )

        embs = model.encode(
            texts,
            batch_size=batch_size,
            convert_to_tensor=True,
            normalize_embeddings=normalize,
            show_progress_bar=False,
        )
        return embs.float()

    elif encoder_backend == "hf_embedding":
        from transformers import AutoTokenizer, AutoModel

        try:
            tokenizer = AutoTokenizer.from_pretrained(
                encoder_name,
                local_files_only=local_files_only,
                trust_remote_code=trust_remote_code,
                use_fast=True,
            )
            print("[hf_embedding] fast tokenizer loaded")
        except Exception as e:
            print(f"[hf_embedding] fast tokenizer failed: {e}")
            print("[hf_embedding] fallback to slow tokenizer")
            tokenizer = AutoTokenizer.from_pretrained(
                encoder_name,
                local_files_only=local_files_only,
                trust_remote_code=trust_remote_code,
                use_fast=False,
            )
            print("[hf_embedding] slow tokenizer loaded")

        torch_dtype = None
        if str(device).startswith("cuda") and torch.cuda.is_available():
            torch_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        model = AutoModel.from_pretrained(
            encoder_name,
            local_files_only=local_files_only,
            trust_remote_code=trust_remote_code,
            torch_dtype=torch_dtype,
            low_cpu_mem_usage=True,
        )
        model = model.to(device)
        model.eval()
        print(
            f"[hf_embedding] model loaded and moved to {device}, "
            f"dtype={torch_dtype}",
            flush=True,
        )
        # embedding 模型建议左填充
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token if tokenizer.eos_token is not None else tokenizer.unk_token
        tokenizer.padding_side = "left"

        outputs = []

        with torch.no_grad():
            for i in range(0, len(texts), batch_size):
                batch_texts = texts[i:i + batch_size]

                batch = tokenizer(
                    batch_texts,
                    padding=True,
                    truncation=True,
                    max_length=512,
                    return_tensors="pt",
                )
                batch = {k: v.to(device) for k, v in batch.items()}

                out = model(**batch)

                if hasattr(out, "last_hidden_state"):
                    hidden = out.last_hidden_state
                else:
                    raise ValueError(f"[hf_embedding] model output has no last_hidden_state: {type(out)}")

                if pooling == "last":
                    pooled = _last_token_pool(hidden, batch["attention_mask"])
                else:
                    pooled = _mean_pool(hidden, batch["attention_mask"])

                if normalize:
                    pooled = F.normalize(pooled, p=2, dim=-1)

                outputs.append(pooled.detach().cpu())

        return torch.cat(outputs, dim=0).float()

    else:
        raise ValueError(f"Unsupported encoder_backend: {encoder_backend}")


def apply_semantic_control(q_tensor, mode="real", seed=0):
    if mode == "real":
        return q_tensor
    if mode == "zero":
        return torch.zeros_like(q_tensor)
    g = torch.Generator(device=q_tensor.device)
    g.manual_seed(int(seed))
    if mode == "shuffle":
        perm = torch.randperm(q_tensor.size(0), generator=g, device=q_tensor.device)
        return q_tensor[perm]
    if mode == "random":
        x = torch.randn_like(q_tensor)
        x = F.normalize(x, dim=-1)
        return x
    raise ValueError(f"Unknown semantic control mode: {mode}")

class ZeroBasedQSemanticFusion(nn.Module):
    """
    For AKT/QIKT in pykt:
    - question ids are 0-based
    - do NOT use padding_idx=0
    """
    def __init__(self, num_q, d_model, sem_input_dim, dropout=0.2, q_inject_mode="medium"):
        super().__init__()
        self.num_q = int(num_q)
        self.d_model = int(d_model)
        self.sem_input_dim = int(sem_input_dim)
        self.q_inject_mode = str(q_inject_mode)

        self.q_sem_raw = nn.Embedding(self.num_q, self.sem_input_dim)
        self.q_sem_raw.weight.requires_grad_(False)

        self.q_sem_delta = nn.Embedding(self.num_q, self.d_model)
        self.q_sem_proj = nn.Linear(self.sem_input_dim, self.d_model, bias=False)
        nn.init.xavier_uniform_(self.q_sem_proj.weight)

        self.sem_norm = nn.LayerNorm(self.d_model)

        self.q_sem_gate = nn.Sequential(
            nn.Linear(self.d_model * 2, self.d_model),
            nn.GELU(),
            nn.Linear(self.d_model, 1),
        )

        self.q_fuse = nn.Sequential(
            nn.Linear(self.d_model * 2, self.d_model),
            nn.LayerNorm(self.d_model),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def init_from_tensor(self, q_tensor):
        assert q_tensor.size(0) == self.num_q
        assert q_tensor.size(1) == self.sem_input_dim
        self.q_sem_raw.weight.data.copy_(q_tensor.to(self.q_sem_raw.weight.device))

    def project_q_sem(self, q_idx):
        q_idx = q_idx.long().clamp(min=0, max=self.num_q - 1)
        raw = self.q_sem_raw(q_idx)
        sem = self.q_sem_proj(raw)
        sem = self.sem_norm(sem)
        sem = sem + self.q_sem_delta(q_idx)
        return sem

    def fuse(self, q_id_embed, q_idx):
        q_sem = self.project_q_sem(q_idx)
        mode = self.q_inject_mode

        if mode == "light":
            emb_q = q_id_embed + q_sem
        elif mode in ["medium", "strong"]:
            q_gate = torch.sigmoid(
                self.q_sem_gate(torch.cat([q_id_embed, q_sem], dim=-1))
            )
            q_sem_used = q_gate * q_sem
            emb_q = self.q_fuse(torch.cat([q_id_embed, q_sem_used], dim=-1))
        elif mode == "none":
            emb_q = q_id_embed
        else:
            raise ValueError(f"Unknown q_inject_mode={mode}")
        return emb_q, q_sem

def attach_q_sem_to_akt(
    model,
    question_texts,
    encoder_name,
    sem_input_dim=384,
    local_files_only=True,
    batch_size=64,
    semantic_control_mode="real",
    semantic_control_seed=0,
):
    """
    Patch AKT after init_model().
    Assumption:
      - AKT in pykt uses n_pid as question id space
      - separate_qa=False (default in pykt AKT)
    """
    assert hasattr(model, "model_name") and model.model_name == "akt"
    assert model.n_pid > 0, "AKT q-sem patch needs question ids (n_pid > 0)."

    dev = next(model.parameters()).device
    d_model = model.q_embed.embedding_dim

    q_tensor = encode_texts_to_tensor(
        texts=question_texts,
        encoder_name=encoder_name,
        device=dev,
        local_files_only=local_files_only,
        normalize=True,
        batch_size=batch_size,
    )
    q_tensor = apply_semantic_control(
        q_tensor,
        mode=semantic_control_mode,
        seed=semantic_control_seed,
    )

    if q_tensor.size(1) != sem_input_dim:
        raise ValueError(
            f"[AKT-QSEM] encoder dim mismatch: got {q_tensor.size(1)}, expected {sem_input_dim}"
        )
    if q_tensor.size(0) != model.n_pid:
        raise ValueError(
            f"[AKT-QSEM] num_q mismatch: got texts={q_tensor.size(0)}, model.n_pid={model.n_pid}"
        )

    model.q_sem_fuser = ZeroBasedQSemanticFusion(
        num_q=model.n_pid,
        d_model=d_model,
        sem_input_dim=sem_input_dim,
        dropout=float(model.dropout),
    ).to(dev)
    model.q_sem_fuser.init_from_tensor(q_tensor)
    
    model.patch_meta = {
        "patch_name": "q_sem_patch",
        "model_name": "akt",
        "injection_target": "question",
        "injection_mode": "gate_mul + concat_mlp + overwrite_q_embed",
        "affects_question_branch": True,
        "affects_concept_branch": False,
        "affects_final_head": False,
        "extra_loss": False,
        "forward_patch_type": "monkey_patch_forward",
        "sem_input_dim": int(sem_input_dim),
        "num_q": int(model.n_pid),
    }

    def patched_forward(self, q_data, target, pid_data=None, qtest=False):
        emb_type = self.emb_type
        if emb_type.startswith("qid"):
            q_embed_data, qa_embed_data = self.base_emb(q_data, target)
        else:
            raise NotImplementedError("[AKT-QSEM] only qid-like emb_type is supported now.")

        # inject question semantic prior by pid_data
        if pid_data is not None:
            q_embed_data, _ = self.q_sem_fuser.fuse(q_embed_data, pid_data)

            # pykt AKT default is separate_qa=False
            if not self.separate_qa:
                qa_embed_data = self.qa_embed(target) + q_embed_data
            else:
                qa_data = q_data + self.n_question * target
                qa_embed_data = self.qa_embed(qa_data) + q_embed_data

        pid_embed_data = None
        if self.n_pid > 0:
            q_embed_diff_data = self.q_embed_diff(q_data)
            pid_embed_data = self.difficult_param(pid_data)

            q_embed_data = q_embed_data + pid_embed_data * q_embed_diff_data

            qa_embed_diff_data = self.qa_embed_diff(target)
            if self.separate_qa:
                qa_embed_data = qa_embed_data + pid_embed_data * qa_embed_diff_data
            else:
                qa_embed_data = qa_embed_data + pid_embed_data * (qa_embed_diff_data + q_embed_diff_data)

            c_reg_loss = (pid_embed_data ** 2.).sum() * self.l2
        else:
            c_reg_loss = 0.

        d_output = self.model(q_embed_data, qa_embed_data, pid_embed_data)
        concat_q = torch.cat([d_output, q_embed_data], dim=-1)
        output = self.out(concat_q).squeeze(-1)
        preds = torch.sigmoid(output)

        if not qtest:
            return preds, c_reg_loss
        else:
            return preds, c_reg_loss, concat_q

    model.forward = types.MethodType(patched_forward, model)
    print("✅ [PATCH] AKT attached with question semantic prior.")
    return model
class QIKTQueEmbWithQSem(nn.Module):
    """
    Only supports QIKT with emb_type='iekt'
    """
    def __init__(self, base_que_emb, dropout=0.2, sem_input_dim=384, q_inject_mode="medium"):
        super().__init__()
        self.base = base_que_emb
        assert self.base.emb_type == "iekt", \
            f"[QIKT-QSEM] only emb_type='iekt' is supported now, got {self.base.emb_type}"

        self.num_q = self.base.num_q
        self.num_c = self.base.num_c
        self.emb_size = self.base.emb_size
        self.device = self.base.device
        self.emb_type = self.base.emb_type
        self.q_inject_mode = str(q_inject_mode)

        self.q_sem_fuser = ZeroBasedQSemanticFusion(
            num_q=self.num_q,
            d_model=self.emb_size,
            sem_input_dim=sem_input_dim,
            dropout=dropout,
            q_inject_mode=self.q_inject_mode,
        )
        self.q_inter_proj = nn.Linear(self.emb_size, self.emb_size * 4, bias=False)

        self.q_inter_gate = nn.Sequential(
            nn.Linear(self.emb_size * 5, self.emb_size),
            nn.GELU(),
            nn.Linear(self.emb_size, 1),
        )


    def init_from_tensor(self, q_tensor):
        self.q_sem_fuser.init_from_tensor(q_tensor)

    def get_avg_skill_emb(self, c):
        return self.base.get_avg_skill_emb(c)

    def forward(self, q, c, r=None):
        emb_c = self.base.get_avg_skill_emb(c)
        emb_q_id = self.base.que_emb(q)
        emb_q, q_sem = self.q_sem_fuser.fuse(emb_q_id, q)

        emb_qc = torch.cat([emb_q, emb_c], dim=-1)
        xemb = self.base.que_c_linear(emb_qc)

        emb_qca = torch.cat([
            emb_qc.mul((1 - r).unsqueeze(-1).repeat(1, 1, self.emb_size * 2)),
            emb_qc.mul((r).unsqueeze(-1).repeat(1, 1, self.emb_size * 2))
        ], dim=-1)
        if self.q_inject_mode == "strong":
            g_inter = torch.sigmoid(
                self.q_inter_gate(torch.cat([emb_qca, q_sem], dim=-1))
            )
            emb_qca = emb_qca + g_inter * self.q_inter_proj(q_sem)


        return xemb, emb_qca, emb_qc, emb_q, emb_c


def attach_q_sem_to_qikt(
    model,
    question_texts,
    encoder_name,
    sem_input_dim=384,
    local_files_only=True,
    batch_size=64,
    semantic_control_mode="real",
    semantic_control_seed=0,
    q_inject_mode="medium",
):
    """
    Patch QIKT after init_model().
    Works for QIKT wrapper model, not raw QIKTNet.
    """
    assert hasattr(model, "model_name") and model.model_name == "qikt"
    dev = next(model.parameters()).device

    q_tensor = encode_texts_to_tensor(
        texts=question_texts,
        encoder_name=encoder_name,
        device=dev,
        local_files_only=local_files_only,
        normalize=True,
        batch_size=batch_size,
    )
    q_tensor = apply_semantic_control(
        q_tensor,
        mode=semantic_control_mode,
        seed=semantic_control_seed,
    )
    if q_tensor.size(1) != sem_input_dim:
        raise ValueError(
            f"[QIKT-QSEM] encoder dim mismatch: got {q_tensor.size(1)}, expected {sem_input_dim}"
        )
    if q_tensor.size(0) != model.model.num_q:
        raise ValueError(
            f"[QIKT-QSEM] num_q mismatch: got texts={q_tensor.size(0)}, model.model.num_q={model.model.num_q}"
        )

    wrapped = QIKTQueEmbWithQSem(
        base_que_emb=model.model.que_emb,
        dropout=float(model.model.dropout_layer.p),
        sem_input_dim=sem_input_dim,
        q_inject_mode=q_inject_mode,
    ).to(dev)
    wrapped.init_from_tensor(q_tensor)
    
    model.patch_meta = {
        "patch_name": "q_sem_patch",
        "model_name": "qikt",
        "injection_target": "question",
        "injection_mode": f"q_sem_{q_inject_mode}",
        "affects_question_branch": True,
        "affects_concept_branch": False,
        "affects_final_head": False,
        "extra_loss": False,
        "forward_patch_type": "replace_model.model.que_emb",
        "sem_input_dim": int(sem_input_dim),
        "num_q": int(model.model.num_q),
    }

    model.model.que_emb = wrapped
    print("✅ [PATCH] QIKT attached with question semantic prior.")
    return model
