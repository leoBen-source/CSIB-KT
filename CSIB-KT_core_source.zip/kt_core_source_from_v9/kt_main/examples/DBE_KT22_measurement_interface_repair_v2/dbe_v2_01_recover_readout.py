#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Repair machine-readable answer readout from the exact frozen v1 solver traces.

No official answer/correctness/human response is loaded by this script.

For v1 records with parse_ok_all=True:
    preserve final_answer exactly.

For records with any malformed/truncated attempt:
    run a deterministic readout adapter over ONLY:
      - unlabeled option texts,
      - v1 candidate answer strings,
      - v1 incomplete solver traces.
    The original question text is deliberately withheld from the adapter.

This is an interface repair, not re-generation of synthetic solver traces.
"""
from __future__ import annotations
import argparse, json, re, hashlib
from pathlib import Path
from typing import List
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

SYSTEM = """You are a strict answer-readout adapter, not a problem solver.
Do not solve a new question and do not add reasoning.
You receive unlabeled answer options and outputs from an already completed solver.
Infer which listed option the solver output most strongly supports.
Return exactly one JSON object such as {"final_answer":"B"} and nothing else.
"""

LETTERS="ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def sha256_file(p: Path):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def parse_letter(text: str, nopt: int):
    s=str(text or "").strip()
    hits=re.findall(r'"final_answer"\s*:\s*"([A-Za-z])"',s)
    if hits:
        c=hits[-1].upper()
        if c in LETTERS[:nopt]:
            return c, True
    # Very strict fallback: a standalone option letter in the adapter output.
    hits=re.findall(r'(?<![A-Za-z])([A-Za-z])(?![A-Za-z])',s)
    for x in reversed(hits):
        c=x.upper()
        if c in LETTERS[:nopt]:
            return c, True
    return "", False

def build_prompt(item, rec):
    opts=item.get("options",[]) or []
    lines=["Options (labels are for transcription only):"]
    for i,x in enumerate(opts):
        lines.append(f"{LETTERS[i]}. {x}")
    lines.append("")
    lines.append("Existing candidate answer strings from the frozen solver:")
    for i,x in enumerate(rec.get("candidate_answers",[]) or []):
        lines.append(f"candidate_{i+1}: {x}")
    fails=rec.get("raw_parse_failures",[]) or []
    if fails:
        lines.append("")
        lines.append("Incomplete frozen solver traces:")
        for i,x in enumerate(fails):
            # Keep the exact trace content but bound input size safely.
            lines.append(f"trace_{i+1}:")
            lines.append(str(x)[-12000:])
    lines.append("")
    lines.append("Transcribe the most supported option. JSON only.")
    return "\n".join(lines)

def chat(tok, user_text):
    msgs=[{"role":"system","content":SYSTEM},{"role":"user","content":user_text}]
    return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)

def next_token_fallback(model, tok, prompt, nopt):
    """Exact deterministic candidate-sequence log-likelihood fallback.

    This does not rely on option letters being one tokenizer token.  For each
    candidate letter, score the full candidate token sequence conditioned on
    the identical readout prompt and choose the highest log-likelihood.
    """
    prefix_text=prompt+"\nFinal option letter:"
    prefix=tok(prefix_text,return_tensors="pt",truncation=True,max_length=8180,add_special_tokens=False)
    prefix_ids=prefix["input_ids"][0].tolist()
    scores=[]
    for c in LETTERS[:nopt]:
        cand_ids=tok.encode(" "+c,add_special_tokens=False)
        if not cand_ids:
            cand_ids=tok.encode(c,add_special_tokens=False)
        ids=torch.tensor([prefix_ids+cand_ids],dtype=torch.long,device=model.device)
        attn=torch.ones_like(ids)
        with torch.inference_mode():
            logits=model(input_ids=ids,attention_mask=attn).logits[0]
        lp=torch.log_softmax(logits,dim=-1)
        base=len(prefix_ids)
        s=0.0
        for j,tok_id in enumerate(cand_ids):
            # Token at absolute position base+j is predicted by logits at base+j-1.
            s+=float(lp[base+j-1,int(tok_id)].item())
        scores.append(s)
    return LETTERS[int(torch.tensor(scores).argmax().item())]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--generation_bank",required=True)
    ap.add_argument("--v1_responses",required=True)
    ap.add_argument("--model_name_or_path",required=True)
    ap.add_argument("--out_jsonl",required=True)
    ap.add_argument("--audit_json",required=True)
    ap.add_argument("--local_files_only",action="store_true")
    ap.add_argument("--batch_size",type=int,default=8)
    args=ap.parse_args()

    bank={}
    with open(args.generation_bank,encoding="utf-8") as f:
        for line in f:
            if line.strip():
                x=json.loads(line); bank[int(x["qid"])]=x

    records=[]
    with open(args.v1_responses,encoding="utf-8") as f:
        for line in f:
            if line.strip():
                records.append(json.loads(line))
    if not records:
        raise RuntimeError("no v1 responses")

    # Fail closed before loading the model if the exact frozen v1 response
    # population does not expose the downstream identity contract.
    required_identity=("qid","policy_id","replica","synthetic_student_id")
    for i,r in enumerate(records):
        missing=[k for k in required_identity if k not in r]
        if missing:
            raise RuntimeError(
                f"v1 response record index={i} missing frozen identity keys {missing}; "
                f"available_keys={sorted(r.keys())}"
            )

    tok=AutoTokenizer.from_pretrained(args.model_name_or_path,local_files_only=args.local_files_only,trust_remote_code=True)
    if tok.pad_token_id is None:
        tok.pad_token=tok.eos_token
    tok.padding_side="left"
    dtype=torch.bfloat16 if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else (
        torch.float16 if torch.cuda.is_available() else torch.float32
    )
    model=AutoModelForCausalLM.from_pretrained(
        args.model_name_or_path,local_files_only=args.local_files_only,trust_remote_code=True,
        torch_dtype=dtype,device_map="auto"
    )
    model.eval()

    out=Path(args.out_jsonl)
    out.parent.mkdir(parents=True,exist_ok=True)

    # Never stream directly into the authoritative output.  A crash or parser
    # exception must leave only a .tmp file, never a truncated "completed" file.
    tmp=out.with_name(out.name+".tmp")
    if tmp.exists():
        tmp.unlink()

    repaired=0
    source_parse_ok_all_n=0
    greedy_ok=0
    fallback_n=0
    invalid_item=0
    label_canonicalized_n=0
    method_counts={}

    with tmp.open("w",encoding="utf-8") as fo:
        for st in range(0,len(records),args.batch_size):
            batch=records[st:st+args.batch_size]
            need=[]
            prompts=[]

            for bi,r in enumerate(batch):
                q=int(r["qid"])
                item=bank.get(q)
                if item is None or not (item.get("options") or []):
                    invalid_item+=1
                    raise RuntimeError(f"qid={q} missing generation-bank options")

                if bool(r.get("parse_ok_all",False)):
                    continue

                need.append(bi)
                prompts.append(chat(tok,build_prompt(item,r)))

            decoded={}
            if prompts:
                enc=tok(
                    prompts,
                    return_tensors="pt",
                    padding=True,
                    truncation=True,
                    max_length=8192,
                ).to(model.device)

                with torch.inference_mode():
                    y=model.generate(
                        **enc,
                        max_new_tokens=12,
                        do_sample=False,
                        pad_token_id=tok.pad_token_id,
                        eos_token_id=tok.eos_token_id,
                    )

                plen=enc["input_ids"].shape[1]
                for j,yy in enumerate(y):
                    decoded[need[j]]=tok.decode(
                        yy[plen:],
                        skip_special_tokens=True,
                    )

            for bi,r in enumerate(batch):
                q=int(r["qid"])
                item=bank[q]
                nopt=len(item.get("options") or [])

                z=dict(r)
                z["v2_source_v1_parse_ok_all"]=bool(
                    r.get("parse_ok_all",False)
                )
                z["v2_repair_applied"]=False
                z["v2_readout_method"]="v1_exact_preserve"
                z["v2_readout_raw"]=""

                if bool(r.get("parse_ok_all",False)):
                    source_parse_ok_all_n+=1
                    final=str(r.get("final_answer",""))
                else:
                    repaired+=1
                    raw=decoded.get(bi,"")
                    final,ok=parse_letter(raw,nopt)

                    if ok:
                        greedy_ok+=1
                        method="greedy_json_readout"
                    else:
                        prompt=chat(tok,build_prompt(item,r))
                        final=next_token_fallback(
                            model,
                            tok,
                            prompt,
                            nopt,
                        )
                        fallback_n+=1
                        method="next_token_letter_fallback"

                    z["v2_repair_applied"]=True
                    z["v2_readout_method"]=method
                    z["v2_readout_raw"]=raw

                # PATCH 004 FINAL:
                # Normalize only an explicit option-label surface form.
                # Examples: "B. Column", "B) Column", "Option B: Column".
                #
                # This operation uses no answer key, correctness label, or
                # human response.  The exact pre-normalization string is
                # preserved for audit.
                pre_canonical=str(final or "").strip()
                final=pre_canonical
                valid=final.upper() in LETTERS[:nopt]

                if not valid:
                    m=re.match(
                        r"^\s*(?:option|choice|answer)?\s*"
                        r"([A-Za-z])"
                        r"(?:\s*[.)\]:：、\-]\s*|\s+).+$",
                        final,
                        flags=re.IGNORECASE,
                    )
                    if m:
                        candidate=m.group(1).upper()
                        if candidate in LETTERS[:nopt]:
                            final=candidate
                            valid=True

                # Recompute validity AFTER canonicalization.  This is the exact
                # bug in the earlier patch chain: final changed, but the stale
                # boolean was tested again.
                valid=final.upper() in LETTERS[:nopt]

                if not valid:
                    raise RuntimeError(
                        f"invalid v2 readout qid={q}: {final!r}"
                    )

                canonicalized=(final != pre_canonical)
                if canonicalized:
                    label_canonicalized_n+=1
                    if bool(r.get("parse_ok_all",False)):
                        z["v2_readout_method"]="v1_label_canonicalization"

                z["v2_precanonical_final_answer"]=pre_canonical
                z["v2_label_canonicalized"]=bool(canonicalized)
                z["final_answer"]=final
                z["parse_ok_all"]=True
                z["parse_ok_any"]=True
                z["v2_readout_valid"]=True

                # Identity must already come from the exact frozen v1 source.
                # We deliberately do NOT invent or rewrite synthetic student IDs.
                for key in (
                    "qid",
                    "policy_id",
                    "replica",
                    "synthetic_student_id",
                ):
                    if key not in z:
                        raise RuntimeError(
                            f"qid={q}: missing frozen identity key {key}"
                        )

                method_counts[z["v2_readout_method"]]=(
                    method_counts.get(z["v2_readout_method"],0)+1
                )

                # CRITICAL persistence statement: executable Python on its own
                # physical source lines, never embedded inside a comment.
                fo.write(
                    json.dumps(z,ensure_ascii=False)+"\n"
                )

            fo.flush()
            print(
                f"[V2-READOUT] "
                f"{min(st+len(batch),len(records))}/"
                f"{len(records)}",
                flush=True,
            )

    # Fail-closed persistence + identity audit BEFORE publishing the file.
    persisted=[]
    with tmp.open("r",encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                persisted.append(json.loads(line))

    if len(persisted)!=len(records):
        raise RuntimeError(
            "v2 readout persistence failure: "
            f"source_record_n={len(records)} "
            f"persisted_record_n={len(persisted)} "
            f"tmp={tmp}"
        )

    per_student={}
    for i,(src,z) in enumerate(zip(records,persisted)):
        for key in (
            "qid",
            "policy_id",
            "replica",
            "synthetic_student_id",
        ):
            if str(z.get(key))!=str(src.get(key)):
                raise RuntimeError(
                    "v2 frozen identity mismatch at "
                    f"record_index={i} key={key}: "
                    f"source={src.get(key)!r} "
                    f"persisted={z.get(key)!r}"
                )

        q=int(z["qid"])
        item=bank.get(q)
        if item is None:
            raise RuntimeError(
                f"persisted qid={q} missing from generation bank"
            )

        nopt=len(item.get("options") or [])
        final=str(z.get("final_answer","")).strip().upper()
        if final not in LETTERS[:nopt]:
            raise RuntimeError(
                f"persisted invalid readout qid={q}: {final!r}"
            )

        sid=str(z["synthetic_student_id"])
        g=per_student.setdefault(
            sid,
            {"response_n":0,"qids":set()},
        )
        g["response_n"]+=1
        g["qids"].add(q)

    source_students={
        str(r["synthetic_student_id"]) for r in records
    }
    if set(per_student)!=source_students:
        raise RuntimeError(
            "synthetic-student identity set changed during v2 readout"
        )

    expected_item_n=len(bank)
    bad_students={
        sid:{
            "response_n":g["response_n"],
            "unique_qid_n":len(g["qids"]),
        }
        for sid,g in per_student.items()
        if (
            g["response_n"]!=expected_item_n
            or len(g["qids"])!=expected_item_n
        )
    }
    if bad_students:
        raise RuntimeError(
            "incomplete synthetic students in v2 readout: "
            f"{bad_students}"
        )

    # Publish atomically only after all checks pass.
    tmp.replace(out)

    persisted_sha256=sha256_file(out)
    readout_valid_fraction=(
        sum(
            bool(r.get("v2_readout_valid",False))
            for r in persisted
        )/len(persisted)
    )

    audit={
      "schema_version":
          "dbe_v2_readout_repair_audit_patch004_final",
      "v1_response_sha256":
          sha256_file(Path(args.v1_responses)),
      "generation_bank_sha256":
          sha256_file(Path(args.generation_bank)),
      "persisted_output_sha256":
          persisted_sha256,
      "record_n":
          len(records),
      "persisted_record_n":
          len(persisted),
      "item_n":
          expected_item_n,
      "synthetic_student_n":
          len(per_student),
      # Backward-compatible field name.  These are source records whose v1
      # parser reported parse_ok_all=True; some can still undergo label-only
      # canonicalization such as "B. Column" -> "B".
      "unchanged_parse_ok_all_n":
          source_parse_ok_all_n,
      "source_parse_ok_all_n":
          source_parse_ok_all_n,
      "repair_applied_n":
          repaired,
      "repair_fraction":
          repaired/len(records),
      "label_canonicalized_n":
          label_canonicalized_n,
      "greedy_json_success_n":
          greedy_ok,
      "fallback_n":
          fallback_n,
      "readout_valid_fraction":
          readout_valid_fraction,
      "method_counts":
          method_counts,
      "identity_contract":
          (
            "qid/policy_id/replica/synthetic_student_id are copied "
            "unchanged from the exact frozen v1 response population and "
            "verified line by line before atomic publication."
          ),
      "persistence_contract":
          (
            "The authoritative JSONL is created by atomic replacement only "
            "after source-count, identity, item, student, and readout-validity "
            "checks pass. Interrupted runs can leave only a .tmp file."
          ),
      "scientific_contract":
          (
            "No official answer/correctness/human response was loaded. "
            "Exact v1 solver traces were not regenerated. Only explicit "
            "option-label surface forms can be canonicalized."
          ),
    }

    Path(args.audit_json).write_text(
        json.dumps(
            audit,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    print(
        "[V2-PERSISTENCE-CHECK] "
        f"PASS: {len(persisted)} responses; "
        f"{len(per_student)} synthetic students x "
        f"{expected_item_n} items."
    )
    print(json.dumps(audit,ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()
