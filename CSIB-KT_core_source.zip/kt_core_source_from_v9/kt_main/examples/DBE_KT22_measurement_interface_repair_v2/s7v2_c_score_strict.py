#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Strict scoring with ordered multi-blank semantics."""
from __future__ import annotations
import argparse, json
from pathlib import Path
import pandas as pd
from s7v2_common import score_from_spec

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--item_bank_jsonl", required=True)
    ap.add_argument("--responses_jsonl", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--min_scoring_coverage", type=float, default=.98)
    args = ap.parse_args()

    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    bank = {}
    with open(args.item_bank_jsonl, encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                o = json.loads(line); bank[int(o["qid"])] = o

    rows = []; methods = {}; missing = set()
    with open(args.responses_jsonl, encoding="utf-8") as fh:
        for line in fh:
            if not line.strip():
                continue
            r = json.loads(line); q = int(r["qid"])
            if q not in bank:
                missing.add(q); continue
            item = bank[q]
            try:
                correct, why = score_from_spec(r.get("final_answer",""), item["answer_spec"])
                scoring_valid = 1
            except Exception as e:
                correct, why, scoring_valid = False, f"scoring_error:{type(e).__name__}", 0
            methods[why] = methods.get(why, 0) + 1
            rows.append({
                "qid": q, "policy_id": r["policy_id"], "replica": int(r["replica"]),
                "synthetic_student_id": r["synthetic_student_id"],
                "final_answer": r.get("final_answer",""),
                "correct": int(bool(correct)), "scoring_valid": int(scoring_valid),
                "score_method": why,
                "attempts": int(r.get("attempts",1)),
                "reasoning_budget": int(r.get("reasoning_budget",0)),
                "thinking": int(bool(r.get("thinking",False))),
                "modal_vote_count": int(r.get("modal_vote_count",1)),
                "parse_ok_any": int(bool(r.get("parse_ok_any",True)))
            })
    df = pd.DataFrame(rows)
    df.to_csv(out/"synthetic_response_matrix_v2.csv", index=False)

    item_valid = df.groupby("qid").scoring_valid.min() if len(df) else pd.Series(dtype=float)
    coverage = float(item_valid.mean()) if len(item_valid) else 0.0
    per_student = df.groupby("synthetic_student_id").agg(
        accuracy=("correct","mean"), valid_fraction=("scoring_valid","mean"),
        response_n=("qid","count")).reset_index()
    per_student.to_csv(out/"synthetic_student_raw_accuracy.csv", index=False)
    summary = {
        "schema_version":"s7v2_strict_scorer",
        "item_n": len(bank), "response_n": int(len(df)),
        "item_scoring_coverage": coverage,
        "overall_accuracy": float(df.loc[df.scoring_valid==1,"correct"].mean()) if len(df) else None,
        "student_accuracy_min": float(per_student.accuracy.min()) if len(per_student) else None,
        "student_accuracy_max": float(per_student.accuracy.max()) if len(per_student) else None,
        "student_accuracy_sd": float(per_student.accuracy.std(ddof=0)) if len(per_student) else None,
        "score_method_counts": methods, "missing_bank_qids": sorted(missing)[:100]
    }
    (out/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if coverage < args.min_scoring_coverage:
        raise RuntimeError(f"strict scoring coverage {coverage:.3f} < required {args.min_scoring_coverage:.3f}")

if __name__ == "__main__":
    main()
