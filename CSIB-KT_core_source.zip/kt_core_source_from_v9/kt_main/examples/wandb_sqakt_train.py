import argparse
from wandb_train import main

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_name", type=str, default="assist2009")
    parser.add_argument("--model_name", type=str, default="sqakt")
    parser.add_argument("--emb_type", type=str, default="qid")
    parser.add_argument("--save_dir", type=str, default="saved_model")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--fold", type=int, default=0)

    parser.add_argument("--d_model", type=int, default=256)
    parser.add_argument("--n_heads", type=int, default=4)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--learning_rate", type=float, default=3e-4)

    parser.add_argument("--gamma_init", type=float, default=-2.25)
    parser.add_argument("--gru_layers", type=int, default=1)

    parser.add_argument("--use_v4_init", type=int, default=1)
    parser.add_argument("--v4_alpha", type=float, default=0.7)
    parser.add_argument("--v4_alpha_q", type=float, default=0.7)
    parser.add_argument("--v4_local_files_only", type=int, default=1)
    parser.add_argument("--minilm_path", type=str, default="/home/dell/KT/KT_LLM_experiments/kt_main/data/all-MiniLM-L6-v2")
    parser.add_argument("--sem_input_dim", type=int, default=384)
    parser.add_argument("--dataset_dir_override", type=str, default="")
    parser.add_argument("--teacher_dir_override", type=str, default="")
    parser.add_argument("--semantic_dataset_root_override", type=str, default="")
    parser.add_argument("--text_encoder_path", type=str, default="")
    parser.add_argument("--text_encoder_backend", type=str, default="sentence_transformers", choices=["sentence_transformers", "hf_embedding"])



    # SQAKT-v2
    parser.add_argument("--backbone_type", type=str, default="gru", choices=["gru", "trans"])
    parser.add_argument("--n_layers", type=int, default=1)
    parser.add_argument("--ffn_mult", type=int, default=4)
    parser.add_argument("--debug_q_align", type=int, default=1)


    parser.add_argument("--use_wandb", type=int, default=1)
    parser.add_argument("--add_uuid", type=int, default=1)
    parser.add_argument("--v4_text_source", type=str, default="raw")
    parser.add_argument("--use_c_sem", type=int, default=1)
    parser.add_argument("--use_q_sem", type=int, default=1)
    # Full official KC-set input for one-question-per-interaction XES3G5M runs.
    # This changes only the concept channel representation; question IDs remain intact.
    parser.add_argument("--kc_set_input", type=int, default=0)
    parser.add_argument("--kc_pooling", type=str, default="mean", choices=["mean"])
    parser.add_argument("--kc_set_max_concepts", type=int, default=0, help="Set-aware SQAKT only; 0 keeps data_config value")
    parser.add_argument("--q_inject_mode", type=str, default="none")
    # semantic control
    parser.add_argument("--semantic_control_mode", type=str, default="real",
                        choices=["real", "zero", "shuffle", "random", "same_kc_shuffle"])
    parser.add_argument("--semantic_control_seed", type=int, default=0)

    # semantic injection scale
    parser.add_argument("--q_sem_scale", type=float, default=0.05)
    parser.add_argument("--c_sem_scale", type=float, default=0.05)

    # clean control: default off
    parser.add_argument("--use_q_sem_delta", type=int, default=0)
    parser.add_argument("--use_c_sem_delta", type=int, default=0)

    # auxiliary losses
    parser.add_argument("--lambda_align_q", type=float, default=0.0)
    parser.add_argument("--lambda_align_c", type=float, default=0.0)
    parser.add_argument("--lambda_same", type=float, default=0.0)
    parser.add_argument("--lambda_smooth", type=float, default=0.0)

    # runtime
    parser.add_argument("--sem_batch_size", type=int, default=8)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--num_epochs", type=int, default=200)
    parser.add_argument("--use_q_support_gate", type=int, default=0)
    parser.add_argument("--q_support_gate_type", type=str, default="inv_sqrt")
    parser.add_argument("--q_support_gate_floor", type=float, default=0.0)
    parser.add_argument("--q_support_path", type=str, default="")

    # Recommended item parameterization:
    #   e_q = LN(B1_q + g_I(s_q) * Delta_q)
    # B1 is always present; Delta_q is a zero-initialized item-ID residual.
    parser.add_argument(
        "--q_item_parameterization", type=str, default="legacy_independent",
        choices=["legacy_independent", "id_only_cold_mask", "semantic_base_residual"],
    )
    parser.add_argument("--q_sem_anchor_scale", type=float, default=1.0)
    parser.add_argument(
        "--q_id_gate_type", type=str, default="sqrt_reliability",
        choices=["none", "cold_mask", "sqrt_reliability", "reliability"],
    )
    parser.add_argument("--q_id_tau", type=float, default=20.0)
    parser.add_argument("--q_id_residual_zero_init", type=int, default=1)
    parser.add_argument("--q_id_residual_dropout", type=float, default=0.0)
    parser.add_argument("--q_strict_cold_zero_id", type=int, default=1)

    # Contribution-3 stage-1: support-adaptive ID-content arbitration.
    # This is different from the old additive support gate.
    parser.add_argument("--use_q_content_arbitration", type=int, default=0)
    parser.add_argument("--q_content_tau", type=float, default=20.0)
    parser.add_argument("--q_content_eps", type=float, default=0.0)
    parser.add_argument("--q_content_id_floor", type=float, default=0.05)
    parser.add_argument("--q_content_sem_scale", type=float, default=-1.0)
    parser.add_argument("--q_content_sem_floor", type=float, default=0.0)
    parser.add_argument("--same_kc_shuffle_map_path", type=str, default="")
    parser.add_argument("--use_q_structured_sem", type=int, default=0)
    parser.add_argument("--q_structured_features_path", type=str, default="")
    parser.add_argument("--structured_semantic_control_mode", type=str, default="")
    # B3 dual-view refinement branch (separate from B1 anchor).
    parser.add_argument("--use_q_ref_sem", type=int, default=0)
    parser.add_argument("--use_q_ref_structured_sem", type=int, default=0)
    parser.add_argument("--q_ref_structured_features_path", type=str, default="")
    parser.add_argument("--q_ref_sem_scale", type=float, default=0.05)
    parser.add_argument(
        "--q_ref_gate_type", type=str, default="seen_inv_sqrt",
        choices=["seen_inv_sqrt", "all_inv_sqrt", "seen_constant", "log_bandpass", "off"],
    )
    parser.add_argument("--q_ref_gate_floor", type=float, default=0.0)
    parser.add_argument(
        "--q_ref_fusion_mode", type=str, default="static_legacy",
        choices=["static_legacy", "target_state_gate"],
    )
    parser.add_argument(
        "--q_ref_projection_mode", type=str, default="shared_zero_adapter",
        choices=["shared_zero_adapter", "independent_legacy"],
    )
    parser.add_argument("--q_ref_detach_shared_projection", type=int, default=1)
    parser.add_argument("--q_ref_cap_to_anchor_ratio", type=float, default=0.50)
    parser.add_argument("--q_ref_band_on", type=float, default=2.0)
    parser.add_argument("--q_ref_band_off", type=float, default=50.0)
    parser.add_argument("--q_ref_band_slope_on", type=float, default=4.0)
    parser.add_argument("--q_ref_band_slope_off", type=float, default=4.0)
    parser.add_argument("--q_ref_cold_scale", type=float, default=0.0)
    parser.add_argument(
        "--q_ref_semantic_control_mode", type=str, default="real",
        choices=["real", "zero", "shuffle", "random", "same_kc_shuffle"],
    )
    # fold-specific calibrated / residual LLM prior
    parser.add_argument("--use_q_calib_prior", type=int, default=0)
    parser.add_argument("--q_calib_prior_path", type=str, default="")
    parser.add_argument("--q_calib_value_col", type=str, default="calibrated_value")
    parser.add_argument(
        "--q_calib_prior_mode",
        type=str,
        default="incorrect_rate",
        choices=["incorrect_rate", "incorrect_delta", "correct_logit"],
    )
    parser.add_argument(
        "--q_calib_qid_base",
        type=str,
        default="auto",
        choices=["auto", "zero_based", "one_based"],
    )
    parser.add_argument("--q_calib_scale_init", type=float, default=0.05)
    parser.add_argument("--q_calib_learnable_scale", type=int, default=1)
    parser.add_argument("--q_calib_use_support_gate", type=int, default=1)
    parser.add_argument("--q_calib_normalize", type=int, default=1)
    parser.add_argument("--q_calib_clip", type=float, default=5.0)
    # Contribution-3 stage-2: independent residual gate for logit correction.
    parser.add_argument(
        "--q_residual_gate_type",
        type=str,
        default="legacy_support",
        choices=["legacy_support", "none", "sqrt_tau", "inv_sqrt", "inv_log", "binary_tail"],
    )
    parser.add_argument("--q_residual_tau", type=float, default=20.0)
    parser.add_argument("--q_residual_gate_floor", type=float, default=0.0)
    parser.add_argument("--q_residual_tail_threshold", type=float, default=20.0)
    parser.add_argument(
        "--q_content_arbitration_mode",
        type=str,
        default="sqrt_replace",
        choices=["sqrt_replace", "hard", "replace", "soft", "soft_id", "soft_arbitration", "cold_mask_constant_sem"],
    )
    parser.add_argument("--q_content_id_mix_gamma", type=float, default=0.25)
    parser.add_argument("--q_content_use_layernorm", type=int, default=1)

    args = parser.parse_args()
    main(vars(args))
