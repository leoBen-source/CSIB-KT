# coding: utf-8
"""
Unified teacher-profile verbalizer + semantic text builders.

This file replaces semantic_text_builders.py. Keep the public function names
from the old file so existing model code can import them from here instead:

    from verbalize_teacher_profiles_generic import build_question_texts_from_teacher_json

CLI output:
  concept_template_texts.json
  question_template_texts.json
  llm_rewrite_prompts.jsonl  (optional)
"""

import os
import json
import argparse
from collections import Counter
from typing import Dict, Iterable, List, Sequence

import pandas as pd


def safe_text(x):
    if x is None:
        return ""
    try:
        if pd.isna(x):
            return ""
    except Exception:
        pass
    return " ".join(str(x).strip().split())


def clean_id(x):
    s = safe_text(x)
    if s.endswith(".0"):
        s = s[:-2]
    return s


def load_records(path):
    if path.endswith(".jsonl"):
        rows = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
        return rows
    if path.endswith(".csv"):
        return pd.read_csv(path, low_memory=False).to_dict("records")
    raise ValueError(f"Unsupported file: {path}")


def join_list(v, sep="; "):
    if isinstance(v, list):
        return sep.join([safe_text(x) for x in v if safe_text(x)])
    # CSV may store list as string like "['a', 'b']". Keep it readable, no eval.
    return safe_text(v)


def get_question_key(rec):
    for k in ["question_id_raw", "problem_id", "question_id", "qid", "id"]:
        val = safe_text(rec.get(k, ""))
        if val:
            return val
    return ""


def get_concept_key(rec):
    for k in ["concept_id_raw", "skill_id", "concept_id", "kc_id", "tag_id", "id"]:
        val = safe_text(rec.get(k, ""))
        if val:
            return val
    return ""


def get_concept_name(rec):
    for k in ["concept_name", "skill_name", "concept_id_raw", "skill_id", "concept_id"]:
        val = safe_text(rec.get(k, ""))
        if val:
            return val
    return ""


def _fmt_float(x, digits=3):
    try:
        if x is None or pd.isna(x):
            return ""
        return f"{float(x):.{digits}f}"
    except Exception:
        return ""


def _append_stats(parts, rec, correctness_name="Observed train-only correctness"):
    diff = safe_text(rec.get("difficulty_bucket", "unknown"))
    support = rec.get("support_count", None)
    rate = _fmt_float(rec.get("train_correct_rate", None))
    if support is not None and safe_text(support) != "" and safe_text(support) != "nan":
        try:
            parts.append(f"Train-fold support count is {int(float(support))}.")
        except Exception:
            pass
    if diff:
        parts.append(f"Estimated difficulty is {diff}.")
    if rate:
        parts.append(f"{correctness_name} is about {rate}.")
    for key, label in [
        ("avg_attempt_count", "Average attempt count"),
        ("avg_hint_count", "Average hint count"),
        ("avg_hint_ratio", "Average hint ratio"),
        ("avg_ms_first_response", "Average first response time in ms"),
        ("avg_incorrects", "Average incorrect attempts"),
        ("avg_corrects", "Average correct attempts"),
    ]:
        val = _fmt_float(rec.get(key, None))
        if val:
            parts.append(f"{label} is about {val}.")


def concept_text(rec, dataset="generic", prior_variant="combo"):
    sname = get_concept_name(rec)
    qcnt = rec.get("question_count", None)
    parts = []
    if dataset == "algebra2005":
        parts.append(f"This algebra skill is {sname}.")
        _append_stats(parts, rec, correctness_name="Observed train-only first-attempt correctness")
        rep_steps = join_list(rec.get("representative_steps", []))
        rep_qs = join_list(rec.get("representative_questions", []))
        rep_hier = join_list(rec.get("top_problem_hierarchy", []))
        opp = join_list(rec.get("opportunity_examples", []))
        if qcnt is not None and safe_text(qcnt) not in ["", "nan"]:
            parts.append(f"It is linked to about {int(float(qcnt))} questions in the metadata table.")
        if rep_steps:
            parts.append(f"Representative steps include: {rep_steps}.")
        if rep_qs:
            parts.append(f"Representative questions include: {rep_qs}.")
        if rep_hier:
            parts.append(f"Common hierarchy includes: {rep_hier}.")
        if opp:
            parts.append(f"Typical opportunity values include: {opp}.")
    elif dataset in ["ednet", "ednet5k", "ednet5w"]:
        parts.append(f"This EdNet concept tag is {sname}.")
        _append_stats(parts, rec, correctness_name="Observed train-only correctness proxy")
        rep_parts = join_list(rec.get("representative_parts", []))
        bundles = join_list(rec.get("top_bundle_ids", []))
        rep_qs = join_list(rec.get("representative_questions", []))
        if rep_parts:
            parts.append(f"It commonly appears in part(s): {rep_parts}.")
        if qcnt is not None and safe_text(qcnt) not in ["", "nan"]:
            parts.append(f"It is linked to about {int(float(qcnt))} questions in the metadata table.")
        if bundles:
            parts.append(f"Common bundle ids include: {bundles}.")
        if rep_qs:
            parts.append(f"Representative question ids include: {rep_qs}.")
    else:  # assist2009 / generic
        if prior_variant in ["content", "combo"]:
            parts.append(f"This ASSIST2009 knowledge concept is {sname}.")
        else:
            parts.append(f"ASSIST2009 concept {sname}.")

        if prior_variant in ["behavior", "combo"]:
            _append_stats(parts, rec, correctness_name="Observed train-only correctness")

        if prior_variant in ["content", "combo"]:
            rep = join_list(rec.get("representative_originals", []))
            answer_types = join_list(rec.get("answer_types", []))
            templates = join_list(rec.get("top_template_ids", []))
            if qcnt is not None and safe_text(qcnt) not in ["", "nan"]:
                parts.append(f"It is linked to about {int(float(qcnt))} questions in the metadata table.")
            if templates:
                parts.append(f"Common template ids include: {templates}.")
            if answer_types:
                parts.append(f"Common answer types include: {answer_types}.")
            if rep:
                parts.append(f"Representative question texts include: {rep}.")
    return " ".join([p for p in parts if p]) or f"concept {sname}"


def question_text(rec, dataset="generic", prior_variant="combo"):
    qkey = get_question_key(rec)
    parts = []
    if dataset == "algebra2005":
        pname = safe_text(rec.get("problem_name", ""))
        sname = safe_text(rec.get("step_name", "")) or safe_text(rec.get("representative_step_text", ""))
        hier = safe_text(rec.get("problem_hierarchy", ""))
        view = safe_text(rec.get("problem_view", ""))
        kcs = join_list(rec.get("kc_list", []))
        opp = join_list(rec.get("opportunity_list", []))
        if pname:
            parts.append(f"Problem name is {pname}.")
        if sname:
            parts.append(f"Step is {sname}.")
        if hier:
            parts.append(f"Hierarchy is {hier}.")
        if view:
            parts.append(f"Problem view is {view}.")
        if kcs:
            parts.append(f"Related skills are: {kcs}.")
        if opp:
            parts.append(f"Opportunity values include: {opp}.")
        _append_stats(parts, rec, correctness_name="Observed train-only first-attempt correctness")
    elif dataset in ["ednet", "ednet5k", "ednet5w"]:
        ans = safe_text(rec.get("correct_answer", ""))
        part = safe_text(rec.get("part", ""))
        tags = join_list(rec.get("tags", []))
        bundle = safe_text(rec.get("bundle_id", ""))
        explanation = safe_text(rec.get("explanation_id", ""))
        if part:
            parts.append(f"This EdNet English question belongs to part {part}.")
        if tags:
            parts.append(f"Associated tags are: {tags}.")
        if ans:
            parts.append(f"Correct answer option is {ans}.")
        if bundle:
            parts.append(f"Bundle id is {bundle}.")
        if explanation:
            parts.append(f"Explanation id is {explanation}.")
        _append_stats(parts, rec, correctness_name="Observed train-only correctness proxy")
    else:  # assist2009 / generic
        skill_name = safe_text(rec.get("skill_name", ""))
        original = safe_text(rec.get("original", ""))
        answer_type = safe_text(rec.get("answer_type", ""))
        template_id = safe_text(rec.get("template_id", ""))
        if prior_variant in ["content", "combo"]:
            if skill_name:
                parts.append(f"This ASSIST2009 problem practices the skill {skill_name}.")
            if template_id:
                parts.append(f"Template id is {template_id}.")
            if answer_type:
                parts.append(f"Answer type is {answer_type}.")
            if original:
                parts.append(f"Problem text: {original}.")
        if prior_variant in ["behavior", "combo"]:
            _append_stats(parts, rec, correctness_name="Observed train-only correctness")
        if not parts:
            parts.append(f"ASSIST2009 question id {qkey}.")
    return " ".join([p for p in parts if p]) or f"question id {qkey}"


def build_prompt_for_llm(entity_type, entity_id, text):
    return {
        "entity_type": entity_type,
        "entity_id": entity_id,
        "input_text": text,
        "instruction": (
            "Rewrite the following educational profile into one concise, factual, "
            "teacher-style semantic description for knowledge tracing. Keep only useful "
            "information for semantic similarity and student modeling. Do not invent facts. "
            "Do not mention validation or test labels."
        ),
    }


def load_map_questions(path):
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    return {clean_id(k): int(v) for k, v in obj.get("questions", obj).items()}


def load_map_concepts(path):
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    if "concepts" in obj:
        mp = obj["concepts"]
    elif "skills" in obj:
        mp = obj["skills"]
    else:
        mp = obj
    return {clean_id(k): int(v) for k, v in mp.items()}


def _aligned_texts(num_items: int, raw2idx: Dict[str, int], raw2text: Dict[str, str], pad_text: str, fallback_prefix: str) -> List[str]:
    out = [pad_text] * int(num_items)
    miss = 0
    for raw_id, idx0 in raw2idx.items():
        idx0 = int(idx0)
        if not (0 <= idx0 < int(num_items)):
            continue
        txt = safe_text(raw2text.get(clean_id(raw_id), ""))
        if not txt:
            txt = f"{fallback_prefix} {raw_id}"
            miss += 1
        out[idx0] = txt
    print(f"[ALIGNED-TEXTS] {fallback_prefix}: num={num_items}, miss={miss}")
    return out


# -------- Integrated replacements for semantic_text_builders.py --------

def build_concept_texts_from_assist2009_skillname(num_c: int, kc_map_path: str, raw_csv_path: str, pad_text: str = ""):
    sid2idx0 = load_map_concepts(kc_map_path)
    try:
        df = pd.read_csv(raw_csv_path, usecols=lambda c: c in ["skill_id", "skill_name"], encoding="utf-8", low_memory=False, dtype=str)
    except Exception as e:
        print(f"[ASSIST2009-C] failed to read CSV: {e}")
        return [f"skill {i}" for i in range(num_c)]
    df["skill_id"] = df.get("skill_id", "").map(clean_id)
    df["skill_name"] = df.get("skill_name", "").map(safe_text)
    df = df[(df["skill_id"] != "") & (df["skill_name"] != "")].copy()
    sid2name = df.groupby("skill_id")["skill_name"].agg(lambda s: Counter([safe_text(x) for x in s if safe_text(x)]).most_common(1)[0][0] if len(s) else "").to_dict()
    return _aligned_texts(num_c, sid2idx0, sid2name, pad_text, "skill")


def build_question_texts_from_assist2009(num_q: int, qid_map_path: str, raw_csv_path: str, pad_text: str = "", max_original_chars: int = 160):
    qmap = load_map_questions(qid_map_path)
    cols = ["problem_id", "assistment_id", "skill_name", "template_id", "original", "answer_text", "answer_type"]
    try:
        df = pd.read_csv(raw_csv_path, encoding="utf-8", low_memory=False, dtype=str, usecols=lambda c: c in cols)
    except Exception as e:
        print(f"[ASSIST2009-Q] failed to read CSV: {e}")
        return [pad_text] * num_q
    for col in ["problem_id", "assistment_id"]:
        if col in df.columns:
            df[col] = df[col].map(clean_id)
    qids = set(qmap.keys())
    overlap_problem = len(qids & set(df["problem_id"].dropna().map(clean_id).unique())) if "problem_id" in df.columns else 0
    overlap_assist = len(qids & set(df["assistment_id"].dropna().map(clean_id).unique())) if "assistment_id" in df.columns else 0
    id_col = "problem_id" if overlap_problem >= overlap_assist and overlap_problem > 0 else "assistment_id" if overlap_assist > 0 else ""
    if not id_col:
        return _aligned_texts(num_q, qmap, {}, pad_text, "question")

    def pick_mode(s):
        vals = [safe_text(x) for x in s if safe_text(x)]
        return Counter(vals).most_common(1)[0][0] if vals else ""

    raw2text = {}
    for qid, g in df.groupby(id_col):
        parts = []
        for col, label in [("skill_name", "skill"), ("template_id", "template"), ("answer_type", "answer type")]:
            if col in g.columns:
                val = pick_mode(g[col])
                if val:
                    parts.append(f"{label}: {val}")
        if "original" in g.columns:
            val = pick_mode(g["original"])
            if val:
                parts.append(f"problem: {val[:max_original_chars]}")
        if "answer_text" in g.columns:
            val = pick_mode(g["answer_text"])
            if val:
                parts.append(f"answer: {val[:max_original_chars]}")
        raw2text[clean_id(qid)] = " | ".join(parts) if parts else f"question id {qid}"
    return _aligned_texts(num_q, qmap, raw2text, pad_text, "question")


def build_concept_texts_from_teacher_json(num_c: int, kc_map_path: str, teacher_json_path: str, pad_text: str = "", fallback_prefix: str = "skill"):
    raw2idx = load_map_concepts(kc_map_path)
    with open(teacher_json_path, "r", encoding="utf-8") as f:
        raw2text = {clean_id(k): safe_text(v) for k, v in json.load(f).items()}
    return _aligned_texts(num_c, raw2idx, raw2text, pad_text, fallback_prefix)


def build_question_texts_from_teacher_json(num_q: int, qid_map_path: str, teacher_json_path: str, pad_text: str = "", fallback_prefix: str = "question"):
    raw2idx = load_map_questions(qid_map_path)
    with open(teacher_json_path, "r", encoding="utf-8") as f:
        raw2text = {clean_id(k): safe_text(v) for k, v in json.load(f).items()}
    return _aligned_texts(num_q, raw2idx, raw2text, pad_text, fallback_prefix)


def build_question_texts_from_qid_keys(num_q: int, qid_map_path: str, pad_text: str = ""):
    qmap = load_map_questions(qid_map_path)
    raw2text = {}
    for raw_qid in qmap:
        txt = safe_text(raw_qid).replace("-----", " ").replace("----", " ").replace("---", " ").replace("__", " ")
        raw2text[raw_qid] = " ".join(txt.split()) or f"question id {raw_qid}"
    return _aligned_texts(num_q, qmap, raw2text, pad_text, "question")


def export_question_template_texts_generic(qid_map_path: str, source_csv_paths, out_json_path: str, preferred_text_cols=None, max_text_chars: int = 256):
    qmap = load_map_questions(qid_map_path)
    raw_qids = set(qmap.keys())
    dfs = []
    for p in source_csv_paths:
        if os.path.exists(p):
            try:
                df = pd.read_csv(p, low_memory=False, dtype=str)
                df.columns = [str(c).strip() for c in df.columns]
                dfs.append(df)
                print(f"[Q-TEMPLATE] loaded {p}, shape={df.shape}")
            except Exception as e:
                print(f"[Q-TEMPLATE] failed {p}: {e}")
    if not dfs:
        raise FileNotFoundError(f"No valid source csv found: {source_csv_paths}")
    df = pd.concat(dfs, axis=0, ignore_index=True).drop_duplicates()
    best_col, best_series, best_overlap = None, None, -1
    for col in df.columns:
        s = df[col].map(clean_id)
        overlap = len(set(s.unique()) & raw_qids)
        if overlap > best_overlap:
            best_col, best_series, best_overlap = col, s, overlap
    combo_candidates = [("Problem Name", "Step Name"), ("problem_name", "step_name"), ("problem_id", "step_id")]
    for a, b in combo_candidates:
        if a in df.columns and b in df.columns:
            sa, sb = df[a].map(clean_id), df[b].map(clean_id)
            for sep in ["----", "-----", "__", "_", "::", "-"]:
                s = sa + sep + sb
                overlap = len(set(s.unique()) & raw_qids)
                if overlap > best_overlap:
                    best_col, best_series, best_overlap = f"{a}+{b}[{sep}]", s, overlap
    print(f"[Q-TEMPLATE] qid matcher={best_col}, overlap={best_overlap}/{len(raw_qids)}")
    df["_qid_raw_"] = best_series.map(clean_id)
    if preferred_text_cols is None:
        preferred_text_cols = [
            "problem_name", "step_name", "Problem Name", "Step Name", "skill_name",
            "kc_name", "KC(Default)", "original", "question_text", "body", "hint",
            "template_id", "answer_type", "answer_text", "part", "tags", "correct_answer",
        ]
    usable = [c for c in preferred_text_cols if c in df.columns]
    if not usable:
        usable = [c for c in df.columns if c != "_qid_raw_" and str(df[c].dtype) == "object"][:6]

    def pick_mode(s):
        vals = [safe_text(x) for x in s if safe_text(x)]
        return Counter(vals).most_common(1)[0][0] if vals else ""

    out, miss = {}, 0
    grouped = df.groupby("_qid_raw_")
    for raw_qid in sorted(raw_qids):
        if raw_qid not in grouped.groups:
            out[raw_qid] = f"question id {raw_qid}"
            miss += 1
            continue
        g = grouped.get_group(raw_qid)
        parts = []
        for col in usable:
            val = pick_mode(g[col])
            if val:
                parts.append(f"{col}: {val[:max_text_chars]}")
        out[raw_qid] = " | ".join(parts) if parts else f"question id {raw_qid}"
    os.makedirs(os.path.dirname(out_json_path), exist_ok=True)
    with open(out_json_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"[Q-TEMPLATE] saved {out_json_path}; total={len(out)}, miss={miss}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", type=str, default="generic", choices=["generic", "assist2009", "algebra2005", "ednet", "ednet5k", "ednet5w"])
    ap.add_argument("--concept_profiles", type=str, required=True)
    ap.add_argument("--question_profiles", type=str, required=True)
    ap.add_argument("--output_dir", type=str, required=True)
    ap.add_argument("--emit_llm_prompts", type=int, default=1)
    ap.add_argument("--prior_variant", type=str, default="combo", choices=["content", "behavior", "combo"],)

    args = ap.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    concept_records = load_records(args.concept_profiles)
    question_records = load_records(args.question_profiles)
    concept_out, question_out, llm_prompts = {}, {}, []
    for rec in concept_records:
        sid = get_concept_key(rec)
        if not sid:
            continue
        txt = concept_text(rec, dataset=args.dataset, prior_variant=args.prior_variant)
        concept_out[sid] = txt
        if args.emit_llm_prompts == 1:
            llm_prompts.append(build_prompt_for_llm("concept", sid, txt))
    for rec in question_records:
        pid = get_question_key(rec)
        if not pid:
            continue
        txt = question_text(rec, dataset=args.dataset, prior_variant=args.prior_variant)
        question_out[pid] = txt
        if args.emit_llm_prompts == 1:
            llm_prompts.append(build_prompt_for_llm("question", pid, txt))
    with open(os.path.join(args.output_dir, "concept_template_texts.json"), "w", encoding="utf-8") as f:
        json.dump(concept_out, f, ensure_ascii=False, indent=2)
    with open(os.path.join(args.output_dir, "question_template_texts.json"), "w", encoding="utf-8") as f:
        json.dump(question_out, f, ensure_ascii=False, indent=2)
    with open(os.path.join(args.output_dir, "verbalize_meta.json"), "w", encoding="utf-8") as f:
        json.dump({
            "dataset": args.dataset,
            "prior_variant": args.prior_variant,
            "concept_profiles": args.concept_profiles,
            "question_profiles": args.question_profiles,
        }, f, ensure_ascii=False, indent=2)
    if args.emit_llm_prompts == 1:
        with open(os.path.join(args.output_dir, "llm_rewrite_prompts.jsonl"), "w", encoding="utf-8") as f:
            for rec in llm_prompts:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print(f"[VERBALIZE] saved template texts to {args.output_dir}")
    print(f"  concept_template_texts.json size={len(concept_out)}")
    print(f"  question_template_texts.json size={len(question_out)}")
    print(f"  llm prompts={len(llm_prompts) if args.emit_llm_prompts == 1 else 0}")


if __name__ == "__main__":
    main()
