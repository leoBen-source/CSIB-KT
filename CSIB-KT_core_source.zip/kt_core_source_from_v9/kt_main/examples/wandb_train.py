import os
import argparse
import json
import pandas as pd
import hashlib
import types
import torch
import datetime
torch.set_num_threads(4)
from torch.optim import SGD, Adam
import copy
from pykt.models import train_model, evaluate, init_model
from pykt.utils import debug_print, set_seed
from pykt.datasets import init_dataset4train
from semantic_patch import attach_q_sem_to_qikt
from patch_audit import named_param_shapes, audit_model_patch, print_patch_audit, optimizer_membership
from verbalize_teacher_profiles_generic import (
    build_concept_texts_from_assist2009_skillname,
    build_question_texts_from_assist2009,
    build_concept_texts_from_teacher_json,
    build_question_texts_from_teacher_json,
    build_question_texts_from_qid_keys,
    export_question_template_texts_generic,
)
from tools.semantic_debug_tools import (
    debug_check_q_alignment,
    inspect_sqakt_index_and_text_alignment,
)


os.environ['CUDA_LAUNCH_BLOCKING'] = "1"
device = "cpu" if not torch.cuda.is_available() else "cuda"
os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:2'

def make_safe_params_str(params, max_len=120):
    """
    Safe experiment name builder.

    It is model-agnostic:
    - Works for SQAKT and all baseline models.
    - Does not put long absolute paths into the folder name.
    - Keeps important visible factors.
    - Uses hash of full params to preserve uniqueness.
    """

    model_name = str(params.get("model_name", "model"))
    dataset_name = str(params.get("dataset_name", "dataset"))
    fold = params.get("fold", 0)
    emb_type = str(params.get("emb_type", "emb"))
    seed = params.get("seed", 0)

    # Common hyperparameters that are useful to see.
    visible_keys_common = [
        "d_model",
        "n_heads",
        "dropout",
        "learning_rate",
        "batch_size",
        "num_epochs",
        "seed",
    ]

    # SQAKT-specific keys that are useful to see.
    visible_keys_sqakt = [
        "use_v4_init",
        "use_c_sem",
        "use_q_sem",
        "v4_text_source",
        "q_inject_mode",
        "backbone_type",
        "lambda_align",
        "lambda_align_q",
        "lambda_align_c",
        "lambda_same",
        "lambda_smooth",
        "sem_input_dim",
    ]

    # Strong baseline semantic-injection variants can also reuse these.
    visible_keys_semantic = [
        "text_encoder_backend",
        "pooling",
        "normalize",
    ]

    visible_keys = list(visible_keys_common)

    if model_name == "sqakt":
        visible_keys += visible_keys_sqakt + visible_keys_semantic
    else:
        # For other baselines, only include semantic keys if they actually exist.
        visible_keys += [
            k for k in visible_keys_sqakt + visible_keys_semantic
            if k in params
        ]

    readable_parts = [
        str(dataset_name),
        str(model_name),
        str(emb_type),
        f"fold{fold}",
    ]

    for k in visible_keys:
        if k not in params:
            continue
        v = params.get(k)
        if v is None:
            continue

        # Never put full paths into folder name.
        if "path" in k.lower() or "dir" in k.lower() or "root" in k.lower():
            v = os.path.basename(os.path.normpath(str(v)))

        sv = str(v)
        sv = sv.replace("/", "_").replace("\\", "_").replace(" ", "")
        sv = sv.replace(":", "_")

        if len(sv) > 30:
            sv = sv[:30]

        readable_parts.append(f"{k}-{sv}")

    readable = "_".join(readable_parts)

    # Do not include operational fields in the hash.
    hash_ignore_keys = {
        "save_dir",
        "add_uuid",
        "use_wandb",
        "wandb_project",
        "wandb_name",
        "device",
        "num_workers",
    }

    hash_params = {
        k: v for k, v in params.items()
        if k not in hash_ignore_keys
    }

    full_signature = json.dumps(
        hash_params,
        sort_keys=True,
        ensure_ascii=False,
        default=str,
    )
    short_hash = hashlib.md5(full_signature.encode("utf-8")).hexdigest()[:8]

    params_str = f"{readable}_{short_hash}"

    if len(params_str) > max_len:
        params_str = params_str[:max_len - 9] + "_" + short_hash

    return params_str

def save_config(train_config, model_config, data_config, params, save_dir):
    d = {"train_config": train_config, 'model_config': model_config, "data_config": data_config, "params": params}
    save_path = os.path.join(save_dir, "config.json")
    with open(save_path, "w") as fout:
        json.dump(d, fout)

def init_akt_q_sem_from_texts(
    model,
    question_texts,
    encoder_name,
    encoder_backend="sentence_transformers",
    device="cpu",
    local_files_only=True,
    batch_size=64,
    semantic_control_mode="real",
    semantic_control_seed=0,
):
    from semantic_patch import encode_texts_to_tensor, apply_semantic_control

    assert hasattr(model, "model_name") and model.model_name == "akt"
    assert getattr(model, "use_q_sem", False), "[AKT-SEM] use_q_sem must be 1"
    assert model.q_sem_raw is not None, "[AKT-SEM] q_sem_raw is None"

    expected_num_q = int(model.n_pid)
    assert len(question_texts) == expected_num_q, f"[AKT-SEM] len(question_texts)={len(question_texts)} != model.n_pid={expected_num_q}"

    q_tensor = encode_texts_to_tensor(
        texts=question_texts,
        encoder_name=encoder_name,
        encoder_backend=encoder_backend,
        device=device,
        local_files_only=local_files_only,
        normalize=True,
        batch_size=batch_size,
    )
    q_tensor = apply_semantic_control(q_tensor, mode=semantic_control_mode, seed=semantic_control_seed)

    assert q_tensor.size(0) == expected_num_q
    assert q_tensor.size(1) == model.sem_input_dim

    table_rows = model.q_sem_raw.weight.size(0)
    assert table_rows in [expected_num_q, expected_num_q + 1]

    with torch.no_grad():
        model.q_sem_raw.weight.data.zero_()
        model.q_sem_raw.weight.data[:expected_num_q].copy_(q_tensor.to(model.q_sem_raw.weight.device))
        model.q_sem_raw.weight.requires_grad_(False)

    print("[AKT/QTEXT-CHECK] len(question_texts) =", len(question_texts))
    print("[AKT/QTEXT-CHECK] model.n_pid =", model.n_pid)
    print("[AKT-SEM-CHECK] q_sem_raw.mean_abs =", model.q_sem_raw.weight.data[:expected_num_q].abs().mean().item())
    print(f"✅ [AKT-SEM] loaded semantic tensor into native akt.py path: table={tuple(model.q_sem_raw.weight.shape)}, used_rows={expected_num_q}, mode={model.q_inject_mode}")
def init_akt_q_sem_from_precomputed(
    model,
    q_sem_precomputed_path,
    semantic_control_mode="real",
    semantic_control_seed=0,
):
    from semantic_patch import apply_semantic_control

    assert hasattr(model, "model_name") and model.model_name == "akt"
    assert getattr(model, "use_q_sem", False), "[AKT-SEM] use_q_sem must be 1"
    assert model.q_sem_raw is not None, "[AKT-SEM] q_sem_raw is None"

    obj = torch.load(q_sem_precomputed_path, map_location="cpu")

    if isinstance(obj, dict) and "tensor" in obj:
        q_tensor = obj["tensor"].float()
    elif torch.is_tensor(obj):
        q_tensor = obj.float()
    else:
        raise ValueError(
            f"[AKT-SEM] unsupported precomputed file format: {q_sem_precomputed_path}"
        )

    expected_num_q = int(model.n_pid)

    assert q_tensor.size(0) == expected_num_q, (
        f"[AKT-SEM] precomputed rows={q_tensor.size(0)} "
        f"!= model.n_pid={expected_num_q}"
    )

    assert q_tensor.size(1) == model.sem_input_dim, (
        f"[AKT-SEM] precomputed dim={q_tensor.size(1)} "
        f"!= model.sem_input_dim={model.sem_input_dim}"
    )

    q_tensor = apply_semantic_control(
        q_tensor,
        mode=semantic_control_mode,
        seed=semantic_control_seed,
    )

    with torch.no_grad():
        model.q_sem_raw.weight.data.zero_()
        model.q_sem_raw.weight.data[:expected_num_q].copy_(
            q_tensor.to(model.q_sem_raw.weight.device)
        )
        model.q_sem_raw.weight.requires_grad_(False)

    print("✅ [AKT-SEM] loaded precomputed q semantic tensor")
    print("[AKT-SEM] path =", q_sem_precomputed_path)
    print("[AKT-SEM] tensor shape =", tuple(q_tensor.shape))
    print("[AKT-SEM] control =", semantic_control_mode)
    print("[AKT-SEM] q_sem_raw.mean_abs =", model.q_sem_raw.weight.data[:expected_num_q].abs().mean().item())

def init_akt_q_behavior_from_json(
    model,
    qid_map_path,
    behavior_json_path,
    device="cpu",
):
    assert hasattr(model, "model_name") and model.model_name == "akt"
    assert getattr(model, "use_q_behavior", False), "[AKT-BEHAVIOR] use_q_behavior must be 1"
    assert model.q_behavior_raw is not None

    with open(qid_map_path, "r", encoding="utf-8") as f:
        obj = json.load(f)

    qmap = obj["questions"] if isinstance(obj, dict) and "questions" in obj else obj
    qmap = {str(k).strip(): int(v) for k, v in qmap.items()}

    with open(behavior_json_path, "r", encoding="utf-8") as f:
        feat = json.load(f)

    expected_num_q = int(model.n_pid)
    rows = torch.zeros(expected_num_q, int(model.q_behavior_input_dim), dtype=torch.float32)

    # First pass: collect log_support max for normalization.
    max_log_support = 1e-6
    for qid in qmap:
        r = feat.get(str(qid), None)
        if r is not None:
            max_log_support = max(max_log_support, float(r.get("log_support", 0.0)))

    miss = 0
    for raw_qid, idx0 in qmap.items():
        if not (0 <= int(idx0) < expected_num_q):
            continue

        r = feat.get(str(raw_qid), None)
        if r is None:
            miss += 1
            # missing behavior defaults:
            # log_support_norm=0, rate=0.5, missing=1, unknown=1
            rows[idx0, :] = torch.tensor([0.0, 0.5, 1.0, 1.0, 0.0, 0.0, 0.0])
            continue

        log_support_norm = float(r.get("log_support", 0.0)) / max_log_support
        rate = float(r.get("train_correct_rate_filled", 0.5))
        rate_missing = float(r.get("rate_missing", 1))

        rows[idx0, :] = torch.tensor([
            log_support_norm,
            rate,
            rate_missing,
            float(r.get("difficulty_unknown", 0)),
            float(r.get("difficulty_hard", 0)),
            float(r.get("difficulty_medium", 0)),
            float(r.get("difficulty_easy", 0)),
        ])

    table_rows = model.q_behavior_raw.weight.size(0)
    assert table_rows in [expected_num_q, expected_num_q + 1]

    with torch.no_grad():
        model.q_behavior_raw.weight.data.zero_()
        model.q_behavior_raw.weight.data[:expected_num_q].copy_(rows.to(model.q_behavior_raw.weight.device))
        model.q_behavior_raw.weight.requires_grad_(False)

    print("[AKT-BEHAVIOR] loaded behavior features")
    print("[AKT-BEHAVIOR] behavior_json_path =", behavior_json_path)
    print("[AKT-BEHAVIOR] q_behavior_raw.shape =", tuple(model.q_behavior_raw.weight.shape))
    print("[AKT-BEHAVIOR] miss =", miss)
    print("[AKT-BEHAVIOR] mean_abs =", model.q_behavior_raw.weight.data[:expected_num_q].abs().mean().item())

def _find_existing_file(candidates):
    for p in candidates:
        if p and os.path.exists(p):
            return p
    return ""


def _safe_num_q(model, model_name):
    if model_name == "akt":
        return int(model.n_pid)
    if model_name == "qikt":
        return int(model.model.num_q)
    return int(getattr(model, "num_q", 0))


def _safe_num_c(model):
    return int(getattr(model, "num_c", 0))


def _json_has_nested_concepts(map_path):
    if not map_path or not os.path.exists(map_path):
        return False
    with open(map_path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    return isinstance(obj, dict) and "concepts" in obj and isinstance(obj["concepts"], dict)


def _pick_semantic_json(v4_src, template_path, teacher_path):
    if v4_src == "teacher" and teacher_path and os.path.exists(teacher_path):
        return teacher_path, "teacher"
    if template_path and os.path.exists(template_path):
        return template_path, "template"
    return "", "missing"


def _build_concept_texts_from_map_keys(num_c, kc_map_path, prefix="concept"):
    if not kc_map_path or not os.path.exists(kc_map_path):
        return [""] * num_c

    with open(kc_map_path, "r", encoding="utf-8") as f:
        kc_map_obj = json.load(f)

    if isinstance(kc_map_obj, dict) and "concepts" in kc_map_obj and isinstance(kc_map_obj["concepts"], dict):
        kc_map = kc_map_obj["concepts"]
    else:
        kc_map = kc_map_obj

    out = [""] * num_c
    for raw_cid, idx0 in kc_map.items():
        idx0 = int(idx0)
        if 0 <= idx0 < num_c:
            txt = str(raw_cid).replace("~~", "; ").replace("[", "").replace("]", "")
            out[idx0] = " ".join(txt.split()) or f"{prefix} {raw_cid}"
    return out


def build_concept_texts_from_keyid2idx_teacher_json(
    num_c: int,
    keyid2idx_path: str,
    teacher_json_path: str,
    pad_text: str = "",
    fallback_prefix: str = "concept",
):
    with open(keyid2idx_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    if isinstance(meta, dict) and "concepts" in meta and isinstance(meta["concepts"], dict):
        cmap = meta["concepts"]
    else:
        cmap = meta

    with open(teacher_json_path, "r", encoding="utf-8") as f:
        cid2text = json.load(f)

    out = [pad_text] * num_c
    miss = 0

    for cid_str, idx0 in cmap.items():
        idx0 = int(idx0)
        if not (0 <= idx0 < num_c):
            continue
        txt = str(cid2text.get(str(cid_str).strip(), "")).strip()
        if not txt:
            txt = f"{fallback_prefix} {cid_str}"
            miss += 1
        out[idx0] = txt

    print(f"✅ [TEACHER-C] loaded concept texts: miss={miss}, num_c={num_c}")
    for i in range(min(4, num_c)):
        if out[i]:
            print(f"  C{i}: {out[i][:120]}")
    return out


def _build_concept_texts_auto(num_c, kc_map_path, text_json_path, fallback_prefix):
    if not kc_map_path:
        return [f"{fallback_prefix} {i}" if i > 0 else "" for i in range(num_c)]

    if text_json_path and os.path.exists(text_json_path):
        if _json_has_nested_concepts(kc_map_path):
            return build_concept_texts_from_keyid2idx_teacher_json(
                num_c=num_c,
                keyid2idx_path=kc_map_path,
                teacher_json_path=text_json_path,
                pad_text="",
                fallback_prefix=fallback_prefix,
            )
        else:
            return build_concept_texts_from_teacher_json(
                num_c=num_c,
                kc_map_path=kc_map_path,
                teacher_json_path=text_json_path,
                pad_text="",
                fallback_prefix=fallback_prefix,
            )

    return _build_concept_texts_from_map_keys(num_c, kc_map_path, prefix=fallback_prefix)


def _build_dataset_semantic_texts(dataset_name, model_name, model, params, dataset_root):
    """
    唯一语义文本入口：
    - assist2009 / algebra2005 / ednet
    - sqakt / akt / qikt / llmkt
    只负责“文本准备”，不做具体注入。
    """
    semantic_root = params.get("semantic_dataset_root_override", dataset_root)

    teacher_dir = params.get("teacher_dir_override", "")
    if not teacher_dir:
        teacher_subdir = params.get("teacher_subdir", "")

        if not teacher_subdir:
            prior_variant = params.get("semantic_prior_variant", "combo")
            teacher_subdir = f"fold{int(params.get('fold', 0))}_trainonly_{prior_variant}"

        teacher_dir = os.path.join(semantic_root, "teacher", teacher_subdir)
    
    os.makedirs(teacher_dir, exist_ok=True)

    v4_src = params.get("v4_text_source", "raw")
    num_q = _safe_num_q(model, model_name)
    num_c = _safe_num_c(model)

    use_q_sem = bool(getattr(model, "use_q_sem", params.get("use_q_sem", 0)))
    use_c_sem = bool(getattr(model, "use_c_sem", params.get("use_c_sem", 0))) and model_name not in ["akt", "qikt"]

    pack = {
        "concept_texts": None,
        "question_texts": None,
        "question_text_source": "none",
        "concept_text_source": "none",
        "teacher_dir": teacher_dir,
    }

    # =========================
    # assist2009
    # =========================
    if dataset_name == "assist2009":
        raw_csv = os.path.join(dataset_root, "skill_builder_data_corrected_collapsed_utf8.csv")
        qid_map_path = os.path.join(semantic_root, "keyid2idx.json")
        kc_map_path = _find_existing_file([
            os.path.join(dataset_root, "correct_kc_map.json"),
            os.path.join(semantic_root, "kc_map.json"),
        ])

        template_question_path = os.path.join(teacher_dir, "question_template_texts.json")
        template_concept_path = os.path.join(teacher_dir, "concept_template_texts.json")
        teacher_question_path = os.path.join(teacher_dir, "question_llm_texts.json")
        teacher_concept_path = os.path.join(teacher_dir, "concept_llm_texts.json")

        if use_q_sem and num_q > 0:
            if v4_src in ["raw", "skill_name"]:
                pack["question_texts"] = build_question_texts_from_assist2009(
                    num_q=num_q,
                    qid_map_path=qid_map_path,
                    raw_csv_path=raw_csv,
                    pad_text="",
                )
                pack["question_text_source"] = "raw"
            else:
                q_json, q_src = _pick_semantic_json(v4_src, template_question_path, teacher_question_path)
                pack["question_texts"] = build_question_texts_from_teacher_json(
                    num_q=num_q,
                    qid_map_path=qid_map_path,
                    teacher_json_path=q_json,
                    pad_text="",
                )
                pack["question_text_source"] = q_src

        if use_c_sem and num_c > 0:
            if v4_src in ["raw", "skill_name"]:
                pack["concept_texts"] = build_concept_texts_from_assist2009_skillname(
                    num_c=num_c,
                    kc_map_path=kc_map_path,
                    raw_csv_path=raw_csv,
                    pad_text="",
                )
                pack["concept_text_source"] = "raw"
            else:
                c_json, c_src = _pick_semantic_json(v4_src, template_concept_path, teacher_concept_path)
                pack["concept_texts"] = build_concept_texts_from_teacher_json(
                    num_c=num_c,
                    kc_map_path=kc_map_path,
                    teacher_json_path=c_json,
                    pad_text="",
                )
                pack["concept_text_source"] = c_src

        return pack

    # =========================
    # algebra2005
    # =========================
    if dataset_name == "algebra2005":
        qid_map_path = os.path.join(semantic_root, "keyid2idx.json")
        kc_map_path = _find_existing_file([
            os.path.join(semantic_root, "keyid2idx.json"),   # 若含 concepts 字段，可直接复用
            os.path.join(semantic_root, "kc_map.json"),
            os.path.join(semantic_root, "correct_kc_map.json"),
            os.path.join(semantic_root, "tag2idx.json"),
            params.get("concept_map_path", ""),
        ])

        template_question_path = os.path.join(teacher_dir, "question_template_texts.json")
        template_concept_path = os.path.join(teacher_dir, "concept_template_texts.json")
        teacher_question_path = os.path.join(teacher_dir, "question_llm_texts.json")
        teacher_concept_path = os.path.join(teacher_dir, "concept_llm_texts.json")

        # question template 缺失时自动生成
        if not os.path.exists(template_question_path):
            export_question_template_texts_generic(
                qid_map_path=qid_map_path,
                source_csv_paths=[
                    os.path.join(dataset_root, "train_valid.csv"),
                    os.path.join(dataset_root, "test.csv"),
                    os.path.join(dataset_root, "train_valid_quelevel.csv"),
                    os.path.join(dataset_root, "test_quelevel.csv"),
                ],
                out_json_path=template_question_path,
                preferred_text_cols=[
                    "Problem Hierarchy", "Problem Name", "Problem View", "Step Name",
                    "KC(Default)", "Opportunity(Default)"
                ],
                max_text_chars=int(params.get("max_sem_text_chars", 256)),
            )

        if use_q_sem and num_q > 0:
            q_json, q_src = _pick_semantic_json(v4_src, template_question_path, teacher_question_path)
            pack["question_texts"] = build_question_texts_from_teacher_json(
                num_q=num_q,
                qid_map_path=qid_map_path,
                teacher_json_path=q_json,
                pad_text="",
                fallback_prefix="algebra question",
            )
            pack["question_text_source"] = q_src

        if use_c_sem and num_c > 0:
            c_json, c_src = _pick_semantic_json(v4_src, template_concept_path, teacher_concept_path)

            if not c_json and int(params.get("strict_semantic_assets", 1)) == 1:
                raise FileNotFoundError(
                    f"[ALG-CSEM] use_c_sem=1 but no concept semantic json found under {teacher_dir}. "
                    f"Expected concept_template_texts.json or concept_llm_texts.json."
                )

            pack["concept_texts"] = _build_concept_texts_auto(
                num_c=num_c,
                kc_map_path=kc_map_path,
                text_json_path=c_json,
                fallback_prefix="algebra concept",
            )
            pack["concept_text_source"] = c_src if c_json else "map_fallback"

        return pack

    # =========================
    # ednet
    # =========================
    if dataset_name in ["ednet", "ednet5k", "ednet5w"]:
        qid_map_path = os.path.join(semantic_root, "keyid2idx.json")
        kc_map_path = _find_existing_file([
            os.path.join(semantic_root, "keyid2idx.json"),
            os.path.join(semantic_root, "tag2idx.json"),
            os.path.join(semantic_root, "kc_map.json"),
            os.path.join(semantic_root, "correct_kc_map.json"),
            os.path.join(semantic_root, "tag_map.json"),
            params.get("concept_map_path", ""),
        ])

        template_question_path = os.path.join(teacher_dir, "question_template_texts.json")
        template_concept_path = os.path.join(teacher_dir, "concept_template_texts.json")
        teacher_question_path = os.path.join(teacher_dir, "question_llm_texts.json")
        teacher_concept_path = os.path.join(teacher_dir, "concept_llm_texts.json")

        if use_q_sem and num_q > 0:
            q_json, q_src = _pick_semantic_json(v4_src, template_question_path, teacher_question_path)
            if q_json:
                pack["question_texts"] = build_question_texts_from_teacher_json(
                    num_q=num_q,
                    qid_map_path=qid_map_path,
                    teacher_json_path=q_json,
                    pad_text="",
                    fallback_prefix="ednet question",
                )
                pack["question_text_source"] = q_src
            else:
                pack["question_texts"] = build_question_texts_from_qid_keys(
                    num_q=num_q,
                    qid_map_path=qid_map_path,
                    pad_text="",
                )
                pack["question_text_source"] = "qid_key_fallback"

        if use_c_sem and num_c > 0:
            c_json, c_src = _pick_semantic_json(v4_src, template_concept_path, teacher_concept_path)

            if not c_json and int(params.get("strict_semantic_assets", 0)) == 1:
                raise FileNotFoundError(
                    f"[EDNET-CSEM] use_c_sem=1 but no concept semantic json found under {teacher_dir}."
                )

            pack["concept_texts"] = _build_concept_texts_auto(
                num_c=num_c,
                kc_map_path=kc_map_path,
                text_json_path=c_json,
                fallback_prefix="ednet concept",
            )
            pack["concept_text_source"] = c_src if c_json else "map_fallback"

        return pack
    # =========================
    # XES3G5M
    # =========================
    if dataset_name.lower() in ["xes3g5m", "xes3g5m_question", "xes3g5m_quelevel"]:
        qid_map_path = os.path.join(semantic_root, "keyid2idx.json")

        template_question_path = os.path.join(teacher_dir, "question_template_texts.json")
        teacher_question_path = os.path.join(teacher_dir, "question_llm_texts.json")

        if use_q_sem and num_q > 0:
            q_json, q_src = _pick_semantic_json(
                v4_src,
                template_question_path,
                teacher_question_path,
            )

            if q_json and os.path.exists(q_json):
                pack["question_texts"] = build_question_texts_from_teacher_json(
                    num_q=num_q,
                    qid_map_path=qid_map_path,
                    teacher_json_path=q_json,
                    pad_text="",
                    fallback_prefix="xes question",
                )
                pack["question_text_source"] = q_src
            else:
                # 结构化 prior / precomputed prior 都不需要 question text json。
                if (
                    int(params.get("use_precomputed_q_sem", 0)) != 1
                    and int(params.get("use_q_structured_sem", 0)) != 1
                ):
                    raise FileNotFoundError(
                        f"[XES-QSEM] no question semantic json found under {teacher_dir}"
                    )
                pack["question_texts"] = [""] * num_q
                if int(params.get("use_q_structured_sem", 0)) == 1:
                    pack["question_text_source"] = "empty_for_structured"
                else:
                    pack["question_text_source"] = "empty_for_precomputed"
        pack["concept_texts"] = None
        pack["concept_text_source"] = "none"

        return pack

    # fallback
    if use_q_sem and num_q > 0:
        pack["question_texts"] = [""] * num_q
        pack["question_text_source"] = "empty_fallback"

    if use_c_sem and num_c > 0:
        pack["concept_texts"] = [f"concept {i}" if i > 0 else "" for i in range(num_c)]
        pack["concept_text_source"] = "index_fallback"

    return pack


def main(params):
    scaler = None
    if "use_wandb" not in params:
        params['use_wandb'] = 1

    if params['use_wandb'] == 1:
        import wandb
        wandb.init()

    set_seed(params["seed"])
    model_name, dataset_name, fold, emb_type, save_dir = params["model_name"], params["dataset_name"], params["fold"], params["emb_type"], params["save_dir"]

    debug_print(text="load config files.", fuc_name="main")

    with open("../configs/kt_config.json") as f:
        config = json.load(f)
        train_config = config["train_config"]
        if model_name in config:
            print(f"✅ [CONFIG] Loading default params for {model_name}")
            for k, v in config[model_name].items():
                if k not in params:
                    params[k] = v
        if model_name in ["dkvmn", "deep_irt", "sakt", "saint", "saint++", "akt", "robustkt", "folibikt", "atkt", "lpkt", "skvmn", "dimkt"]:
            train_config["batch_size"] = 64
        if model_name in ["simplekt", "stablekt", "datakt", "sparsekt"]:
            train_config["batch_size"] = 64
        if model_name in ["gkt"]:
            train_config["batch_size"] = 16
        if model_name in ["qdkt", "qikt"] and dataset_name in ['algebra2005', 'bridge2algebra2006']:
            train_config["batch_size"] = 32
        if model_name in ["dtransformer"]:
            train_config["batch_size"] = 32
        model_config = copy.deepcopy(params)
        for key in ["model_name", "dataset_name", "emb_type", "save_dir", "fold", "seed"]:
            del model_config[key]
        if 'batch_size' in params:
            train_config["batch_size"] = params['batch_size']
        if 'num_epochs' in params:
            train_config["num_epochs"] = params['num_epochs']
    batch_size, num_epochs, optimizer = train_config["batch_size"], train_config["num_epochs"], train_config["optimizer"]

    with open("../configs/data_config.json") as fin:
        data_config = json.load(fin)

    dataset_dir_override = params.get("dataset_dir_override", "")
    if dataset_dir_override:
        if dataset_name not in data_config:
            raise KeyError(f"dataset_name={dataset_name} not found in data_config.json.")
        data_config[dataset_name] = copy.deepcopy(data_config[dataset_name])
        data_config[dataset_name]["dpath"] = dataset_dir_override

    # SQAKT has two intentionally distinct data contracts.  Legacy runs keep the
    # scalar-concept KTDataset path; canonical RQ1 runs opt in to one-question-per-
    # interaction + full-KC-set KTQueDataset via kc_set_input=1.  Do not add SQAKT
    # to que_type_models: its training/evaluation interface is the normal direct
    # forward() path, not the question-type wrapper interface.
    if model_name == "sqakt":
        data_config[dataset_name] = copy.deepcopy(data_config[dataset_name])
        data_config[dataset_name]["sqakt_set_aware"] = int(params.get("kc_set_input", 0))
        data_config[dataset_name]["sqakt_kc_pooling"] = str(params.get("kc_pooling", "mean"))
        if int(params.get("kc_set_input", 0)) == 1:
            set_max = int(params.get("kc_set_max_concepts", 0))
            if set_max <= 0:
                set_max = int(data_config[dataset_name].get("max_concepts", 1))
            if set_max <= 1:
                raise ValueError(
                    "[SQAKT-SET] kc_set_input=1 requires a full-KC-set max_concepts > 1. "
                    "For XES3G5M official metadata the audited maximum is 6; pass "
                    "--kc_set_max_concepts 6."
                )
            data_config[dataset_name]["max_concepts"] = set_max

    print(f"✅ [DATA] using dataset_name={dataset_name}")
    print(f"✅ [DATA] override dpath -> {data_config[dataset_name]['dpath']}")
    if 'maxlen' in data_config[dataset_name]:
        train_config["seq_len"] = data_config[dataset_name]['maxlen']
    seq_len = train_config["seq_len"]
    
    print("Start init data")
    print(dataset_name, model_name, data_config, fold, batch_size)

    debug_print(text="init_dataset", fuc_name="main")
    if model_name not in ["dimkt"]:
        train_loader, valid_loader, *_ = init_dataset4train(dataset_name=dataset_name, model_name=model_name, data_config=data_config, i=fold, batch_size=batch_size,)
    else:
        diff_level = params["difficult_levels"]
        train_loader, valid_loader, *_ = init_dataset4train(dataset_name, model_name, data_config, fold, batch_size, diff_level=diff_level)

    if model_name == "sqakt" and int(params.get("debug_q_align", 0)) == 1 and dataset_name == "assist2009":
        debug_check_q_alignment(train_loader, "/home/dell/KT/KT_LLM_experiments/kt_main/data/assist2009/keyid2idx.json")

    if model_name == "sqakt" and dataset_name == "assist2009" and int(params.get("debug_sqakt_align", 0)) == 1:
        teacher_dir = f"/home/dell/KT/KT_LLM_experiments/kt_main/data/assist2009/teacher/debug_full"
        inspect_sqakt_index_and_text_alignment(
            train_loader=train_loader,
            qid_map_path="/home/dell/KT/KT_LLM_experiments/kt_main/data/assist2009/keyid2idx.json",
            kc_map_path="/home/dell/KT/KT_LLM_experiments/kt_main/data/assist2009/correct_kc_map.json",
            question_text_json_path=os.path.join(teacher_dir, "question_template_texts.json"),
            concept_text_json_path=os.path.join(teacher_dir, "concept_template_texts.json"),
            max_batches=20,
        )

    params_str = make_safe_params_str(params)

    print(f"params: {params}")
    print(f"safe params_str: {params_str}")

    if params.get('add_uuid', 0) == 1 and params.get("use_wandb", 0) == 1:
        import uuid
        params_str = params_str + f"_{str(uuid.uuid4())[:8]}"

    ckpt_path = os.path.join(save_dir, f"{model_name}_{emb_type}_{params_str}")
    os.makedirs(ckpt_path, exist_ok=True)

    with open(os.path.join(ckpt_path, "run_config.json"), "w", encoding="utf-8") as f:
        json.dump(params, f, ensure_ascii=False, indent=2, default=str)

    print(f"Start training model: {model_name}, embtype: {emb_type}, save_dir: {ckpt_path}, dataset_name: {dataset_name}")
    print(f"model_config: {model_config}")
    print(f"train_config: {train_config}")

    if model_name in ["dimkt"]:
        del model_config['weight_decay']

    save_config(train_config, model_config, data_config[dataset_name], params, ckpt_path)
    learning_rate = params["learning_rate"]
    for remove_item in ['use_wandb', 'learning_rate', 'add_uuid', 'l2']:
        if remove_item in model_config:
            del model_config[remove_item]
    if model_name in ["saint", "saint++", "sakt", "atdkt", "simplekt", "stablekt", "datakt", "folibikt"]:
        model_config["seq_len"] = seq_len

    debug_print(text="init_model", fuc_name="main")
    print(f"model_name:{model_name}")
    model = init_model(model_name, model_config, data_config[dataset_name], emb_type)
    before_patch_param_dict = named_param_shapes(model)

    if model_name == "sqakt":
        model.grad_clip = float(params.get("grad_clip", 1.0))
    after_patch_summary = audit_model_patch(before_patch_param_dict, model, save_path=os.path.join(ckpt_path, "patch_audit.json"))
    print_patch_audit(after_patch_summary)

    if model_name in ["llmkt", "sqakt", "akt", "qikt"] and params.get("use_v4_init", 0) == 1:
        dataset_root = data_config[dataset_name]["dpath"]

        semantic_pack = _build_dataset_semantic_texts(
            dataset_name=dataset_name,
            model_name=model_name,
            model=model,
            params=params,
            dataset_root=dataset_root,
        )

        concept_texts = semantic_pack["concept_texts"]
        question_texts = semantic_pack["question_texts"]

        if getattr(model, "use_q_sem", False) and question_texts is not None:
            expected_q = _safe_num_q(model, model_name)
            assert len(question_texts) == expected_q, \
                f"[Q-SEM] len(question_texts)={len(question_texts)} != expected_q={expected_q}"

        if model_name not in ["akt", "qikt"] and getattr(model, "use_c_sem", False) and concept_texts is not None:
            expected_c = _safe_num_c(model)
            assert len(concept_texts) == expected_c, \
                f"[C-SEM] len(concept_texts)={len(concept_texts)} != expected_c={expected_c}"

        print(
            f"✅ [SEM] dataset={dataset_name}, model={model_name}, "
            f"q_src={semantic_pack['question_text_source']}, "
            f"c_src={semantic_pack['concept_text_source']}"
        )

        text_encoder_name = params.get(
            "text_encoder_path",
            params.get(
                "minilm_path",
                "/home/dell/KT/KT_LLM_experiments/kt_main/data/all-MiniLM-L6-v2"
            )
        )
        text_encoder_backend = params.get("text_encoder_backend", "sentence_transformers")
        v4_local_files_only = bool(params.get("v4_local_files_only", 1))

        if model_name == "llmkt":
            model.init_new_tokens_with_minilm(
                concept_texts=concept_texts,
                question_texts=question_texts,
                minilm_name=text_encoder_name,
                encoder_backend=text_encoder_backend,
                device=device,
                local_files_only=v4_local_files_only,
            )
            if getattr(model, "use_concept_memory", False) and hasattr(model, "init_concept_memory_prior_from_tokens"):
                model.init_concept_memory_prior_from_tokens()

        elif model_name == "sqakt":
            if int(params.get("use_q_structured_sem", 0)) == 1:
                from structured_semantic_loader import (
                    load_structured_q_features,
                    apply_structured_semantic_control,
                )
                q_struct_path = params.get("q_structured_features_path", "")
                if not q_struct_path:
                    teacher_dir = semantic_pack["teacher_dir"]
                    q_struct_path = os.path.join(
                        teacher_dir,
                        "question_structured_features.pt"
                    )
                q_tensor, q_manifest, qid_to_idx = load_structured_q_features(
                    q_struct_path,
                    device=device,
                )
                control_mode = params.get(
                    "structured_semantic_control_mode",
                    params.get("semantic_control_mode", "real"),
                )
                if not control_mode:
                    control_mode = params.get("semantic_control_mode", "real")
                q_tensor = apply_structured_semantic_control(
                    q_tensor,
                    mode=control_mode,
                    seed=int(params.get("semantic_control_seed", 0)),
                    same_kc_shuffle_map_path=params.get("same_kc_shuffle_map_path", ""),
                    qid_to_idx=qid_to_idx,
                )
                q_ref_tensor = None
                if int(params.get("use_q_ref_structured_sem", 0)) == 1:
                    q_ref_path = params.get("q_ref_structured_features_path", "")
                    if not q_ref_path:
                        raise ValueError("use_q_ref_structured_sem=1 requires q_ref_structured_features_path")
                    q_ref_tensor, q_ref_manifest, q_ref_qid_to_idx = load_structured_q_features(
                        q_ref_path, device=device,
                    )
                    if q_ref_qid_to_idx != qid_to_idx:
                        raise ValueError("[SQAKT-B3] anchor/refinement qid_to_idx mismatch")
                    ref_control = params.get("q_ref_semantic_control_mode", "real")
                    q_ref_tensor = apply_structured_semantic_control(
                        q_ref_tensor,
                        mode=ref_control,
                        seed=int(params.get("semantic_control_seed", 0)),
                        same_kc_shuffle_map_path=params.get("same_kc_shuffle_map_path", ""),
                        qid_to_idx=q_ref_qid_to_idx,
                    )
                    print(
                        f"✅ [SQAKT-B3] refinement source={q_ref_path}, "
                        f"control={ref_control}, feature_dim={q_ref_tensor.size(1)}"
                    )
                model.init_semantic_from_precomputed_tensor(
                    question_tensor=q_tensor,
                    question_ref_tensor=q_ref_tensor,
                    concept_tensor=None,
                    semantic_control_mode=control_mode,
                    semantic_control_seed=int(params.get("semantic_control_seed", 0)),
                    same_kc_shuffle_map_path=params.get("same_kc_shuffle_map_path", ""),
                    qid_to_idx=qid_to_idx,
                )
                print(
                    f"✅ [SQAKT-STRUCT] source={q_struct_path}, "
                    f"control={control_mode}, feature_dim={q_tensor.size(1)}"
                )
            else:
                model.init_semantic_from_encoder(
                    concept_texts=concept_texts if getattr(model, "use_c_sem", False) else None,
                    question_texts=question_texts if getattr(model, "use_q_sem", False) else None,
                    encoder_name=text_encoder_name,
                    encoder_backend=text_encoder_backend,
                    device=device,
                    local_files_only=v4_local_files_only,
                    normalize=True,              
                    batch_size=int(params.get("sem_batch_size", 64)),
                    pooling=params.get("pooling", "mean"),
                    semantic_control_mode=params.get("semantic_control_mode", "real"),
                    semantic_control_seed=int(params.get("semantic_control_seed", 0)),
                    q_semantic_control_mode=params.get("q_semantic_control_mode", None),
                    c_semantic_control_mode=params.get("c_semantic_control_mode", None),
                    same_kc_shuffle_map_path=params.get("same_kc_shuffle_map_path", ""),
                    q_same_kc_shuffle_map_path=params.get("same_kc_shuffle_map_path", ""),
                )

        elif model_name == "akt":
            q_sem_precomputed_path = params.get("q_sem_precomputed_path", "")

            if int(params.get("use_precomputed_q_sem", 0)) == 1:
                if not q_sem_precomputed_path:
                    teacher_dir = semantic_pack["teacher_dir"]
                    emb_mode = params.get("precomputed_q_sem_mode", "")

                    candidates = []
                    if emb_mode:
                         candidates.append(os.path.join(teacher_dir, f"aligned_q_sem_{emb_mode}.pt"))

                    candidates += [
                        os.path.join(teacher_dir, "aligned_q_sem_content.pt"),
                        os.path.join(teacher_dir, "aligned_q_sem_analysis.pt"),
                        os.path.join(teacher_dir, "aligned_q_sem_content_analysis_avg.pt"),
                    ]

                    q_sem_precomputed_path = _find_existing_file(candidates)

                if not q_sem_precomputed_path:
                    raise FileNotFoundError(
                        f"[AKT-SEM] use_precomputed_q_sem=1 but no q_sem_precomputed_path found. "
                        f"teacher_dir={semantic_pack['teacher_dir']}"
                    )

                init_akt_q_sem_from_precomputed(
                    model=model,
                    q_sem_precomputed_path=q_sem_precomputed_path,
                    semantic_control_mode=params.get("semantic_control_mode", "real"),
                    semantic_control_seed=int(params.get("semantic_control_seed", 0)),
                )

            else:
                init_akt_q_sem_from_texts(
                    model=model,
                    question_texts=question_texts,
                    encoder_name=text_encoder_name,
                    encoder_backend=text_encoder_backend,
                    device=device,
                    local_files_only=v4_local_files_only,
                    batch_size=int(params.get("sem_batch_size", 64)),
                    semantic_control_mode=params.get("semantic_control_mode", "real"),
                    semantic_control_seed=int(params.get("semantic_control_seed", 0)),
                )

        elif model_name == "qikt":
            model = attach_q_sem_to_qikt(
                model=model,
                question_texts=question_texts,
                encoder_name=text_encoder_name,
                encoder_backend=text_encoder_backend,
                sem_input_dim=int(params.get("sem_input_dim", 384)),
                local_files_only=v4_local_files_only,
                batch_size=int(params.get("sem_batch_size", 64)),
                semantic_control_mode=params.get("semantic_control_mode", "real"),
                semantic_control_seed=int(params.get("semantic_control_seed", 0)),
                q_inject_mode=params.get("q_inject_mode", "medium"),
            )
    if model_name == "akt" and int(params.get("use_q_behavior", 0)) == 1:
        dataset_root = data_config[dataset_name]["dpath"]
        semantic_root = params.get("semantic_dataset_root_override", dataset_root)

        behavior_path = params.get("q_behavior_path", "")
        if not behavior_path:
            teacher_dir = params.get("teacher_dir_override", "")
            if not teacher_dir:
                teacher_subdir = params.get("teacher_subdir", "")
                if not teacher_subdir:
                    prior_variant = params.get("semantic_prior_variant", "metadata_skill_answer")
                    teacher_subdir = f"fold{int(params.get('fold', 0))}_trainonly_{prior_variant}"
                teacher_dir = os.path.join(semantic_root, "teacher", teacher_subdir)
 
            behavior_path = os.path.join(teacher_dir, "question_behavior_features.json")
 
        qid_map_path = os.path.join(semantic_root, "keyid2idx.json")

        init_akt_q_behavior_from_json(
            model=model,
            qid_map_path=qid_map_path,
            behavior_json_path=behavior_path,
            device=device,
        )

    if model_name in ["saint", "saint++"] and not hasattr(model, "model"):
        model.model = types.SimpleNamespace(train=lambda mode=True: model.train(mode), eval=lambda: model.eval())

    if model_name == "hawkes":
        weight_p, bias_p = [], []
        for name, p in filter(lambda x: x[1].requires_grad, model.named_parameters()):
            if 'bias' in name:
                bias_p.append(p)
            else:
                weight_p.append(p)
        optdict = [{'params': weight_p}, {'params': bias_p, 'weight_decay': 0}]
        opt = torch.optim.Adam(optdict, lr=learning_rate, weight_decay=params['l2'])
    elif model_name == "iekt":
        opt = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-6)
    elif model_name == "dtransformer":
        print("dtransformer weight_decay = 1e-5")
        opt = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)
    elif model_name == "dimkt":
        opt = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=params['weight_decay'])
    else:
        if optimizer == "sgd":
            opt = SGD(model.parameters(), learning_rate, momentum=0.9)
        elif optimizer == "adam":
            if model_name == "llmkt":
                llm_params, other_params, emb_params = [], [], []
                for n, p in model.named_parameters():
                    if not p.requires_grad:
                        continue
                    is_llm = n.startswith("llm.")
                    is_token_emb = (".wte." in n) or (n.endswith("wte.weight")) or ("word_embeddings" in n)
                    if is_token_emb:
                        emb_params.append(p)
                    elif is_llm:
                        llm_params.append(p)
                    else:
                        other_params.append(p)

                opt = torch.optim.AdamW(
                    [
                        {"params": other_params, "lr": learning_rate, "weight_decay": 1e-3},
                        {"params": emb_params, "lr": learning_rate * 5.0, "weight_decay": 1e-4},
                        {"params": llm_params, "lr": learning_rate * 0.1, "weight_decay": 1e-4},
                    ],
                    lr=learning_rate,
                    betas=(0.9, 0.999),
                    eps=1e-8,
                )
                opt_rows = optimizer_membership(model, opt)
                opt_save_path = os.path.join(ckpt_path, "optimizer_membership.json")
                with open(opt_save_path, "w", encoding="utf-8") as f:
                    json.dump(opt_rows, f, ensure_ascii=False, indent=2)
                print("✅ [OPT-AUDIT] saved optimizer membership to", opt_save_path)
                print(f"✅ [OPT] llmkt groups: other={len(other_params)}, emb={len(emb_params)}, llm={len(llm_params)}")
                scaler = torch.cuda.amp.GradScaler()
                print("🔥 [LLMKT] AMP GradScaler initialized for LLMKT model.")
                found = any(p is model.wte.weight for g in opt.param_groups for p in g["params"])
                print("✅ [OPT DBG] wte.weight in optimizer:", found)
                if hasattr(model, "wte"):
                    print("✅ [OPT DBG] wte.requires_grad:", model.wte.weight.requires_grad)
            else:
                opt = Adam(model.parameters(), learning_rate)

    testauc, testacc = -1, -1
    window_testauc, window_testacc = -1, -1
    validauc, validacc = -1, -1
    best_epoch = -1
    save_model = True

    debug_print(text="train model", fuc_name="main")
    if model_name == "rkt":
        testauc, testacc, window_testauc, window_testacc, validauc, validacc, best_epoch = train_model(model, train_loader, valid_loader, num_epochs, opt, ckpt_path, None, None, save_model, data_config[dataset_name], fold)
    else:
        testauc, testacc, window_testauc, window_testacc, validauc, validacc, best_epoch = train_model(model, train_loader, valid_loader, num_epochs, opt, ckpt_path, None, None, save_model, scaler=scaler)

    if save_model:
        best_model = init_model(model_name, model_config, data_config[dataset_name], emb_type)
        # 关键修复：如果训练时用了 structured semantic，
        # 重新创建 best_model 后也必须先构造相同 shape 的 q_sem_raw / sem_proj。
        if model_name == "sqakt" and int(params.get("use_q_structured_sem", 0)) == 1:
            from structured_semantic_loader import (
                load_structured_q_features,
                apply_structured_semantic_control,
            )
            q_struct_path = params.get("q_structured_features_path", "")
            if not q_struct_path:
                teacher_dir = semantic_pack["teacher_dir"]
                q_struct_path = os.path.join(teacher_dir, "question_structured_features.pt")
            q_tensor, q_manifest, qid_to_idx = load_structured_q_features(
                q_struct_path,
                device=device,
            )
            control_mode = params.get(
                "structured_semantic_control_mode",
                params.get("semantic_control_mode", "real"),
            )
            if not control_mode:
                control_mode = params.get("semantic_control_mode", "real")
            q_tensor = apply_structured_semantic_control(
                q_tensor,
                mode=control_mode,
                seed=int(params.get("semantic_control_seed", 0)),
                same_kc_shuffle_map_path=params.get("same_kc_shuffle_map_path", ""),
                qid_to_idx=qid_to_idx,
            )
            q_ref_tensor = None
            if int(params.get("use_q_ref_structured_sem", 0)) == 1:
                q_ref_path = params.get("q_ref_structured_features_path", "")
                if not q_ref_path:
                    raise ValueError("use_q_ref_structured_sem=1 requires q_ref_structured_features_path")
                q_ref_tensor, q_ref_manifest, q_ref_qid_to_idx = load_structured_q_features(
                    q_ref_path, device=device,
                )
                if q_ref_qid_to_idx != qid_to_idx:
                    raise ValueError("[SQAKT-B3] anchor/refinement qid_to_idx mismatch on reload")
                ref_control = params.get("q_ref_semantic_control_mode", "real")
                q_ref_tensor = apply_structured_semantic_control(
                    q_ref_tensor,
                    mode=ref_control,
                    seed=int(params.get("semantic_control_seed", 0)),
                    same_kc_shuffle_map_path=params.get("same_kc_shuffle_map_path", ""),
                    qid_to_idx=q_ref_qid_to_idx,
                )
            best_model.init_semantic_from_precomputed_tensor(
                question_tensor=q_tensor,
                question_ref_tensor=q_ref_tensor,
                concept_tensor=None,
                semantic_control_mode=control_mode,
                semantic_control_seed=int(params.get("semantic_control_seed", 0)),
                same_kc_shuffle_map_path=params.get("same_kc_shuffle_map_path", ""),
                qid_to_idx=qid_to_idx,
            )
            print(
                f"✅ [LOAD-BEST-STRUCT] initialized best_model structured prior: "
                f"source={q_struct_path}, control={control_mode}, shape={tuple(q_tensor.shape)}"
            )
        best_model = best_model.to(device)
        net = torch.load(os.path.join(ckpt_path, emb_type + "_model.ckpt"))
        missing, unexpected = best_model.load_state_dict(net, strict=False)
        print("[LOAD best_model] missing:", missing)
        print("[LOAD best_model] unexpected:", unexpected)
 
    print("fold\tmodelname\tembtype\ttestauc\ttestacc\twindow_testauc\twindow_testacc\tvalidauc\tvalidacc\tbest_epoch")
    print(str(fold) + "\t" + model_name + "\t" + emb_type + "\t" + str(round(testauc, 4)) + "\t" + str(round(testacc, 4)) + "\t" + str(round(window_testauc, 4)) + "\t" + str(round(window_testacc, 4)) + "\t" + str(validauc) + "\t" + str(validacc) + "\t" + str(best_epoch))
    model_save_path = os.path.join(ckpt_path, emb_type + "_model.ckpt")
    print(f"end:{datetime.datetime.now()}")
    result_summary = {
        "seed": int(params["seed"]),
        "model_name": model_name,
        "dataset_name": dataset_name,
        "emb_type": emb_type,
        "validauc": float(validauc),
        "validacc": float(validacc),
        "testauc": float(testauc),
        "testacc": float(testacc),
        "window_testauc": float(window_testauc),
        "window_testacc": float(window_testacc),
        "best_epoch": int(best_epoch),
        "model_save_path": model_save_path,
        "ckpt_path": ckpt_path,
    }
    summary_path = os.path.join(ckpt_path, "result_summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(result_summary, f, ensure_ascii=False, indent=2)

    print(f"SUMMARY_JSON: {summary_path}")

    if params['use_wandb'] == 1:
        wandb.log({"validauc": validauc, "validacc": validacc, "best_epoch": best_epoch, "model_save_path": model_save_path})
