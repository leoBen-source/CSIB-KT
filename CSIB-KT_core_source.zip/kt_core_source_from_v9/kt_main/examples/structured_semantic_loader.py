import json
import torch
import torch.nn.functional as F


def load_structured_q_features(path, device="cpu"):
    obj = torch.load(path, map_location="cpu")
    if isinstance(obj, dict) and "x" in obj:
        x = obj["x"].float()
        manifest = obj.get("manifest", {})
        qid_to_idx = obj.get("qid_to_idx", {})
    else:
        x = obj.float()
        manifest = {}
        qid_to_idx = {}
    return x.to(device), manifest, qid_to_idx


def canon_qid(x):
    s = str(x).strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s


def apply_structured_semantic_control(
    x,
    mode="real",
    seed=0,
    same_kc_shuffle_map_path="",
    qid_to_idx=None,
):
    if mode == "real":
        return x

    if mode == "zero":
        return torch.zeros_like(x)

    g = torch.Generator(device=x.device)
    g.manual_seed(int(seed))

    if mode == "shuffle":
        perm = torch.randperm(x.size(0), generator=g, device=x.device)
        return x[perm]

    if mode == "random":
        # 与你原来的 random prior 逻辑一致：随机 frozen item vector
        z = torch.randn(x.size(0), x.size(1), generator=g, device=x.device)
        z = F.normalize(z, p=2, dim=-1)
        return z

    if mode == "same_kc_shuffle":
        if not same_kc_shuffle_map_path:
            raise ValueError("same_kc_shuffle requires same_kc_shuffle_map_path.")
        if qid_to_idx is None:
            raise ValueError("same_kc_shuffle requires qid_to_idx.")

        with open(same_kc_shuffle_map_path, "r", encoding="utf-8") as f:
            m = json.load(f)

        out = x.clone()
        for qid, mapped_qid in m.items():
            qid = canon_qid(qid)
            mapped_qid = canon_qid(mapped_qid)

            if qid not in qid_to_idx or mapped_qid not in qid_to_idx:
                continue

            i = int(qid_to_idx[qid])
            j = int(qid_to_idx[mapped_qid])

            if 0 <= i < x.size(0) and 0 <= j < x.size(0):
                out[i] = x[j]

        return out

    raise ValueError(f"Unknown structured semantic control mode: {mode}")
