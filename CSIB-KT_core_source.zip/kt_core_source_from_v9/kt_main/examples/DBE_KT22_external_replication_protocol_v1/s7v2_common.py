#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import json, math, re, unicodedata, hashlib
from fractions import Fraction
from pathlib import Path
import numpy as np
import pandas as pd

EPS = 1e-6

def clip_prob(p):
    return np.clip(np.asarray(p, float), EPS, 1-EPS)

def logit(p):
    p = clip_prob(p)
    return np.log(p) - np.log1p(-p)

def sigmoid(x):
    return 1/(1+np.exp(-np.clip(np.asarray(x, float), -40, 40)))

def nll(y, p):
    y = np.asarray(y, int); p = clip_prob(p)
    return float(-np.mean(y*np.log(p) + (1-y)*np.log1p(-p)))

def canon_id(x):
    s = str(x).strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s

def load_qid_map(path):
    obj = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(obj, dict) and "questions" in obj:
        obj = obj["questions"]
    fwd = {canon_id(k): int(v) for k, v in obj.items()}
    rev = {v: k for k, v in fwd.items()}
    if len(rev) != len(fwd):
        raise RuntimeError("qid map has duplicate model ids")
    return fwd, rev

def load_questions(path):
    obj = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(obj, dict) and "questions" in obj:
        obj = obj["questions"]
    if not isinstance(obj, dict):
        raise RuntimeError("questions.json must be a dict")
    return {canon_id(k): (v if isinstance(v, dict) else {"content": str(v)}) for k, v in obj.items()}

def lookup_meta(qmeta, raw_qid, model_qid):
    cands = [canon_id(raw_qid), str(int(model_qid))]
    r = str(raw_qid)
    cands.append(r[1:] if r.startswith("q") else "q"+r)
    for c in cands:
        if c in qmeta:
            return qmeta[c]
    return {}

def flatten_values(x):
    if x is None:
        return []
    if isinstance(x, dict):
        out = []
        for k in sorted(x, key=str):
            out.extend(flatten_values(x[k]))
        return out
    if isinstance(x, (list, tuple, set)):
        out = []
        for v in x:
            out.extend(flatten_values(v))
        return out
    s = " ".join(str(x).replace("\u3000", " ").split()).strip()
    return [s] if s else []

def qtype(meta):
    return str(meta.get("question_type", meta.get("type", "unknown")) or "unknown")

def option_list(meta):
    x = meta.get("options", [])
    if isinstance(x, dict):
        return [str(v) for k, v in sorted(x.items(), key=lambda kv: str(kv[0]))]
    if isinstance(x, (list, tuple)):
        return [str(v) for v in x]
    return flatten_values(x)

def normalize_answer(s):
    s = unicodedata.normalize("NFKC", str(s or "")).strip().lower()
    s = s.replace("＄", "$").replace("，", ",").replace("；", ";").replace("：", ":")
    s = re.sub(r"\\(?:left|right)", "", s)
    s = s.replace("$", "").replace("\\,", "").replace("\\;", "")
    s = re.sub(r"\\text\{([^{}]*)\}", r"\1", s)
    s = s.replace("{", "").replace("}", "")
    s = re.sub(r"^(?:答案|answer|final_answer|final answer)\s*[:：=]\s*", "", s)
    s = re.sub(r"\s+", "", s)
    return s.strip("。.;；,，")

NUM_RE = re.compile(r"[-+]?(?:\d+\.\d+|\d+/\d+|\d+)")

def numeric_vector(s):
    vals = []
    for t in NUM_RE.findall(normalize_answer(s)):
        try:
            vals.append(float(Fraction(t)) if "/" in t else float(t))
        except Exception:
            pass
    return vals

def scalar_equal(pred, gold):
    p = normalize_answer(pred); g = normalize_answer(gold)
    if p == g and p:
        return True, "exact"
    pv = numeric_vector(p); gv = numeric_vector(g)
    if pv and gv and len(pv) == len(gv) == 1:
        if abs(pv[0]-gv[0]) <= 1e-6*max(1.0, abs(gv[0])):
            return True, "numeric"
    return False, "no_match"

def build_answer_spec(meta):
    """Conservative answer specification.

    Fill-in items with >1 top-level answer entries are treated as ordered multi-blank.
    This deliberately does NOT reinterpret them as alternative single answers.
    """
    raw = meta.get("answer")
    qt = qtype(meta)
    opts = option_list(meta)
    fill_like = ("填空" in qt) or ("blank" in qt.lower())

    if fill_like and isinstance(raw, (list, tuple)) and len(raw) > 1:
        slots = []
        for x in raw:
            vals = flatten_values(x)
            slots.append(vals if vals else [""])
        return {"kind": "multi_blank_ordered", "slots": slots, "slot_n": len(slots)}

    vals = flatten_values(raw)
    if opts:
        # Single- or multi-select. Keep official metadata entries as accepted choices.
        return {"kind": "choice", "accepted": vals, "options": opts}
    return {"kind": "single", "accepted": vals}

def split_predicted_slots(pred, slot_n):
    s = str(pred or "").strip()
    # First prefer explicit delimiters used for multiple blanks.
    parts = [x.strip() for x in re.split(r"[;；|]", s) if x.strip()]
    if len(parts) == slot_n:
        return parts
    # For numeric multi-blank, numeric extraction is safer than splitting commas
    # because commas may be thousands separators.
    nums = NUM_RE.findall(normalize_answer(s))
    if len(nums) == slot_n:
        return nums
    # Last conservative fallback: comma / Chinese comma if exact slot count.
    parts = [x.strip() for x in re.split(r"[,，]", s) if x.strip()]
    return parts if len(parts) == slot_n else []

def score_from_spec(pred, spec):
    kind = spec["kind"]
    if kind == "multi_blank_ordered":
        parts = split_predicted_slots(pred, int(spec["slot_n"]))
        if len(parts) != int(spec["slot_n"]):
            return False, "multi_blank_arity"
        methods = []
        for p, alternatives in zip(parts, spec["slots"]):
            ok = False; why = "no_match"
            for g in alternatives:
                z, m = scalar_equal(p, g)
                if z:
                    ok = True; why = m; break
            if not ok:
                return False, "multi_blank_slot_mismatch"
            methods.append(why)
        return True, "multi_blank_ordered"

    if kind == "single":
        for g in spec.get("accepted", []):
            ok, why = scalar_equal(pred, g)
            if ok:
                return True, why
        return False, "no_match"

    if kind == "choice":
        opts = spec.get("options", [])
        accepted = [normalize_answer(x) for x in spec.get("accepted", []) if normalize_answer(x)]
        p = normalize_answer(pred)
        if p in accepted:
            return True, "choice_exact"
        letters = "abcdefghijklmnopqrstuvwxyz"
        m = re.match(r"^(?:option|选项)?([a-z])(?:[.、:：\-])?(.*)$", p)
        if m:
            idx = letters.find(m.group(1))
            if 0 <= idx < len(opts):
                chosen = normalize_answer(opts[idx])
                if chosen in accepted:
                    return True, "choice_letter"
                # Metadata can store letter/index instead of option text.
                if normalize_answer(m.group(1)) in accepted:
                    return True, "choice_letter_meta"
        # Numeric index metadata sensitivity.
        if p.isdigit():
            k = int(p)
            if normalize_answer(p) in accepted:
                return True, "choice_index_meta"
            for idx in [k, k-1]:
                if 0 <= idx < len(opts) and normalize_answer(opts[idx]) in accepted:
                    return True, "choice_index"
        # Direct option text.
        for i, opt in enumerate(opts):
            if p == normalize_answer(opt):
                letter = letters[i]
                if normalize_answer(letter) in accepted or normalize_answer(str(i)) in accepted or normalize_answer(str(i+1)) in accepted:
                    return True, "choice_text"
        return False, "choice_no_match"

    return False, "unknown_spec"

def extract_final_answer(text):
    s = str(text or "").strip()
    # Prefer the last explicit JSON object containing final_answer.
    hits = re.findall(r'\{[^{}]*"final_answer"\s*:\s*"([^"]*)"[^{}]*\}', s, flags=re.S)
    if hits:
        return hits[-1].strip(), True
    # Accept a terminal FINAL marker.
    m = re.findall(r"(?:FINAL|Final|final)\s*[:：]\s*(.+)", s)
    if m:
        return m[-1].strip().splitlines()[0].strip(), False
    # Strip think blocks if present and keep last non-empty line.
    s = re.sub(r"<think>.*?</think>", "", s, flags=re.S|re.I).strip()
    lines = [x.strip() for x in s.splitlines() if x.strip()]
    return (lines[-1] if lines else ""), False

def normalize_vote_answer(s):
    return normalize_answer(s)

def recall_at_frac(y, score, frac=.10):
    y = np.asarray(y, int); score = np.asarray(score, float)
    n = max(1, int(math.ceil(len(y)*float(frac))))
    idx = np.argsort(-score, kind="mergesort")[:n]
    tp = int(y[idx].sum())
    return tp/max(int(y.sum()),1), tp/max(n,1), tp, n

def safe_corr(a, b, method="spearman"):
    a = pd.Series(np.asarray(a, float)); b = pd.Series(np.asarray(b, float))
    if len(a) < 4 or a.std(ddof=0) < 1e-12 or b.std(ddof=0) < 1e-12:
        return np.nan
    return float(a.corr(b, method=method))
