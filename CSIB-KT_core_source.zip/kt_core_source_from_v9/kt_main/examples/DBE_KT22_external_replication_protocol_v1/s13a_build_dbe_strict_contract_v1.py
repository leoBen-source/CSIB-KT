#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Freeze the DBE-KT22 external strict-new-item contract before outcomes are inspected.

Primary eligibility:
- question has transactions and a non-empty official KC-set;
- its exact KC-set contains at least two eligible questions;
- sufficient *label-free* response support exists overall and in the fixed eval-user split;
- optional primary text-only filter excludes items whose prompt contains obvious image tags;
- exact/canonical duplicate content is kept in the same content group fold;
- every retained target has an exact-KC-set peer outside its held-out fold.

No human correctness value is used to decide item inclusion or fold assignment.
"""
from __future__ import annotations
import argparse, hashlib, html, json, re
from collections import defaultdict
from pathlib import Path
import pandas as pd

FILES={
    "questions":"Questions.csv","qkc":"Question_KC_Relationships.csv","kcs":"KCs.csv",
    "choices":"Question_Choices.csv","tx":"Transaction.csv"
}

def find_col(df, names, required=True):
    low={str(c).lower():c for c in df.columns}
    for n in names:
        if n.lower() in low: return low[n.lower()]
    if required: raise RuntimeError(f"none of columns {names} in {list(df.columns)}")
    return None

def bval(x):
    s=str(x).strip().lower()
    if s in {"true","1","t","yes","y"}: return True
    if s in {"false","0","f","no","n","nan","none",""}: return False
    return bool(x)

def norm_text(x):
    s=html.unescape(str(x or ""))
    s=re.sub(r"<[^>]+>"," ",s)
    s=re.sub(r"\s+"," ",s).strip().lower()
    return s

def visual_like(x):
    s=str(x or "").lower()
    return int(bool(re.search(r"<img\b|\.(?:png|jpg|jpeg|gif|svg)\b|data:image|\[image\]|figure\s+\d",s)))

def sha(s): return hashlib.sha256(str(s).encode("utf-8")).hexdigest()
def bucket(x,seed): return int(sha(f"{seed}|{x}")[:12],16)%100

def file_sha(path:Path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for c in iter(lambda:f.read(1<<20),b""): h.update(c)
    return h.hexdigest()

def qid_int(x): return int(float(x))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data_root",required=True); ap.add_argument("--out_dir",required=True)
    ap.add_argument("--n_folds",type=int,default=5); ap.add_argument("--fold_seed",type=int,default=20260828)
    ap.add_argument("--student_split_seed",type=int,default=20260828)
    ap.add_argument("--train_user_pct",type=int,default=70); ap.add_argument("--valid_user_pct",type=int,default=15)
    ap.add_argument("--min_total_interactions",type=int,default=100)
    ap.add_argument("--min_eval_first_exposures",type=int,default=30)
    ap.add_argument("--exclude_visual",type=int,default=1)
    ap.add_argument("--exclude_hidden",type=int,default=1)
    args=ap.parse_args()
    root=Path(args.data_root).resolve(); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    paths={k:root/v for k,v in FILES.items()}
    for p in paths.values():
        if not p.is_file(): raise FileNotFoundError(p)
    q=pd.read_csv(paths["questions"],low_memory=False); qkc=pd.read_csv(paths["qkc"],low_memory=False)
    ch=pd.read_csv(paths["choices"],low_memory=False); tx=pd.read_csv(paths["tx"],low_memory=False)
    qidc=find_col(q,["id"]); qqc=find_col(qkc,["question_id"]); qkc_c=find_col(qkc,["knowledgecomponent_id"])
    txq=find_col(tx,["question_id"]); txs=find_col(tx,["student_id"]); hidden=find_col(tx,["is_hidden"],False)
    txid=find_col(tx,["id"],False); txstart=find_col(tx,["start_time"],False); txend=find_col(tx,["end_time"],False)
    if args.exclude_hidden and hidden:
        hv=tx[hidden].map(lambda x: 1 if str(x).strip().lower() in {"true","1","t","yes","y"} else 0)
        tx=tx[hv==0].copy()
    qtext=find_col(q,["question_text"],False); qrich=find_col(q,["question_rich_text"],False)
    qtitle=find_col(q,["question_title"],False)
    ctext=find_col(ch,["choice_text","text"],False); cid=find_col(ch,["id"],False)

    qids=set(q[qidc].map(qid_int)); qmap={qid_int(r[qidc]):r for _,r in q.iterrows()}
    # Released DBE variants may name the choice foreign key question_id or step_id.
    # Resolve by overlap with the actual Questions.id namespace, not by column order.
    choice_ref_candidates=[c for c in ch.columns if str(c).lower() in {"question_id","step_id"}]
    def choice_overlap(c):
        vals=set()
        for x in ch[c].dropna():
            try: vals.add(qid_int(x))
            except Exception: pass
        return len(vals & qids)
    cq=max(choice_ref_candidates,key=choice_overlap) if choice_ref_candidates else None
    kcmap=defaultdict(set)
    for _,r in qkc.iterrows(): kcmap[qid_int(r[qqc])].add(qid_int(r[qkc_c]))
    total=tx[txq].map(qid_int).value_counts().to_dict()

    # Fixed user split; support calculation uses only identity/timestamps, never correctness.
    def usplit(s):
        b=bucket(s,args.student_split_seed)
        if b<args.train_user_pct: return "train"
        if b<args.train_user_pct+args.valid_user_pct: return "valid"
        return "eval"
    keep_cols=[c for c in [txs,txq,txstart,txend,txid] if c]
    tx2=tx[keep_cols].copy(); tx2["student_key"]=tx2[txs].astype(str); tx2["qid"]=tx2[txq].map(qid_int)
    tx2["user_split"]=tx2.student_key.map(usplit)
    sort_cols=["student_key"]+[c for c in [txstart,txend,txid] if c]
    tx2=tx2.sort_values(sort_cols,kind="mergesort").reset_index(drop=True)
    eval_first=(tx2[tx2.user_split=="eval"].drop_duplicates(["student_key","qid"]).qid.value_counts().to_dict())

    # Choice text only for canonical duplicate grouping. Correct-choice metadata is not touched here.
    options=defaultdict(list)
    if cq and ctext:
        zz=ch.copy()
        if cid: zz=zz.sort_values(cid)
        for _,r in zz.iterrows(): options[qid_int(r[cq])].append(norm_text(r[ctext]))

    records=[]
    for qid in sorted(qids):
        ks=tuple(sorted(kcmap.get(qid,set())))
        if not ks: continue
        r=qmap[qid]
        raw=" ".join(str(r[c]) for c in [qtitle,qtext,qrich] if c and pd.notna(r[c]))
        vis=visual_like(raw)
        content=norm_text(raw)+" || OPTIONS: "+" || ".join(options.get(qid,[]))
        records.append({
            "target_qid":qid,"target_kc_key":"|".join(map(str,ks)),"kc_n":len(ks),
            "canonical_content_id":sha(content),"visual_like":vis,
            "response_support_total":int(total.get(qid,0)),"eval_first_exposure_support":int(eval_first.get(qid,0)),
        })
    d=pd.DataFrame(records)
    d=d[(d.response_support_total>=args.min_total_interactions)&(d.eval_first_exposure_support>=args.min_eval_first_exposures)].copy()
    if args.exclude_visual: d=d[d.visual_like==0].copy()
    # Exact KC-set support >=2 before fold construction.
    counts=d.groupby("target_kc_key").target_qid.transform("count")
    d=d[counts>=2].copy().reset_index(drop=True)
    if len(d)<50: raise RuntimeError(f"too few eligible DBE items before folding: {len(d)}")

    # Assign canonical content groups within each exact KC-set across folds.  A duplicate content group never splits.
    fold_load=[0]*args.n_folds; assigned={}
    for kc,g in d.groupby("target_kc_key",sort=True):
        groups=[]
        for cid,gg in g.groupby("canonical_content_id",sort=True):
            groups.append((cid,sorted(gg.target_qid.astype(int)),len(gg)))
        groups.sort(key=lambda x:sha(f"{args.fold_seed}|{kc}|{x[0]}"))
        used=[]
        for i,(cid,qs,n) in enumerate(groups):
            if i<args.n_folds:
                candidates=[f for f in range(args.n_folds) if f not in used]
                f=min(candidates,key=lambda x:(fold_load[x],x)); used.append(f)
            else:
                f=min(range(args.n_folds),key=lambda x:(fold_load[x],x))
            assigned[(kc,cid)]=f; fold_load[f]+=n
    d["content_group_fold"]=[assigned[(r.target_kc_key,r.canonical_content_id)] for r in d.itertuples(index=False)]

    # Label-free *strict* evaluation support: first exposure must occur after at
    # least one legal warm event when all items in the target's item fold are
    # excluded from history.  This matches the downstream causal scorer rather
    # than merely counting first exposures anywhere in the sequence.
    fold_of={int(r.target_qid):int(r.content_group_fold) for r in d.itertuples(index=False)}
    cold_by_fold={f:set(d.loc[d.content_group_fold.astype(int)==f,"target_qid"].astype(int)) for f in range(args.n_folds)}
    strict_support=defaultdict(int)
    ez=tx2[tx2.user_split=="eval"]
    for _,ug in ez.groupby("student_key",sort=False):
        seen=set()
        # warm_count is fold-specific because each item fold defines a different
        # legal history. All DBE questions with official KC mapping can be warm.
        warm_count={f:0 for f in range(args.n_folds)}
        for rr in ug.itertuples(index=False):
            qid=int(rr.qid)
            if qid in fold_of and qid not in seen:
                f=fold_of[qid]
                if warm_count[f]>=1:
                    strict_support[qid]+=1
                seen.add(qid)
            if qid in kcmap:
                for f in range(args.n_folds):
                    if qid not in cold_by_fold[f]:
                        warm_count[f]+=1
    d["eval_strict_first_exposure_support"]=[int(strict_support.get(int(q),0)) for q in d.target_qid]
    d=d[d.eval_strict_first_exposure_support>=args.min_eval_first_exposures].copy().reset_index(drop=True)
    if len(d)<50: raise RuntimeError(f"too few eligible DBE items after strict warm-history exposure support: {len(d)}")

    # Iteratively remove any target whose exact-KC-set support would vanish outside its fold.
    changed=True
    while changed:
        changed=False; bad=[]
        for r in d.itertuples(index=False):
            peers=d[(d.target_kc_key==r.target_kc_key)&(d.content_group_fold.astype(int)!=int(r.content_group_fold))]
            if peers.empty: bad.append(int(r.target_qid))
        if bad:
            d=d[~d.target_qid.astype(int).isin(bad)].copy().reset_index(drop=True); changed=True
    if len(d)<50: raise RuntimeError(f"too few eligible DBE items after exact-KC peer/fold safety: {len(d)}")
    folds=sorted(d.content_group_fold.astype(int).unique())
    if folds!=list(range(args.n_folds)): raise RuntimeError(f"non-complete folds after filtering: {folds}")

    # Recheck each duplicate content id is fold-pure.
    dupfold=d.groupby("canonical_content_id").content_group_fold.nunique()
    if int((dupfold>1).sum())!=0: raise RuntimeError("canonical duplicate content split across folds")
    d["question_type"]="multiple_choice"; d["strict_clean_nonvisual_noformat"]=1
    d=d.sort_values(["content_group_fold","target_kc_key","target_qid"]).reset_index(drop=True)
    d.to_csv(out/"dbe_strict_group_contract.csv",index=False)

    summary={
        "schema_version":"s13a_dbe_strict_contract_v1","data_root":str(root),
        "target_n":int(len(d)),"fold_sizes":{str(k):int(v) for k,v in d.content_group_fold.value_counts().sort_index().items()},
        "exact_kcset_n":int(d.target_kc_key.nunique()),"min_exact_kcset_size":int(d.groupby('target_kc_key').size().min()),
        "response_support_total_min":int(d.response_support_total.min()),"eval_first_exposure_support_min":int(d.eval_first_exposure_support.min()),
        "eval_strict_first_exposure_support_min":int(d.eval_strict_first_exposure_support.min()),
        "exclude_visual":bool(args.exclude_visual),"exclude_hidden":bool(args.exclude_hidden),"visual_like_retained_n":int(d.visual_like.sum()),
        "n_folds":args.n_folds,"fold_seed":args.fold_seed,"student_split_seed":args.student_split_seed,
        "user_split_pct":{"train":args.train_user_pct,"valid":args.valid_user_pct,"eval":100-args.train_user_pct-args.valid_user_pct},
        "selection_uses_human_correctness":False,
        "primary_rule":"exact KC-set support >=2; canonical-content-group-safe item folds; fixed user split; label-free strict first-exposure warm-history support; target fold frozen before any synthetic->human performance is inspected",
        "choice_question_reference_column":str(cq) if cq else None,
        "input_sha256":{k:file_sha(p) for k,p in paths.items()},
    }
    (out/"dbe_strict_contract_manifest.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=="__main__": main()
