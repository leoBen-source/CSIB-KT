#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build separate DBE generation and scoring banks.

Generation bank contains deployment-time item content/options/KC metadata only.
Scoring bank additionally contains official correctness. This physically prevents
the generator process from loading answer keys.
"""
from __future__ import annotations
import argparse,html,json,re
from collections import defaultdict
from pathlib import Path
import pandas as pd

FORBIDDEN_GEN_KEYS={"answer_spec","answer_raw","accepted","correct_answer","is_correct",
                    "explanation","hint","difficulty","difficulty_level"}

def find_col(df,names,required=True):
    low={str(c).lower():c for c in df.columns}
    for n in names:
        if n.lower() in low:return low[n.lower()]
    if required:raise RuntimeError(f"none of {names} in {list(df.columns)}")
    return None
def qi(x):return int(float(x))
def bval(x):return str(x).strip().lower() in {"true","1","t","yes","y"}
def clean(s):
    s=html.unescape(str(s or ""));s=re.sub(r"<\s*br\s*/?>","\n",s,flags=re.I);s=re.sub(r"</\s*p\s*>","\n",s,flags=re.I)
    s=re.sub(r"<[^>]+>"," ",s);s=re.sub(r"[ \t]+"," ",s);s=re.sub(r"\n\s*\n+","\n",s);return s.strip()

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--data_root",required=True);ap.add_argument("--group_item_csv",required=True);ap.add_argument("--out_dir",required=True)
    args=ap.parse_args();root=Path(args.data_root);out=Path(args.out_dir);out.mkdir(parents=True,exist_ok=True)
    g=pd.read_csv(args.group_item_csv,low_memory=False);q=pd.read_csv(root/"Questions.csv",low_memory=False);ch=pd.read_csv(root/"Question_Choices.csv",low_memory=False)
    qidc=find_col(q,["id"]);qids=set(q[qidc].map(qi));qmap={qi(r[qidc]):r for _,r in q.iterrows()}
    cands=[c for c in ch.columns if str(c).lower() in {"question_id","step_id"}]
    if not cands:raise RuntimeError(f"cannot resolve choice question reference: {list(ch.columns)}")
    def overlap(c):
        vals=set()
        for x in ch[c].dropna():
            try:vals.add(qi(x))
            except:pass
        return len(vals&qids)
    cq=max(cands,key=overlap);ctext=find_col(ch,["choice_text","text"]);ccorr=find_col(ch,["is_correct","correct"]);cid=find_col(ch,["id"],False)
    zz=ch.sort_values(cid) if cid else ch.copy();opts=defaultdict(list);gold=defaultdict(list)
    for _,r in zz.iterrows():
        try:qid=qi(r[cq])
        except:continue
        t=clean(r[ctext])
        if not t:continue
        opts[qid].append(t)
        if bval(r[ccorr]):gold[qid].append(t)
    title=find_col(q,["question_title"],False);text=find_col(q,["question_text"],False);rich=find_col(q,["question_rich_text"],False)
    rows=[]
    fg=(out/"dbe_item_generation_bank.jsonl").open("w",encoding="utf-8")
    fs=(out/"dbe_item_scoring_bank.jsonl").open("w",encoding="utf-8")
    try:
        for r in g.itertuples(index=False):
            qid=int(r.target_qid);m=qmap[qid];fields=[]
            if title and pd.notna(m[title]) and clean(m[title]):fields.append(clean(m[title]))
            body=""
            if text and pd.notna(m[text]) and clean(m[text]):body=clean(m[text])
            elif rich and pd.notna(m[rich]):body=clean(m[rich])
            if body and body not in fields:fields.append(body)
            content="\n".join(fields).strip();options=opts.get(qid,[]);accepted=gold.get(qid,[])
            if not content or len(options)<2 or not accepted:raise RuntimeError(f"qid={qid} incomplete content/options/correct choice")
            if len(accepted)!=1:raise RuntimeError(f"qid={qid} has {len(accepted)} correct choices")
            gen={"qid":qid,"raw_qid":str(qid),"content_group_fold":int(r.content_group_fold),
                 "canonical_content_id":str(r.canonical_content_id),"target_kc_key":str(r.target_kc_key),
                 "question_type":"multiple_choice","content":content,"options":options}
            bad=FORBIDDEN_GEN_KEYS & set(gen)
            if bad:raise RuntimeError(f"forbidden generation keys qid={qid}: {sorted(bad)}")
            score=dict(gen);score["answer_spec"]={"kind":"choice","accepted":accepted,"options":options};score["answer_raw"]=accepted
            fg.write(json.dumps(gen,ensure_ascii=False)+"\n");fs.write(json.dumps(score,ensure_ascii=False)+"\n")
            rows.append({"qid":qid,"option_n":len(options),"correct_option_n":len(accepted),"content_chars":len(content),"content_group_fold":int(r.content_group_fold)})
    finally:
        fg.close();fs.close()
    z=pd.DataFrame(rows);z.to_csv(out/"dbe_item_bank_audit.csv",index=False)
    s={"schema_version":"s13d_dbe_item_bank_v2","item_n":int(len(z)),
       "generation_bank":"dbe_item_generation_bank.jsonl","scoring_bank":"dbe_item_scoring_bank.jsonl",
       "contract":"The generation process cannot access official correctness; answers exist only in the separate scoring bank."}
    (out/"summary.json").write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding="utf-8");print(json.dumps(s,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
