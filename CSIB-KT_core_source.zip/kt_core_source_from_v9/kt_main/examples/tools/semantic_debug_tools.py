# -*- coding: utf-8 -*-
"""
semantic_debug_tools.py

用途：
1) 外部调试 question / concept 索引与文本对齐
2) 不改训练主逻辑，不影响正式训练
3) 可被 wandb_train.py import 调用
4) 也可单独命令行运行

支持两个主检查：
- debug_check_q_alignment:
    检查 train_loader 中 active qseqs / shft_qseqs 与 qid_map 的索引范围是否一致，
    尤其排查“真实 question 0 被 padding_idx=0 吃掉”的问题。
- inspect_sqakt_index_and_text_alignment:
    检查 SQAKT 场景下：
    - q / c active index 统计
    - qid_map / kc_map 范围
    - 文本 JSON 与 map 的 key overlap
    - builder slot / model read slot 的直观预览

可作为：
- import 工具函数
- CLI 调试脚本
"""

import os
import json
import argparse
from typing import Optional

import torch


def clean_id(x):
    s = str(x).strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s


def _load_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _require_exists(path: Optional[str], name: str):
    if not path:
        raise ValueError(f"[{name}] path is empty.")
    if not os.path.exists(path):
        raise FileNotFoundError(f"[{name}] not found: {path}")


def _get_qmap_questions(qid_map_path: str):
    obj = _load_json(qid_map_path)
    if isinstance(obj, dict) and "questions" in obj and isinstance(obj["questions"], dict):
        return obj["questions"]
    if isinstance(obj, dict):
        return obj
    raise ValueError(f"[QMAP] unexpected json format: {qid_map_path}")


def _get_cmap_concepts(kc_map_path: str):
    obj = _load_json(kc_map_path)

    if isinstance(obj, dict):
        # 常见嵌套优先
        for k in ["concepts", "skills", "kc", "kcs"]:
            if k in obj and isinstance(obj[k], dict):
                return obj[k]
        # 否则按平铺 map 处理
        return obj

    raise ValueError(f"[CMAP] unexpected json format: {kc_map_path}")


def debug_check_q_alignment(train_loader, qid_map_path: str, print_prefix: str = ""):
    """
    检查：
    - qmap idx min/max
    - active qseqs / shft_qseqs min/max
    - active 0 的数量
    用于快速判断：
    1) 问题索引范围是否越界/错位
    2) question idx=0 是否真实存在且被 padding 冲突
    """
    _require_exists(qid_map_path, "qid_map_path")

    qmap = _get_qmap_questions(qid_map_path)
    qidxs = [int(v) for v in qmap.values()]
    if len(qidxs) == 0:
        raise ValueError("[Q-ALIGN DEBUG] empty question map.")

    batch = next(iter(train_loader))
    qseqs = batch["qseqs"]
    shft_qseqs = batch["shft_qseqs"]
    masks = batch["masks"].bool()
    smasks = batch["smasks"].bool()

    cur_q = torch.masked_select(qseqs, masks)
    nxt_q = torch.masked_select(shft_qseqs, smasks)

    if cur_q.numel() == 0 or nxt_q.numel() == 0:
        raise ValueError("[Q-ALIGN DEBUG] active q tensors are empty. Please check train_loader.")

    pf = f"{print_prefix} " if print_prefix else ""

    print(f"{pf}========== [Q-ALIGN DEBUG] ==========")
    print(f"{pf}qmap idx min/max: {min(qidxs)} / {max(qidxs)}")
    print(f"{pf}active qseqs min/max: {int(cur_q.min())} / {int(cur_q.max())}")
    print(f"{pf}active shft_qseqs min/max: {int(nxt_q.min())} / {int(nxt_q.max())}")
    print(f"{pf}active qseqs zero count: {(cur_q == 0).sum().item()}")
    print(f"{pf}active shft_qseqs zero count: {(nxt_q == 0).sum().item()}")
    print(f"{pf}qseqs[0][:20] = {qseqs[0][:20].tolist()}")
    print(f"{pf}shft_qseqs[0][:20] = {shft_qseqs[0][:20].tolist()}")

    inv_q = {int(v): clean_id(k) for k, v in qmap.items()}
    if 0 in inv_q:
        print(f"{pf}❗ [QMAP] real question index 0 exists, raw_problem_id={inv_q[0]}")
        print(f"{pf}❗ [WARN] if q embedding uses padding_idx=0, real question 0 may be treated as padding.")

    print(f"{pf}=====================================")


def inspect_sqakt_index_and_text_alignment(
    train_loader,
    qid_map_path: str,
    kc_map_path: str,
    question_text_json_path: Optional[str] = None,
    concept_text_json_path: Optional[str] = None,
    max_batches: int = 20,
    print_prefix: str = "",
):
    """
    SQAKT 索引/文本对齐详细检查。

    检查内容：
    1) active q/c 统计（min/max/zero_count/unique_count）
    2) qid_map / kc_map 的 idx 范围
    3) question_text_json / concept_text_json 与 map keys 的 overlap
    4) 预览若干 idx 对应文本，用于快速看 builder_slot / model_read_slot 的直观关系
    """
    _require_exists(qid_map_path, "qid_map_path")
    _require_exists(kc_map_path, "kc_map_path")
    if question_text_json_path:
        _require_exists(question_text_json_path, "question_text_json_path")
    if concept_text_json_path:
        _require_exists(concept_text_json_path, "concept_text_json_path")

    pf = f"{print_prefix} " if print_prefix else ""

    print(f"\n{pf}========== [SQAKT INDEX/TEXT ALIGN INSPECT] ==========")

    q_vals_all = []
    qshft_vals_all = []
    c_vals_all = []
    cshft_vals_all = []

    for bi, batch in enumerate(train_loader):
        if bi >= max_batches:
            break

        masks = batch["masks"].bool()
        smasks = batch["smasks"].bool()

        q_vals_all.append(torch.masked_select(batch["qseqs"], masks).cpu())
        qshft_vals_all.append(torch.masked_select(batch["shft_qseqs"], smasks).cpu())
        c_vals_all.append(torch.masked_select(batch["cseqs"], masks).cpu())
        cshft_vals_all.append(torch.masked_select(batch["shft_cseqs"], smasks).cpu())

    if len(q_vals_all) == 0:
        raise ValueError("[SQAKT ALIGN] no batches collected from train_loader.")

    q_vals = torch.cat(q_vals_all, dim=0)
    qshft_vals = torch.cat(qshft_vals_all, dim=0)
    c_vals = torch.cat(c_vals_all, dim=0)
    cshft_vals = torch.cat(cshft_vals_all, dim=0)

    def print_stats(name, x):
        uniq = torch.unique(x)
        print(
            f"{pf}[{name}] size={x.numel()}, "
            f"min={int(x.min())}, max={int(x.max())}, "
            f"zero_count={int((x == 0).sum())}, unique_count={int(uniq.numel())}"
        )
        print(f"{pf}[{name}] first_20={x[:20].tolist()}")

    print_stats("q_active", q_vals)
    print_stats("qshft_active", qshft_vals)
    print_stats("c_active", c_vals)
    print_stats("cshft_active", cshft_vals)

    if int((q_vals == 0).sum()) > 0 or int((qshft_vals == 0).sum()) > 0:
        print(f"{pf}❗ [WARN] active question ids contain 0.")
        print(f"{pf}❗ [WARN] if q_id_embed/q_sem_embed use padding_idx=0, real question 0 is being treated as padding.")

    if int((c_vals == 0).sum()) > 0 or int((cshft_vals == 0).sum()) > 0:
        print(f"{pf}❗ [WARN] active concept ids contain 0.")
        print(f"{pf}❗ [WARN] if c_id_embed/c_sem_embed use padding_idx=0, real concept 0 may be treated as padding.")

    qmap = _get_qmap_questions(qid_map_path)
    q_idxs = sorted(int(v) for v in qmap.values())
    inv_q = {int(v): clean_id(k) for k, v in qmap.items()}

    if len(q_idxs) == 0:
        raise ValueError("[QMAP] empty question map.")

    print(f"\n{pf}[QMAP] num_questions={len(qmap)}, idx_min={min(q_idxs)}, idx_max={max(q_idxs)}")
    print(f"{pf}[QMAP] first_10_idx={q_idxs[:10]}")
    if 0 in inv_q:
        print(f"{pf}❗ [QMAP] real question index 0 exists, raw_problem_id={inv_q[0]}")

    kc_map = _get_cmap_concepts(kc_map_path)
    kc_map_clean = {clean_id(k): int(v) for k, v in kc_map.items()}
    c_idxs = sorted(kc_map_clean.values())
    inv_c = {int(v): clean_id(k) for k, v in kc_map_clean.items()}

    if len(c_idxs) == 0:
        raise ValueError("[KCMAP] empty concept map.")

    print(f"\n{pf}[KCMAP] num_concepts={len(kc_map_clean)}, idx_min={min(c_idxs)}, idx_max={max(c_idxs)}")
    print(f"{pf}[KCMAP] first_10_idx={c_idxs[:10]}")
    if 0 in inv_c:
        print(f"{pf}❗ [KCMAP] real concept index 0 exists, raw_skill_id={inv_c[0]}")

    raw_qids = set(clean_id(k) for k in qmap.keys())
    raw_cids = set(clean_id(k) for k in kc_map_clean.keys())

    if question_text_json_path is not None:
        qtxt = _load_json(question_text_json_path)
        qtxt_clean = {clean_id(k): v for k, v in qtxt.items()}
        qtxt_keys = set(qtxt_clean.keys())
        overlap_q = raw_qids & qtxt_keys
        only_in_qmap = sorted(list(raw_qids - qtxt_keys))[:10]
        only_in_qtxt = sorted(list(qtxt_keys - raw_qids))[:10]

        print(f"\n{pf}[QTEXT] path={question_text_json_path}")
        print(f"{pf}[QTEXT] json_keys={len(qtxt_keys)}, overlap_with_qmap={len(overlap_q)}/{len(raw_qids)}")
        print(f"{pf}[QTEXT] only_in_qmap(sample)={only_in_qmap}")
        print(f"{pf}[QTEXT] only_in_qtxt(sample)={only_in_qtxt}")

        print(f"\n{pf}[QTEXT SLOT CHECK] builder stores 0-based texts; model lookup may shift to embedding slot idx0+1 depending on implementation.")
        probe_q_idxs = [0, 1, 2, 3, 10, max(q_idxs)]
        for idx in probe_q_idxs:
            if idx in inv_q:
                raw_qid = inv_q[idx]
                hit = raw_qid in qtxt_clean
                preview = str(qtxt_clean.get(raw_qid, ""))[:100]
                print(
                    f"{pf}  idx={idx}, raw_qid={raw_qid}, json_hit={hit}, "
                    f"text_preview='{preview}'"
                )

    if concept_text_json_path is not None:
        ctxt = _load_json(concept_text_json_path)
        ctxt_clean = {clean_id(k): v for k, v in ctxt.items()}
        ctxt_keys = set(ctxt_clean.keys())
        overlap_c = raw_cids & ctxt_keys
        only_in_kcmap = sorted(list(raw_cids - ctxt_keys))[:10]
        only_in_ctxt = sorted(list(ctxt_keys - raw_cids))[:10]

        print(f"\n{pf}[CTEXT] path={concept_text_json_path}")
        print(f"{pf}[CTEXT] json_keys={len(ctxt_keys)}, overlap_with_kcmap={len(overlap_c)}/{len(raw_cids)}")
        print(f"{pf}[CTEXT] only_in_kcmap(sample)={only_in_kcmap}")
        print(f"{pf}[CTEXT] only_in_ctxt(sample)={only_in_ctxt}")

        print(f"\n{pf}[CTEXT SLOT CHECK] builder stores 0-based texts; model lookup may shift to embedding slot idx0+1 depending on implementation.")
        probe_c_idxs = [0, 1, 2, 3, 10, max(c_idxs)]
        for idx in probe_c_idxs:
            if idx in inv_c:
                raw_cid = inv_c[idx]
                hit = raw_cid in ctxt_clean
                preview = str(ctxt_clean.get(raw_cid, ""))[:100]
                print(
                    f"{pf}  idx={idx}, raw_skill_id={raw_cid}, json_hit={hit}, "
                    f"text_preview='{preview}'"
                )

    print(f"{pf}======================================================\n")


def build_train_loader_for_debug(
    dataset_name: str,
    model_name: str,
    fold: int,
    batch_size: Optional[int] = None,
    data_config_path: str = "../configs/data_config.json",
    dataset_dir_override: str = "",
):
    """
    为独立 CLI 调试构造 train_loader。
    只依赖 pykt 的 init_dataset4train，不动训练逻辑。
    """
    from pykt.datasets import init_dataset4train

    with open(data_config_path, "r", encoding="utf-8") as f:
        data_config = json.load(f)

    if dataset_name not in data_config:
        raise KeyError(f"dataset_name={dataset_name} not found in {data_config_path}")

    if dataset_dir_override:
        data_config[dataset_name] = dict(data_config[dataset_name])
        data_config[dataset_name]["dpath"] = dataset_dir_override

    if batch_size is None:
        batch_size = 64

    train_loader, valid_loader, *_ = init_dataset4train(
        dataset_name=dataset_name,
        model_name=model_name,
        data_config=data_config,
        i=fold,
        batch_size=batch_size,
    )
    return train_loader, valid_loader, data_config


def main():
    parser = argparse.ArgumentParser(description="Semantic alignment debug tools")

    parser.add_argument("--mode", type=str, default="both", choices=["q_align", "sqakt_align", "both"])
    parser.add_argument("--dataset_name", type=str, required=True)
    parser.add_argument("--model_name", type=str, default="sqakt")
    parser.add_argument("--fold", type=int, default=0)
    parser.add_argument("--batch_size", type=int, default=64)

    parser.add_argument("--data_config_path", type=str, default="../configs/data_config.json")
    parser.add_argument("--dataset_dir_override", type=str, default="")

    parser.add_argument("--qid_map_path", type=str, required=True)
    parser.add_argument("--kc_map_path", type=str, default="")
    parser.add_argument("--question_text_json_path", type=str, default="")
    parser.add_argument("--concept_text_json_path", type=str, default="")
    parser.add_argument("--max_batches", type=int, default=20)

    args = parser.parse_args()

    train_loader, _, data_config = build_train_loader_for_debug(
        dataset_name=args.dataset_name,
        model_name=args.model_name,
        fold=args.fold,
        batch_size=args.batch_size,
        data_config_path=args.data_config_path,
        dataset_dir_override=args.dataset_dir_override,
    )

    used_root = data_config[args.dataset_name]["dpath"]
    print(f"✅ [DEBUG-LOADER] dataset={args.dataset_name}, model={args.model_name}, fold={args.fold}, batch_size={args.batch_size}")
    print(f"✅ [DEBUG-LOADER] dpath={used_root}")

    if args.mode in ["q_align", "both"]:
        debug_check_q_alignment(
            train_loader=train_loader,
            qid_map_path=args.qid_map_path,
            print_prefix=f"[{args.dataset_name}/{args.model_name}]",
        )

    if args.mode in ["sqakt_align", "both"]:
        if not args.kc_map_path:
            raise ValueError("--kc_map_path is required when mode=sqakt_align or both")

        inspect_sqakt_index_and_text_alignment(
            train_loader=train_loader,
            qid_map_path=args.qid_map_path,
            kc_map_path=args.kc_map_path,
            question_text_json_path=args.question_text_json_path or None,
            concept_text_json_path=args.concept_text_json_path or None,
            max_batches=args.max_batches,
            print_prefix=f"[{args.dataset_name}/{args.model_name}]",
        )


if __name__ == "__main__":
    main()
