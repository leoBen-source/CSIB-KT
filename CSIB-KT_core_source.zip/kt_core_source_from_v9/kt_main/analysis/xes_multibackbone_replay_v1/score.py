#!/usr/bin/env python3
"""Score the identical held-out 522-item event panel for each frozen backbone.

The current response is checked against the source for coordinates only. It is
never passed into the KT forward pass. 'prefix' admits earlier new-item answers
from the same original sequence chunk and must use frozen warm-fit priors.
"""
import argparse,csv,copy,json,os,sys
from pathlib import Path
import numpy as np,pandas as pd
from measurement import atomic_csv,file_hash,save_json

def load_model(project,run):
    import torch
    project=Path(project).resolve();sys.path[:0]=[str(project/'examples'),str(project)]
    os.chdir(project/'examples')
    from pykt.models import load_model as pykt_load
    cfg=json.loads((Path(run)/'config.json').read_text());params=cfg['params'];mn=params['model_name']
    mc=copy.deepcopy(cfg['model_config'])
    for k in ('use_wandb','learning_rate','add_uuid','l2','dataset_dir_override','num_epochs','batch_size'):
        mc.pop(k,None)
    if mn=='dkt':mc={k:v for k,v in mc.items() if k in ('emb_size','dropout','pretrain_dim')}
    dc=copy.deepcopy(cfg['data_config']);dc['dpath']=params['dataset_dir_override']
    net=pykt_load(mn,mc,dc,params['emb_type'],str(run));net.eval()
    return net,cfg

def prob(net,mn,hq,hc,hr,q,c,device):
    import torch
    if not hq:raise ValueError('Empty legal KT history')
    with torch.inference_mode():
        if mn=='dkt':
            ct=torch.tensor([hc],dtype=torch.long,device=device);rt=torch.tensor([hr],dtype=torch.long,device=device)
            p=net(ct,rt)[0,-1,c]
        else:
            qt=torch.tensor([hq+[q]],dtype=torch.long,device=device)
            ct=torch.tensor([hc+[c]],dtype=torch.long,device=device)
            rt=torch.tensor([hr+[0]],dtype=torch.long,device=device)
            if mn=='akt':p=net(ct,rt,qt)[0][:,-1][0]
            elif mn=='simplekt':
                d={'qseqs':qt[:,:-1],'cseqs':ct[:,:-1],'rseqs':rt[:,:-1],
                    'shft_qseqs':qt[:,1:],'shft_cseqs':ct[:,1:],'shft_rseqs':rt[:,1:]}
                p=net(d)[0,-1]
            else:raise ValueError(mn)
    value=float(p.detach().cpu())
    if not np.isfinite(value) or not 0<value<1:raise ValueError('Invalid backbone probability')
    return value

def score(a):
    teacher=Path(a.teacher).resolve();data=Path(a.data).resolve();run=Path(a.run).resolve();out=Path(a.out).resolve()
    if out.exists():raise ValueError('Fresh output directory required')
    train=json.loads((data/'projection_manifest.json').read_text());cfg=json.loads((run/'config.json').read_text());mn=cfg['params']['model_name']
    assert mn in ('akt','simplekt','dkt') and Path(cfg['params']['dataset_dir_override']).resolve()==data
    assert file_hash(data/'train_valid_sequences.csv')==train['output_sha256']
    # Audit question-specific cold parameters: untouched zero-initialized rows.
    net,cfg=load_model(a.project,run)
    e=pd.read_csv(teacher/'clean/teacher_aligned_event_baseline_targetidfree.csv.gz',dtype={'event_id':str,'student_key':str,'target_kc_key':str})
    qkc={int(k):sorted(set(map(int,v))) for k,v in json.loads((teacher/'inputs/q_to_kc_set.json').read_text()).items()}
    targets=set(e.target_qid.astype(int));assert len(targets)==522
    if hasattr(net,'difficult_param'):
        import torch
        with torch.no_grad():
            cold=net.difficult_param.weight[sorted(targets)]
            if torch.max(torch.abs(cold)).item()>1e-8:raise ValueError('Cold item-specific embedding was trained or initialized nonzero')
    im=json.loads((teacher/'inputs/input_manifest.json').read_text());src=Path(im['event_source_csv'])
    if file_hash(src)!=im['coordinate_source_sha256']:raise ValueError('Canonical source SHA mismatch')
    grouped={int(i):v for i,v in e.groupby('row_index')};seen=set();rows=[]
    device=next(net.parameters()).device
    with src.open(newline='',encoding='utf8') as f:
        for idx,row in enumerate(csv.DictReader(f)):
            if idx not in grouped:continue
            seen.add(idx)
            qs=[int(float(s)) for s in row['questions'].split(',')]
            ys=[int(float(s)) for s in row['responses'].split(',')]
            if len(qs)!=len(ys):raise ValueError('Unaligned original source row')
            for ev in grouped[idx].sort_values('target_position').itertuples(index=False):
                pos=int(ev.target_position);q=int(ev.target_qid)
                if qs[pos]!=q or ys[pos]!=int(ev.label):raise ValueError('Target source coordinate mismatch')
                legal=[j for j in range(pos) if qs[j]>=0 and ys[j] in (0,1) and qs[j] in qkc and
                       (a.mode=='prefix' or qs[j] not in targets)]
                if not legal:raise ValueError('No legal history for evaluated event '+str(ev.event_id))
                p=prob(net,mn,[qs[j] for j in legal],[qkc[qs[j]][0] for j in legal],
                       [ys[j] for j in legal],q,qkc[q][0],device)
                rows.append((str(ev.event_id),p,len(legal)))
            if len(rows)%20000<30:print(mn,a.mode,'events',len(rows),flush=True)
    if seen!=set(grouped) or len(rows)!=len(e):raise ValueError('Scored event universe mismatch')
    z=pd.DataFrame(rows,columns=['event_id','new_p','history_length'])
    if z.event_id.duplicated().any():raise ValueError('Duplicate event')
    out.mkdir(parents=True)
    result=e.merge(z,on='event_id',validate='one_to_one');result['teacher_kc_uniform']=result.pop('new_p')
    path=out/'events.csv.gz';atomic_csv(result,path)
    save_json(Path(str(path)+'.manifest.json'),dict(model=mn,history_mode='warm' if a.mode=='warm' else 'student_prefix',
        checkpoint_sha256=file_hash(run/'qid_model.ckpt'),source_sha256=file_hash(src),train_projection_sha256=train['output_sha256'],
        event_n=len(e),target_n=len(targets),scores_sha256=file_hash(path),state_scope='only earlier positions in the original sequence chunk',
        target_response_used_as_model_input=False,chronological_global_claim=False))
    print('SCORE_PASS',mn,a.mode,path,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for arg in ('project','teacher','data','run','out'):p.add_argument('--'+arg,required=True)
    p.add_argument('--mode',choices=('warm','prefix'),default='warm');score(p.parse_args())
