#!/usr/bin/env python3
"""Train the supplied project's native PyKT AKT/simpleKT/DKT code."""
import argparse,copy,importlib.util,json,os,sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--project',required=True);ap.add_argument('--data',required=True)
    ap.add_argument('--model',choices=['akt','simplekt','dkt'],required=True);ap.add_argument('--save',required=True)
    ap.add_argument('--seed',type=int,default=42);ap.add_argument('--epochs',type=int,default=200);a=ap.parse_args()
    project=Path(a.project).resolve();data=Path(a.data).resolve();save=Path(a.save).resolve()
    man=json.loads((data/'projection_manifest.json').read_text())
    from measurement import file_hash
    assert file_hash(data/'train_valid_sequences.csv')==man['output_sha256'] and man['cold_target_events']==0
    if save.exists():raise ValueError('Use a new model output directory')
    cfg=json.loads((project/'configs/data_config.json').read_text())['xes3g5m']
    if man['max_qid']>=int(cfg['num_q']) or man['max_concept_id']>=int(cfg['num_c']):
        raise ValueError('Official ID projection exceeds PyKT embedding configuration')
    for key in ('train_valid_file','train_valid_file_quelevel'):
        alias=data/cfg[key]
        if alias!=data/'train_valid_sequences.csv':
            alias.parent.mkdir(parents=True,exist_ok=True)
            if alias.exists():raise ValueError('Unexpected existing alias '+str(alias))
            alias.symlink_to(os.path.relpath(data/'train_valid_sequences.csv',alias.parent))
    sys.path[:0]=[str(project/'examples'),str(project)]
    spec=importlib.util.find_spec('pykt')
    if not spec or project/'pykt' not in Path(spec.origin).resolve().parents:raise ValueError('Wrong PyKT import')
    os.chdir(project/'examples');import wandb_train as wt
    orig=wt.init_model
    def safe_init(m,mc,dc,emb):
        mc=copy.deepcopy(mc)
        for k in ('dataset_dir_override','num_epochs','batch_size','learning_rate','use_wandb','add_uuid','l2'):
            mc.pop(k,None)
        if m=='dkt':mc={k:v for k,v in mc.items() if k in ('dropout','emb_size','pretrain_dim')}
        return orig(m,mc,dc,emb)
    wt.init_model=safe_init
    common=dict(dataset_name='xes3g5m',model_name=a.model,fold=3,seed=a.seed,emb_type='qid',
        save_dir=str(save),dataset_dir_override=str(data),use_wandb=0,add_uuid=0,num_epochs=a.epochs)
    if a.model=='akt':common.update(dropout=.2,d_model=256,d_ff=512,num_attn_heads=8,n_blocks=4,learning_rate=1e-4,batch_size=64,
        use_v4_init=0,use_q_sem=0,use_q_behavior=0,q_inject_mode='none',semantic_control_mode='zero')
    elif a.model=='simplekt':common.update(dropout=.1,d_model=256,d_ff=256,num_attn_heads=4,n_blocks=2,
        final_fc_dim=256,final_fc_dim2=256,learning_rate=1e-4,batch_size=64)
    else:common.update(dropout=.2,emb_size=200,learning_rate=1e-3,batch_size=64)
    wt.main(common)
    runs=list(save.glob('*/qid_model.ckpt'))
    if len(runs)!=1:raise ValueError('Expected one trained checkpoint: '+str(runs))
    (save/'selected_run.txt').write_text(str(runs[0].parent.resolve())+'\n')
    print('TRAIN_PASS',runs[0].parent,flush=True)

if __name__=='__main__':main()
