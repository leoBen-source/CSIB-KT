#!/usr/bin/env python3
"""Project the audited cold-excluded SQAKT stream to one official KC per item.

AKT, simpleKT and DKT in this repository read a scalar concept per event. The
projection keeps every item, event and student fold; it never chooses a KC using
student responses. The original full KC set is retained for item calibration.
"""
import argparse, csv, json, hashlib
from pathlib import Path
from measurement import file_hash, save_json


def inputs(teacher):
    teacher = Path(teacher).resolve()
    receipt = json.loads((teacher/'models/shared_teacher/training_receipt.json').read_text())
    assert receipt['status']=='PASS' and receipt['training_cold_interactions']==receipt['validation_cold_interactions']==0
    cfg = json.loads((Path(receipt['run'])/'config.json').read_text())['data_config']
    root = Path(cfg['dpath'])
    candidates = [root/cfg[k] for k in ('sqakt_train_valid_file','train_valid_file_quelevel','train_valid_file') if k in cfg]
    good = [p for p in candidates if p.is_file() and file_hash(p)==receipt['csv_sha256']]
    if len({p.resolve() for p in good})!=1:
        raise ValueError('Cannot identify the EXACT audited SQAKT training CSV by receipt SHA256: '+str(candidates))
    qkc = {int(k): sorted(set(map(int,v))) for k,v in json.loads((teacher/'inputs/q_to_kc_set.json').read_text()).items()}
    import pandas as pd
    targets = set(pd.read_csv(teacher/'clean/content_group_safe_item_targets_targetidfree.csv',usecols=['target_qid']).target_qid.astype(int))
    assert len(targets)==522 and all(qkc.get(q) for q in targets)
    return good[0],qkc,targets,receipt


def prepare(teacher,out):
    src,qkc,targets,receipt=inputs(teacher)
    out=Path(out)
    if out.exists():raise ValueError('Fresh output directory required: '+str(out))
    out.mkdir(parents=True)
    dst=out/'train_valid_sequences.csv'
    counts={'rows':0,'events':0,'projected_multi_kc_events':0,'max_qid':-1,'max_concept_id':-1,'folds':{}}
    with src.open(newline='',encoding='utf8') as f, dst.open('w',newline='',encoding='utf8') as w:
        reader=csv.DictReader(f); assert {'questions','concepts','responses','selectmasks','fold'}<=set(reader.fieldnames)
        writer=csv.DictWriter(w,fieldnames=reader.fieldnames);writer.writeheader()
        for row in reader:
            qs=row['questions'].split(',');cs=row['concepts'].split(',');rs=row['responses'].split(',');ms=row['selectmasks'].split(',')
            if not len(qs)==len(cs)==len(rs)==len(ms):raise ValueError('Unaligned source row')
            projected=[]
            for q in qs:
                q=int(float(q))
                if q<0:projected.append('-1');continue
                if q in targets:raise ValueError('Cold target leaked into backbone training/validation CSV: '+str(q))
                if q not in qkc or not qkc[q]:raise ValueError('Missing official KC for q='+str(q))
                projected.append(str(qkc[q][0]));counts['events']+=1
                counts['max_qid']=max(counts['max_qid'],q)
                counts['max_concept_id']=max(counts['max_concept_id'],qkc[q][0])
                counts['projected_multi_kc_events']+=len(qkc[q])>1
            row['concepts']=','.join(projected);writer.writerow(row)
            counts['rows']+=1;fold=str(row['fold']);counts['folds'][fold]=counts['folds'].get(fold,0)+1
    if set(counts['folds'])!={'0','1','2','3','4'} or counts['events']<1000:raise ValueError('Unexpected user folds or empty data')
    save_json(out/'projection_manifest.json',dict(source=str(src),source_sha256=file_hash(src),output_sha256=file_hash(dst),
        sqakt_checkpoint_sha256=receipt['checkpoint_sha256'],excluded_target_n=len(targets),cold_target_events=0,
        projection='minimum official KC identifier for each item; all 522 targets kept for test',**counts))
    print(json.dumps(counts,ensure_ascii=False),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--teacher',required=True);p.add_argument('--out',required=True);a=p.parse_args();prepare(a.teacher,a.out)
