#!/usr/bin/env python3
"""Use the checkpoint's native prefix forward for every official FA prediction.

The cached implementation remains a diagnostic; it does not provide the
published probabilities and its former 1e-6 gate is not silently changed.
"""
import argparse,copy,importlib.util,json,math,os,sys,time,traceback
from pathlib import Path
from collections import Counter

def write(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.partial');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False));os.replace(tmp,path)
def pad(kcs,width):
    values=sorted(set(map(int,kcs)))
    if len(values)>width:raise ValueError('KC set exceeds trained width')
    return values+[-1]*(width-len(values))
def official_prefix(torch,model,q,c,r,kc,target):
    """r contains past warm responses only; current target label is not an input."""
    device=q.device;n=q.shape[1]
    if n<1 or c.shape[1]!=n or r.shape[1]!=n:raise ValueError('Invalid native history shape')
    next_c=torch.cat([c[:,1:],torch.tensor([[kc]],dtype=torch.long,device=device)],dim=1)
    next_q=torch.cat([q[:,1:],torch.tensor([[target]],dtype=torch.long,device=device)],dim=1)
    valid=torch.ones(q.shape,dtype=torch.bool,device=device)
    return model(c,r,cshft=next_c,q=q,qshft=next_q,valid_mask=valid)[0,-1]

def main():
    p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--root',required=True);p.add_argument('--diagnostic-per-fold',type=int,default=20);a=p.parse_args()
    project=Path(a.project).resolve();root=Path(a.root).resolve();teacher=root/'external_known_kc/fa/teacher';diag=root/'score_diagnostics/fa';diag.mkdir(parents=True,exist_ok=True)
    try:
        import numpy as np,pandas as pd,torch
        from measurement import file_hash,atomic_csv,EPS
        from scipy.special import expit
        from native_template_v5_2 import resolve_template
        sys.path[:0]=[str(project/'examples'),str(project)];os.chdir(project/'examples')
        from pykt.models import load_model
        data=teacher/'data';geom=json.loads((data/'geometry.json').read_text());receipt=json.loads((teacher/'models/shared_teacher/training_receipt.json').read_text())
        if receipt.get('status')!='PASS' or receipt['training_cold_interactions'] or receipt['validation_cold_interactions']:raise ValueError('Training receipt failed')
        run=Path(receipt['run']);checkpoint=run/'qid_model.ckpt'
        if file_hash(checkpoint)!=receipt['checkpoint_sha256']:raise ValueError('Checkpoint changed')
        eventpath=teacher/'clean/teacher_aligned_event_baseline_targetidfree.csv.gz'
        if eventpath.exists() or (teacher/'scoring_audit.json').exists():raise FileExistsError('Preserve existing scored files; inspect before rerunning native scoring')
        torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
        if hasattr(torch,'set_float32_matmul_precision'):torch.set_float32_matmul_precision('highest')
        cfg=json.loads((run/'config.json').read_text());mc=copy.deepcopy(cfg['model_config'])
        for k in ['dataset_dir_override','semantic_dataset_root_override','teacher_dir_override','num_epochs','batch_size','learning_rate','use_wandb','add_uuid','l2']:mc.pop(k,None)
        model=load_model('sqakt',mc,cfg['data_config'],'qid',str(run));model.eval()
        if not model.kc_set_input or model.q_item_parameterization!='id_only_cold_mask':raise ValueError('Unexpected native SQAKT configuration')
        device=next(model.parameters()).device;width=int(cfg['model_config']['kc_set_max_concepts'])
        qmap={int(q):int(i) for q,i in geom['qmap'].items()};kmap={int(k):int(i) for k,i in geom['kmap'].items()};qkc={int(q):list(map(int,ks)) for q,ks in geom['qkc'].items()}
        group=pd.read_csv(teacher/'inputs/group.csv',dtype={'target_kc_key':str});cold=set(map(int,group.target_qid));info=group.set_index('target_qid');excluded=set(json.loads((teacher/'inputs/excluded_candidate_qids.json').read_text()))
        if not cold<=excluded:raise ValueError('Evaluation targets outside excluded candidate bank')
        template,_,_,_=resolve_template(root.parent/'s12_strict_shared_teacher_v1')
        spec=importlib.util.spec_from_file_location('fa_cached_diagnostic',template/'shared_scorer.py');cached=importlib.util.module_from_spec(spec);sys.modules[spec.name]=cached;spec.loader.exec_module(cached)
        rows=[];diffs=[];diag_counts=Counter();diag_errors=[];clipped_n=0;started=time.monotonic()
        with (data/'eval_sequences.jsonl').open() as f,torch.inference_mode():
            for ridx,line in enumerate(f):
                row=json.loads(line);qs=list(map(int,row['qraw']));ys=list(map(int,row['response']));pos=[j for j,q in enumerate(qs) if q not in excluded]
                if not pos:continue
                qt=torch.tensor([[qmap[qs[j]] for j in pos]],dtype=torch.long,device=device);rt=torch.tensor([[ys[j] for j in pos]],dtype=torch.long,device=device)
                ct=torch.tensor([[pad([kmap[k] for k in qkc[qs[j]]],width) for j in pos]],dtype=torch.long,device=device)
                hist=None
                for j,q in enumerate(qs):
                    if q not in cold or not row['first'][j]:continue
                    n=int(np.searchsorted(pos,j))
                    if n<1:continue
                    if any(qs[t] in excluded or t>=j for t in pos[:n]):raise ValueError('Target/future response entered history')
                    kc=pad([kmap[k] for k in qkc[q]],width)
                    value=official_prefix(torch,model,qt[:,:n],ct[:,:n],rt[:,:n],kc,qmap[q]);logit=float(value.cpu())
                    if not math.isfinite(logit):raise ValueError('Nonfinite native logit')
                    # The evaluator already clips probabilities to this same EPS
                    # before taking logits; use its convention at serialization.
                    raw_probability=float(expit(logit));probability=float(np.clip(raw_probability,EPS,1-EPS));clipped_n+=int(probability!=raw_probability)
                    fold=int(info.loc[q,'content_group_fold'])
                    if diag_counts[fold]<a.diagnostic_per_fold:
                        diag_counts[fold]+=1
                        try:
                            if hist is None:hist=cached.encode_hist(model,qt,ct,rt,torch.ones(qt.shape,dtype=torch.bool,device=device))
                            old=cached.score_one(model,hist[:,:n],torch.ones((1,n),dtype=torch.bool,device=device),n-1,qmap[q],kc)[0]
                            delta=abs(logit-float(old.cpu()));pdiff=abs(probability-float(np.clip(expit(float(old.cpu())),EPS,1-EPS)))
                            if not math.isfinite(delta):raise ValueError('Nonfinite diagnostic difference')
                            diffs.append(dict(content_group_fold=fold,warm_history_len=n,logit_difference=delta,probability_difference=pdiff))
                        except Exception as exc:
                            if len(diag_errors)<20:diag_errors.append(dict(type=type(exc).__name__,message=str(exc)))
                    rows.append(dict(event_id=f"{row['user']}|ord{row['start']+j}|q{q}",student_key=str(row['user']),target_qid=q,target_kc_key=str(info.loc[q,'target_kc_key']),content_group_fold=fold,label=ys[j],teacher_kc_uniform=probability,native_logit=logit,row_index=ridx,target_position=j,warm_history_len=n))
                if (ridx+1)%100==0:print('FA_NATIVE_PROGRESS',ridx+1,'chunks',len(rows),'events',flush=True)
        e=pd.DataFrame(rows)
        if set(e.target_qid)!=cold or e.event_id.duplicated().any() or e.duplicated(['student_key','target_qid']).any():raise ValueError('Native event universe/uniqueness failed')
        coverage_path=diag/'coverage_preflight.json'
        if coverage_path.is_file():
            coverage=json.loads(coverage_path.read_text());expected={int(q):int(n) for q,n in coverage['support_counts'].items()};actual={int(q):int(n) for q,n in e.groupby('target_qid').size().items()}
            if actual!=expected:raise ValueError('Native event coverage differs from prior label-free preflight')
        support={int(q):int(n) for q,n in e.groupby('target_qid').size().items()};dense={q:n for q,n in support.items() if n>=30}
        audit=dict(status='PASS',model='SQAKT',scoring_mode='native_prefix_forward_v5_4',event_n=len(e),item_n=len(cold),eligible_item_n=len(cold),dense_prediction_item_n=len(dense),dense_prediction_event_n=sum(dense.values()),target_current_response_used=False,all_target_weights_excluded=True,excluded_candidate_n=len(excluded),history='same-chunk earlier non-candidate items only',checkpoint_sha256=receipt['checkpoint_sha256'],scorer_sha256=file_hash(__file__),config_sha256=file_hash(run/'config.json'),event_sha256=None,probability_clip_eps=EPS,probability_clipped_n=clipped_n,probability_serialization='sigmoid in float64; same EPS convention as downstream measurement.logit',sparse_items_below_30={str(q):n for q,n in support.items() if n<30},cached_diagnostic_event_n=len(diffs),cached_diagnostic_max_logit_difference=max([d['logit_difference'] for d in diffs],default=None),cached_diagnostic_max_probability_difference=max([d['probability_difference'] for d in diffs],default=None),cached_diagnostic_errors=diag_errors,cached_diagnostic_not_an_acceptance_gate=True,tf32=False,autocast=False,torch_version=str(torch.__version__),elapsed_seconds=time.monotonic()-started)
        (teacher/'clean').mkdir(exist_ok=True);atomic_csv(e,eventpath);atomic_csv(group,teacher/'clean/content_group_safe_item_targets_targetidfree.csv');audit['event_sha256']=file_hash(eventpath)
        write(teacher/'inputs/input_manifest.json',dict(event_source_csv=str(data/'eval_sequences.jsonl'),coordinate_source_sha256=file_hash(data/'eval_sequences.jsonl'),history=audit['history'],source_schema='external native SQAKT revision JSONL',scoring_mode=audit['scoring_mode']))
        write(teacher/'inputs/q_to_kc_set.json',qkc);write(diag/'native_cache_diagnostic.json',dict(rows=diffs,errors=diag_errors,role='diagnostic only; all official predictions use native forward'))
        write(teacher/'scoring_audit.json',audit);write(diag/'native_score_resume.json',audit);print('FA_NATIVE_SCORE_PASS',len(e),'events',len(cold),'RQ2 items',len(dense),'prediction items',flush=True)
    except Exception as exc:
        write(diag/'native_score_resume.json',dict(status='FAILED',exception_type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),retrained=False));raise
if __name__=='__main__':main()
