#!/usr/bin/env python3
"""Train a shared native SQAKT on FA/DBE, excluding ALL selected items.

Reuses the user's frozen raw-data readers and student split. Their older
StrictColdGRUKT class is NOT used: the model is the same pykt SQAKT as XES.
Stages write a new revision directory and preserve old external confirmations.
"""
import argparse,csv,copy,importlib.util,json,os,sys
from pathlib import Path
from collections import Counter
import numpy as np,pandas as pd
from measurement import save_json,file_hash,atomic_csv
from native_template_v5_2 import resolve_template

def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

def prepare(a):
    root=Path(a.out).resolve();project=Path(a.project).resolve()
    if root.exists():raise ValueError('Use a new external revision directory')
    if a.dataset=='fa':
        base=project/'data/FoundationalASSIST/external_confirmation_v1'
        reader=module(Path(__file__).parent/'legacy_readers/fa10_foldclean_kt_v1.py','fa_reader')
        I,qkc,_=reader.prepare_tables(Path(a.raw or project/'data/FoundationalASSIST/raw/Data'),base/'01_contract/foundationalassist_user_split.csv',base/'01_contract/foundationalassist_contract_manifest.json')
        tab=I.rename(columns={'_qid':'qraw','_user':'user','_y':'y','_split':'split'})
        group=pd.read_csv(base/'01_contract/foundationalassist_strict_group_contract.csv',dtype={'target_kc_key':str})
        panel=base/'04_synthetic/scored/synthetic_response_matrix_v2.csv'
    else:
        base=project/'data/DBE-KT22/external_replication_final_v1'
        reader=module(Path(__file__).parent/'legacy_readers/s13b_dbe_foldclean_kt_v1.py','dbe_reader')
        tab,qkc=reader.prepare_tables(Path(a.raw or project/'data/DBE-KT22/2_DBE_KT22_datafiles_100102_csv'),1)
        tab=tab.rename(columns={'qid':'qraw','student_key':'user'})
        tab['split']=tab.user.map(lambda u:reader.usplit(str(u),20260828,70,15))
        group=pd.read_csv(base/'01_contract/dbe_strict_group_contract.csv',dtype={'target_kc_key':str})
        # Reuse the repaired scoring interface, never v1's superseded readouts.
        candidates=[project/'data/DBE-KT22/external_replication_measurement_repair_v2/02_scored/synthetic_response_matrix_v2.csv']
        panel=Path(a.panel) if a.panel else next((p for p in candidates if p.is_file()),None)
        if panel is None:raise FileNotFoundError('Set --panel to the repaired DBE synthetic_response_matrix_v2.csv; v1 must not be substituted')
    if a.panel:panel=Path(a.panel)
    qkc={int(float(q)):sorted(set(int(float(k)) for k in ks)) for q,ks in qkc.items()}
    tab=tab.copy();tab.qraw=tab.qraw.map(lambda x:int(float(x)));tab.user=tab.user.astype(str)
    tab=tab[tab.qraw.isin(qkc)];group.target_qid=group.target_qid.astype(int)
    cold=set(group.target_qid);qids=sorted(set(tab.qraw)&set(qkc));qmap={q:i for i,q in enumerate(qids)}
    kcs=sorted({k for q in qids for k in qkc[q]});kmap={k:i for i,k in enumerate(kcs)}
    if not cold<=set(qmap):raise ValueError('Some contract targets are absent from raw interactions')
    warm_train=tab[(tab.split=='train')&~tab.qraw.isin(cold)]
    observed_kcs={k for q in warm_train.qraw.unique() for k in qkc[q]}
    unknown={q:sorted(set(qkc[q])-observed_kcs) for q in cold if not set(qkc[q])<=observed_kcs}
    root.parent.mkdir(parents=True,exist_ok=True)
    save_json(root.parent/'qualification_audit.json',dict(dataset=a.dataset,contract_item_n=len(cold),known_kc_after_all_selected_excluded=not bool(unknown),unknown_kcs_by_item=unknown,selection_uses_response_labels=False))
    candidate_group=group.copy()
    if unknown:
        if not a.known_kc_only:raise ValueError('Known-KC condition fails; inspect qualification_audit.json or explicitly select --known-kc-only')
        group=group[~group.target_qid.isin(unknown)].copy()
    if group.empty:raise ValueError('No known-KC candidate remains')
    root.mkdir(parents=True);data=root/'data';data.mkdir();(root/'inputs').mkdir();(root/'clean').mkdir()
    counts=Counter();support=Counter();evaluations=[];rows=[];width=200;maxc=max(map(len,qkc.values()))
    user_map={u:i for i,u in enumerate(sorted(tab.user.unique()))}
    for user,z in tab.groupby('user',sort=False):
        sp=str(z.split.iloc[0]);seq=list(zip(z.qraw.astype(int),z.y.astype(int)))
        if sp in ['train','valid']:
            warm=[(q,y) for q,y in seq if q not in cold]
            for start in range(0,len(warm),width):
                chunk=warm[start:start+width]
                if len(chunk)<2:continue
                qs=[qmap[q] for q,y in chunk];cs=['_'.join(str(kmap[k]) for k in qkc[q]) for q,y in chunk];ys=[y for q,y in chunk];pad=width-len(chunk)
                rows.append(dict(fold=0 if sp=='train' else 3,uid=user_map[str(user)],questions=','.join(map(str,qs+[-1]*pad)),concepts=','.join(cs+['-1']*pad),responses=','.join(map(str,ys+[-1]*pad)),selectmasks=','.join(map(str,[1]*len(chunk)+[-1]*pad))))
                counts[sp]+=len(chunk)
                if sp=='train':support.update(qmap[q] for q,y in chunk)
        elif sp=='eval':
            seen=set();first=[]
            for q,y in seq:first.append(q not in seen);seen.add(q)
            for start in range(0,len(seq),width):
                chunk=seq[start:start+width]
                evaluations.append(dict(user=user,start=start,qraw=[q for q,y in chunk],response=[y for q,y in chunk],first=first[start:start+width]))
        else:raise ValueError('Unexpected student split: '+sp)
    inverse={i:q for q,i in qmap.items()}
    actual_train_kcs={k for i in support for k in qkc[inverse[i]]}
    missing_actual={q:sorted(set(qkc[q])-actual_train_kcs) for q in set(group.target_qid) if not set(qkc[q])<=actual_train_kcs}
    if missing_actual:
        if not a.known_kc_only:raise ValueError('Known KC absent from retained training chunks: '+str(missing_actual))
        group=group[~group.target_qid.isin(missing_actual)].copy()
    if group.empty:raise ValueError('No known-KC candidate remains after training-chunk retention')
    rejected={int(q):sorted(set(qkc[int(q)])-actual_train_kcs) for q in cold-set(group.target_qid)}
    save_json(root/'inputs/excluded_candidate_qids.json',sorted(map(int,cold)))
    atomic_csv(candidate_group,root/'inputs/original_candidate_group.csv')
    save_json(root/'inputs/known_kc_selection.json',dict(policy='known-kc-only' if a.known_kc_only else 'require-all',original_candidate_n=len(cold),eligible_item_n=len(group),rejected_item_n=len(rejected),rejected_missing_kcs=rejected,training_exclusion_n=len(cold),selection_uses_response_labels=False,selected_all_have_known_kcs=True,content_fold_counts=group.content_group_fold.value_counts().sort_index().to_dict()))
    pd.DataFrame(rows).to_csv(data/'train_valid_sequences_quelevel.csv',index=False)
    with (data/'eval_sequences.jsonl').open('w',encoding='utf8') as f:
        for row in evaluations:f.write(json.dumps(row,ensure_ascii=False)+'\n')
    save_json(data/'q_support_train_foldclean.json',{str(q):int(n) for q,n in support.items()})
    save_json(data/'geometry.json',dict(qmap=qmap,kmap=kmap,qkc=qkc,max_concepts=maxc,num_q=len(qmap),num_c=len(kmap),width=width))
    atomic_csv(group,root/'inputs/group.csv');atomic_csv(pd.read_csv(panel),root/'inputs/synthetic_response_panel.csv')
    save_json(data/'preparation_audit.json',dict(dataset=a.dataset,all_contract_items_excluded=True,excluded_item_n=len(cold),cold_training_events=0,cold_validation_events=0,
        source_reader_sha256=file_hash(reader.__file__),contract_sha256=file_hash(root/'inputs/group.csv'),training_csv_sha256=file_hash(data/'train_valid_sequences_quelevel.csv'),
        panel_source=str(panel),panel_sha256=file_hash(panel),counts=counts,eval_window='raw interaction chunks of 200; first exposure defined over entire student sequence'))
    print('EXTERNAL_PREPARE_PASS',root,flush=True)

def train(a):
    import torch
    project=Path(a.project).resolve();root=Path(a.out).resolve();data=root/'data';geom=json.loads((data/'geometry.json').read_text())
    template,receipt,cfg,template_audit=resolve_template(a.xes_teacher)
    save_json(root/'data/native_template_v5_2.json',template_audit)
    audit=json.loads((data/'preparation_audit.json').read_text())
    if file_hash(data/'train_valid_sequences_quelevel.csv')!=audit['training_csv_sha256']:raise ValueError('Prepared training source changed')
    save=root/'models/shared_teacher';save.mkdir(parents=True,exist_ok=True)
    if list(save.glob('*/qid_model.ckpt')):raise ValueError('A checkpoint already exists; do not silently retrain')
    sys.path[:0]=[str(project/'examples'),str(project)];os.chdir(project/'examples');import wandb_train as wt
    dc=copy.deepcopy(cfg['data_config']);dc.update(dpath=str(data),num_q=geom['num_q'],num_c=geom['num_c'],max_concepts=geom['max_concepts'],folds=[0,3],input_type=['questions','concepts'],maxlen=200,
        train_valid_file='train_valid_sequences_quelevel.csv',train_valid_file_quelevel='train_valid_sequences_quelevel.csv')
    dataset='revision_'+a.dataset;dc['dataset_name']=dataset;original_json=wt.json
    class JSONProxy:
        def __getattr__(self,name):return getattr(original_json,name)
        def load(self,f,*args,**kwargs):
            obj=original_json.load(f,*args,**kwargs)
            if str(getattr(f,'name','')).endswith('data_config.json'):obj[dataset]=copy.deepcopy(dc)
            return obj
    wt.json=JSONProxy();orig_init=wt.init_model;orig_data=wt.init_dataset4train
    def init(m,mc,d,emb):
        mc=copy.deepcopy(mc)
        for k in ['dataset_dir_override','semantic_dataset_root_override','teacher_dir_override','num_epochs','batch_size','learning_rate','use_wandb','add_uuid']:mc.pop(k,None)
        return orig_init(m,mc,d,emb)
    def datasets(*args,**kwargs):
        result=orig_data(*args,**kwargs);cold=set(json.loads((root/'inputs/excluded_candidate_qids.json').read_text()));mapping={int(q):int(i) for q,i in geom['qmap'].items()};ids={mapping[q] for q in cold};checks=[]
        for loader in result[:2]:
            actual=set(loader.dataset.dori['qseqs'].detach().cpu().unique().tolist());checks.append(len(actual&ids))
        if any(checks):raise ValueError('Cold target appears in actually loaded training/validation tensors')
        save_json(data/'actual_loader_audit.json',dict(cold_training_events=checks[0],cold_validation_events=checks[1],status='PASS'))
        return result
    wt.init_model=init;wt.init_dataset4train=datasets
    params=copy.deepcopy(cfg['model_config']);params.update(dataset_name=dataset,model_name='sqakt',fold=3,seed=42,emb_type='qid',save_dir=str(save),dataset_dir_override=str(data),
        semantic_dataset_root_override=str(data),teacher_dir_override='',q_support_path=str(data/'q_support_train_foldclean.json'),use_wandb=0,add_uuid=0,num_epochs=a.epochs,
        kc_set_input=1,kc_set_max_concepts=max(2,geom['max_concepts']))
    # KTQueDataset requires max_concepts>1 for this native route even if this
    # domain happens to have singleton sets only; the extra slot is padding.
    dc['max_concepts']=max(2,geom['max_concepts']);wt.main(params)
    checkpoints=list(save.glob('*/qid_model.ckpt'))
    if len(checkpoints)!=1:raise ValueError('Expected one native SQAKT checkpoint')
    save_json(save/'training_receipt.json',dict(status='PASS',run=str(checkpoints[0].parent),checkpoint_sha256=file_hash(checkpoints[0]),
        training_cold_interactions=0,validation_cold_interactions=0,excluded_item_n=audit['excluded_item_n'],csv_sha256=audit['training_csv_sha256'],
        model='native project SQAKT',architecture_template=str(receipt['run']),student_selection='original frozen train/valid/eval users',early_stop='native warm-only PyKT validation'))
    print('EXTERNAL_TRAIN_PASS',checkpoints[0].parent,flush=True)

def score(a):
    import torch
    project=Path(a.project).resolve();root=Path(a.out).resolve();data=root/'data';geom=json.loads((data/'geometry.json').read_text())
    qmap={int(q):int(i) for q,i in geom['qmap'].items()};kmap={int(k):int(i) for k,i in geom['kmap'].items()};qkc={int(q):list(map(int,ks)) for q,ks in geom['qkc'].items()}
    receipt=json.loads((root/'models/shared_teacher/training_receipt.json').read_text());run=Path(receipt['run'])
    if file_hash(run/'qid_model.ckpt')!=receipt['checkpoint_sha256']:raise ValueError('Checkpoint changed')
    sys.path[:0]=[str(project/'examples'),str(project)]
    from pykt.models import load_model
    template,_,_,_=resolve_template(a.xes_teacher)
    scorer=module(template/'shared_scorer.py','external_native_scorer')
    cfg=json.loads((run/'config.json').read_text());mc=copy.deepcopy(cfg['model_config'])
    for k in ['dataset_dir_override','semantic_dataset_root_override','teacher_dir_override','num_epochs','batch_size','learning_rate','use_wandb','add_uuid','l2']:mc.pop(k,None)
    model=load_model('sqakt',mc,cfg['data_config'],'qid',str(run));model.eval()
    if not model.kc_set_input or model.q_item_parameterization!='id_only_cold_mask':raise ValueError('External checkpoint is not the intended native SQAKT')
    maxc=int(cfg['model_config']['kc_set_max_concepts']);device=next(model.parameters()).device
    group=pd.read_csv(root/'inputs/group.csv',dtype={'target_kc_key':str});cold=set(group.target_qid.astype(int));info=group.set_index('target_qid')
    excluded=set(json.loads((root/'inputs/excluded_candidate_qids.json').read_text()))
    rows=[];parity=[];seen_folds=set()
    with (data/'eval_sequences.jsonl').open(encoding='utf8') as f,torch.inference_mode():
        for ridx,line in enumerate(f):
            row=json.loads(line);qs=row['qraw'];ys=row['response'];pos=[j for j,q in enumerate(qs) if q not in excluded]
            if not pos:continue
            qt=torch.tensor([[qmap[qs[j]] for j in pos]],dtype=torch.long,device=device);rt=torch.tensor([[ys[j] for j in pos]],dtype=torch.long,device=device)
            ct=torch.tensor([[scorer.pad_kcs([kmap[k] for k in qkc[qs[j]]],maxc) for j in pos]],dtype=torch.long,device=device);valid=torch.ones(qt.shape,dtype=torch.bool,device=device)
            hist=scorer.encode_hist(model,qt,ct,rt,valid)
            for j,q in enumerate(qs):
                if q not in cold or not row['first'][j]:continue
                n=int(np.searchsorted(pos,j))
                if n<1:continue
                kc=scorer.pad_kcs([kmap[k] for k in qkc[q]],maxc);value=scorer.score_one(model,hist[:,:n],valid[:,:n],n-1,qmap[q],kc)[0]
                if len(parity)<10:
                    cq=torch.cat([ct[:,:n],torch.tensor([[kc]],dtype=torch.long,device=device)],1);qq=torch.cat([qt[:,:n],torch.tensor([[qmap[q]]],dtype=torch.long,device=device)],1)
                    native=model(ct[:,:n],rt[:,:n],cshft=cq[:,1:],q=qt[:,:n],qshft=qq[:,1:],valid_mask=valid[:,:n])[0,-1]
                    parity.append(float(abs(native-value).cpu()))
                fold=int(info.loc[q,'content_group_fold']);seen_folds.add(fold)
                rows.append(dict(event_id=f"{row['user']}|ord{row['start']+j}|q{q}",student_key=row['user'],target_qid=q,target_kc_key=str(info.loc[q,'target_kc_key']),
                    content_group_fold=fold,label=int(ys[j]),teacher_kc_uniform=float(torch.sigmoid(value).cpu()),row_index=ridx,target_position=j,warm_history_len=n))
    if not parity or max(parity)>1e-6:raise ValueError('Native versus cached-prefix SQAKT scoring parity failed: '+str(parity))
    e=pd.DataFrame(rows)
    if set(e.target_qid)!=cold:raise ValueError('Some selected items have no legal first-exposure events; inspect target/history support')
    atomic_csv(e,root/'clean/teacher_aligned_event_baseline_targetidfree.csv.gz');atomic_csv(group,root/'clean/content_group_safe_item_targets_targetidfree.csv')
    save_json(root/'inputs/input_manifest.json',dict(event_source_csv=str(data/'eval_sequences.jsonl'),coordinate_source_sha256=file_hash(data/'eval_sequences.jsonl'),
        history='earlier warm items in the same raw-interaction chunk',source_schema='external_sqakt revision JSONL; not the XES coordinate CSV'))
    save_json(root/'inputs/q_to_kc_set.json',qkc)
    save_json(root/'scoring_audit.json',dict(status='PASS',model='SQAKT',event_n=len(e),item_n=len(cold),max_native_forward_logit_difference=max(parity),
        history='same-chunk earlier non-candidate items; original candidate exclusion retained',target_current_response_used=False,all_target_weights_excluded=True,excluded_candidate_n=len(excluded),eligible_item_n=len(cold),
        sparse_items_below_30=e.groupby('target_qid').size().loc[lambda x:x<30].to_dict(),new_protocol=True,old_external_confirmatory_verdict_unchanged=True))
    print('EXTERNAL_SCORE_PASS',root,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['prepare','train','score']);p.add_argument('--project',required=True);p.add_argument('--xes-teacher',required=True)
    p.add_argument('--dataset',choices=['fa','dbe'],required=True);p.add_argument('--out',required=True);p.add_argument('--raw');p.add_argument('--panel');p.add_argument('--epochs',type=int,default=200)
    p.add_argument('--known-kc-only',action='store_true',help='Evaluate only known-KC targets; exclude every original candidate from training and history')
    a=p.parse_args();globals()[a.stage](a)
