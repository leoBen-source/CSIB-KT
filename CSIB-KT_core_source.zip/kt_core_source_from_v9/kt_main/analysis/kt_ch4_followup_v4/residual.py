#!/usr/bin/env python3
"""Restore the documented KC reference plus six-summary residual estimator.

This reconstructs archived CalKC_Final/KC6_Final means on the uploaded XES
inputs. It is not the one-hot KC intercept model in the previous experiment.py.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from measurement import Features,SIX,logit,atomic_csv,save_json,file_hash

MAIN='KC6_Final'

def kc_reference(train,test,strength=5.):
    stats=train.groupby('target_kc_key').criterion.agg(['mean','size'])
    overall=float(train.criterion.mean())
    mean=(stats['size']*stats['mean']+strength*overall)/(stats['size']+strength)
    return test.target_kc_key.map(mean).fillna(overall).to_numpy(float)

def reference_pair(g,scope,tr,te):
    """Mapper-training references exclude the item's entire content fold."""
    allowed=g[g.content_group_fold.isin(scope)]
    refs={}
    for fold in sorted(scope):
        val=allowed[allowed.content_group_fold==fold]
        ref=kc_reference(allowed[allowed.content_group_fold!=fold],val)
        refs.update(zip(val.target_qid,ref))
    tr=tr.copy();te=te.copy()
    tr['kc_ref']=tr.target_qid.map(refs);te['kc_ref']=kc_reference(allowed,te)
    if tr.kc_ref.isna().any():raise ValueError('Incomplete cross-fitted KC reference')
    return tr,te

def fit_offset(tr,events,columns,offset=True,l2=100.):
    cols=list(columns);X=tr[cols].to_numpy(float)
    if not np.isfinite(X).all():raise ValueError('Non-finite mapper input')
    mean=X.mean(0);sd=X.std(0);sd=np.where(sd<1e-8,1.,sd)
    D=np.column_stack([np.ones(len(tr)),(X-mean)/sd]);n=len(tr)
    scope=set(tr.target_qid);e=events[events.target_qid.isin(scope)]
    if set(e.target_qid)!=scope:raise ValueError('Mapper events missing')
    index=e.target_qid.map(dict(zip(tr.target_qid,range(n)))).to_numpy(int)
    eta0=logit(e.teacher_kc_uniform);y=e.label.to_numpy(float)
    counts=e.groupby('target_qid').size();w=1/(n*e.target_qid.map(counts).to_numpy(float))
    off=tr.kc_ref.to_numpy(float) if offset else np.zeros(n)
    def fg(b):
        eta=eta0+(off+D@b)[index]
        residual=w*(expit(eta)-y)
        loss=np.sum(w*(np.logaddexp(0,eta)-y*eta))+l2*np.sum(b[1:]**2)/(2*n)
        grad=D.T@np.bincount(index,weights=residual,minlength=n)+np.r_[0.,l2*b[1:]/n]
        return float(loss),grad
    # Preserve the archived optimizer convention; this reproduces its means.
    z=minimize(fg,np.zeros(D.shape[1]),jac=True,method='L-BFGS-B')
    if not z.success:raise RuntimeError('Residual fit failed: '+str(z.message))
    return dict(columns=cols,mean=mean,scale=sd,coef=z.x,offset_kc=offset,l2=l2,
                objective=float(z.fun),training_qids=tr.target_qid.tolist())

def predict(model,items):
    X=items[model['columns']].to_numpy(float)
    z=model['coef'][0]+((X-model['mean'])/model['scale'])@model['coef'][1:]
    return z+(items.kc_ref.to_numpy(float) if model['offset_kc'] else 0.)

def specifications(suite):
    spec={'CalKC_Final':(True,['kc_ref']),MAIN:(True,['kc_ref']+SIX)}
    if suite in ['modules','full']:
        spec['No_KC_Reference']=(False,SIX)
    if suite=='full':
        spec.update(Global_MAP=(False,[]),No_KC_Reference=(False,SIX),
            KC_Rate1_MAP=(True,['kc_ref','raw_logit_local']),
            KC_Rasch1_MAP=(True,['kc_ref','rasch_local']),
            KC_Rasch2_MAP=(True,['kc_ref','rasch_local','log_a']),
            KC_Location2_MAP=(True,['kc_ref','rasch_local','twopl_local']),
            No_SE_Summaries=(True,['kc_ref']+[c for c in SIX if c not in ['log_se','precision']]))
        for c in SIX:spec['Without_'+c]=(True,['kc_ref']+[v for v in SIX if v!=c])
    return spec

def fit_priors(g,e,r,out,suite='main',variance=1.,aux=None):
    """All supervised feature fitting is rebuilt outside each content fold."""
    out=Path(out);F=Features(g,e,r,signature=None);models={};rows=[];features=[]
    for outer in sorted(g.content_group_fold.unique()):
        scope=set(g.content_group_fold.unique())-{outer}
        tr,te=F.pair(scope,g.loc[g.content_group_fold==outer,'target_qid'].tolist())
        tr,te=reference_pair(g,scope,tr,te)
        spec=specifications(suite)
        if aux is not None:
            acols=[c for c in aux if c.startswith('feature_')]
            if not acols:raise ValueError('Auxiliary feature columns must start with feature_')
            tr=tr.merge(aux,on='target_qid',validate='one_to_one');te=te.merge(aux,on='target_qid',validate='one_to_one')
            if tr[acols].isna().any().any() or te[acols].isna().any().any():raise ValueError('Auxiliary features missing')
            spec['KC_Content_MAP']=(True,['kc_ref']+acols)
            spec['KC_Content6_MAP']=(True,['kc_ref']+acols+SIX)
        models[str(outer)]={}
        for name,(offset,cols) in spec.items():
            model=fit_offset(tr,e,cols,offset);mu=predict(model,te);models[str(outer)][name]=model
            for q,key,m in zip(te.target_qid,te.target_kc_key,mu):
                rows.append(dict(target_qid=int(q),target_kc_key=str(key),content_group_fold=int(outer),
                                 method=name,prior_mean=float(m),prior_var=variance))
        features.append(te);print('Restored residual mapper outer fold',outer,flush=True)
    prior=pd.DataFrame(rows)
    if suite in ['modules','full']:
        only=prior[prior.method==MAIN].copy();only['method']='KC6_PriorOnly'
        prior=pd.concat([prior,only],ignore_index=True)
    if suite=='full':
        zero=prior[prior.method==MAIN].copy();zero['method']='Zero_MAP';zero['prior_mean']=0.
        prior=pd.concat([prior,zero],ignore_index=True)
    atomic_csv(prior,out/'prior_table.csv');atomic_csv(pd.concat(features),out/'features_oof.csv.gz')
    atomic_csv(g,out/'current_item_criterion.csv');save_json(out/'fitted_models.json',models)
    save_json(out/'measurement_scopes.json',F.scope_log)
    return prior

def load(teacher,responses,scores=None):
    """XES canonical files; CPU refitting needs no checkpoint or training CSV."""
    teacher=Path(teacher)
    receipt=json.loads((teacher/'models/shared_teacher/training_receipt.json').read_text())
    if receipt.get('status')!='PASS' or receipt['training_cold_interactions'] or receipt['validation_cold_interactions']:
        raise ValueError('SQAKT exclusion audit did not pass')
    gp=teacher/'clean/content_group_safe_item_targets_targetidfree.csv'
    ep=Path(scores) if scores else teacher/'clean/teacher_aligned_event_baseline_targetidfree.csv.gz'
    g=pd.read_csv(gp,dtype={'target_kc_key':str})[['target_qid','target_kc_key','content_group_fold','canonical_content_id']]
    e=pd.read_csv(ep,dtype={'event_id':str,'student_key':str,'target_kc_key':str})
    if g.target_qid.duplicated().any() or e.event_id.duplicated().any() or e.duplicated(['student_key','target_qid']).any():raise ValueError('Duplicate item/event/first exposure')
    if set(e.target_qid)!=set(g.target_qid) or not e.label.isin([0,1]).all():raise ValueError('Invalid event support')
    if not e.teacher_kc_uniform.between(0,1,inclusive='neither').all():raise ValueError('Invalid KT probability')
    if (g.groupby('canonical_content_id').content_group_fold.nunique()>1).any():raise ValueError('Content group crosses folds')
    if (e.groupby('target_qid').size()<1).any():raise ValueError('Empty item event support')
    if scores:
        sm=json.loads(Path(str(ep)+'.manifest.json').read_text())
        if sm.get('history_mode')!='warm' or file_hash(ep)!=sm['scores_sha256']:raise ValueError('Only audited warm-only scores can fit the prior')
    r=pd.read_csv(responses,dtype={'synthetic_student_id':str,'policy_id':str})
    if 'scoring_valid' in r:r=r[r.scoring_valid.astype(int)==1]
    r=r[r.qid.isin(g.target_qid)].copy()
    if r.duplicated(['qid','synthetic_student_id']).any() or not r.correct.isin([0,1]).all():raise ValueError('Invalid synthetic panel')
    panel=r.pivot(index='qid',columns='synthetic_student_id',values='correct').reindex(g.target_qid)
    if panel.shape!=(len(g),20) or panel.isna().any().any():raise ValueError('Incomplete 20-channel synthetic panel')
    stats=e.groupby('target_qid').agg(y=('label','sum'),n=('label','size'),p=('teacher_kc_uniform','mean'))
    stats['criterion']=logit((stats.y+8*stats.p)/(stats.n+8))-logit(stats.p)
    g=g.merge(stats[['criterion']],left_on='target_qid',right_index=True,validate='one_to_one')
    return g,e,r,dict(group=str(gp),events=str(ep),responses=str(responses))
