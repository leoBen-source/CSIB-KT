#!/usr/bin/env python3
"""Assemble chapter evidence from completed runs; retain absolute effect sizes."""
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

MAIN='KC6_Final'
NAMES={'KC6_Final':'Full method','CalKC_Final':'Without synthetic summaries','No_KC_Reference':'Without KC reference',
    'KC6_PriorOnly':'Without MAP','RawKT':'RawKT','MathBERT_linear':'MathBERT linear','MathBERT_RFF':'MathBERT RFF',
    'MathBERT_answer_RFF':'Answer-aware MathBERT RFF','LLM_direct':'LLM direct','Joint':'Joint'}

def complete(path):
    p=Path(path)/'completion.json'
    return p.is_file() and json.loads(p.read_text()).get('status')=='PASS'

def wide(curve,methods):
    rows=[]
    for m in methods:
        row={'method':m,'label':NAMES[m]}
        for k in [0,5]:
            z=curve[(curve.method==m)&(curve.budget==k)]
            if len(z)!=1:raise ValueError('Missing/duplicate result '+str((m,k)))
            row['nll_k'+str(k)]=float(z.iloc[0].item_macro_nll);row['auc_k'+str(k)]=float(z.iloc[0].pooled_auc)
        rows.append(row)
    return pd.DataFrame(rows)

def build(root,out):
    root=Path(root);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    rows=[];status=[]
    domains=[('XES3G5M',root/'primary/sqakt'),('FoundationalASSIST',root/'external_known_kc/fa/fit'),('DBE-KT22',root/'external_known_kc/dbe/fit')]
    for dataset,run in domains:
        ok=complete(run);status.append(dict(dataset=dataset,status='complete' if ok else 'pending',run=str(run)))
        if ok:rows.append({'dataset':dataset,**pd.read_csv(run/'rq2_summary.csv').iloc[0].to_dict()})
    pd.DataFrame(rows).to_csv(out/'table3_verified.csv',index=False)
    pd.DataFrame(status).to_csv(out/'dataset_status.csv',index=False)
    table4=[]
    for model in ['sqakt','akt','simplekt','dkt']:
        if not complete(root/'primary'/model):raise ValueError('Primary model incomplete: '+model)
        d=pd.read_csv(root/'primary'/model/'learning_curve.csv')
        z=wide(d,['RawKT',MAIN]);z.insert(0,'backbone',model);table4.append(z)
    pd.concat(table4,ignore_index=True).to_csv(out/'table4_verified.csv',index=False)
    mods=pd.read_csv(root/'attribution/sqakt/learning_curve.csv')
    pairs=pd.read_csv(root/'attribution/sqakt/paired_nll_comparisons.csv')
    module=wide(mods,[MAIN,'CalKC_Final','No_KC_Reference','KC6_PriorOnly'])
    five=pairs[pairs.budget==5].rename(columns={'baseline':'method'})
    module.merge(five[['method','delta_nll','item_ci_low','item_ci_high','kc_set_ci_low','kc_set_ci_high']],on='method',how='left',validate='one_to_one').to_csv(out/'table6_verified.csv',index=False)
    comp=root/'comparisons/sqakt'
    c=pd.read_csv(comp/'learning_curve.csv');p=pd.read_csv(comp/'paired_nll_comparisons.csv')
    order=[MAIN,'MathBERT_linear','MathBERT_RFF','MathBERT_answer_RFF','LLM_direct','Joint']
    t=wide(c,order);t.to_csv(out/'table7_absolute.csv',index=False)
    effects=[]
    for _,r in p[p.budget.isin([0,5])].iterrows():
        if r.baseline not in order:continue
        k=int(r.budget);a=t[t.method==r.baseline].iloc[0];f=t[t.method==MAIN].iloc[0]
        if not np.isclose(r.delta_nll,a['nll_k'+str(k)]-f['nll_k'+str(k)],rtol=0,atol=1e-10):raise ValueError('Paired/absolute metric mismatch')
        effects.append({**r.to_dict(),'relative_nll_reduction_pct':100*r.delta_nll/a['nll_k'+str(k)],'auc_increase':f['auc_k'+str(k)]-a['auc_k'+str(k)]})
    effects=pd.DataFrame(effects);effects.to_csv(out/'table7_paired_effects.csv',index=False)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'axes.edgecolor':'#9CA9B3'})
    fig,axes=plt.subplots(1,2,figsize=(7.6,3.0),sharey=True,layout='constrained')
    competitors=order[1:];maxhi=float(effects.kc_set_ci_high.max())*1000
    for ax,k in zip(axes,[0,5]):
        d=effects[effects.budget==k].set_index('baseline').loc[competitors]
        x=d.delta_nll.to_numpy()*1000;lo=d.kc_set_ci_low.to_numpy()*1000;hi=d.kc_set_ci_high.to_numpy()*1000;y=np.arange(len(d))
        ax.errorbar(x,y,xerr=np.array([x-lo,hi-x]),fmt='o',color='#237C83',ecolor='#71869B',ms=4,capsize=3,lw=1.15)
        ax.axvline(0,color='#9CA9B3',ls='--',lw=.8);ax.set_xlim(-.2,maxhi*1.08)
        ax.set_title('k = '+str(k),fontsize=10);ax.set_xlabel('NLL reduction of full method (×10⁻³)',fontsize=8)
        ax.set_yticks(y);ax.set_yticklabels([NAMES[m] for m in competitors],fontsize=8)
        ax.grid(axis='x',color='#E5EAED',lw=.6);ax.set_axisbelow(True)
    axes[0].invert_yaxis()
    fig.savefig(out/'figure7_comparison_effects.png',dpi=320,bbox_inches='tight');fig.savefig(out/'figure7_comparison_effects.pdf',bbox_inches='tight');plt.close(fig)
    pri=pd.read_csv(comp/'prior_table.csv').pivot(index='target_qid',columns='method',values='prior_mean')
    diag=[]
    for m in pri.columns:
        d=pri[m]-pri.CalKC_Final
        diag.append(dict(method=m,prior_sd=float(pri[m].std(ddof=0)),correlation_with_kc_prior=float(pri[m].corr(pri.CalKC_Final)),rms_difference_from_kc_prior=float(np.sqrt(np.mean(d*d)))))
    pd.DataFrame(diag).to_csv(out/'prior_similarity_diagnostic.csv',index=False)
    (out/'comparison_effects_manifest.json').write_text(json.dumps(dict(source='existing completed comparisons',effect_direction='comparator NLL minus full method NLL',
        interval='existing pointwise paired 95% KC-set bootstrap',unit_in_plot='1e-3 NLL; absolute NLL retained in table7_absolute.csv',
        comparison_scope='common prediction/calibration interface, not published end-to-end model reproduction',
        main_results_changed=False),indent=2))
    print('CH4_EVIDENCE_PASS',out,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();build(a.root,a.out)
