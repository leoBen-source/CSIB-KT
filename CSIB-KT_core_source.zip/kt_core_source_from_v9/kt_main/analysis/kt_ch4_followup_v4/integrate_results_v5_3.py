#!/usr/bin/env python3
"""Audit conversation-supplied result summaries; never fabricate missing runs."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

MAIN='KC6_Final'
LABELS={'RawKT':'RawKT','CalKC_Final':'KC reference','KC6_Final':'Full method','MathBERT_linear':'MathBERT linear','MathBERT_RFF':'MathBERT RFF','MathBERT_answer_RFF':'Answer-aware MathBERT RFF','LLM_direct':'LLM direct','Joint':'Joint'}
def read(p):return json.loads(Path(p).read_text())
def need(ok,message):
    if not ok:raise ValueError(message)
def audit_run(run):
    need(read(run/'completion.json')['status']=='PASS','Incomplete '+str(run))
    table=pd.read_csv(run/'main_table_k0_k5.csv');curve=pd.read_csv(run/'learning_curve.csv');items=pd.read_csv(run/'seed_averaged_item_metrics.csv.gz',dtype={'target_kc_key':str})
    avg=items.groupby(['budget','method']).item_nll.mean()
    for row in curve.itertuples():need(abs(avg.loc[row.budget,row.method]-row.item_macro_nll)<1e-10,'Curve does not match item metrics '+str(run))
    for row in table.itertuples():
        need(abs(avg.loc[row.budget,row.method]-row.item_macro_nll)<1e-10,'Main table mismatch '+str(run))
        stored=curve[(curve.budget==row.budget)&(curve.method==row.method)]
        need(len(stored)==1 and abs(stored.iloc[0].pooled_auc-row.pooled_auc)<1e-10,'Stored AUC table/curve mismatch '+str(run))
    pair=pd.read_csv(run/'paired_nll_comparisons.csv')
    for row in pair.itertuples():need(abs(avg.loc[row.budget,row.baseline]-avg.loc[row.budget,row.better]-row.delta_nll)<1e-10,'Paired difference mismatch '+str(run))
    if (run/'rq2_summary.csv').is_file():
        pred=pd.read_csv(run/'rq2_item_predictions.csv',float_precision='round_trip');s=pd.read_csv(run/'rq2_summary.csv').iloc[0]
        rho=float(spearmanr(pred.criterion,pred.prior_mean)[0])
        mse=np.mean((pred.criterion-pred.prior_mean)**2);ref=np.mean((pred.criterion-pred.reference_mean)**2)
        need(abs(rho-s.spearman)<1e-10 and abs(ref-mse-s.delta_mse)<1e-10,'RQ2 mismatch '+str(run))
    # Each stored outer mapper must exclude its own target fold.
    if (run/'prior_table.csv').is_file() and (run/'fitted_models.json').is_file():
        prior=pd.read_csv(run/'prior_table.csv');models=read(run/'fitted_models.json')
        for fold,methods in models.items():
            held=set(prior.loc[prior.content_group_fold==int(str(fold).split('_')[0]),'target_qid'])
            candidates=[methods] if 'training_qids' in methods else methods.values()
            for model in candidates:
                if isinstance(model,dict) and 'training_qids' in model:need(not held&set(model['training_qids']),'Mapper fold overlap '+str(run))
    return dict(status='PASS',item_n=int(items.target_qid.nunique()),kc_set_n=int(items.target_kc_key.nunique()),budgets=sorted(map(int,curve.budget.unique())),methods=sorted(curve.method.unique()))

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    runs=[root/'primary'/x for x in ['sqakt','akt','simplekt','dkt']]+[root/'attribution/sqakt',root/'comparisons/sqakt']
    runs += [root/'regularization_sensitivity_v5_2'/x for x in ['l2_10','l2_1000']]
    runs += [root/f'training_seeds/seed_{s}/{kind}' for s in [43,44] for kind in ['fit','comparisons']]
    audit={str(r.relative_to(root)):audit_run(r) for r in runs}
    status=[];domains=[('XES3G5M',root/'primary/sqakt')]
    for name,key in [('FoundationalASSIST','fa'),('DBE-KT22','dbe')]:
        base=root/'external_known_kc'/key;run=base/'fit';receipt=base/'teacher/models/shared_teacher/training_receipt.json'
        complete=(run/'completion.json').is_file() and read(run/'completion.json').get('status')=='PASS'
        stage='evaluation_complete' if complete else 'trained_scoring_or_evaluation_pending' if receipt.is_file() else 'training_pending'
        row=dict(dataset=name,status=stage,run=str(run))
        selection=base/'teacher/inputs/known_kc_selection.json'
        if selection.is_file():row.update({k:read(selection)[k] for k in ['original_candidate_n','eligible_item_n','rejected_item_n','training_exclusion_n']})
        if stage=='evaluation_complete':audit[str(run.relative_to(root))]=audit_run(run);domains.append((name,run))
        status.append(row)
    pd.DataFrame(status).to_csv(out/'external_status.csv',index=False)
    rq=[];perf=[]
    for name,run in domains:
        s=pd.read_csv(run/'rq2_summary.csv').assign(dataset=name);rq.append(s)
        perf.append(pd.read_csv(run/'main_table_k0_k5.csv').assign(dataset=name))
    pd.concat(rq,ignore_index=True).to_csv(out/'rq2_verified.csv',index=False);pd.concat(perf,ignore_index=True).to_csv(out/'cross_dataset_performance.csv',index=False)
    # Recompute descriptive training variation from per-run data, not pool draws.
    c=pd.read_csv(root/'training_seeds/training_seed_metrics.csv');d=pd.read_csv(root/'training_seeds/training_seed_effects.csv')
    for seed in [42,43,44]:
        run=root/'comparisons/sqakt' if seed==42 else root/f'training_seeds/seed_{seed}/comparisons'
        source=pd.read_csv(run/'learning_curve.csv');source=source[source.budget.isin([0,5])].sort_values(['budget','method']);cached=c[c.training_seed==seed].sort_values(['budget','method'])
        need(source[['budget','method']].reset_index(drop=True).equals(cached[['budget','method']].reset_index(drop=True)),'Seed summary row identities differ')
        need(np.allclose(source.item_macro_nll,cached.item_macro_nll,atol=1e-12,rtol=0) and np.allclose(source.pooled_auc,cached.pooled_auc,atol=1e-12,rtol=0),'Seed summary differs from source outputs')
    for seed in [43,44]:
        base=root/f'training_seeds/seed_{seed}/teacher';r=read(base/'models/shared_teacher/training_receipt.json');ev=read(base/'restart_audit.json')
        need(r['training_seed']==seed and r['training_cold_interactions']==r['validation_cold_interactions']==0 and ev['same_events_and_labels'],'Seed audit failed')
        cfg=next((base/'models/shared_teacher').glob('*/config.json'));need(hashlib.sha256(cfg.read_bytes()).hexdigest()==r['config_sha256'],'Seed config hash differs')
        need(read(cfg)['params']['seed']==seed,'Seed parameter forwarding failed')
    seeds=c.groupby(['budget','method'],as_index=False).agg(nll_mean=('item_macro_nll','mean'),nll_sd=('item_macro_nll','std'),auc_mean=('pooled_auc','mean'),auc_sd=('pooled_auc','std'),training_n=('training_seed','nunique'))
    effects=d.groupby(['budget','baseline'],as_index=False).agg(delta_mean=('delta_nll','mean'),delta_sd=('delta_nll','std'),positive_trainings=('delta_nll',lambda x:int((x>0).sum())))
    need((seeds.training_n==3).all(),'Missing independent training')
    seeds.to_csv(out/'training_seeds_verified.csv',index=False);effects.to_csv(out/'training_seed_effects_verified.csv',index=False)
    reg=pd.read_csv(root/'regularization_sensitivity_v5_2/regularization_sensitivity_metrics.csv');re=pd.read_csv(root/'regularization_sensitivity_v5_2/regularization_sensitivity_effects.csv')
    need(set(reg.bridge_l2)=={10.,100.,1000.},'Sensitivity grid incomplete')
    for row in re.itertuples():
        s=reg[(reg.bridge_l2==row.bridge_l2)&(reg.budget==row.budget)].set_index('method').item_macro_nll
        need(abs(s[row.baseline]-s[row.better]-row.delta_nll)<1e-10,'Sensitivity paired effect mismatch')
    reg.to_csv(out/'regularization_metrics.csv',index=False);re.to_csv(out/'regularization_effects.csv',index=False)
    # Journal figures use only completed domains and keep identity/zero references.
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.bbox':'tight'})
    colors=['#207E87','#BC7056','#617A9B']
    fig,axs=plt.subplots(1,len(domains),figsize=(5.0*len(domains),4.1),squeeze=False)
    preds=[pd.read_csv(run/'rq2_item_predictions.csv') for _,run in domains];v=np.concatenate([p[['criterion','prior_mean']].to_numpy().ravel() for p in preds]);lim=(np.floor(v.min()-.2),np.ceil(v.max()+.2))
    for ax,(name,run),pred,color in zip(axs[0],domains,preds,colors):
        s=pd.read_csv(run/'rq2_summary.csv').iloc[0];ax.scatter(pred.prior_mean,pred.criterion,s=17,alpha=.52,color=color,linewidth=0)
        ax.plot(lim,lim,color='#8E9BA5',lw=1,ls='--');ax.axhline(0,color='#C1C9CF',lw=.7);ax.set(xlim=lim,ylim=lim,xlabel='Out-of-fold prior mean',ylabel='Human-response criterion',title=f'{name}\nSpearman = {s.spearman:.3f}, n = {int(s.item_n)}')
    fig.tight_layout(w_pad=2)
    for ext in ['png','pdf']:fig.savefig(out/f'figure4.{ext}',dpi=240)
    plt.close(fig)
    fig,axs=plt.subplots(1,len(domains),figsize=(5.1*len(domains),3.7),squeeze=False);gain=[]
    for ax,(name,run),color in zip(axs[0],domains,colors):
        d=pd.read_csv(run/'paired_nll_comparisons.csv');d=d[(d.baseline=='RawKT')&(d.better==MAIN)].sort_values('budget');gain.append(d.assign(dataset=name))
        ax.axhline(0,color='#A5AFB8',lw=.8);ax.plot(d.budget,d.delta_nll,'o-',color=color,lw=1.8,ms=4);ax.fill_between(d.budget,d.kc_set_ci_low,d.kc_set_ci_high,color=color,alpha=.15,linewidth=0)
        ax.set(title=name,xlabel='Calibration responses per item (k)',ylabel='NLL reduction versus RawKT',xticks=[0,1,2,5,10,20],ylim=(-.005,.26));ax.grid(axis='y',color='#DFE5E8',lw=.6)
    fig.tight_layout(w_pad=2)
    for ext in ['png','pdf']:fig.savefig(out/f'figure5.{ext}',dpi=240)
    plt.close(fig);pd.concat(gain,ignore_index=True).to_csv(out/'figure5_data.csv',index=False)
    # All settings are visible; no best held-out result is selected.
    fig,axs=plt.subplots(1,2,figsize=(10,4),sharex=True,sharey=True)
    methods=['LLM_direct','MathBERT_linear','MathBERT_RFF','MathBERT_answer_RFF','Joint']
    palette=['#227E87','#AA684E','#6C8C5B','#5C779C','#966A91']
    for ax,budget in zip(axs,[0,5]):
        for method,color in zip(methods,palette):
            z=re[(re.budget==budget)&(re.baseline==method)].sort_values('bridge_l2');ax.plot(z.bridge_l2,z.delta_nll*1000,'o-',color=color,label=LABELS[method],lw=1.3,ms=4)
        ax.axhline(0,color='#7E8D97',lw=.8);ax.set(xscale='log',xticks=[10,100,1000],xticklabels=['10','100','1000'],title=f'k = {budget}',xlabel='L2 penalty',ylabel='NLL reduction of full method (×10⁻³)');ax.grid(axis='y',color='#E1E7EB',lw=.6)
    handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,ncol=3,loc='lower center',bbox_to_anchor=(.5,-.12),frameon=False,fontsize=9);fig.tight_layout()
    for ext in ['png','pdf']:fig.savefig(out/f'figureS2_regularization.{ext}',dpi=240)
    plt.close(fig)
    report=dict(status='PASS_for_available_outputs',audited_completed_run_n=len(audit),runs=audit,external_status=status,
        unverified=['FA scoring/evaluation; failure log not included','XES global chronological first exposure; supplied audit is REVIEW_CROSS_ROW_ORDER','Independent synthetic response generation','Chronological deployment replay'],
        interpretation='No new GPU training or scoring performed by this integration; NLL and paired differences recomputed from supplied item metrics; Spearman/MSE recomputed from item predictions; stored AUC checked between tables/curves, not recomputed without event predictions')
    (out/'integration_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('INTEGRATION_AUDIT_PASS',len(audit),'completed runs; FA pending')
if __name__=='__main__':main()
