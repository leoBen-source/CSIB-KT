#!/usr/bin/env python3
"""Only the three planned module deletions; no result-driven selection."""
import argparse
from pathlib import Path
import pandas as pd
from measurement import atomic_csv
from residual import MAIN

def make(run,out):
    run=Path(run);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    c=pd.read_csv(run/'learning_curve.csv');d=pd.read_csv(run/'paired_nll_comparisons.csv');rows=[]
    for method,label in [(MAIN,'Full method'),('CalKC_Final','Without six summaries'),('No_KC_Reference','Without explicit KC reference'),('KC6_PriorOnly','Without MAP')]:
        row={'method':method,'configuration':label}
        for k in [0,5]:
            a=c[(c.method==method)&(c.budget==k)].iloc[0]
            row.update({f'nll_k{k}':a.item_macro_nll,f'auc_k{k}':a.pooled_auc})
            if method!=MAIN:
                a=d[(d.baseline==method)&(d.budget==k)].iloc[0]
                row.update({f'{name}_k{k}':a[name] for name in ['delta_nll','item_ci_low','item_ci_high','kc_set_ci_low','kc_set_ci_high']})
        rows.append(row)
    atomic_csv(pd.DataFrame(rows),out/'table6_modules.csv')
    print('MODULE_TABLE_PASS',out/'table6_modules.csv')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--out',required=True);a=p.parse_args();make(a.run,a.out)
