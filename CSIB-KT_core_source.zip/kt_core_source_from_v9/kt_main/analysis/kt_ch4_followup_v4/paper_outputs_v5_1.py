#!/usr/bin/env python3
"""Manuscript tables and scientific plots; absent domains are never fabricated."""
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from measurement import atomic_csv
from residual import MAIN

def save(fig,path):
    fig.savefig(str(path)+'.png',dpi=300,bbox_inches='tight');fig.savefig(str(path)+'.pdf',bbox_inches='tight');plt.close(fig)

def main():
    p=argparse.ArgumentParser();p.add_argument('--primary-root',required=True);p.add_argument('--out',required=True);p.add_argument('--fa');p.add_argument('--dbe');a=p.parse_args()
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True);root=Path(a.primary_root)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    table=[]
    for model in ['sqakt','akt','simplekt','dkt']:
        d=pd.read_csv(root/model/'main_table_k0_k5.csv')
        for method in ['RawKT',MAIN]:
            row={'backbone':model,'configuration':'RawKT' if method=='RawKT' else 'KT + method'}
            for k in [0,5]:
                z=d[(d.budget==k)&(d.method==method)].iloc[0];row[f'nll_k{k}']=z.item_macro_nll;row[f'auc_k{k}']=z.pooled_auc
            table.append(row)
    atomic_csv(pd.DataFrame(table),out/'table4.csv')
    runs=[('XES3G5M',root/'sqakt')]
    if a.fa:runs.append(('FoundationalASSIST',Path(a.fa)))
    if a.dbe:runs.append(('DBE-KT22',Path(a.dbe)))
    rq=[]
    fig,axes=plt.subplots(1,len(runs),figsize=(4.3*len(runs),3.65),squeeze=False)
    for ax,(dataset,path) in zip(axes[0],runs):
        z=pd.read_csv(path/'rq2_item_predictions.csv');s=pd.read_csv(path/'rq2_summary.csv').iloc[0];rq.append({'dataset':dataset,**s.to_dict()})
        ax.scatter(z.prior_mean,z.criterion,s=14,alpha=.42,color='#276A8A',edgecolors='none')
        lo=float(min(z.prior_mean.min(),z.criterion.min()));hi=float(max(z.prior_mean.max(),z.criterion.max()));ax.plot([lo,hi],[lo,hi],color='#A15136',lw=1.1,label='Identity')
        ax.axhline(0,color='#aaaaaa',lw=.6);ax.set(xlabel='Out-of-fold prior mean',ylabel='Human-response criterion',title=f'{dataset}\nSpearman = {s.spearman:.3f}, n = {int(s.item_n)}');ax.legend(frameon=False)
    fig.tight_layout();save(fig,out/'figure4')
    atomic_csv(pd.DataFrame(rq),out/'table3.csv')
    from paper_visuals_v5_1 import draw_publication_figures
    draw_publication_figures(a.primary_root,out,fa=a.fa,dbe=a.dbe)
    print('PAPER_OUTPUTS_PASS',out,flush=True)
if __name__=='__main__':main()
