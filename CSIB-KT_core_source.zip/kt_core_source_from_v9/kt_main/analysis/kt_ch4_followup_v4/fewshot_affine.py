#!/usr/bin/env python3
"""Same-budget scalar versus affine MAP diagnostic, with frozen KT scores.

b ~ N(main prior mean, 1), a ~ N(1, 1). This compares additional freedom at
k=0,5; it does not deploy or select a new primary method from test performance.
"""
import argparse,hashlib,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from sklearn.metrics import roc_auc_score
from measurement import atomic_csv,logit,map_vector,save_json,file_hash
from residual import MAIN
from evaluation import SEEDS

def main():
    p=argparse.ArgumentParser();p.add_argument('--events',required=True);p.add_argument('--base-run',required=True);p.add_argument('--out',required=True);a=p.parse_args();out=Path(a.out)
    if out.exists():raise ValueError('Fresh output directory required')
    manifest=json.loads((Path(a.base_run)/'run_manifest.json').read_text())
    if file_hash(a.events)!=manifest['inputs']['events']['sha256']:raise ValueError('Main and affine score inputs differ')
    e=pd.read_csv(a.events,dtype={'event_id':str,'target_kc_key':str});pri=pd.read_csv(Path(a.base_run)/'prior_table.csv');pri=pri[pri.method==MAIN].set_index('target_qid');rows=[];auc=[]
    for seed in SEEDS:
        pool={(k,m):[[],[]] for k in [0,5] for m in ['Scalar','Affine']}
        for q,z in e.groupby('target_qid'):
            z=z.sort_values('event_id').reset_index(drop=True)
            if len(z)<30:continue
            sd=int.from_bytes(hashlib.sha256(f's19_calibration_pool|{seed}|{q}'.encode()).digest()[:8],'little')%(2**32-1);ix=np.random.default_rng(sd).permutation(len(z))[:20];keep=np.ones(len(z),bool);keep[ix]=False
            eta=logit(z.teacher_kc_uniform);y=z.label.to_numpy(float);mu=float(pri.loc[q,'prior_mean']);var=float(pri.loc[q,'prior_var'])
            for k in [0,5]:
                scalar=float(map_vector(y[ix][:k],z.teacher_kc_uniform.to_numpy()[ix][:k],[mu],[var])[0])
                xx=eta[ix][:k];yy=y[ix][:k]
                def fg(theta):
                    slope,bias=theta;value=slope*xx+bias;res=expit(value)-yy
                    loss=np.sum(np.logaddexp(0,value)-yy*value)+.5*(slope-1)**2+.5*(bias-mu)**2/var
                    return float(loss),np.array([res@xx+slope-1,res.sum()+(bias-mu)/var])
                fit=minimize(fg,np.array([1.,mu]),jac=True,method='L-BFGS-B')
                if not fit.success:raise ValueError('Affine fit failed')
                for name,slope,bias in [('Scalar',1.,scalar),('Affine',fit.x[0],fit.x[1])]:
                    v=slope*eta[keep]+bias;prediction=expit(v);loss=float(np.mean(np.logaddexp(0,v)-y[keep]*v))
                    rows.append(dict(seed=seed,budget=k,target_qid=q,target_kc_key=str(z.target_kc_key.iloc[0]),method=name,item_nll=loss,slope=slope,bias=bias));pool[k,name][0].append(y[keep]);pool[k,name][1].append(prediction)
        for (k,name),(ys,ps) in pool.items():auc.append(dict(seed=seed,budget=k,method=name,pooled_auc=roc_auc_score(np.concatenate(ys),np.concatenate(ps))))
    out.mkdir(parents=True);items=pd.DataFrame(rows);atomic_csv(items,out/'item_metrics.csv.gz');mean=items.groupby(['budget','method'],as_index=False).item_nll.mean().merge(pd.DataFrame(auc).groupby(['budget','method'],as_index=False).pooled_auc.mean(),on=['budget','method']);atomic_csv(mean,out/'summary.csv')
    from affine_summary import summarize
    result=summarize(items,out);save_json(out/'manifest.json',dict(slope_prior_mean=1.,slope_prior_var=1.,intercept_prior='same main-method prior',interpretation='capacity diagnostic at the same response budget; test results do not select the primary model'))
    print(mean.to_string(index=False));print(result.to_string(index=False))
if __name__=='__main__':main()
