#!/usr/bin/env python3
import argparse,json
from pathlib import Path
import pandas as pd
from measurement import save_json,file_hash
from residual import load,fit_priors,MAIN
from evaluation import evaluate,summaries,rq2

def main():
    p=argparse.ArgumentParser();p.add_argument('--teacher',required=True);p.add_argument('--scores');p.add_argument('--out',required=True)
    p.add_argument('--responses',default=str(Path(__file__).parent/'data/synthetic_response_panel.csv'))
    p.add_argument('--suite',choices=['main','modules','full'],default='main');p.add_argument('--aux-features');p.add_argument('--bootstrap',type=int,default=5000)
    p.add_argument('--budgets',default='0,1,2,5,10,20');p.add_argument('--verify-archived-prior');a=p.parse_args()
    out=Path(a.out)
    if out.exists():raise ValueError('Fresh output directory required')
    g,e,r,paths=load(a.teacher,a.responses,a.scores);out.mkdir(parents=True)
    aux=pd.read_csv(a.aux_features) if a.aux_features else None
    save_json(out/'run_manifest.json',dict(implementation='KC reference plus six-summary residual; archived estimator restored',main=MAIN,
        inputs={k:dict(path=str(Path(v).resolve()),sha256=file_hash(v)) for k,v in paths.items()},config=vars(a),variance=1.,kc_strength=5.,slope_l2=100.,backbone_retrained=False))
    prior=fit_priors(g,e,r,out,suite=a.suite,aux=aux)
    if a.verify_archived_prior:
        old=pd.read_csv(a.verify_archived_prior);z=prior[prior.method.isin(['CalKC_Final',MAIN])].merge(old,on=['target_qid','method'],suffixes=('_new','_old'),validate='one_to_one')
        if len(z)!=len(g)*2:raise ValueError('Archived prior coverage differs')
        error=float(abs(z.prior_mean_new-z.prior_mean_old).max());save_json(out/'archive_parity.json',dict(max_mean_difference=error,compared_rows=len(z),variance_max_difference=float(abs(z.prior_var_new-z.prior_var_old).max())))
        if error>1e-6:raise ValueError('Restored means did not match the archived prior')
    items,curve=evaluate(g,e,prior,out,budgets=[int(k) for k in a.budgets.split(',')]);summaries(items,out,a.bootstrap);rq2(g,prior,out,a.bootstrap)
    save_json(out/'completion.json',dict(status='PASS',main=MAIN));print('PASS',out/'main_table_k0_k5.csv',flush=True)

if __name__=='__main__':main()
