#!/usr/bin/env python3
"""Add both item and exact-KC-set confidence intervals without re-fitting MAP."""
import argparse
from pathlib import Path
import numpy as np,pandas as pd
from measurement import atomic_csv

def summarize(items,out,draws=5000):
    avg=items.groupby(['target_qid','target_kc_key','budget','method'],as_index=False).item_nll.mean();result=[]
    for k in sorted(avg.budget.unique()):
        z=avg[avg.budget==k].pivot(index=['target_qid','target_kc_key'],columns='method',values='item_nll').reset_index()
        d=(z.Affine-z.Scalar).to_numpy();blocks=[t.index.to_numpy() for _,t in z.groupby('target_kc_key')]
        row=dict(budget=k,better='Scalar',baseline='Affine',delta_nll=float(d.mean()))
        for level in ['item','kc_set']:
            rng=np.random.default_rng(7311);values=[]
            for _ in range(draws):
                ix=rng.integers(len(z),size=len(z)) if level=='item' else np.concatenate([blocks[j] for j in rng.integers(len(blocks),size=len(blocks))])
                values.append(d[ix].mean())
            row[level+'_ci_low'],row[level+'_ci_high']=np.quantile(values,[.025,.975])
        result.append(row)
    atomic_csv(pd.DataFrame(result),Path(out)/'paired_nll_comparisons.csv')
    return pd.DataFrame(result)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--bootstrap',type=int,default=5000);a=p.parse_args()
    z=pd.read_csv(Path(a.run)/'item_metrics.csv.gz',dtype={'target_kc_key':str});print(summarize(z,a.run,a.bootstrap).to_string(index=False))
