#!/usr/bin/env python3
"""Unify RQ2 and SQAKT results; never substitute old external protocols."""
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from integrate_results_v5_3 import audit_run

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    domains=[('XES3G5M',root/'primary/sqakt'),('FoundationalASSIST',root/'external_known_kc/fa/fit'),('DBE-KT22',root/'external_known_kc/dbe/fit')]
    rq=[];perf=[];counts=[];gains=[];ready=[];status=[]
    for name,run in domains:
        complete=(run/'completion.json').is_file() and json.loads((run/'completion.json').read_text()).get('status')=='PASS'
        status.append(dict(dataset=name,status='complete' if complete else 'pending',run=str(run)))
        if not complete:
            rq.append(dict(dataset=name,status='pending',item_n=None))
            for method in ['RawKT','KC6_Final']:perf.append(dict(dataset=name,status='pending',method=method,nll_k0=None,auc_k0=None,nll_k5=None,auc_k5=None))
            continue
        audit_run(run);ready.append((name,run));r=pd.read_csv(run/'rq2_summary.csv').iloc[0].to_dict();rq.append(dict(dataset=name,status='complete',**r))
        e=json.loads((run/'evaluation_manifest.json').read_text());counts.append(dict(dataset=name,rq2_item_n=int(r['item_n']),prediction_item_n=e['target_n'],prediction_event_n=e['event_n'],query_event_n_per_pool=e['event_n']-20*e['target_n'],excluded_sparse_qids=e['excluded_sparse_qids']))
        d=pd.read_csv(run/'main_table_k0_k5.csv')
        for method in ['RawKT','KC6_Final']:
            z=d[d.method==method].set_index('budget');perf.append(dict(dataset=name,status='complete',method=method,nll_k0=z.loc[0,'item_macro_nll'],auc_k0=z.loc[0,'pooled_auc'],nll_k5=z.loc[5,'item_macro_nll'],auc_k5=z.loc[5,'pooled_auc']))
        z=pd.read_csv(run/'paired_nll_comparisons.csv');gains.append(z[(z.baseline=='RawKT')&(z.better=='KC6_Final')].assign(dataset=name))
    pd.DataFrame(rq).to_csv(out/'table3_cross_dataset.csv',index=False);pd.DataFrame(perf).to_csv(out/'table4b_cross_dataset_sqakt.csv',index=False);pd.DataFrame(counts).to_csv(out/'sample_counts.csv',index=False)
    pd.concat(gains,ignore_index=True).to_csv(out/'paired_gains_cross_dataset.csv',index=False)
    # Each panel is also exported separately, preserving readable journal labels.
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.bbox':'tight'})
    colors={'XES3G5M':'#237C86','FoundationalASSIST':'#5E799E','DBE-KT22':'#B76D55'}
    all_pred=[pd.read_csv(run/'rq2_item_predictions.csv') for _,run in ready];v=np.concatenate([z[['prior_mean','criterion']].to_numpy().ravel() for z in all_pred]);lo=float(np.floor(v.min()-.2));hi=float(np.ceil(v.max()+.2))
    all_gain=pd.concat(gains,ignore_index=True);ylo=min(0.,float(all_gain.kc_set_ci_low.min()));yhi=max(.01,float(all_gain.kc_set_ci_high.max()))*1.08
    def draw4(ax,name,run):
        z=pd.read_csv(run/'rq2_item_predictions.csv');s=pd.read_csv(run/'rq2_summary.csv').iloc[0];ax.scatter(z.prior_mean,z.criterion,s=19,alpha=.55,color=colors[name],linewidth=0);ax.plot([lo,hi],[lo,hi],ls='--',lw=1,color='#9AA8B1');ax.axhline(0,color='#C6CFD4',lw=.7);ax.set(xlim=(lo,hi),ylim=(lo,hi),xlabel='Out-of-fold prior mean',ylabel='Human-response criterion',title=f'{name}\nSpearman = {s.spearman:.3f}, n = {int(s.item_n)}')
    def draw5(ax,name,run):
        z=all_gain[all_gain.dataset==name].sort_values('budget');ax.axhline(0,color='#8999A5',lw=.8);ax.plot(z.budget,z.delta_nll,'o-',lw=1.7,ms=4,color=colors[name]);ax.fill_between(z.budget,z.kc_set_ci_low,z.kc_set_ci_high,color=colors[name],alpha=.15,linewidth=0);ax.set(title=name,xlabel='Calibration responses per item (k)',ylabel='NLL reduction versus RawKT',xticks=[0,1,2,5,10,20],ylim=(ylo-.005,yhi));ax.grid(axis='y',color='#E2E8EB',lw=.6)
    for num,draw,height in [(4,draw4,3.8),(5,draw5,3.2)]:
        # Three domains use two panels above and a centred panel below instead
        # of squeezing three tiny axes into one Word-column-width strip.
        if len(ready)==3:
            fig=plt.figure(figsize=(10,2*height));gs=fig.add_gridspec(2,4);axes=[fig.add_subplot(gs[0,:2]),fig.add_subplot(gs[0,2:]),fig.add_subplot(gs[1,1:3])]
        else:fig,axs=plt.subplots(1,len(ready),figsize=(5*len(ready),height),squeeze=False);axes=list(axs[0])
        for ax,(name,run) in zip(axes,ready):draw(ax,name,run)
        fig.tight_layout(w_pad=2,h_pad=2)
        for ext in ['png','pdf']:fig.savefig(out/f'figure{num}.{ext}',dpi=240)
        plt.close(fig)
        for name,run in ready:
            fig,ax=plt.subplots(figsize=(5,height));draw(ax,name,run);fig.tight_layout()
            for ext in ['png','pdf']:fig.savefig(out/f'figure{num}_{name}.{ext}',dpi=240)
            plt.close(fig)
    (out/'dataset_status_v5_4.json').write_text(json.dumps(dict(datasets=status,complete_dataset_n=len(ready),complete_three_dataset_results=len(ready)==3,old_protocol_results_substituted=False),ensure_ascii=False,indent=2));print('PAPER_TABLES_V5_4',len(ready),'completed domains; missing domains explicitly pending',flush=True)
if __name__=='__main__':main()
