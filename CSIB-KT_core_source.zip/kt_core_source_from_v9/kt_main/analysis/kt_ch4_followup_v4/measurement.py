# Adapted from the user-supplied kt_calibration/core.py.
# Rebuilds summaries from raw binary synthetic responses and current KT scores.
"""Calibration of item effects conditional on supplied frozen KT predictions.
This package never trains or changes the upstream knowledge tracing model.
"""
from __future__ import annotations
import hashlib, json, gzip, os
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize, minimize_scalar
from scipy.special import expit
from scipy.stats import norm, rankdata
SIX = ['rasch_local', 'twopl_local', 'log_a', 'weighted_correct', 'log_se', 'precision']
EPS = 1e-06

def logit(p):
    p = np.clip(np.asarray(p, float), EPS, 1 - EPS)
    return np.log(p) - np.log1p(-p)

def file_hash(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

def save_json(path, value):

    def clean(x):
        if isinstance(x, np.ndarray):
            return clean(x.tolist())
        if isinstance(x, dict):
            return {str(k): clean(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)):
            return [clean(v) for v in x]
        if isinstance(x, (np.integer, np.floating, np.bool_)):
            return clean(x.item())
        if isinstance(x, float) and (not np.isfinite(x)):
            return None
        return x
    Path(path).write_text(json.dumps(clean(value), ensure_ascii=False, indent=2, allow_nan=False))

def atomic_csv(frame, path):
    path = Path(path)
    raw = frame.to_csv(index=False).encode('utf-8')
    data = gzip.compress(raw, compresslevel=1, mtime=0) if str(path).endswith('.gz') else raw
    temp = path.with_name(path.name + '.partial')
    with open(temp, 'wb') as f:
        n = f.write(data)
        f.flush()
        os.fsync(f.fileno())
    if n != len(data):
        raise IOError('short artifact write')
    os.replace(temp, path)
    if hashlib.sha256(path.read_bytes()).digest() != hashlib.sha256(data).digest():
        raise IOError('output checksum mismatch')

def rho(y, p):
    a, b = (rankdata(y), rankdata(p))
    return float(np.corrcoef(a, b)[0, 1]) if len(a) > 2 and np.std(a) > 1e-12 and (np.std(b) > 1e-12) else np.nan

def bridge_fit(items, events, columns, l2=100.0):
    X = items[columns].to_numpy(float)
    if not np.isfinite(X).all():
        raise ValueError('nonfinite bridge feature')
    mu = X.mean(0)
    sd = X.std(0)
    sd = np.where(sd < 1e-08, 1.0, sd)
    Z = (X - mu) / sd
    ix = {int(q): i for i, q in enumerate(items.target_qid)}
    e = events[events.target_qid.isin(ix)]
    if set(e.target_qid) != set(ix):
        raise ValueError('missing mapper training events')
    idx = e.target_qid.map(ix).to_numpy(int)
    Xe = Z[idx]
    y = e.label.to_numpy(float)
    base = logit(e.teacher_kc_uniform)
    counts = e.groupby('target_qid').size()
    n = len(items)
    w = 1 / (n * e.target_qid.map(counts).to_numpy(float))

    def fg(z):
        eta = base + z[0] + Xe @ z[1:]
        r = w * (expit(eta) - y)
        loss = np.sum(w * (np.logaddexp(0, eta) - y * eta)) + l2 * np.sum(z[1:] ** 2) / (2 * n)
        return (float(loss), np.r_[r.sum(), Xe.T @ r + l2 * z[1:] / n])
    fit = minimize(fg, np.zeros(len(columns) + 1), jac=True, method='L-BFGS-B')
    if not fit.success:
        raise RuntimeError(f'bridge fit failed {fit.message}')
    return dict(mean=mu, scale=sd, coef=fit.x, columns=columns)

def bridge_predict(model, items):
    X = items[model['columns']].to_numpy(float)
    return model['coef'][0] + (X - model['mean']) / model['scale'] @ model['coef'][1:]

def localize(tr, te):
    tr, te = (tr.copy(), te.copy())
    for source, target in [('rasch', 'rasch_local'), ('twopl', 'twopl_local'), ('raw_logit', 'raw_logit_local')]:
        med = tr.groupby('target_kc_key')[source].median()
        glob = float(tr[source].median())
        for t in (tr, te):
            t[target] = t[source] - t.target_kc_key.map(med).fillna(glob)
    for z in (tr, te):
        z['a'] = np.exp(z.log_a)
        z['se'] = np.exp(z.log_se)
        z['info'] = 1 / (z.se * z.se + 1e-06)
        z['level_reliable'] = z.rasch_local * z.precision
    return (tr, te)

def theta_fit(y, beta):

    def f(t):
        eta = t - beta
        return float(np.sum(np.logaddexp(0, eta) - y * eta) + 0.5 * (t / 4.0) ** 2)
    z = minimize_scalar(f, bounds=(-8, 8), method='bounded')
    if not z.success:
        raise RuntimeError('theta fit failed')
    return float(z.x)

def weights_fit(theta, human, bw=0.45, entropy=0.08):
    lo, hi = np.quantile(human, [0.02, 0.98])
    grid = np.linspace(lo, hi, 101)
    hb = max(np.std(human) * 0.18, 0.2)
    take = human if len(human) <= 50000 else human[np.linspace(0, len(human) - 1, 50000).astype(int)]
    target = np.mean(norm.pdf((grid[:, None] - take[None, :]) / hb) / hb, axis=1)
    A = norm.pdf((grid[:, None] - theta[None, :]) / bw) / bw
    sc = max(np.mean(target ** 2), 1e-08)

    def fg(z):
        w = np.exp(z - z.max())
        w /= w.sum()
        err = A @ w - target
        loss = np.mean(err ** 2) / sc + entropy * np.sum(w * np.log(np.clip(w * len(w), 1e-12, None)))
        dw = 2 * A.T @ err / len(grid) / sc + entropy * (np.log(np.clip(w * len(w), 1e-12, None)) + 1)
        return (float(loss), w * (dw - np.dot(w, dw)))
    z = minimize(fg, np.zeros(len(theta)), jac=True, method='L-BFGS-B')
    if not z.success:
        raise RuntimeError('weight fit failed')
    w = np.exp(z.x - z.x.max())
    return w / w.sum()

def irt_fit(theta, y, w):
    wn = w / w.sum() * len(w)

    def rasch(b):
        eta = theta - b
        return float(np.sum(wn * (np.logaddexp(0, eta) - y * eta)) + 0.5 * (b / 4.0) ** 2)
    a = minimize_scalar(rasch, bounds=(-8, 8), method='bounded')
    neff = 1 / np.sum((w / w.sum()) ** 2)
    p = expit(theta - a.x)
    se = np.sqrt(1 / (np.sum(w / w.sum() * neff * p * (1 - p)) + 1 / 16.0))

    def fg(z):
        b, la = z
        scale = np.exp(la)
        eta = scale * (theta - b)
        r = wn * (expit(eta) - y)
        loss = np.sum(wn * (np.logaddexp(0, eta) - y * eta)) + 0.5 * (b / 4.0) ** 2 + 0.5 * (la / 0.6) ** 2
        return (float(loss), np.array([np.sum(-scale * r) + b / 16.0, np.sum(r * eta) + la / 0.36]))
    b = minimize(fg, [0.0, 0.0], jac=True, method='L-BFGS-B', bounds=[(-8, 8), (-2, 2)])
    if not a.success or not b.success:
        raise RuntimeError('item IRT fit failed')
    info = 1 / (se * se + 1e-06)
    return dict(rasch=-float(a.x), twopl=-float(b.x[0]), log_a=float(b.x[1]), weighted_correct=float(np.dot(w, y)), log_se=float(np.log(se)), precision=float(info / (info + 1)))

class Features:
    """Scope-keyed reconstruction. No statistical qualification or support threshold gate."""

    def __init__(self, g, e, r, signature=None):
        self.g = g.set_index('target_qid', drop=False)
        self.e = e
        r = r[r.scoring_valid.astype(int) == 1].copy() if 'scoring_valid' in r else r.copy()
        r = r[r.qid.isin(set(g.target_qid))]
        if r.duplicated(['qid', 'synthetic_student_id']).any():
            raise ValueError('duplicate synthetic channel')
        if not r.correct.isin([0, 1]).all():
            raise ValueError('nonbinary synthetic score')
        self.R = r.pivot(index='qid', columns='synthetic_student_id', values='correct').sort_index(axis=1).reindex(g.target_qid)
        if self.R.isna().any().any() or self.R.shape[1] != 20:
            raise ValueError('expected complete 20-channel panel')
        self.policies = sorted(r.policy_id.unique())
        mp = r.drop_duplicates('synthetic_student_id').set_index('synthetic_student_id').policy_id.to_dict()
        self.policy_indices = [[i for i, s in enumerate(self.R.columns) if mp[s] == pol] for pol in self.policies]
        self.signature = signature
        self.cache = {}
        self.scope_log = []
        ec = e.copy()
        ec['_logit'] = logit(ec.teacher_kc_uniform)
        self.eb = ec
        self.base = ec.groupby('target_qid')._logit.mean()

    def alignment(self, scope):
        key = tuple(sorted(scope))
        if key in self.cache:
            return self.cache[key]
        ids = self.g.loc[self.g.content_group_fold.isin(scope), 'target_qid'].to_numpy(int)
        if len(ids) < 3:
            raise ValueError('insufficient calibration items')
        beta = -(self.base.loc[ids].to_numpy() + self.g.loc[ids, 'criterion'].to_numpy())
        R = self.R.loc[ids].to_numpy(float)
        theta = np.array([theta_fit(R[:, i], beta) for i in range(R.shape[1])])
        ec = self.eb[self.eb.target_qid.isin(ids)]
        human = ec._logit.to_numpy() - ec.target_qid.map(self.base).to_numpy()
        w = weights_fit(theta, human)
        self.cache[key] = (theta, w)
        self.scope_log.append(dict(folds=list(map(int, key)), calibration_n=len(ids), neff=float(1 / np.sum(w * w))))
        return (theta, w)

    def frame(self, scope, ids, train, signature_outer=None):
        rows = []
        for q in ids:
            q = int(q)
            fold = int(self.g.loc[q, 'content_group_fold'])
            allowed = set(scope) - {fold} if train else set(scope)
            if not train and fold in allowed:
                raise ValueError('held item in measurement supervision scope')
            if signature_outer is not None:
                a = self.signature[(self.signature.feature_outer_fold == signature_outer) & (self.signature.target_qid == q)]
                if len(a) != 1:
                    raise ValueError('signature row missing/duplicated')
                a = a.iloc[0]
                expected = 'mapper_train_crossfit' if train else 'outer_test_full_train'
                if str(a.feature_alignment_scope) != expected or int(a.target_content_group_fold) != fold:
                    raise ValueError('precomputed measurement scope mismatch')
                se = float(a.syn_rasch_se)
                info = 1 / (se * se + 1e-06)
                z = dict(rasch=float(a.syn_rasch_level), twopl=float(a.syn_2pl_level), log_a=float(np.log(a.syn_2pl_a)), weighted_correct=float(a.syn_weighted_correct), log_se=float(np.log(se)), precision=float(info / (info + 1)))
            else:
                key = ('item', tuple(sorted(allowed)), q)
                if key not in self.cache:
                    th, w = self.alignment(allowed)
                    self.cache[key] = irt_fit(th, self.R.loc[q].to_numpy(float), w)
                z = self.cache[key]
            R = self.R.loc[q].to_numpy(float)
            mean = float(R.mean())
            cp = np.clip(mean, EPS, 1 - EPS)
            raw = dict(raw_logit=float(logit((R.sum() + 0.5) / (len(R) + 1))), raw_mean=mean, raw_sd=float(R.std()), raw_entropy=float(-cp * np.log(cp) - (1 - cp) * np.log1p(-cp)), raw_p1mp=mean * (1 - mean))
            raw.update({f'response_{i}': v for i, v in enumerate(R)})
            raw.update({f'policy_{i}': float(R[ix].mean()) for i, ix in enumerate(self.policy_indices)})
            rows.append(dict(target_qid=q, target_kc_key=str(self.g.loc[q, 'target_kc_key']), content_group_fold=fold, **z, **raw))
        return pd.DataFrame(rows)

    def pair(self, scope, test_ids, signature_outer=None):
        train_ids = self.g.loc[self.g.content_group_fold.isin(scope), 'target_qid'].tolist()
        tr = self.frame(scope, train_ids, True, signature_outer)
        te = self.frame(scope, test_ids, False, signature_outer)
        return localize(tr, te)

def map_vector(y, p, means, variances):
    means = np.asarray(means, float)
    v = np.asarray(variances, float)
    if not np.isfinite(means).all() or not np.isfinite(v).all() or (v <= 0).any():
        raise ValueError('invalid Gaussian prior')
    b = np.clip(means, -8, 8)
    if not len(y):
        return b
    base = logit(p)
    for _ in range(50):
        prob = expit(base[None, :] + b[:, None])
        grad = np.sum(prob - y, axis=1) + (b - means) / v
        h = np.sum(prob * (1 - prob), axis=1) + 1 / v
        nb = np.clip(b - np.clip(grad / h, -2, 2), -8, 8)
        if np.max(abs(nb - b)) < 1e-10:
            return nb
        b = nb
    raise RuntimeError('MAP did not converge')

def cluster_draws(z, value, B, seed, key):
    z = z.reset_index(drop=True)
    arr = z[value].to_numpy(float)
    groups = [v.index.to_numpy() for _, v in z.groupby(key)]
    rng = np.random.default_rng(seed)
    res = np.empty(B)
    for j in range(B):
        res[j] = arr[np.concatenate([groups[i] for i in rng.integers(0, len(groups), len(groups))])].mean()
    return dict(mean=float(arr.mean()), ci95=np.quantile(res, [0.025, 0.975]).tolist(), n_clusters=len(groups))
