#!/usr/bin/env python3
"""Resolve the audited native SQAKT configuration before any GPU work."""
import argparse,hashlib,json
from pathlib import Path

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def resolve_template(path):
    supplied=Path(path).resolve()
    candidates=[supplied,supplied/'s12_strict_shared_teacher_v1']
    teacher=next((p for p in candidates if (p/'models/shared_teacher/training_receipt.json').is_file()),None)
    if teacher is None:
        raise FileNotFoundError('Native SQAKT training receipt absent. Checked: '+', '.join(str(p/'models/shared_teacher/training_receipt.json') for p in candidates))
    receipt_path=teacher/'models/shared_teacher/training_receipt.json'
    receipt=json.loads(receipt_path.read_text())
    if receipt.get('status')!='PASS' or receipt.get('training_cold_interactions')!=0 or receipt.get('validation_cold_interactions')!=0:
        raise ValueError('Native template receipt is not an audited cold-excluded model: '+str(receipt_path))
    run=Path(receipt['run'])
    if not (run/'config.json').is_file():
        relocated=teacher/'models/shared_teacher'/run.name
        if not (relocated/'config.json').is_file():
            raise FileNotFoundError('Receipt found, but its config is absent: '+str(run/'config.json'))
        run=relocated
    cfg_path=run/'config.json';cfg=json.loads(cfg_path.read_text())
    if receipt.get('config_sha256') and sha(cfg_path)!=receipt['config_sha256']:
        raise ValueError('Native template config hash differs from its training receipt')
    mc=cfg['model_config']
    if mc.get('q_item_parameterization')!='id_only_cold_mask' or int(mc.get('kc_set_input',0))!=1:
        raise ValueError('Template is not native set-aware cold-masked SQAKT')
    for flag in ['use_q_sem','use_c_sem','use_q_ref_sem','use_q_calib_prior','use_q_content_arbitration','use_q_structured_sem','use_q_ref_structured_sem']:
        if mc.get(flag,0):raise ValueError('Unexpected extra item branch in native template: '+flag)
    scorer=teacher/'shared_scorer.py'
    if not scorer.is_file():raise FileNotFoundError('Native shared scorer absent: '+str(scorer))
    receipt=dict(receipt,run=str(run))
    info=dict(status='PASS',supplied_teacher=str(supplied),resolved_teacher=str(teacher),receipt=str(receipt_path),
        config=str(cfg_path),config_sha256=sha(cfg_path),scorer=str(scorer),scorer_sha256=sha(scorer),
        purpose='Native architecture/configuration template; XES checkpoint weights are not transferred to external domains')
    return teacher,receipt,cfg,info

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--teacher',required=True);p.add_argument('--out');a=p.parse_args()
    teacher,receipt,cfg,info=resolve_template(a.teacher)
    if a.out:
        out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(info,indent=2))
    print('NATIVE_TEMPLATE_PASS',teacher,flush=True)
