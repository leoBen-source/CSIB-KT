#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.optimize import minimize

EPS=1e-6

def logit(p):
    p=np.clip(np.asarray(p,float),EPS,1-EPS)
    return np.log(p/(1-p))

def sigmoid(x):
    x=np.clip(np.asarray(x,float),-35,35)
    return 1/(1+np.exp(-x))

def loss_vec(y,p):
    y=np.asarray(y,float); p=np.clip(np.asarray(p,float),EPS,1-EPS)
    return -(y*np.log(p)+(1-y)*np.log(1-p))

def nll(y,p): return float(np.mean(loss_vec(y,p)))
def brier(y,p): return float(np.mean((np.asarray(y,float)-np.asarray(p,float))**2))

def stable_fold(key,k,seed):
    h=hashlib.sha256(f'{seed}|{key}'.encode()).digest()
    return int.from_bytes(h[:8],'little')%k

def fit_scalar_offset(x,y,l2):
    # logit p = x + b
    def obj(v):
        b=float(v[0]); pr=sigmoid(x+b)
        return float(np.sum(loss_vec(y,pr)) + .5*l2*b*b)
    r=minimize(obj,np.array([0.0]),method='BFGS')
    return float(r.x[0])

def fit_affine(x,y,l2):
    # logit p = a*x+b. Regularize toward identity a=1,b=0.
    def obj(v):
        a,b=map(float,v); pr=sigmoid(a*x+b)
        return float(
            np.sum(loss_vec(y,pr)) + .5*l2*((a-1)**2+b*b)
        )
    r=minimize(obj,np.array([1.0,0.0]),method='BFGS')
    return float(r.x[0]),float(r.x[1])

def fit_bin_offsets(x,y,n_bins,prior):
    if len(x)<max(6,n_bins*2):
        return None
    qs=np.quantile(x,np.linspace(0,1,n_bins+1)[1:-1])
    qs=np.unique(qs)
    bins=np.searchsorted(qs,x,side='right')
    B=len(qs)+1; offs=[]
    for b in range(B):
        m=bins==b
        if m.sum()==0:
            offs.append(0.0); continue
        bp=float(sigmoid(x[m]).mean())
        yy=float(y[m].sum()); n=int(m.sum())
        post=(yy+prior*bp)/(n+prior)
        post=np.clip(post,EPS,1-EPS); bp=np.clip(bp,EPS,1-EPS)
        offs.append(
            float(np.log(post/(1-post))-np.log(bp/(1-bp)))
        )
    return qs,np.asarray(offs,float)

def predict_bins(x,model):
    if model is None:
        return sigmoid(x)
    qs,offs=model
    b=np.searchsorted(qs,x,side='right')
    return sigmoid(x+offs[b])

def bootstrap_delta(item,a,b,B,seed):
    # positive => b has lower NLL than a
    d=(item[a]-item[b]).to_numpy(float)
    rng=np.random.default_rng(seed); n=len(d)
    sims=d[rng.integers(0,n,size=(B,n))].mean(axis=1)
    return {
        'mean_delta_nll':float(d.mean()),
        'ci95':[float(np.quantile(sims,.025)),float(np.quantile(sims,.975))],
        'p_delta_le_0':float(np.mean(sims<=0))
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--event_csv',required=True)
    ap.add_argument('--out_dir',required=True)
    ap.add_argument('--cv_folds',type=int,default=5)
    ap.add_argument('--seed',type=int,default=20260828)
    ap.add_argument('--l2',type=float,default=1.0)
    ap.add_argument('--n_bins',type=int,default=3)
    ap.add_argument('--bin_prior',type=float,default=8.0)
    ap.add_argument('--bootstrap',type=int,default=5000)
    args=ap.parse_args()
    out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)

    ev=pd.read_csv(args.event_csv,low_memory=False)
    need={'event_id','target_qid','target_kc_key','label','teacher_kc_uniform'}
    if not need.issubset(ev.columns):
        raise RuntimeError(f'missing {sorted(need-set(ev.columns))}')
    if ev.event_id.duplicated().any():
        raise RuntimeError('duplicate event_id')

    ev=ev.copy()
    ev['base_logit']=logit(ev.teacher_kc_uniform)
    preds=[]; per=[]

    for q,g0 in ev.groupby('target_qid',sort=True):
        g=g0.reset_index().rename(columns={'index':'orig_index'})
        y=g.label.to_numpy(int)
        x=g.base_logit.to_numpy(float)
        n=len(g)

        # Privileged in-sample upper bounds: never deployable; headroom only.
        b_all=fit_scalar_offset(x,y,args.l2)
        a_all,bb_all=fit_affine(x,y,args.l2)
        p_base=sigmoid(x)
        p_scalar_or=sigmoid(x+b_all)
        p_affine_or=sigmoid(a_all*x+bb_all)

        # Cross-fitted response-shape audit.
        folds=np.array([
            stable_fold(k,args.cv_folds,args.seed)
            for k in g.event_id.astype(str)
        ])
        p_s=np.zeros(n); p_a=np.zeros(n); p_bin=np.zeros(n)
        used=np.zeros(n,bool)

        for f in range(args.cv_folds):
            te=folds==f; tr=~te
            if te.sum()==0:
                continue
            if tr.sum()<5 or len(np.unique(y[tr]))<2:
                # Underidentified item fold -> fail closed to baseline.
                p_s[te]=p_base[te]
                p_a[te]=p_base[te]
                p_bin[te]=p_base[te]
                used[te]=True
                continue

            b=fit_scalar_offset(x[tr],y[tr],args.l2)
            a,bb=fit_affine(x[tr],y[tr],args.l2)
            bm=fit_bin_offsets(
                x[tr],y[tr],args.n_bins,args.bin_prior
            )
            p_s[te]=sigmoid(x[te]+b)
            p_a[te]=sigmoid(a*x[te]+bb)
            p_bin[te]=predict_bins(x[te],bm)
            used[te]=True

        if not used.all():
            raise RuntimeError(f'cv prediction incomplete q={q}')

        for i,row in g.iterrows():
            preds.append({
                'event_id':row.event_id,
                'target_qid':int(q),
                'target_kc_key':str(row.target_kc_key),
                'label':int(row.label),
                'base_p':float(p_base[i]),
                'scalar_cf_p':float(p_s[i]),
                'affine_cf_p':float(p_a[i]),
                'bin_cf_p':float(p_bin[i]),
                'cv_fold':int(folds[i])
            })

        per.append({
            'target_qid':int(q),
            'target_kc_key':str(g.target_kc_key.iloc[0]),
            'event_n':n,
            'base_nll':nll(y,p_base),
            'scalar_oracle_nll':nll(y,p_scalar_or),
            'affine_oracle_nll':nll(y,p_affine_or),
            'scalar_cf_nll':nll(y,p_s),
            'affine_cf_nll':nll(y,p_a),
            'bin_cf_nll':nll(y,p_bin),
            'base_brier':brier(y,p_base),
            'scalar_cf_brier':brier(y,p_s),
            'affine_cf_brier':brier(y,p_a),
            'bin_cf_brier':brier(y,p_bin),
            'oracle_scalar_b':b_all,
            'oracle_affine_a':a_all,
            'oracle_affine_b':bb_all
        })

    pr=pd.DataFrame(preds)
    it=pd.DataFrame(per)
    pr.to_csv(
        out/'crossfit_event_predictions.csv.gz',
        index=False,compression='gzip'
    )
    it.to_csv(out/'per_target_headroom.csv',index=False)

    summary={
        'schema_version':'s17_finalbaseline_response_shape_oracle_v1',
        'target_n':int(len(it)),
        'event_n':int(len(pr)),
        'metric':'item-macro NLL primary; privileged oracle is diagnostic only',
        'item_macro_nll':{
            k:float(it[k].mean())
            for k in [
                'base_nll','scalar_oracle_nll','affine_oracle_nll',
                'scalar_cf_nll','affine_cf_nll','bin_cf_nll'
            ]
        },
        'gains':{
            'privileged_scalar_vs_base':
                float((it.base_nll-it.scalar_oracle_nll).mean()),
            'privileged_affine_vs_scalar':
                float((it.scalar_oracle_nll-it.affine_oracle_nll).mean()),
            'crossfit_scalar_vs_base':
                float((it.base_nll-it.scalar_cf_nll).mean()),
            'crossfit_affine_vs_scalar':
                float((it.scalar_cf_nll-it.affine_cf_nll).mean()),
            'crossfit_bin_vs_scalar':
                float((it.scalar_cf_nll-it.bin_cf_nll).mean()),
        },
        'bootstrap':{
            'affine_cf_over_scalar_cf':
                bootstrap_delta(
                    it,'scalar_cf_nll','affine_cf_nll',
                    args.bootstrap,args.seed+1
                ),
            'bin_cf_over_scalar_cf':
                bootstrap_delta(
                    it,'scalar_cf_nll','bin_cf_nll',
                    args.bootstrap,args.seed+2
                ),
        },
        'decision_rule':(
            'Do not build a student-conditioned method merely because point '
            'estimates are positive. Treat state-dependent shape as supported '
            'only if affine/bin cross-fitted gains over scalar are positive '
            'with target-bootstrap lower CI > 0 and practically non-negligible. '
            'Otherwise keep scalar calibration and move to measurement '
            'reliability/uncertainty.'
        )
    }
    (out/'summary.json').write_text(
        json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8'
    )
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
