#!/usr/bin/env python3
"""Publication plots from audited result tables; no retraining or new statistics.

Gain intervals are the existing pointwise paired KC-set bootstrap intervals.
Pool counts are resampling diagnostics, never independent replications.
"""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator,PercentFormatter

MAIN='KC6_Final'
TEAL='#237C83';RUST='#BA6550';INK='#263D50';SLATE='#71869B'
COLORS={'sqakt':TEAL,'akt':'#6C78A5','simplekt':'#BB8848','dkt':'#B66B83'}
LABELS={'sqakt':'SQAKT','akt':'AKT','simplekt':'simpleKT','dkt':'DKT'}

def theme():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':10,
        'axes.titlesize':11,'axes.titleweight':'medium','axes.edgecolor':'#9CA9B3',
        'axes.labelcolor':INK,'text.color':INK,'xtick.color':INK,'ytick.color':INK,
        'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,
        'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':8.5,
        'pdf.fonttype':42,'ps.fonttype':42,'savefig.facecolor':'white'})

def save(fig,out,name):
    fig.savefig(out/(name+'.png'),dpi=320,bbox_inches='tight',pad_inches=.08)
    fig.savefig(out/(name+'.pdf'),bbox_inches='tight',pad_inches=.08)
    plt.close(fig)

def clean(ax):
    ax.set_axisbelow(True);ax.grid(axis='y',color='#E4E9ED',lw=.65)
    ax.tick_params(length=3,width=.6)

def curve_data(run):
    run=Path(run)
    manifest=json.loads((run/'evaluation_manifest.json').read_text())
    if not manifest.get('evaluation_complement_fixed'):
        raise ValueError('A fixed evaluation complement is required for this figure')
    d=pd.read_csv(run/'learning_curve.csv')
    z=d[d.method==MAIN][['budget','item_macro_nll']].rename(columns={'item_macro_nll':'method_nll'})
    raw=d[d.method=='RawKT'][['budget','item_macro_nll']].rename(columns={'item_macro_nll':'raw_nll'})
    z=z.merge(raw,on='budget',validate='one_to_one').sort_values('budget')
    z['delta_nll']=z.raw_nll-z.method_nll
    ci=pd.read_csv(run/'paired_nll_comparisons.csv')
    ci=ci[(ci.better==MAIN)&(ci.baseline=='RawKT')]
    z=z.merge(ci[['budget','delta_nll','kc_set_ci_low','kc_set_ci_high']],on='budget',suffixes=('','_check'),validate='one_to_one')
    if not np.allclose(z.delta_nll,z.delta_nll_check,rtol=0,atol=1e-10):
        raise ValueError('Curve versus paired interval estimates do not match')
    return z.drop(columns='delta_nll_check')

def learning_figures(primary,out,fa=None,dbe=None,metric='gain'):
    primary=Path(primary);runs=[('XES3G5M',primary/'sqakt')]
    for title,path in [('FoundationalASSIST',fa),('DBE-KT22',dbe)]:
        if path:runs.append((title,Path(path)))
    size=(4.15,3.3) if len(runs)==1 else (7.5,2.95)
    fig,axes=plt.subplots(1,len(runs),figsize=size,squeeze=False,layout='constrained')
    exports=[]
    for ax,(title,run) in zip(axes[0],runs):
        z=curve_data(run);x=z.budget.to_numpy();y=z.delta_nll if metric=='gain' else z.method_nll
        ax.plot(x,y,color=TEAL,marker='o',lw=1.8,ms=4,mec='white',mew=.55)
        if metric=='gain':
            ax.fill_between(x,z.kc_set_ci_low.to_numpy(),z.kc_set_ci_high.to_numpy(),color=TEAL,alpha=.13,linewidth=0)
            ax.axhline(0,color='#A9B4BD',lw=.7,zorder=0)
        ax.set_title(title,pad=10);ax.set_xlabel('Calibration responses per item (k)')
        ax.set_ylabel('NLL reduction' if metric=='gain' else 'Method item-macro NLL')
        ax.set_xticks([0,1,2,5,10,20]);ax.set_xlim(-.7,20.7);clean(ax)
        if len(runs)>1:
            ax.set_xlabel('Calibration responses per item (k)',fontsize=8)
            ax.set_ylabel('NLL reduction' if metric=='gain' else 'Method item-macro NLL',fontsize=8)
            ax.set_title(title,pad=8,fontsize=9);ax.tick_params(labelsize=7)
            ax.yaxis.set_major_locator(MaxNLocator(4))
        exports.append(z.assign(dataset=title,backbone='sqakt'))
    save(fig,out,'figure5')
    pd.concat(exports,ignore_index=True).to_csv(out/'figure5_data.csv',index=False)
    fig,ax=plt.subplots(figsize=(5.1,3.45),layout='constrained')
    all_models=[]
    for model,marker in [('sqakt','o'),('akt','s'),('simplekt','^'),('dkt','D')]:
        z=curve_data(primary/model);y=z.delta_nll if metric=='gain' else z.method_nll
        ax.plot(z.budget,y,color=COLORS[model],marker=marker,lw=1.65,ms=4,mec='white',mew=.5,label=LABELS[model]+' + method')
        all_models.append(z.assign(dataset='XES3G5M',backbone=model))
    if metric=='gain':ax.axhline(0,color='#A9B4BD',lw=.7,zorder=0)
    ax.set(xlabel='Calibration responses per item (k)',ylabel='NLL reduction' if metric=='gain' else 'Method item-macro NLL',xticks=[0,1,2,5,10,20],xlim=(-.7,20.7))
    ax.legend(frameon=False,ncols=2,loc='upper center',bbox_to_anchor=(.5,1.25),columnspacing=1)
    clean(ax);save(fig,out,'xes_backbone_curves')
    pd.concat(all_models,ignore_index=True).to_csv(out/'xes_backbone_curves_data.csv',index=False)
    return [title for title,_ in runs]

def item_data(run):
    run=Path(run)
    a=pd.read_csv(run/'heterogeneity_k0.csv',dtype={'target_kc_key':str})
    b=pd.read_csv(run/'heterogeneity_k5.csv',dtype={'target_kc_key':str})
    z=b.merge(a[['target_qid','delta_nll']].rename(columns={'delta_nll':'gain_k0'}),on='target_qid',validate='one_to_one')
    z=z.rename(columns={'delta_nll':'gain_k5'})
    pool=run.parent.parent/'paper_outputs/heterogeneity_plot_items_k5.csv'
    if pool.is_file():
        p=pd.read_csv(pool)
        ck=z.merge(p[['target_qid','RawKT',MAIN]],on='target_qid',suffixes=('','_pool'),validate='one_to_one')
        if len(ck)!=len(z) or not np.allclose(ck.RawKT,ck.RawKT_pool,rtol=0,atol=1e-10) or not np.allclose(ck[MAIN],ck[MAIN+'_pool'],rtol=0,atol=1e-10):
            raise ValueError('Pool diagnostic and primary result do not match')
        return z.merge(p[['target_qid','harmed_seeds','pool_seeds']],on='target_qid',validate='one_to_one')
    sources=[run/'item_metrics.csv.gz',run.parent.parent/'attribution/sqakt/item_metrics.csv.gz']
    source=next((p for p in sources if p.is_file()),None)
    if source is None:raise FileNotFoundError('Need audited pool aggregate or item_metrics.csv.gz for pool diagnostic')
    d=pd.read_csv(source);d=d[(d.budget==5)&d.method.isin(['RawKT',MAIN])]
    p=d.pivot(index=['target_qid','seed'],columns='method',values='item_nll')
    counts=(p[MAIN]>p.RawKT).groupby('target_qid').agg(['sum','count']).reset_index().rename(columns={'sum':'harmed_seeds','count':'pool_seeds'})
    return z.merge(counts,on='target_qid',validate='one_to_one')

def scatter(ax,x,y,good,xlabel,ylabel,labels):
    clean(ax);ax.grid(False)
    for mask,col,label in [(~good,RUST,labels[1]),(good,TEAL,labels[0])]:
        ax.scatter(x[mask],y[mask],s=15,color=col,alpha=.65,edgecolors='white',linewidths=.22,label=label)
    lo=float(min(x.min(),y.min()));hi=float(max(x.max(),y.max()));span=hi-lo
    lo-=span*.04;hi+=span*.06
    ax.plot([lo,hi],[lo,hi],color='#8C9AA5',lw=.85,ls=(0,(3,3)),zorder=0)
    ax.set(xlim=(lo,hi),ylim=(lo,hi),xlabel=xlabel,ylabel=ylabel)
    ax.set_aspect('equal',adjustable='box');ax.xaxis.set_major_locator(MaxNLocator(5));ax.yaxis.set_major_locator(MaxNLocator(5))
    ax.legend(frameon=False,loc='upper left',handletextpad=.3,borderpad=.15,markerscale=.95)

def heterogeneity_figure(run,out):
    z=item_data(run);n=len(z);good=z.gain_k5>0
    if set(z.pool_seeds)!={10}:raise ValueError('This pool diagnostic requires all ten original pool seeds')
    fig=plt.figure(figsize=(8.3,6.3),layout='constrained')
    grid=fig.add_gridspec(2,2,height_ratios=[1.3,.7])
    axes=[fig.add_subplot(grid[0,0]),fig.add_subplot(grid[0,1]),fig.add_subplot(grid[1,:])]
    scatter(axes[0],z.RawKT,z[MAIN],good,'RawKT item NLL','Method item NLL (k = 5)',
        (f'Lower NLL ({int(good.sum())})',f'Higher NLL ({int((~good).sum())})'))
    improved=z.gain_k5>z.gain_k0
    scatter(axes[1],z.gain_k0,z.gain_k5,improved,'NLL reduction at k = 0','NLL reduction at k = 5',
        (f'Lower after MAP ({int(improved.sum())})',f'Higher after MAP ({int((~improved).sum())})'))
    for name in ['x','y']:
        getattr(axes[1],'set_'+name+'scale')('symlog',linthresh=.025,linscale=.8)
        getattr(axes[1],'set_'+name+'ticks')([-.1,0,.1,1.])
        getattr(axes[1],'set_'+name+'ticklabels')(['-0.1','0','0.1','1'])
    axes[1].set_xlabel('NLL reduction at k = 0\n(symmetric log scale)',fontsize=9)
    axes[1].set_ylabel('NLL reduction at k = 5\n(symmetric log scale)',fontsize=9)
    for fn in [axes[1].axhline,axes[1].axvline]:fn(0,color='#D2DADF',lw=.7,zorder=0)
    count=z.harmed_seeds.value_counts().reindex(range(int(z.pool_seeds.max())+1),fill_value=0)
    ax=axes[2];clean(ax);colors=[TEAL if i==0 else RUST if i==len(count)-1 else '#9BADBA' for i in count.index]
    ax.bar(count.index,count.to_numpy()/n,color=colors,width=.76,edgecolor='white',lw=.4)
    ax.yaxis.set_major_formatter(PercentFormatter(1,decimals=0))
    ax.set(xlabel='Pools with higher NLL (out of 10)',ylabel='Share of items',xticks=count.index,xlim=(-.7,len(count)-.3),ylim=(0,max(count)/n*1.19))
    for i in [0,len(count)-1]:ax.text(i,float(count.iloc[i])/n+.008,f'{int(count.iloc[i])}',ha='center',va='bottom',fontsize=9,color=colors[i])
    save(fig,out,'figure6_heterogeneity')
    z.to_csv(out/'figure6_item_data.csv',index=False)
    count.rename_axis('harmed_pools').reset_index(name='item_count').to_csv(out/'figure6_pool_counts.csv',index=False)
    x=z.gain_k0;y=z.gain_k5
    summary=dict(item_n=n,mean_gain_k0=float(x.mean()),mean_gain_k5=float(y.mean()),median_gain_k5=float(y.median()),
        positive_gain_k0=int((x>0).sum()),positive_gain_k5=int((y>0).sum()),map_lower_nll_items=int((y>x).sum()),
        map_higher_nll_items=int((y<x).sum()),both_positive=int(((x>0)&(y>0)).sum()),rescued=int(((x<=0)&(y>0)).sum()),
        lost=int(((x>0)&(y<=0)).sum()),both_nonpositive=int(((x<=0)&(y<=0)).sum()),
        harmed_at_least_once=int((z.harmed_seeds>=1).sum()),harmed_at_least_twice=int((z.harmed_seeds>=2).sum()),
        harmed_all_pools=int((z.harmed_seeds==z.pool_seeds).sum()),never_harmed=int((z.harmed_seeds==0).sum()),
        note='Descriptive paired means; pool changes affect calibration and evaluation complement; no item-level significance inference')
    (out/'figure6_summary.json').write_text(json.dumps(summary,indent=2))
    return summary

def draw_publication_figures(primary,out,fa=None,dbe=None,metric='gain'):
    theme();out=Path(out);out.mkdir(parents=True,exist_ok=True)
    domains=learning_figures(primary,out,fa,dbe,metric)
    summary=heterogeneity_figure(Path(primary)/'sqakt',out)
    (out/'figure_manifest.json').write_text(json.dumps(dict(domains=domains,all_three_domains_present=len(domains)==3,
        curve_metric=metric,figure5_backbone='SQAKT',xes_backbones=list(LABELS),rawkt_performance_curve_drawn=False,
        gain_interval='Existing pointwise paired KC-set 95% bootstrap; conditional on one trained backbone and synthetic panel',
        panel_letter_labels=False,training_or_evaluation_modified=False),indent=2))
    print('VISUALS_PASS',out,'domains',domains,flush=True)
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--primary-root',required=True);p.add_argument('--out',required=True)
    p.add_argument('--fa');p.add_argument('--dbe');p.add_argument('--curve-metric',choices=['gain','nll'],default='gain')
    a=p.parse_args();draw_publication_figures(a.primary_root,a.out,a.fa,a.dbe,a.curve_metric)
