#!/usr/bin/env python3
"""Exploratory fixed-grid robustness; never select a primary model on these results.

Only bridge L2 changes (10,100,1000). Every method in a case uses the same L2.
All content scopes, input hashes, MAP variance and held-out pool rules persist.
"""
import argparse,json
from pathlib import Path
import pandas as pd
import residual,comparisons
from measurement import atomic_csv,save_json,file_hash
from evaluation import evaluate,summaries

def main():
    p=argparse.ArgumentParser();p.add_argument('--teacher',required=True);p.add_argument('--root',required=True)
    p.add_argument('--responses',required=True);p.add_argument('--mathbert-free',required=True);p.add_argument('--mathbert-answer',required=True)
    p.add_argument('--direct',required=True);p.add_argument('--out',required=True);p.add_argument('--bootstrap',type=int,default=5000);a=p.parse_args()
    root=Path(a.root);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((root/'comparisons/sqakt/comparison_manifest.json').read_text())
    for key,path in [('mathbert_free',a.mathbert_free),('mathbert_answer',a.mathbert_answer),('direct',a.direct)]:
        if file_hash(path)!=manifest['raw_feature_hashes'][key]:raise ValueError('Changed representation input: '+key)
    g,e,r,paths=residual.load(a.teacher,a.responses)
    base=json.loads((root/'primary/sqakt/run_manifest.json').read_text())
    for key in ['events','group','responses']:
        if file_hash(paths[key])!=base['inputs'][key]['sha256']:raise ValueError('Changed primary input: '+key)
    maps={'MathBERT_linear':(comparisons.embeddings(a.mathbert_free),False),'MathBERT_RFF':(comparisons.embeddings(a.mathbert_free),True),
        'MathBERT_answer_RFF':(comparisons.embeddings(a.mathbert_answer),True)}
    direct=pd.read_csv(a.direct).set_index('target_qid')
    save_json(out/'regularization_sensitivity_manifest.json',dict(grid=[10.,100.,1000.],selection_on_outer_results=False,
        purpose='Exploratory robustness after primary results; all settings reported; primary L2=100 unchanged',
        inputs={k:dict(path=str(v),sha256=file_hash(v)) for k,v in paths.items()},budgets=[0,5],variance=1.,
        refit_scope='All mapper slopes including nested Joint; no backbone or LLM generation rerun'))
    result=[];effects=[];original_r=residual.fit_offset;original_c=comparisons.fit_offset
    for strength in [10.,100.,1000.]:
        case=out/('l2_'+str(int(strength)))
        if strength==100.:
            source=root/'comparisons/sqakt'
            if json.loads((source/'completion.json').read_text()).get('status')!='PASS':raise ValueError('Primary comparison incomplete')
        elif (case/'completion.json').is_file() and json.loads((case/'completion.json').read_text()).get('status')=='PASS':source=case
        else:
            if case.exists():raise ValueError('Preserve incomplete sensitivity output for diagnosis: '+str(case))
            case.mkdir()
            def configured(*args,**kwargs):
                args=list(args)
                if len(args)>=5:args[4]=strength;kwargs.pop('l2',None)
                else:kwargs['l2']=strength
                return original_r(*args,**kwargs)
            try:
                residual.fit_offset=configured;comparisons.fit_offset=configured
                prior=residual.fit_priors(g,e,r,case,suite='main')
                extra,models,scopes,meta=comparisons.fit_all(g,e,r,prior,maps,direct)
                prior=pd.concat([prior,extra],ignore_index=True);atomic_csv(prior,case/'prior_table.csv')
                save_json(case/'comparison_models.json',models);save_json(case/'joint_nesting_scopes.json',scopes)
                items,curve=evaluate(g,e,prior,case,budgets=[0,5]);summaries(items,case,a.bootstrap)
                save_json(case/'completion.json',dict(status='PASS',bridge_l2=strength,exploratory=True))
            finally:residual.fit_offset=original_r;comparisons.fit_offset=original_c
            source=case
        c=pd.read_csv(source/'learning_curve.csv');result.append(c[c.budget.isin([0,5])].assign(bridge_l2=strength))
        d=pd.read_csv(source/'paired_nll_comparisons.csv');effects.append(d[d.budget.isin([0,5])].assign(bridge_l2=strength))
    atomic_csv(pd.concat(result,ignore_index=True),out/'regularization_sensitivity_metrics.csv')
    atomic_csv(pd.concat(effects,ignore_index=True),out/'regularization_sensitivity_effects.csv')
    save_json(out/'completion.json',dict(status='PASS',primary_results_replaced=False,selected_best_setting=False))
    print('SENSITIVITY_PASS',out,flush=True)

if __name__=='__main__':main()
