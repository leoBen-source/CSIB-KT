#!/usr/bin/env python3
"""Read-only timestamp audit; row index is never treated as chronology."""
import argparse,csv,json
from decimal import Decimal,InvalidOperation
from pathlib import Path
from collections import Counter
import pandas as pd
from measurement import file_hash

def stamp(x):
    try:
        v=Decimal(str(x).strip())
        return v if v.is_finite() and v>=0 else None
    except (InvalidOperation,ValueError):return None
def write(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2))
def main():
    p=argparse.ArgumentParser();p.add_argument('--teacher',required=True);p.add_argument('--raw-source',required=True);p.add_argument('--out',required=True);a=p.parse_args();teacher=Path(a.teacher).resolve();raw=Path(a.raw_source).resolve();out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((teacher/'inputs/input_manifest.json').read_text());source=Path(manifest['event_source_csv'])
    if file_hash(source)!=manifest['coordinate_source_sha256']:raise ValueError('Coordinate source hash changed')
    events=pd.read_csv(teacher/'clean/teacher_aligned_event_baseline_targetidfree.csv.gz',dtype={'event_id':str,'student_key':str})
    if events.duplicated(['student_key','target_qid']).any():raise ValueError('Duplicate selected student-item events')
    excluded=set(map(int,pd.read_csv(teacher/'clean/content_group_safe_item_targets_targetidfree.csv').target_qid))
    requests={int(i):z for i,z in events.groupby('row_index')};selected={};mismatch=[];future=[];missing_warm_time=[];matched=0
    with source.open(newline='',encoding='utf8') as f:
        reader=csv.DictReader(f)
        if 'timestamps' not in reader.fieldnames:raise ValueError('Coordinate timestamps column missing')
        for ridx,row in enumerate(reader):
            if ridx not in requests:continue
            qs=[int(float(v)) for v in row['questions'].split(',')];ys=[int(float(v)) for v in row['responses'].split(',')];ts=[stamp(v) for v in row['timestamps'].split(',')]
            if not len(qs)==len(ys)==len(ts):raise ValueError('Coordinate sequence lengths differ')
            prefix_max=[None];prefix_unknown=[0];mx=None;unknown=0
            for q,y,t in zip(qs,ys,ts):
                if q>=0 and q not in excluded and y in [0,1]:
                    if t is None:unknown+=1
                    else:mx=t if mx is None else max(mx,t)
                prefix_max.append(mx);prefix_unknown.append(unknown)
            for ev in requests[ridx].itertuples(index=False):
                j=int(ev.target_position);q=int(ev.target_qid);key=(str(ev.student_key),q)
                if j>=len(qs) or str(row['uid'])!=key[0] or qs[j]!=q or ys[j]!=int(ev.label):mismatch.append(str(ev.event_id));continue
                matched+=1;selected[key]=dict(event_id=str(ev.event_id),time=ts[j],label=int(ev.label))
                if prefix_unknown[j]:missing_warm_time.append(str(ev.event_id))
                if ts[j] is not None and prefix_max[j] is not None and prefix_max[j]>ts[j]:future.append(str(ev.event_id))
    earliest={};min_n=Counter();missing=Counter();seen=Counter();raw_match=Counter()
    with raw.open(newline='',encoding='utf8') as f:
        reader=csv.DictReader(f)
        if not {'uid','questions','responses','timestamps'}<=set(reader.fieldnames):raise ValueError('Original source lacks aligned time fields')
        for row in reader:
            uid=str(row['uid']);qs=row['questions'].split(',');ys=row['responses'].split(',');ts=row['timestamps'].split(',')
            if not len(qs)==len(ys)==len(ts):raise ValueError('Original sequence lengths differ')
            for q,y,t in zip(qs,ys,ts):
                key=(uid,int(float(q)))
                try:response=int(float(y))
                except ValueError:continue
                if key not in selected or response not in [0,1]:continue
                seen[key]+=1;value=stamp(t)
                if value is None:missing[key]+=1;continue
                if key not in earliest or value<earliest[key]:earliest[key]=value;min_n[key]=1
                elif value==earliest[key]:min_n[key]+=1
                if value==selected[key]['time'] and response==selected[key]['label']:raw_match[key]+=1
    earlier=[];ties=[];unknown=[];notfound=[]
    for key,z in selected.items():
        t=z['time'];lo=earliest.get(key)
        if t is None or lo is None or missing[key]:unknown.append(z['event_id']);continue
        if not raw_match[key]:notfound.append(z['event_id'])
        if lo<t:earlier.append(dict(event_id=z['event_id'],selected_timestamp=str(t),earliest_timestamp=str(lo)))
        elif lo==t and min_n[key]>1:ties.append(z['event_id'])
    known_times=[z['time'] for z in selected.values() if z['time'] is not None]
    plausible_ms=bool(known_times) and all(Decimal('100000000000')<=t<=Decimal('100000000000000') for t in known_times)
    failures=bool(mismatch or future or (earlier and plausible_ms) or notfound or matched!=len(events))
    review=bool(unknown or ties or missing_warm_time or not plausible_ms)
    status='FAIL' if failures else 'REVIEW_TIMESTAMP_COVERAGE_OR_TIES' if review else 'PASS_WITHIN_PROVIDED_ORIGINAL_SOURCE'
    report=dict(status=status,event_n=len(events),matched_coordinate_n=matched,coordinate_mismatch_n=len(mismatch),earlier_original_response_n=len(earlier),same_minimum_timestamp_ambiguous_n=len(ties),unknown_response_time_n=len(unknown),unmatched_original_event_n=len(notfound),warm_prefix_later_than_target_n=len(future),warm_prefix_missing_time_n=len(missing_warm_time),global_chronological_first_response_verified=status.startswith('PASS'),coverage_scope='All rows in the explicitly supplied original question-level CSV; no assertion about unavailable external history',timestamp_units='Interaction START timestamps in milliseconds according to published XES3G5M release; no invented row ordering',plausible_epoch_millisecond_scale=plausible_ms,selected_timestamp_min=str(min(known_times)) if known_times else None,selected_timestamp_max=str(max(known_times)) if known_times else None,response_completion_availability_verified=False,availability_note='The dataset lacks response end timestamps; start-order auditing is not a wall-clock answer-availability replay',coordinate_source_sha256=file_hash(source),original_source_sha256=file_hash(raw),examples_earlier=earlier[:20],examples_mismatch=mismatch[:20],examples_ties=ties[:20],examples_unknown=unknown[:20],examples_unmatched=notfound[:20],examples_future_history=future[:20],event_support_modified=False)
    write(out/'timestamp_first_response_audit.json',report);print('XES_TIMESTAMP_AUDIT',status,'earlier',len(earlier),'ambiguous_ties',len(ties),flush=True)
    return 0 if status.startswith('PASS') else 2
if __name__=='__main__':raise SystemExit(main())
