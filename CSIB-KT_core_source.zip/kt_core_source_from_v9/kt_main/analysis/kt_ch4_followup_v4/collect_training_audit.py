#!/usr/bin/env python3
"""Return small training provenance; never upload checkpoints or giant CSVs."""
import argparse,csv,json,sys,copy
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import pandas as pd
from measurement import file_hash,save_json

def main():
    p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--teacher',required=True);p.add_argument('--multi-root',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    root=Path(a.multi_root);out=Path(a.out);teacher=Path(a.teacher)
    sys.path[:0] = [str(Path(a.project).resolve() / 'examples'), str(Path(a.project).resolve())]
    from pykt.datasets import init_dataset4train
    if out.exists():raise ValueError('Fresh audit output directory required')
    out.mkdir(parents=True);cold=set(pd.read_csv(teacher/'clean/content_group_safe_item_targets_targetidfree.csv').target_qid.astype(int));results=[]
    for model in ['akt','simplekt','dkt']:
        selected=root/f'models/{model}/selected_run.txt';run=Path(selected.read_text().strip());cfg=json.loads((run/'config.json').read_text());dc=cfg['data_config'];data=Path(cfg['params']['dataset_dir_override'])
        source=data/dc['train_valid_file'];counts={'train':0,'validation':0};allcounts={'train':0,'validation':0}
        with source.open(newline='',encoding='utf8') as f:
            for row in csv.DictReader(f):
                role='validation' if int(row['fold'])==3 else 'train'
                for token in row['questions'].split(','):
                    q=int(float(token))
                    if q>=0:allcounts[role]+=1;counts[role]+=q in cold
        actual_dc=copy.deepcopy(dc)
        if Path(actual_dc['dpath']).resolve()!=data.resolve():raise ValueError('Saved data path and override disagree; inspect before auditing')
        dataset=cfg['params']['dataset_name'];fold=int(cfg['params']['fold'])
        loaders=init_dataset4train(dataset_name=dataset,model_name=model,data_config={dataset:actual_dc},i=fold,batch_size=64)
        tensor_checks={}
        for role,loader in zip(['train','validation'],loaders[:2]):
            dori=loader.dataset.dori
            tensors=[dori[k] for k in ['qseqs','shft_qseqs'] if k in dori]
            if not tensors:raise ValueError('Cannot locate actual question tensors')
            observed=set()
            for tensor in tensors:observed.update(map(int,tensor.detach().cpu().unique().tolist()))
            overlap=sorted(observed&cold);tensor_checks[role]=dict(cold_unique_qids=overlap,question_tensor_names=[k for k in ['qseqs','shft_qseqs'] if k in dori])
            if overlap:raise ValueError('Cold interactions present in loaded tensors or cached dataset: '+str(overlap))
        del loaders
        cache_files=[dict(path=str(f),sha256=file_hash(f),bytes=f.stat().st_size) for f in data.glob('*.pkl')]
        result=dict(model=model,run=str(run),source=str(source.resolve()),source_sha256=file_hash(source),checkpoint_sha256=file_hash(run/'qid_model.ckpt'),cold_event_counts=counts,total_event_counts=allcounts,actual_loader_checks=tensor_checks,dataset_cache_files=cache_files,
                    config=cfg,projection_manifest=json.loads((data/'projection_manifest.json').read_text()))
        if any(counts.values()):raise ValueError('Cold interactions present in actual configured training source')
        save_json(out/f'{model}_audit.json',result);results.append(result)
    save_json(out/'status.json',dict(status='PASS',models=[r['model'] for r in results],excluded_target_n=len(cold)))
    with ZipFile(out/'small_training_audit.zip','w',ZIP_DEFLATED) as z:
        for f in sorted(out.glob('*.json')):z.write(f,f.name)
    print('UPLOAD',out/'small_training_audit.zip',flush=True)
if __name__=='__main__':main()
