#!/usr/bin/env python3
"""Describe independent SQAKT training seeds; pool draws are not treated as runs."""
import argparse,json
from pathlib import Path
import pandas as pd

p=argparse.ArgumentParser();p.add_argument('--root',required=True);a=p.parse_args();root=Path(a.root)
sources=[(42,root/'comparisons/sqakt')]+[(s,root/f'training_seeds/seed_{s}/comparisons') for s in [43,44]]
curves=[];paired=[];reference=None
for seed,run in sources:
    if json.loads((run/'completion.json').read_text()).get('status')!='PASS':raise ValueError('Seed incomplete: '+str(seed))
    e=json.loads((run/'evaluation_manifest.json').read_text())
    signature={k:e[k] for k in ['target_n','event_n','pool_size','seeds','evaluation_complement_fixed']}
    if reference is None:reference=signature
    elif signature!=reference:raise ValueError('Seed evaluation contract differs: '+str(seed))
    if seed!=42:
        receipt=json.loads((run.parent/'teacher/models/shared_teacher/training_receipt.json').read_text())
        audit=json.loads((run.parent/'teacher/restart_audit.json').read_text())
        if receipt.get('training_seed')!=seed or not audit.get('same_events_and_labels'):raise ValueError('Seed training audit differs')
    d=pd.read_csv(run/'learning_curve.csv');curves.append(d[d.budget.isin([0,5])].assign(training_seed=seed))
    d=pd.read_csv(run/'paired_nll_comparisons.csv');paired.append(d[d.budget.isin([0,5])].assign(training_seed=seed))
out=root/'training_seeds';out.mkdir(parents=True,exist_ok=True)
c=pd.concat(curves,ignore_index=True);d=pd.concat(paired,ignore_index=True)
c.to_csv(out/'training_seed_metrics.csv',index=False);d.to_csv(out/'training_seed_effects.csv',index=False)
c.groupby(['budget','method'],as_index=False).agg(training_seed_n=('training_seed','nunique'),nll_mean=('item_macro_nll','mean'),nll_sd=('item_macro_nll','std'),auc_mean=('pooled_auc','mean'),auc_sd=('pooled_auc','std')).to_csv(out/'training_seed_summary.csv',index=False)
d.groupby(['budget','baseline'],as_index=False).agg(delta_nll_mean=('delta_nll','mean'),delta_nll_sd=('delta_nll','std'),positive_training_seeds=('delta_nll',lambda x:int((x>0).sum()))).to_csv(out/'training_seed_effect_summary.csv',index=False)
(out/'training_seed_manifest.json').write_text(json.dumps(dict(training_seeds=[42,43,44],backbone='SQAKT',new_independent_trainings=2,existing_seed42_reused=True,
    evaluation_contract=reference,synthetic_panel='fixed; no independent generation inference',report='all per-seed estimates plus descriptive mean/sample SD; no claim that pool draws are training replications'),indent=2))
print('TRAINING_SEEDS_PASS',out,flush=True)
