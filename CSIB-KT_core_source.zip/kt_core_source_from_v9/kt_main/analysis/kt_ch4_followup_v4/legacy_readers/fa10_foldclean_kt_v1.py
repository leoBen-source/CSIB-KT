#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FoundationalASSIST strict fold-clean GRU-KT baseline.

Mirrors the DBE StrictColdGRUKT contract:
- 5 frozen content-safe target folds.
- For outer fold f, ALL interactions of target items in f are removed from
  train/validation sequences and from valid/eval history-state updates.
- Query representation = skill-set embedding + support-gated question-ID residual.
  Every outer-fold target qID has support gate exactly zero.
- KT weights are fit on frozen train students; early stopping uses frozen valid
  students on warm events only.
- First target exposure is scored causally from warm-only history.
- valid target events are exported for human item-residual calibration.
- eval target events are exported for final qualification / later NLL-HRS.
"""
from __future__ import annotations
import argparse, hashlib, json, math, random
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader


def find_col(df, names, required=True):
    low = {str(c).strip().lower(): c for c in df.columns}
    for n in names:
        if str(n).strip().lower() in low:
            return low[str(n).strip().lower()]
    if required:
        raise RuntimeError(f"none of {names} in {list(df.columns)}")
    return None


def qid_str(x):
    s = str(x).strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s


def stable_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    try:
        torch.use_deterministic_algorithms(True, warn_only=True)
    except Exception:
        pass


@dataclass
class Seq:
    q: list[int]
    k: list[list[int]]
    y: list[int]


class SeqDataset(Dataset):
    def __init__(self, seqs, max_len=300):
        self.samples = []
        for s in seqs:
            for st in range(0, len(s.q), max_len):
                ed = min(len(s.q), st + max_len)
                if ed - st >= 2:
                    self.samples.append(Seq(s.q[st:ed], s.k[st:ed], s.y[st:ed]))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, i):
        return self.samples[i]


def collate(batch):
    B = len(batch)
    L = max(len(x.q) for x in batch)
    K = max(len(ks) for x in batch for ks in x.k)
    q = torch.zeros(B, L, dtype=torch.long)
    kc = torch.full((B, L, K), -1, dtype=torch.long)
    y = torch.zeros(B, L, dtype=torch.long)
    mask = torch.zeros(B, L, dtype=torch.bool)
    for b, s in enumerate(batch):
        n = len(s.q)
        q[b, :n] = torch.tensor(s.q, dtype=torch.long)
        y[b, :n] = torch.tensor(s.y, dtype=torch.long)
        mask[b, :n] = 1
        for t, ks in enumerate(s.k):
            kc[b, t, :len(ks)] = torch.tensor(ks, dtype=torch.long)
    return q, kc, y, mask


class StrictColdGRUKT(nn.Module):
    def __init__(self, nq, nkc, d=128, dropout=.2, seen_mask=None):
        super().__init__()
        self.d = d
        self.q_emb = nn.Embedding(nq, d)
        self.kc_emb = nn.Embedding(nkc + 1, d, padding_idx=nkc)
        self.r_emb = nn.Embedding(2, d)
        self.in_norm = nn.LayerNorm(d)
        self.q_norm = nn.LayerNorm(d)
        self.drop = nn.Dropout(dropout)
        self.gru = nn.GRU(d, d, batch_first=True)
        self.h0 = nn.Parameter(torch.zeros(d))
        self.head = nn.Sequential(
            nn.Linear(2*d, d), nn.ReLU(), nn.Dropout(dropout), nn.Linear(d, 1)
        )
        if seen_mask is None:
            seen_mask = torch.ones(nq, dtype=torch.float32)
        self.register_buffer("seen_q", seen_mask.float())

    def kc_pool(self, kc):
        pad = self.kc_emb.num_embeddings - 1
        idx = torch.where(kc < 0, torch.full_like(kc, pad), kc)
        e = self.kc_emb(idx)
        m = (kc >= 0).unsqueeze(-1)
        return (e*m).sum(-2) / m.sum(-2).clamp_min(1)

    def query(self, q, kc):
        k = self.kc_pool(kc)
        gate = self.seen_q[q].unsqueeze(-1)
        return self.q_norm(k + gate*self.q_emb(q))

    def forward(self, q, kc, y, mask):
        k = self.kc_pool(kc)
        gate = self.seen_q[q].unsqueeze(-1)
        x = self.in_norm(k + gate*self.q_emb(q) + self.r_emb(y.clamp(0, 1)))
        x = self.drop(x)
        out, _ = self.gru(x)
        B, L, D = out.shape
        hp = torch.cat([self.h0.view(1,1,D).expand(B,1,D), out[:, :-1, :]], dim=1)
        qu = self.query(q, kc)
        return self.head(torch.cat([hp, qu], dim=-1)).squeeze(-1)

    def one_step_update(self, h, q, kc, y):
        k = self.kc_pool(kc)
        gate = self.seen_q[q].unsqueeze(-1)
        x = self.in_norm(k + gate*self.q_emb(q) + self.r_emb(y))
        _, hn = self.gru(x[:, None, :], h[None, :, :])
        return hn[0]

    def score_from_state(self, h, q, kc):
        qu = self.query(q, kc)
        return self.head(torch.cat([h, qu], dim=-1)).squeeze(-1)


def prepare_tables(data_dir: Path, user_split_csv: Path, contract_manifest: Path):
    # Skills
    S = pd.read_csv(data_dir/"Skills.csv", low_memory=False)
    sp = find_col(S, ["problem_id"])
    sk = find_col(S, ["skill_id"])
    qkc = defaultdict(set)
    for q, k in S[[sp, sk]].dropna().itertuples(index=False, name=None):
        qkc[qid_str(q)].add(str(k).strip())

    manifest = json.loads(contract_manifest.read_text(encoding="utf-8"))
    ambiguous = set(str(x) for x in manifest.get("ambiguous_problem_ids_excluded", []))
    for q in ambiguous:
        qkc.pop(q, None)

    # Frozen user split produced before Qwen generation.
    U = pd.read_csv(user_split_csv, dtype=str)
    uc = find_col(U, ["user_xid", "user_id", "student_id"])
    sc = find_col(U, ["user_split"])
    split_map = dict(zip(U[uc].astype(str), U[sc].astype(str)))
    if set(split_map.values()) - {"train", "valid", "eval"}:
        raise RuntimeError("unexpected user split labels")

    # Interactions: only fields required by KT.
    hdr = pd.read_csv(data_dir/"Interactions.csv", nrows=0)
    iq = find_col(hdr, ["problem_id"])
    iu = find_col(hdr, ["user_id", "user_xid", "student_id"])
    iy = find_col(hdr, ["discrete_score"])
    it = find_col(hdr, ["end_time"], required=False)
    iid = find_col(hdr, ["id"], required=False)
    use = [iq, iu, iy] + ([it] if it else []) + ([iid] if iid else [])
    I = pd.read_csv(data_dir/"Interactions.csv", usecols=use, low_memory=False)
    I["_qid"] = I[iq].map(qid_str)
    I["_user"] = I[iu].astype(str)
    I["_yraw"] = pd.to_numeric(I[iy], errors="coerce")
    I = I[I["_yraw"].notna()].copy()
    I["_y"] = (I["_yraw"] >= 1.0).astype(int)
    I["_source_row"] = np.arange(len(I), dtype=np.int64)
    if it:
        I["_time"] = pd.to_datetime(I[it], errors="coerce", utc=True)
    else:
        I["_time"] = pd.NaT

    # Same general exclusion as the frozen target contract.
    I = I[~I["_qid"].isin(ambiguous)].copy()
    I = I[I["_qid"].isin(set(qkc.keys()))].copy()
    I["_split"] = I["_user"].map(split_map)
    if I["_split"].isna().any():
        miss = int(I["_split"].isna().sum())
        raise RuntimeError(f"{miss} interaction rows belong to users absent from frozen split")
    I = I.sort_values(["_user", "_time", "_source_row"], kind="mergesort").reset_index(drop=True)

    qkc = {q: tuple(sorted(v)) for q, v in qkc.items() if v}
    return I, qkc, split_map


def build_maps(I, qkc):
    qids = sorted(set(I["_qid"]) & set(qkc))
    kcs = sorted({k for q in qids for k in qkc[q]})
    return {q:i for i,q in enumerate(qids)}, {k:i for i,k in enumerate(kcs)}


def kidx(q, qkc, kmap):
    return [kmap[k] for k in qkc[q]]


def make_sequences(I, qkc, qmap, kmap, cold):
    z = I[~I["_qid"].isin(cold)].copy()
    out = {"train": [], "valid": []}
    for sp in ["train", "valid"]:
        for _, g in z[z["_split"] == sp].groupby("_user", sort=False):
            qs, ks, ys = [], [], []
            for q_raw, y_raw in g[["_qid", "_y"]].itertuples(index=False, name=None):
                q = str(q_raw)
                if q not in qmap or q not in qkc:
                    continue
                qs.append(qmap[q])
                ks.append(kidx(q, qkc, kmap))
                ys.append(int(y_raw))
            if len(qs) >= 2:
                out[sp].append(Seq(qs, ks, ys))
    return out


def eval_loader(model, loader, device):
    model.eval()
    loss = 0.0
    n = 0
    with torch.inference_mode():
        for q, k, y, m in loader:
            q, k, y, m = [x.to(device) for x in [q,k,y,m]]
            logits = model(q, k, y, m)
            l = nn.functional.binary_cross_entropy_with_logits(
                logits[m], y[m].float(), reduction="sum"
            )
            loss += float(l)
            n += int(m.sum())
    return loss / max(n, 1)


def train_model(args, I, qkc, qmap, kmap, cold, seen_mask, out):
    seqs = make_sequences(I, qkc, qmap, kmap, cold)
    tr = SeqDataset(seqs["train"], args.max_seq_len)
    va = SeqDataset(seqs["valid"], args.max_seq_len)
    if len(tr) == 0 or len(va) == 0:
        raise RuntimeError("empty train/valid sequence dataset")
    dl = DataLoader(tr, batch_size=args.batch_size, shuffle=True, collate_fn=collate, num_workers=0)
    vl = DataLoader(va, batch_size=args.batch_size, shuffle=False, collate_fn=collate, num_workers=0)

    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))
    model = StrictColdGRUKT(len(qmap), len(kmap), args.d_model, args.dropout, seen_mask).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    best = math.inf
    bad = 0
    hist = []
    for ep in range(1, args.epochs + 1):
        model.train()
        tl, n = 0.0, 0
        for q, k, y, m in dl:
            q, k, y, m = [x.to(device) for x in [q,k,y,m]]
            opt.zero_grad(set_to_none=True)
            logits = model(q, k, y, m)
            loss = nn.functional.binary_cross_entropy_with_logits(logits[m], y[m].float())
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            tl += float(loss.detach()) * int(m.sum())
            n += int(m.sum())
        vn = eval_loader(model, vl, device)
        trn = tl / max(n, 1)
        hist.append({"epoch": ep, "train_nll": trn, "valid_warm_nll": vn})
        print(f"[FA-KT] outer={args.outer_fold} epoch={ep} train_nll={trn:.6f} valid_warm_nll={vn:.6f}", flush=True)
        if vn < best - 1e-5:
            best = vn
            bad = 0
            torch.save(model.state_dict(), out/"model.pt")
        else:
            bad += 1
            if bad >= args.patience:
                break

    pd.DataFrame(hist).to_csv(out/"training_curve.csv", index=False)
    model.load_state_dict(torch.load(out/"model.pt", map_location=device))
    model.eval()
    return model, best, device, len(tr), len(va)


def score_split(model, device, args, I, qkc, qmap, kmap, cold, contract, split_name):
    info = contract.set_index("target_qid").to_dict("index")
    z = I[I["_split"] == split_name].copy()
    rows = []

    for q in cold:
        if float(model.seen_q[qmap[q]].item()) != 0.0:
            raise RuntimeError(f"cold q {q} seen gate nonzero")

    with torch.inference_mode():
        for user, g in z.groupby("_user", sort=False):
            h = model.h0.detach().to(device).view(1, -1)
            seen_target = set()
            warm_n = 0
            for ordinal, (q_raw, y_raw) in enumerate(
                g[["_qid", "_y"]].itertuples(index=False, name=None)
            ):
                q = str(q_raw)
                y = int(y_raw)
                if q not in qmap or q not in qkc:
                    continue
                qi = torch.tensor([qmap[q]], dtype=torch.long, device=device)
                kc = torch.tensor([kidx(q, qkc, kmap)], dtype=torch.long, device=device)

                if q in cold:
                    # Score first exposure only. Every cold-fold event is excluded
                    # from history updates, even after it has been scored.
                    if q in seen_target:
                        continue
                    seen_target.add(q)
                    if warm_n < args.min_warm_history:
                        continue
                    logit = model.score_from_state(h, qi, kc)[0]
                    inf = info[q]
                    rows.append({
                        "event_id": f"{split_name}|{user}|ord{ordinal}|q{q}",
                        "student_key": str(user),
                        "student_split": split_name,
                        "target_position": int(ordinal),
                        "target_qid": q,
                        "outer_fold": int(args.outer_fold),
                        "target_kc_key": str(inf["target_kc_key"]),
                        "label": y,
                        "warm_history_len": int(warm_n),
                        "teacher_kc_uniform": float(torch.sigmoid(logit).cpu()),
                    })
                    continue

                yy = torch.tensor([y], dtype=torch.long, device=device)
                h = model.one_step_update(h, qi, kc, yy)
                warm_n += 1

    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", required=True)
    ap.add_argument("--contract_csv", required=True)
    ap.add_argument("--contract_manifest", required=True)
    ap.add_argument("--user_split_csv", required=True)
    ap.add_argument("--outer_fold", type=int, required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--d_model", type=int, default=128)
    ap.add_argument("--dropout", type=float, default=.2)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--weight_decay", type=float, default=1e-5)
    ap.add_argument("--batch_size", type=int, default=16)
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--patience", type=int, default=10)
    ap.add_argument("--max_seq_len", type=int, default=300)
    ap.add_argument("--min_warm_history", type=int, default=1)
    ap.add_argument("--device", default="")
    args = ap.parse_args()

    stable_seed(args.seed)
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    contract = pd.read_csv(args.contract_csv, dtype={"target_qid": str}, low_memory=False)
    contract["target_qid"] = contract["target_qid"].map(qid_str)
    cold = set(
        contract.loc[contract["content_group_fold"].astype(int) == args.outer_fold, "target_qid"]
    )
    if not cold:
        raise RuntimeError("empty cold fold")

    I, qkc, split_map = prepare_tables(
        Path(args.data_dir), Path(args.user_split_csv), Path(args.contract_manifest)
    )
    qmap, kmap = build_maps(I, qkc)
    missing = sorted(cold - set(qmap))
    if missing:
        raise RuntimeError(f"cold qids missing qmap: {missing[:20]}")

    # Seen support is based only on actual TRAIN users after removing this cold fold.
    trainq = set(
        I[(I["_split"] == "train") & (~I["_qid"].isin(cold))]["_qid"].astype(str)
    )
    seen = torch.tensor(
        [1.0 if q in trainq else 0.0 for q,_ in sorted(qmap.items(), key=lambda kv:kv[1])],
        dtype=torch.float32
    )
    if any(float(seen[qmap[q]]) != 0.0 for q in cold):
        raise RuntimeError("cold seen-mask construction failure")

    model, best, device, train_seq_n, valid_seq_n = train_model(
        args, I, qkc, qmap, kmap, cold, seen, out
    )
    valid_ev = score_split(model, device, args, I, qkc, qmap, kmap, cold, contract, "valid")
    eval_ev = score_split(model, device, args, I, qkc, qmap, kmap, cold, contract, "eval")

    if eval_ev.empty:
        raise RuntimeError("no strict-cold eval events")
    observed = set(eval_ev["target_qid"].astype(str))
    miss_eval = sorted(cold - observed)
    if miss_eval:
        raise RuntimeError(f"no eval event for {len(miss_eval)} targets, sample={miss_eval[:20]}")
    observed_valid = set(valid_ev["target_qid"].astype(str))
    miss_valid = sorted(cold - observed_valid)
    if miss_valid:
        raise RuntimeError(f"no valid calibration event for {len(miss_valid)} targets, sample={miss_valid[:20]}")

    valid_ev.to_csv(out/"valid_event_baseline.csv.gz", index=False, compression="gzip")
    eval_ev.to_csv(out/"eval_event_baseline.csv.gz", index=False, compression="gzip")

    cfg = {
        "schema_version": "fa10_foldclean_kt_v1",
        "outer_fold": args.outer_fold,
        "cold_target_n": len(cold),
        "valid_event_n": int(len(valid_ev)),
        "eval_event_n": int(len(eval_ev)),
        "valid_student_n": int(valid_ev["student_key"].nunique()),
        "eval_student_n": int(eval_ev["student_key"].nunique()),
        "valid_target_min_event_n": int(valid_ev.groupby("target_qid").size().min()),
        "eval_target_min_event_n": int(eval_ev.groupby("target_qid").size().min()),
        "best_valid_warm_nll": float(best),
        "n_questions": len(qmap),
        "n_skills": len(kmap),
        "train_seen_q_n": int(seen.sum()),
        "train_sequence_chunks": int(train_seq_n),
        "valid_sequence_chunks": int(valid_seq_n),
        "model_seed": args.seed,
        "target_id_contract": (
            "all outer-fold target qID support gates are zero; all cold-fold "
            "events are omitted from state updates; first target exposure only"
        ),
        "student_role_contract": (
            "train=KT fitting; valid=warm-event early stopping plus later target-item "
            "residual calibration; eval=qualification and later downstream evaluation"
        ),
        "hyperparameters": {
            "d_model": args.d_model, "dropout": args.dropout, "lr": args.lr,
            "weight_decay": args.weight_decay, "batch_size": args.batch_size,
            "epochs_max": args.epochs, "patience": args.patience,
            "max_seq_len": args.max_seq_len, "min_warm_history": args.min_warm_history,
        },
    }
    (out/"manifest.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(cfg, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
