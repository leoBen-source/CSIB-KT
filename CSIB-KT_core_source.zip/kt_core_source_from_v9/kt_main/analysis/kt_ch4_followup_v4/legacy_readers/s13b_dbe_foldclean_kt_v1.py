#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Train and score a strict-cold, target-ID-free GRU KT prior on DBE-KT22.

The model intentionally mirrors the final paper decomposition rather than chasing
DBE SOTA:
  history encoder: real warm human interactions (question id + KC-set + response)
  query: official KC-set + support-gated question-ID residual
  strict target: all target-fold interactions are removed from fitting; target
                 question support is zero, so its ID residual is exactly zero

Student split is fixed by hash: train/valid/eval.  The eval students are never
used to fit model weights.  First target exposure is scored from causal warm-only
history; all target-fold events are omitted from state updates.
"""
from __future__ import annotations
import argparse, hashlib, json, math, random
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader


def find_col(df,names,required=True):
    low={str(c).lower():c for c in df.columns}
    for n in names:
        if n.lower() in low:return low[n.lower()]
    if required: raise RuntimeError(f"none of {names} in {list(df.columns)}")
    return None

def qid_int(x): return int(float(x))
def boolish(x):
    s=str(x).strip().lower()
    if s in {"true","1","t","yes","y"}: return 1
    if s in {"false","0","f","no","n"}: return 0
    return None

def hbucket(x,seed):
    s=hashlib.sha256(f"{seed}|{x}".encode()).hexdigest(); return int(s[:12],16)%100

def usplit(x,seed,train_pct,valid_pct):
    b=hbucket(x,seed)
    if b<train_pct:return "train"
    if b<train_pct+valid_pct:return "valid"
    return "eval"

def stable_seed(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


@dataclass
class Seq:
    q: list[int]; k: list[list[int]]; y: list[int]

class SeqDataset(Dataset):
    def __init__(self, seqs, max_len=300):
        self.samples=[]
        for s in seqs:
            for st in range(0,len(s.q),max_len):
                ed=min(len(s.q),st+max_len)
                if ed-st>=2:self.samples.append(Seq(s.q[st:ed],s.k[st:ed],s.y[st:ed]))
    def __len__(self): return len(self.samples)
    def __getitem__(self,i): return self.samples[i]

def collate(batch):
    B=len(batch); L=max(len(x.q) for x in batch); K=max(len(ks) for x in batch for ks in x.k)
    q=torch.zeros(B,L,dtype=torch.long); kc=torch.full((B,L,K),-1,dtype=torch.long)
    y=torch.zeros(B,L,dtype=torch.long); mask=torch.zeros(B,L,dtype=torch.bool)
    for b,s in enumerate(batch):
        n=len(s.q); q[b,:n]=torch.tensor(s.q); y[b,:n]=torch.tensor(s.y); mask[b,:n]=1
        for t,ks in enumerate(s.k): kc[b,t,:len(ks)]=torch.tensor(ks)
    return q,kc,y,mask

class StrictColdGRUKT(nn.Module):
    def __init__(self,nq,nkc,d=128,dropout=.2,seen_mask=None):
        super().__init__(); self.d=d
        self.q_emb=nn.Embedding(nq,d); self.kc_emb=nn.Embedding(nkc+1,d,padding_idx=nkc)
        self.r_emb=nn.Embedding(2,d); self.in_norm=nn.LayerNorm(d); self.q_norm=nn.LayerNorm(d)
        self.drop=nn.Dropout(dropout); self.gru=nn.GRU(d,d,batch_first=True)
        self.h0=nn.Parameter(torch.zeros(d)); self.head=nn.Sequential(nn.Linear(2*d,d),nn.ReLU(),nn.Dropout(dropout),nn.Linear(d,1))
        if seen_mask is None: seen_mask=torch.ones(nq,dtype=torch.float32)
        self.register_buffer("seen_q",seen_mask.float())
    def kc_pool(self,kc):
        pad=self.kc_emb.num_embeddings-1; idx=torch.where(kc<0,torch.full_like(kc,pad),kc)
        e=self.kc_emb(idx); m=(kc>=0).unsqueeze(-1)
        return (e*m).sum(-2)/m.sum(-2).clamp_min(1)
    def query(self,q,kc):
        k=self.kc_pool(kc); gate=self.seen_q[q].unsqueeze(-1); return self.q_norm(k+gate*self.q_emb(q))
    def forward(self,q,kc,y,mask):
        k=self.kc_pool(kc); gate=self.seen_q[q].unsqueeze(-1); x=self.in_norm(k+gate*self.q_emb(q)+self.r_emb(y.clamp(0,1))); x=self.drop(x)
        out,_=self.gru(x); B,L,D=out.shape
        hp=torch.cat([self.h0.view(1,1,D).expand(B,1,D),out[:,:-1,:]],dim=1)
        qu=self.query(q,kc); return self.head(torch.cat([hp,qu],dim=-1)).squeeze(-1)
    def one_step_update(self,h,q,kc,y):
        # h: [1,d], q:[1], kc:[1,K], y:[1]
        k=self.kc_pool(kc); gate=self.seen_q[q].unsqueeze(-1); x=self.in_norm(k+gate*self.q_emb(q)+self.r_emb(y));
        out,hn=self.gru(x[:,None,:],h[None,:,:]); return hn[0]
    def score_from_state(self,h,q,kc):
        qu=self.query(q,kc); return self.head(torch.cat([h,qu],dim=-1)).squeeze(-1)


def prepare_tables(root:Path,exclude_hidden:int):
    tx=pd.read_csv(root/"Transaction.csv",low_memory=False); qkc=pd.read_csv(root/"Question_KC_Relationships.csv",low_memory=False)
    txq=find_col(tx,["question_id"]); txs=find_col(tx,["student_id"]); txy=find_col(tx,["answer_state"])
    txid=find_col(tx,["id"],False); ts=find_col(tx,["start_time"],False); te=find_col(tx,["end_time"],False); hidden=find_col(tx,["is_hidden"],False)
    tx=tx.copy(); tx["qid"]=tx[txq].map(qid_int); tx["student_key"]=tx[txs].astype(str); tx["y"]=tx[txy].map(boolish)
    tx=tx[tx.y.notna()].copy(); tx["y"]=tx.y.astype(int)
    if exclude_hidden and hidden:
        hv=tx[hidden].map(boolish).fillna(0).astype(int); tx=tx[hv==0].copy()
    sortcols=["student_key"]
    for c in [ts,te,txid]:
        if c and c in tx.columns: sortcols.append(c)
    tx=tx.sort_values(sortcols,kind="mergesort").reset_index(drop=False).rename(columns={"index":"source_row_index"})
    qq=find_col(qkc,["question_id"]); kk=find_col(qkc,["knowledgecomponent_id"])
    qkc_map=defaultdict(set)
    for _,r in qkc.iterrows(): qkc_map[qid_int(r[qq])].add(qid_int(r[kk]))
    return tx,{q:tuple(sorted(v)) for q,v in qkc_map.items()}


def build_maps(tx,qkc_map):
    qids=sorted(set(tx.qid.astype(int))|set(qkc_map)); kcs=sorted({k for v in qkc_map.values() for k in v})
    return {q:i for i,q in enumerate(qids)},{k:i for i,k in enumerate(kcs)}

def kidx(q,qkc_map,kmap): return [kmap[k] for k in qkc_map[q]]

def make_sequences(tx,qkc_map,qmap,kmap,cold,seed,train_pct,valid_pct):
    z=tx[~tx.qid.astype(int).isin(cold)].copy(); z["split"]=z.student_key.map(lambda x:usplit(x,seed,train_pct,valid_pct))
    out={"train":[],"valid":[]}
    for sp in ["train","valid"]:
        for _,g in z[z.split==sp].groupby("student_key",sort=False):
            qs=[];ks=[];ys=[]
            for r in g.itertuples(index=False):
                q=int(r.qid)
                if q not in qmap or q not in qkc_map: continue
                qs.append(qmap[q]);ks.append(kidx(q,qkc_map,kmap));ys.append(int(r.y))
            if len(qs)>=2: out[sp].append(Seq(qs,ks,ys))
    return out

def eval_loader(model,loader,device):
    model.eval(); loss=0.; n=0
    with torch.inference_mode():
        for q,k,y,m in loader:
            q,k,y,m=[x.to(device) for x in [q,k,y,m]]; logits=model(q,k,y,m)
            l=nn.functional.binary_cross_entropy_with_logits(logits[m],y[m].float(),reduction="sum")
            loss+=float(l);n+=int(m.sum())
    return loss/max(n,1)


def train_model(args,tx,qkc_map,qmap,kmap,cold,seen_mask,out):
    seqs=make_sequences(tx,qkc_map,qmap,kmap,cold,args.student_split_seed,args.train_user_pct,args.valid_user_pct)
    tr=SeqDataset(seqs["train"],args.max_seq_len); va=SeqDataset(seqs["valid"],args.max_seq_len)
    if len(tr)==0 or len(va)==0: raise RuntimeError("empty train/valid sequence dataset")
    dl=DataLoader(tr,batch_size=args.batch_size,shuffle=True,collate_fn=collate,num_workers=0)
    vl=DataLoader(va,batch_size=args.batch_size,shuffle=False,collate_fn=collate,num_workers=0)
    device=torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))
    model=StrictColdGRUKT(len(qmap),len(kmap),args.d_model,args.dropout,seen_mask).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=args.weight_decay)
    best=math.inf; bad=0; hist=[]
    for ep in range(1,args.epochs+1):
        model.train(); tl=0.;n=0
        for q,k,y,m in dl:
            q,k,y,m=[x.to(device) for x in [q,k,y,m]]; opt.zero_grad(set_to_none=True)
            logits=model(q,k,y,m); loss=nn.functional.binary_cross_entropy_with_logits(logits[m],y[m].float())
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),5.0); opt.step(); tl+=float(loss.detach())*int(m.sum());n+=int(m.sum())
        vn=eval_loader(model,vl,device); trn=tl/max(n,1); hist.append({"epoch":ep,"train_nll":trn,"valid_nll":vn})
        print(f"[DBE-KT] epoch={ep} train_nll={trn:.6f} valid_nll={vn:.6f}",flush=True)
        if vn < best-1e-5:
            best=vn;bad=0;torch.save(model.state_dict(),out/"model.pt")
        else:
            bad+=1
            if bad>=args.patience: break
    pd.DataFrame(hist).to_csv(out/"training_curve.csv",index=False)
    model.load_state_dict(torch.load(out/"model.pt",map_location=device)); model.eval()
    return model,best,device


def score_eval(model,device,args,tx,qkc_map,qmap,kmap,cold,contract):
    target_info=contract.set_index("target_qid").to_dict("index"); cold=set(cold)
    z=tx.copy(); z["split"]=z.student_key.map(lambda x:usplit(x,args.student_split_seed,args.train_user_pct,args.valid_user_pct))
    z=z[z.split=="eval"].copy(); rows=[]
    # audit: all target ids have support gate exactly zero
    for q in cold:
        if float(model.seen_q[qmap[q]].item())!=0.: raise RuntimeError(f"cold q {q} seen gate nonzero")
    with torch.inference_mode():
        for sk,g in z.groupby("student_key",sort=False):
            h=model.h0.detach().to(device).view(1,-1); seen_target=set(); warm_n=0
            for ordinal,r in enumerate(g.itertuples(index=False)):
                q=int(r.qid); y=int(r.y)
                if q not in qmap or q not in qkc_map: continue
                qi=torch.tensor([qmap[q]],dtype=torch.long,device=device)
                kc=torch.tensor([kidx(q,qkc_map,kmap)],dtype=torch.long,device=device)
                if q in cold:
                    if q in seen_target: continue
                    seen_target.add(q)
                    if warm_n<args.min_warm_history: continue
                    logit=model.score_from_state(h,qi,kc)[0]
                    inf=target_info[q]
                    rows.append({
                        "event_id":f"{sk}|ord{ordinal}|q{q}","student_key":str(sk),"row_index":int(r.source_row_index),
                        "target_position":int(ordinal),"target_qid":q,"outer_fold":int(args.outer_fold),
                        "target_kc_key":str(inf["target_kc_key"]),"label":y,"warm_history_len":int(warm_n),
                        "teacher_kc_uniform":float(torch.sigmoid(logit).cpu()),
                    })
                    # Strict-cold state: do NOT update with any held-out-fold event.
                    continue
                yy=torch.tensor([y],dtype=torch.long,device=device); h=model.one_step_update(h,qi,kc,yy); warm_n+=1
    return pd.DataFrame(rows)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data_root",required=True); ap.add_argument("--contract_csv",required=True); ap.add_argument("--outer_fold",type=int,required=True)
    ap.add_argument("--out_dir",required=True); ap.add_argument("--seed",type=int,default=42); ap.add_argument("--student_split_seed",type=int,default=20260828)
    ap.add_argument("--train_user_pct",type=int,default=70); ap.add_argument("--valid_user_pct",type=int,default=15); ap.add_argument("--exclude_hidden",type=int,default=1)
    ap.add_argument("--d_model",type=int,default=128); ap.add_argument("--dropout",type=float,default=.2); ap.add_argument("--lr",type=float,default=3e-4)
    ap.add_argument("--weight_decay",type=float,default=1e-5); ap.add_argument("--batch_size",type=int,default=16); ap.add_argument("--epochs",type=int,default=100)
    ap.add_argument("--patience",type=int,default=10); ap.add_argument("--max_seq_len",type=int,default=300); ap.add_argument("--min_warm_history",type=int,default=1)
    ap.add_argument("--device",default="")
    args=ap.parse_args(); stable_seed(args.seed)
    out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    root=Path(args.data_root); contract=pd.read_csv(args.contract_csv,low_memory=False)
    cold=set(contract.loc[contract.content_group_fold.astype(int)==args.outer_fold,"target_qid"].astype(int))
    if not cold: raise RuntimeError("empty cold fold")
    tx,qkc_map=prepare_tables(root,args.exclude_hidden); qmap,kmap=build_maps(tx,qkc_map)
    if not cold.issubset(qmap): raise RuntimeError(f"cold qids missing transaction map {sorted(cold-set(qmap))[:20]}")
    # Seen support is computed from actual TRAIN users after cold-fold removal.
    trusers=set(tx.loc[tx.student_key.map(lambda x:usplit(x,args.student_split_seed,args.train_user_pct,args.valid_user_pct))=="train","student_key"])
    trainq=set(tx[(tx.student_key.isin(trusers))&(~tx.qid.astype(int).isin(cold))].qid.astype(int))
    seen=torch.tensor([1.0 if q in trainq else 0.0 for q,_ in sorted(qmap.items(),key=lambda kv:kv[1])],dtype=torch.float32)
    if any(seen[qmap[q]].item()!=0 for q in cold): raise RuntimeError("cold seen mask construction failure")

    model,best,device=train_model(args,tx,qkc_map,qmap,kmap,cold,seen,out)
    ev=score_eval(model,device,args,tx,qkc_map,qmap,kmap,cold,contract)
    if ev.empty: raise RuntimeError("no DBE strict-cold eval events")
    obs=set(ev.target_qid.astype(int)); missing=sorted(cold-obs)
    if missing: raise RuntimeError(f"no scored eval event for {len(missing)} targets sample={missing[:20]}")
    ev.to_csv(out/"event_baseline.csv",index=False)
    # Save portable maps/config for audit and independent rescoring.
    cfg={
        "schema_version":"s13b_dbe_foldclean_kt_v1","outer_fold":args.outer_fold,"cold_qids":sorted(cold),
        "cold_target_n":len(cold),"event_n":int(len(ev)),"eval_student_n":int(ev.student_key.nunique()),
        "best_valid_nll":float(best),"n_questions":len(qmap),"n_kcs":len(kmap),"train_seen_q_n":int(seen.sum()),
        "student_split_seed":args.student_split_seed,"user_split_pct":{"train":args.train_user_pct,"valid":args.valid_user_pct,"eval":100-args.train_user_pct-args.valid_user_pct},
        "exclude_hidden":bool(args.exclude_hidden),"target_id_contract":"all cold q support gates exactly zero; target query uses KC-set plus zero q-ID residual",
        "qmap":{str(k):int(v) for k,v in qmap.items()},"kcmap":{str(k):int(v) for k,v in kmap.items()},
    }
    (out/"manifest.json").write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({k:v for k,v in cfg.items() if k not in {"qmap","kcmap"}},ensure_ascii=False,indent=2))

if __name__=="__main__": main()
