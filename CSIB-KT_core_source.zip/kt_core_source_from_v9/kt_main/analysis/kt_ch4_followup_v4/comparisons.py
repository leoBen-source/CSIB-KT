#!/usr/bin/env python3
"""Information-source comparisons; Joint uses nested out-of-fold stacking.

Only label-free embeddings/direct estimates are reused. Alignment, KC means,
transformations and supervised bridges are re-fit in their own training scope.
"""
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.decomposition import PCA
from residual import load,reference_pair,fit_offset,predict,MAIN
from measurement import Features,SIX,atomic_csv,save_json,file_hash
from evaluation import evaluate,summaries

def embeddings(path):
    z=np.load(path);q=z['qids'].astype(int);X=z['embedding'].astype(float)
    if len(q)!=len(X) or len(set(q))!=len(q) or not np.isfinite(X).all():raise ValueError('Invalid embedding NPZ')
    return dict(zip(q,X))

def transform(tr,te,mp,rff,seed):
    A=np.stack([mp[int(q)] for q in tr.target_qid]);B=np.stack([mp[int(q)] for q in te.target_qid])
    d=min(64 if rff else 32,len(A)-1,A.shape[1])
    if d<1:raise ValueError('Too few representation-training items')
    p=PCA(n_components=d,svd_solver='randomized',random_state=seed)
    A=p.fit_transform(A);B=p.transform(B);meta={'pca_dim':d,'pca_training_qids':tr.target_qid.tolist()}
    if rff:
        mean=A.mean(0);sd=np.where(A.std(0)<1e-8,1.,A.std(0));A=(A-mean)/sd;B=(B-mean)/sd
        distances=np.concatenate([((A[i+1:]-A[i])**2).sum(1) for i in range(len(A)-1)])
        nonzero=distances[distances>1e-12];gamma=1/max(float(np.median(nonzero)) if len(nonzero) else 1.,1e-8)
        rng=np.random.default_rng(seed+99173);W=rng.normal(0,np.sqrt(2*gamma),size=(d,256));phase=rng.uniform(0,2*np.pi,256)
        A=np.sqrt(2/256)*np.cos(A@W+phase);B=np.sqrt(2/256)*np.cos(B@W+phase);meta.update(rff_dim=256,gamma=gamma)
    cols=[f'feature_{j:03d}' for j in range(A.shape[1])]
    tr=pd.concat([tr.copy(),pd.DataFrame(A,index=tr.index,columns=cols)],axis=1)
    te=pd.concat([te.copy(),pd.DataFrame(B,index=te.index,columns=cols)],axis=1)
    return tr,te,cols,meta

def semantic(g,e,scope,test_ids,mp,rff,seed):
    tr=g[g.content_group_fold.isin(scope)].reset_index(drop=True);te=g[g.target_qid.isin(test_ids)].reset_index(drop=True)
    if set(te.content_group_fold)&set(scope):raise ValueError('Held fold enters semantic training')
    tr,te=reference_pair(g,scope,tr,te);tr,te,cols,meta=transform(tr,te,mp,rff,seed)
    fit=fit_offset(tr,e,['kc_ref']+cols,offset=True)
    return pd.Series(predict(fit,te),index=te.target_qid),dict(model=fit,transform=meta)

def synthetic(g,e,F,scope,test_ids):
    tr,te=F.pair(scope,list(test_ids));tr,te=reference_pair(g,scope,tr,te)
    fit=fit_offset(tr,e,['kc_ref']+SIX,offset=True)
    return pd.Series(predict(fit,te),index=te.target_qid),fit

def fit_all(g,e,r,prior,maps,direct,outer_folds=None):
    folds=set(g.content_group_fold.unique());F=Features(g,e,r)
    cols=[c for c in direct if c.startswith('cm_') and c!='cm_generated_tokens_total']
    if not cols or direct.index.has_duplicates:raise ValueError('Invalid direct-estimate feature table')
    rows=[];models={};scopes=[];inner_rows=[]
    def append(te,name,mu,outer):
        rows.extend(dict(target_qid=int(q),target_kc_key=str(k),content_group_fold=int(outer),method=name,
            prior_mean=float(v),prior_var=1.) for q,k,v in zip(te.target_qid,te.target_kc_key,mu))
    for outer in sorted(folds if outer_folds is None else outer_folds):
        scope=folds-{outer};te0=g[g.content_group_fold==outer].reset_index(drop=True);ids=te0.target_qid.tolist();outer_preds={}
        for name,(mp,rff) in maps.items():
            mu,fit=semantic(g,e,scope,ids,mp,rff,100000+int(outer));outer_preds[name]=mu;models[f'{outer}_{name}']=fit
            append(te0,name,te0.target_qid.map(mu),outer)
        tr=g[g.content_group_fold.isin(scope)].reset_index(drop=True);te=te0.copy();tr,te=reference_pair(g,scope,tr,te)
        for c in cols:tr[c]=tr.target_qid.map(direct[c]);te[c]=te.target_qid.map(direct[c])
        if tr[cols].isna().any().any() or te[cols].isna().any().any():raise ValueError('Missing direct estimates')
        fit=fit_offset(tr,e,['kc_ref']+cols,offset=True);append(te,'LLM_direct',predict(fit,te),outer);models[f'{outer}_LLM_direct']=fit
        inner=[]
        for held in sorted(scope):
            allowed=scope-{held};inner_ids=g.loc[g.content_group_fold==held,'target_qid'].tolist()
            sm,sfit=semantic(g,e,allowed,inner_ids,maps['MathBERT_answer_RFF'][0],True,200000+100*int(outer)+int(held))
            sy,yfit=synthetic(g,e,F,allowed,inner_ids)
            z=g[g.target_qid.isin(inner_ids)].copy();z['semantic_oof']=z.target_qid.map(sm);z['synthetic_oof']=z.target_qid.map(sy)
            inner.append(z);inner_rows.append(z.assign(outer_fold=outer,inner_fold=held))
            models[f'{outer}_Joint_inner_{held}']=dict(semantic=sfit,synthetic=yfit)
            scopes.append(dict(outer_fold=int(outer),inner_held_fold=int(held),stage1_training_folds=sorted(map(int,allowed)),stage1_test_qids=inner_ids))
        meta=pd.concat(inner,ignore_index=True);fit=fit_offset(meta,e,['semantic_oof','synthetic_oof'],offset=False)
        te=te0.copy();te['semantic_oof']=te.target_qid.map(outer_preds['MathBERT_answer_RFF']);sy,yfit=synthetic(g,e,F,scope,ids)
        saved=prior[(prior.method==MAIN)&prior.target_qid.isin(ids)].set_index('target_qid').prior_mean
        error=float(abs(sy.reindex(saved.index)-saved).max())
        if error>1e-6:raise ValueError(f'Main Synthetic6 predictions differ ({error})')
        te['synthetic_oof']=te.target_qid.map(sy);append(te,'Joint',predict(fit,te),outer)
        models[f'{outer}_Joint']=dict(meta=fit,synthetic_outer=yfit,main_parity_max=error)
        print('Comparison outer fold',outer,'Joint nested fits complete',flush=True)
    return pd.DataFrame(rows),models,scopes,pd.concat(inner_rows,ignore_index=True)

def joint_pairwise(items,out,draws):
    avg=items.groupby(['target_qid','target_kc_key','budget','method'],as_index=False).item_nll.mean();rows=[]
    for k in sorted(avg.budget.unique()):
        z=avg[avg.budget==k].pivot(index=['target_qid','target_kc_key'],columns='method',values='item_nll').reset_index()
        for baseline in [MAIN,'MathBERT_answer_RFF']:
            d=(z[baseline]-z.Joint).to_numpy();blocks=[t.index.to_numpy() for _,t in z.groupby('target_kc_key')]
            row=dict(budget=k,better='Joint',baseline=baseline,delta_nll=float(d.mean()))
            for level in ['item','kc_set']:
                rng=np.random.default_rng(7311);values=[]
                for _ in range(draws):
                    ix=rng.integers(len(z),size=len(z)) if level=='item' else np.concatenate([blocks[j] for j in rng.integers(len(blocks),size=len(blocks))])
                    values.append(d[ix].mean())
                row[level+'_ci_low'],row[level+'_ci_high']=np.quantile(values,[.025,.975])
            rows.append(row)
    atomic_csv(pd.DataFrame(rows),Path(out)/'joint_paired_nll_comparisons.csv')

def main():
    p=argparse.ArgumentParser();p.add_argument('--teacher',required=True);p.add_argument('--scores');p.add_argument('--base-run',required=True);p.add_argument('--out',required=True)
    p.add_argument('--responses',default=str(Path(__file__).parent/'data/synthetic_response_panel.csv'))
    p.add_argument('--mathbert-free',required=True);p.add_argument('--mathbert-answer',required=True);p.add_argument('--direct',required=True);p.add_argument('--bootstrap',type=int,default=5000)
    a=p.parse_args();out=Path(a.out)
    if out.exists():raise ValueError('Fresh output directory required')
    g,e,r,paths=load(a.teacher,a.responses,a.scores);manifest=json.loads((Path(a.base_run)/'run_manifest.json').read_text())
    for name in ['events','group','responses']:
        if file_hash(paths[name])!=manifest['inputs'][name]['sha256']:raise ValueError('Main/comparison input differs: '+name)
    prior=pd.read_csv(Path(a.base_run)/'prior_table.csv',dtype={'target_kc_key':str});prior=prior[prior.method.isin([MAIN,'CalKC_Final'])]
    maps={'MathBERT_linear':(embeddings(a.mathbert_free),False),'MathBERT_RFF':(embeddings(a.mathbert_free),True),'MathBERT_answer_RFF':(embeddings(a.mathbert_answer),True)}
    rows,models,scopes,meta=fit_all(g,e,r,prior,maps,pd.read_csv(a.direct).set_index('target_qid'))
    out.mkdir(parents=True);prior=pd.concat([prior,rows],ignore_index=True);atomic_csv(prior,out/'prior_table.csv');save_json(out/'fitted_models.json',models)
    save_json(out/'joint_nesting_scopes.json',scopes);atomic_csv(meta,out/'joint_meta_training_oof.csv.gz')
    save_json(out/'comparison_manifest.json',dict(variance=1.,all_component_methods_use_crossfit_kc_reference=True,
        joint='two scalar component predictions, nested cross-fitting; intercept plus two standardized slopes, L2=100',content_features_reused=True,
        raw_feature_hashes={k:file_hash(v) for k,v in [('mathbert_free',a.mathbert_free),('mathbert_answer',a.mathbert_answer),('direct',a.direct)]},
        claims='Revised common protocol; not a reproduction of published end-to-end MathBERT KT architectures. Direct estimates retain their original prompt/call budget.'))
    items,_=evaluate(g,e,prior,out);summaries(items,out,a.bootstrap);joint_pairwise(items,out,a.bootstrap)
    save_json(out/'completion.json',dict(status='PASS'));print('COMPARISONS_PASS',out,flush=True)
if __name__=='__main__':main()
