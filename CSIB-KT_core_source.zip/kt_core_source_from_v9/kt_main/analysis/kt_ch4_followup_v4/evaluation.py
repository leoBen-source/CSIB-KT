#!/usr/bin/env python3
"""Paired evaluation with the exact archived pool selection rule."""
import hashlib,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.special import expit
from scipy.stats import rankdata
from sklearn.metrics import roc_auc_score
from measurement import logit,map_vector,atomic_csv,save_json
from residual import MAIN

BUDGETS=[0,1,2,5,10,20]
SEEDS=[20260829,20260830,20260831,20260901,20260902,20260903,20260904,20260905,20260906,20260907]

def evaluate(g,e,pri,out,budgets=BUDGETS,seeds=SEEDS):
    out=Path(out);all_n=len(g)
    support=set(e.groupby('target_qid').size().loc[lambda x:x>=30].index)
    if not support:raise ValueError('No item has 20 calibration plus 10 held-out events')
    excluded=sorted(set(g.target_qid)-support)
    g=g[g.target_qid.isin(support)];e=e[e.target_qid.isin(support)];pri=pri[pri.target_qid.isin(support)]
    methods=sorted(pri.method.unique());rows=[];curves=[];pools=[]
    pr={int(q):z.set_index('method').loc[methods] for q,z in pri.groupby('target_qid')}
    groups={int(q):z.sort_values('event_id').reset_index(drop=True) for q,z in e.groupby('target_qid')}
    for seed in seeds:
        pooled={(k,m):[[],[]] for k in budgets for m in ['RawKT']+methods}
        for q,z in groups.items():
            sd=int.from_bytes(hashlib.sha256(f's19_calibration_pool|{seed}|{q}'.encode()).digest()[:8],'little')%(2**32-1)
            ix=np.random.default_rng(sd).permutation(len(z))[:20];keep=np.ones(len(z),bool);keep[ix]=False
            for order,j in enumerate(ix,1):pools.append(dict(seed=seed,target_qid=q,calibration_order=order,event_id=str(z.iloc[j].event_id)))
            y=z.label.to_numpy(float);p=z.teacher_kc_uniform.to_numpy(float);yy=y[keep];base=logit(p[keep]);prior=pr[q]
            within=roc_auc_score(yy,p[keep]) if len(np.unique(yy))==2 else np.nan
            for k in budgets:
                b=map_vector(y[ix][:k],p[ix][:k],prior.prior_mean.to_numpy(),prior.prior_var.to_numpy())
                if 'KC6_PriorOnly' in methods:b[methods.index('KC6_PriorOnly')]=float(prior.loc['KC6_PriorOnly','prior_mean'])
                for name,bias in zip(['RawKT']+methods,np.r_[0.,b]):
                    eta=base+bias;pred=expit(eta)
                    rows.append(dict(seed=seed,budget=k,method=name,target_qid=q,target_kc_key=str(z.target_kc_key.iloc[0]),
                        evaluation_n=len(yy),item_nll=float(np.mean(np.logaddexp(0,eta)-yy*eta)),posterior_bias=float(bias),
                        item_brier=float(np.mean((pred-yy)**2)),within_item_auc=within))
                    pooled[k,name][0].append(yy);pooled[k,name][1].append(pred)
        for (k,m),(ys,ps) in pooled.items():curves.append(dict(seed=seed,budget=k,method=m,pooled_auc=roc_auc_score(np.concatenate(ys),np.concatenate(ps))))
        print('Evaluated pool seed',seed,flush=True)
    items=pd.DataFrame(rows);auc=pd.DataFrame(curves)
    atomic_csv(items,out/'item_metrics.csv.gz');atomic_csv(pd.DataFrame(pools),out/'calibration_pool.csv.gz')
    metrics=items.groupby(['seed','budget','method'],as_index=False).agg(item_macro_nll=('item_nll','mean'),item_macro_brier=('item_brier','mean'),within_item_macro_auc=('within_item_auc','mean')).merge(auc,on=['seed','budget','method'],validate='one_to_one')
    curve=metrics.groupby(['budget','method'],as_index=False)[['item_macro_nll','pooled_auc','item_macro_brier','within_item_macro_auc']].mean()
    atomic_csv(metrics,out/'metrics_by_seed.csv');atomic_csv(curve,out/'learning_curve.csv')
    atomic_csv(curve[curve.budget.isin([0,5])&curve.method.isin(['RawKT',MAIN])],out/'main_table_k0_k5.csv')
    save_json(out/'evaluation_manifest.json',dict(budgets=budgets,seeds=seeds,target_n=len(g),event_n=len(e),
        full_item_n=all_n,excluded_sparse_qids=excluded,pool_size=20,evaluation_complement_fixed=True,history='warm-only, before current event',temporal_replay=False,
        nll='item macro',auc='pooled event AUC, then average across pools',main=MAIN,
        variance='common fixed Gaussian variance 1',statistical_scope='one backbone training seed and one synthetic panel'))
    return items,curve

def summaries(items,out,draws=5000):
    out=Path(out)
    avg=items.groupby(['target_qid','target_kc_key','budget','method'],as_index=False).agg(item_nll=('item_nll','mean'),item_brier=('item_brier','mean'))
    atomic_csv(avg,out/'seed_averaged_item_metrics.csv.gz');records=[];hetero=[]
    for k in sorted(avg.budget.unique()):
        z=avg[avg.budget==k].pivot(index=['target_qid','target_kc_key'],columns='method',values='item_nll').reset_index()
        baselines=[c for c in z if c not in ['target_qid','target_kc_key',MAIN]]
        D=np.column_stack([(z[m]-z[MAIN]).to_numpy() for m in baselines]);blocks=[t.index.to_numpy() for _,t in z.groupby('target_kc_key')]
        rng=np.random.default_rng(7311);wi=rng.multinomial(len(z),np.full(len(z),1/len(z)),size=draws);bi=wi@D/len(z)
        sums=np.vstack([D[ix].sum(0) for ix in blocks]);sizes=np.array([len(ix) for ix in blocks]);wk=rng.multinomial(len(blocks),np.full(len(blocks),1/len(blocks)),size=draws);bk=(wk@sums)/(wk@sizes)[:,None]
        for j,m in enumerate(baselines):
            records.append(dict(budget=k,better=MAIN,baseline=m,delta_nll=float(D[:,j].mean()),item_ci_low=float(np.quantile(bi[:,j],.025)),item_ci_high=float(np.quantile(bi[:,j],.975)),kc_set_ci_low=float(np.quantile(bk[:,j],.025)),kc_set_ci_high=float(np.quantile(bk[:,j],.975)),positive_item_fraction=float((D[:,j]>0).mean())))
        if k in [0,5]:
            h=z[['target_qid','target_kc_key','RawKT',MAIN]].copy();h['delta_nll']=h.RawKT-h[MAIN];h['budget']=k
            atomic_csv(h,out/f'heterogeneity_k{k}.csv');d=h.delta_nll.to_numpy();s=np.sort(d)[::-1];top=max(1,int(np.ceil(.1*len(d))))
            gains=items[(items.budget==k)&items.method.isin(['RawKT',MAIN])].pivot(index=['target_qid','seed'],columns='method',values='item_nll');bad=gains[MAIN]>gains.RawKT
            hetero.append(dict(budget=k,n_items=len(d),mean=float(d.mean()),median=float(np.median(d)),q10=float(np.quantile(d,.1)),q90=float(np.quantile(d,.9)),harm_fraction=float((d<0).mean()),benefit_mean=float(d[d>0].mean()),harm_mean=float(-d[d<0].mean()),top10pct_net_gain_share=float(s[:top].sum()/d.sum()),all_pool_seeds_harmed=int(bad.groupby('target_qid').all().sum())))
    atomic_csv(pd.DataFrame(records),out/'paired_nll_comparisons.csv');atomic_csv(pd.DataFrame(hetero),out/'heterogeneity_summary.csv')

def rq2(g,prior,out,draws=5000):
    out=Path(out)
    p=prior[prior.method==MAIN][['target_qid','prior_mean']]
    z=g.merge(p,on='target_qid',validate='one_to_one');z['reference_mean']=[g.loc[g.content_group_fold!=f,'criterion'].mean() for f in z.content_group_fold]
    x=z.prior_mean.to_numpy();y=z.criterion.to_numpy();ref=z.reference_mean.to_numpy()
    delta=(y-ref)**2-(y-x)**2;blocks=[t.index.to_numpy() for _,t in z.groupby('target_kc_key')]
    def rho(a,b):
        a=rankdata(a);b=rankdata(b)
        return np.corrcoef(a,b)[0,1] if np.std(a)>0 and np.std(b)>0 else np.nan
    row=dict(spearman=float(rho(x,y)),delta_mse=float(delta.mean()),relative_mse_improvement_pct=float(100*delta.mean()/np.mean((y-ref)**2)),item_n=len(z))
    for level in ['item','kc_set']:
        rng=np.random.default_rng(42031 if level=='item' else 42032);rs=[];ms=[]
        for _ in range(draws):
            ix=rng.integers(len(z),size=len(z)) if level=='item' else np.concatenate([blocks[j] for j in rng.integers(len(blocks),size=len(blocks))])
            rs.append(rho(x[ix],y[ix]));ms.append(float(delta[ix].mean()))
        row[level+'_rho_low'],row[level+'_rho_high']=np.nanquantile(rs,[.025,.975])
        row[level+'_mse_low'],row[level+'_mse_high']=np.quantile(ms,[.025,.975])
    atomic_csv(z,out/'rq2_item_predictions.csv');atomic_csv(pd.DataFrame([row]),out/'rq2_summary.csv')
    return row
