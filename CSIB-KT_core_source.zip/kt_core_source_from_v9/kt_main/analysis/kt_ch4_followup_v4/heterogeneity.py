#!/usr/bin/env python3
"""Per-item gains relative to RawKT; statistical data are exported with plots."""
import argparse
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from measurement import atomic_csv
from residual import MAIN

def draw(run,out):
    run=Path(run);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    items=pd.read_csv(run/'item_metrics.csv.gz',dtype={'target_kc_key':str})
    data=items[items.method.isin(['RawKT',MAIN])]
    avg=data.groupby(['target_qid','target_kc_key','budget','method'],as_index=False).item_nll.mean()
    five=avg[avg.budget==5].pivot(index=['target_qid','target_kc_key'],columns='method',values='item_nll').reset_index()
    five['delta_nll']=five.RawKT-five[MAIN]
    seed=data[data.budget==5].pivot(index=['target_qid','seed'],columns='method',values='item_nll').reset_index()
    seed['harmed']=(seed[MAIN]>seed.RawKT).astype(int)
    counts=seed.groupby('target_qid').harmed.agg(['sum','count']).reset_index().rename(columns={'sum':'harmed_seeds','count':'pool_seeds'})
    five=five.merge(counts,on='target_qid',validate='one_to_one');atomic_csv(five,out/'heterogeneity_plot_items_k5.csv')
    fig=plt.figure(figsize=(8.6,5.8));grid=fig.add_gridspec(2,2,height_ratios=[1.1,.85]);axes=[fig.add_subplot(grid[0,0]),fig.add_subplot(grid[0,1]),fig.add_subplot(grid[1,:])]
    ax=axes[0];benefit=five.delta_nll>=0
    for mask,col,label in [(benefit,'#277C82','Lower NLL'),(~benefit,'#BB6843','Higher NLL')]:
        z=five[mask];ax.scatter(z.RawKT,z[MAIN],s=12,alpha=.6,edgecolors='none',color=col,label=f'{label}: {len(z)}')
    lo=float(min(five.RawKT.min(),five[MAIN].min()));hi=float(max(five.RawKT.max(),five[MAIN].max()))
    ax.plot([lo,hi],[lo,hi],color='#777777',lw=.8);ax.set(xlabel='RawKT item NLL',ylabel='Method item NLL',title='A  Item performance, k = 5');ax.legend(frameon=False,fontsize=8)
    ecdfs=[];ax=axes[1]
    for k,col in [(0,'#72859A'),(5,'#277C82')]:
        z=avg[avg.budget==k].pivot(index='target_qid',columns='method',values='item_nll');d=np.sort((z.RawKT-z[MAIN]).to_numpy());y=np.arange(1,len(d)+1)/len(d)
        ax.step(d,y,where='post',color=col,label=f'k = {k}; harmed = {(d<0).mean():.1%}')
        ecdfs.append(pd.DataFrame({'budget':k,'delta_nll':d,'cumulative_fraction':y}))
    ax.set_xscale('symlog',linthresh=.02);ax.axvline(0,color='#777777',lw=.8);ax.set(xlabel='Paired NLL gain (symlog scale)',ylabel='Cumulative fraction of items',title='B  Distribution of paired gains');ax.legend(frameon=False,fontsize=8)
    ax=axes[2];nseeds=int(five.pool_seeds.max());bins=np.arange(nseeds+1);freq=five.harmed_seeds.value_counts().reindex(bins,fill_value=0)
    ax.bar(bins,freq,color=['#BB6843' if j==nseeds else '#72859A' for j in bins],width=.78)
    ax.set(xlabel='Calibration pools with higher NLL',ylabel='Number of items',title='C  Harm across calibration pools',xticks=bins)
    persistent=int((five.harmed_seeds==five.pool_seeds).sum());ax.text(.97,.95,f'All pools: {persistent}/{len(five)}',ha='right',va='top',transform=ax.transAxes,fontsize=9)
    fig.tight_layout();fig.savefig(out/'figure6_heterogeneity.png',dpi=300,bbox_inches='tight');fig.savefig(out/'figure6_heterogeneity.pdf',bbox_inches='tight');plt.close(fig)
    atomic_csv(pd.concat(ecdfs),out/'heterogeneity_ecdf.csv')
    atomic_csv(pd.DataFrame({'harmed_seeds':bins,'item_count':freq.values}),out/'heterogeneity_pool_counts.csv')
    print('HETEROGENEITY_PASS',out,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--out',required=True);a=p.parse_args();draw(a.run,a.out)
