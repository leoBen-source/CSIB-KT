#!/usr/bin/env python3
"""Check supplied XES coordinates without treating row number as a timestamp.

A cross-row repeat is reported as unresolved unless sequence order is supplied;
this script never fabricates chronological evidence or changes event support.
"""
import argparse,csv,json
from pathlib import Path
from collections import defaultdict
import pandas as pd
from measurement import file_hash,save_json

def audit(teacher,out):
    teacher=Path(teacher);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    m=json.loads((teacher/'inputs/input_manifest.json').read_text());source=Path(m['event_source_csv'])
    if file_hash(source)!=m['coordinate_source_sha256']:raise ValueError('Source sequence changed')
    e=pd.read_csv(teacher/'clean/teacher_aligned_event_baseline_targetidfree.csv.gz',dtype={'student_key':str,'event_id':str})
    cold=set(pd.read_csv(teacher/'clean/content_group_safe_item_targets_targetidfree.csv').target_qid.astype(int))
    requests={int(i):z for i,z in e.groupby('row_index')};wanted=set(zip(e.student_key,e.target_qid.astype(int)));occ=defaultdict(list)
    mismatch=[];earlier=[];matched=0
    with source.open(newline='',encoding='utf8') as f:
        for ridx,row in enumerate(csv.DictReader(f)):
            uid=str(row['uid']);qs=[int(float(v)) for v in row['questions'].split(',')];ys=[int(float(v)) for v in row['responses'].split(',')]
            for pos,q in enumerate(qs):
                if (uid,q) in wanted:occ[uid,q].append((ridx,pos))
            if ridx not in requests:continue
            for event in requests[ridx].itertuples(index=False):
                pos=int(event.target_position);q=int(event.target_qid)
                if pos>=len(qs) or uid!=str(event.student_key) or qs[pos]!=q or ys[pos]!=int(event.label):mismatch.append(str(event.event_id));continue
                matched+=1
                if q in qs[:pos]:earlier.append(str(event.event_id))
    cross=sum(any(rr!=int(ev.row_index) for rr,pos in occ[str(ev.student_key),int(ev.target_qid)]) for ev in e.itertuples(index=False))
    report=dict(status='FAIL' if mismatch or earlier or matched!=len(e) else ('REVIEW_CROSS_ROW_ORDER' if cross else 'PASS_WITHIN_PROVIDED_SEQUENCE_SOURCE'),
        event_n=len(e),matched_coordinates=matched,duplicate_selected_student_item=int(e.duplicated(['student_key','target_qid']).sum()),
        coordinate_mismatches=len(mismatch),earlier_same_item_in_selected_row=len(earlier),selected_pairs_with_occurrences_in_other_rows=cross,
        examples_mismatched=mismatch[:10],examples_earlier=earlier[:10],source_sha256=file_hash(source),
        global_chronological_first_response_verified=False,interpretation='Same-row order is checked. Cross-row timestamps and unprovided raw history remain outside this check; row number is not time.')
    save_json(out/'event_history_audit.json',report)

    # 导出相关记录，供核对跨片段顺序；不自动认定哪条是真实首次。
    import gzip
    exported = []
    needed_rows = set()
    affected_items = set()

    for ev in e.itertuples(index=False):
        key = (str(ev.student_key), int(ev.target_qid))
        positions = occ[key]
        if not any(rr != int(ev.row_index) for rr, pp in positions):
            continue
        affected_items.add(int(ev.target_qid))
        for rr, pp in positions:
            needed_rows.add(int(rr))
            exported.append(dict(
                selected_event_id=str(ev.event_id),
                student_key=str(ev.student_key),
                target_qid=int(ev.target_qid),
                selected_row_index=int(ev.row_index),
                selected_position=int(ev.target_position),
                occurrence_row_index=int(rr),
                occurrence_position=int(pp),
                is_selected_occurrence=int(
                    rr == int(ev.row_index) and pp == int(ev.target_position)
                ),
            ))

    columns = [
        "selected_event_id", "student_key", "target_qid",
        "selected_row_index", "selected_position",
        "occurrence_row_index", "occurrence_position",
        "is_selected_occurrence"
    ]
    pd.DataFrame(exported, columns=columns).to_csv(
        out / "cross_row_occurrences.csv.gz", index=False
    )

    with source.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        source_columns = list(reader.fieldnames or [])
        row_key = "_audit_source_csv_row_index"
        if row_key in source_columns:
            raise ValueError("审计行号字段与源文件冲突。")
        with gzip.open(
            out / "cross_row_source_rows.csv.gz",
            "wt", encoding="utf-8", newline=""
        ) as target:
            writer = csv.DictWriter(
                target, fieldnames=[row_key] + source_columns
            )
            writer.writeheader()
            for rr, row in enumerate(reader):
                if rr in needed_rows:
                    writer.writerow({row_key: rr, **row})

    save_json(out / "cross_row_export_manifest.json", dict(
        cross_row_selected_pairs=int(cross),
        affected_items=len(affected_items),
        source_rows_exported=len(needed_rows),
        source_columns=source_columns,
        row_indices_are_zero_based=True,
        chronological_first_response_verified=False,
        interpretation=(
            "Relevant source rows are exported without changing event support. "
            "CSV row order is not assumed to be chronological."
        )
    ))

    if report['status']=='FAIL':raise ValueError('First-exposure/coordinate audit failed; inspect event_history_audit.json')
    print(report)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--teacher',required=True);p.add_argument('--out',required=True);a=p.parse_args();audit(a.teacher,a.out)
