#!/usr/bin/env python3
"""Paired item/KC confidence intervals for the existing response-form diagnostic."""
import argparse
from pathlib import Path
import numpy as np,pandas as pd
from measurement import atomic_csv

def main():
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--bootstrap',type=int,default=5000);a=p.parse_args();root=Path(a.run)
    d=pd.read_csv(root/'per_target_headroom.csv',dtype={'target_kc_key':str}).reset_index(drop=True)
    records=[];rng=np.random.default_rng(7311)
    for better,base in [('scalar_cf_nll','base_nll'),('affine_cf_nll','scalar_cf_nll'),('bin_cf_nll','scalar_cf_nll')]:
        delta=(d[base]-d[better]).to_numpy();row={'better':better,'baseline':base,'delta_nll':delta.mean()}
        for level in ['item','kc_set']:
            blocks=[np.array([i]) for i in range(len(d))] if level=='item' else [z.index.to_numpy() for _,z in d.groupby('target_kc_key')]
            means=[]
            for _ in range(a.bootstrap):means.append(delta[np.concatenate([blocks[j] for j in rng.integers(len(blocks),size=len(blocks))])].mean())
            row[level+'_ci_low'],row[level+'_ci_high']=np.quantile(means,[.025,.975])
        records.append(row)
    atomic_csv(pd.DataFrame(records),root/'paired_nll_comparisons.csv');print(pd.DataFrame(records).to_string(index=False))
if __name__=='__main__':main()
