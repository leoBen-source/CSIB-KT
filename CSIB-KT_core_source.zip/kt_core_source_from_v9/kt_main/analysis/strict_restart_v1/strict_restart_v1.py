#!/usr/bin/env python3
"""Repair actual SQAKT input; keep old experiments intact."""
import argparse, csv, gzip, hashlib, importlib, json, os
import runpy, shutil, subprocess, sys
from collections import Counter
from pathlib import Path

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def read(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def write(p, obj):
    Path(p).write_text(
        json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8"
    )

def sha(p):
    h = hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def cold_hash(qs):
    return hashlib.sha256(
        "\n".join(map(str, sorted(qs))).encode()
    ).hexdigest()

def scan(path, cold, qkc):
    counts = {"training": Counter(), "validation": Counter()}
    nrows = Counter()
    with Path(path).open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        required = {
            "fold", "questions", "concepts", "responses", "selectmasks"
        }
        require(required <= set(reader.fieldnames), "Missing sequence columns")
        for n, row in enumerate(reader):
            fold = int(row["fold"])
            require(fold in range(5), f"Invalid user fold at row {n}")
            role = "validation" if fold == 3 else "training"
            nrows[role] += 1
            z = [
                row[k].split(",")
                for k in ("questions", "concepts", "responses", "selectmasks")
            ]
            require(len(set(map(len, z))) == 1, f"Unaligned row {n}")
            pad_seen = False
            for q, c, y, mask in zip(*z):
                q, y, mask = int(q), int(y), int(mask)
                require(mask in (-1, 0, 1), f"Invalid mask at row {n}")
                if q == -1:
                    pad_seen = True
                    require(
                        c == "-1" and y == -1 and mask == -1,
                        f"Bad padding at row {n}"
                    )
                    continue
                require(
                    not pad_seen and q >= 0 and y in (0, 1),
                    f"Invalid sequence at row {n}"
                )
                require(
                    q not in cold,
                    f"HELD-OUT QUESTION IN INPUT: row={n}, q={q}"
                )
                require(
                    q in qkc
                    and sorted(set(map(int, c.split("_")))) == qkc[q],
                    f"KC-set mismatch: row={n}, q={q}"
                )
                counts[role][q] += 1
    require(
        all(nrows[r] and counts[r] for r in counts),
        "Empty training or validation data"
    )
    return counts, nrows

def check_data(d):
    m = read(d / "foldclean_manifest_v2.json")
    p = d / "train_valid_sequences_quelevel.csv"
    require(
        not p.is_symlink() and sha(p) == m["actual_csv_sha256"],
        "Training CSV changed"
    )
    require(
        sha(d / "q_support_train_foldclean.json") == m["support_sha256"],
        "Support changed"
    )
    return m, p

def legal_support(source, template, cold, qkc):
    byrow = {}
    with gzip.open(template, "rt", newline="", encoding="utf-8") as f:
        events = list(csv.DictReader(f))
    ids = [r["event_id"] for r in events]
    require(len(ids) == len(set(ids)), "Duplicate frozen event identities")
    for r in events:
        byrow.setdefault(int(r["row_index"]), []).append(r)
    counts = Counter()
    with source.open(newline="", encoding="utf-8") as f:
        for n, row in enumerate(csv.DictReader(f)):
            if n not in byrow:
                continue
            require(
                int(row["fold"]) == 3,
                "Event coordinates outside user fold 3"
            )
            qs = [int(float(x)) for x in row["questions"].split(",")]
            ys = [int(float(x)) for x in row["responses"].split(",")]
            prefix = [0]
            for q, y in zip(qs, ys):
                prefix.append(
                    prefix[-1]
                    + int(q not in cold and q in qkc and y in (0, 1))
                )
            for r in byrow.pop(n):
                pos, q = int(r["target_position"]), int(r["target_qid"])
                require(
                    q in cold
                    and qs[pos] == q
                    and ys[pos] == int(r["label"]),
                    "Event coordinate/label mismatch"
                )
                if prefix[pos] >= 1:
                    counts[q] += 1
    require(
        not byrow,
        "Frozen event coordinates missing from original sequence source"
    )
    return counts

def prepare(a, project, p3, out, code):
    require(not out.exists(), f"Output already exists: {out}")
    old = p3 / "s12_xes_targetidfree_prior_v2"
    full = old / "preflight/full522_group.csv"
    template = old / "preflight/full522_event_identity_template.csv.gz"
    qkc_path = p3.parent / "audit/q_to_kc_set.json"
    source = p3 / "cold_dataset/train_valid_sequences.csv"
    raw = project / (
        "data/XES3G5M/question_level/"
        "train_valid_sequences_quelevel.csv"
    )
    required = [full, template, qkc_path, source, raw]
    required += [
        code / x for x in (
            "s12a_score_targetidfree_prior_v2.py",
            "s12b_finalize_targetidfree_prior_v2.py"
        )
    ]
    for p in required:
        require(p.is_file(), f"Missing input: {p}")

    with full.open(newline="", encoding="utf-8") as f:
        g = list(csv.DictReader(f))
    qs = [int(r["target_qid"]) for r in g]
    require(len(qs) == len(set(qs)) == 522, "Expected 522 unique targets")
    require(
        {int(r["content_group_fold"]) for r in g} == set(range(5)),
        "Expected five content folds"
    )
    qkc = {
        int(k): sorted(set(map(int, v)))
        for k, v in read(qkc_path).items()
    }

    for name in ("inputs", "models", "scores", "logs"):
        (out / name).mkdir(parents=True)

    fields = [
        k for k in (
            "target_qid", "target_kc_key",
            "content_group_fold", "canonical_content_id"
        ) if k in g[0]
    ]
    with (out / "inputs/group.csv").open(
        "w", newline="", encoding="utf-8"
    ) as f:
        w = csv.DictWriter(
            f, fieldnames=fields, extrasaction="ignore"
        )
        w.writeheader()
        w.writerows(g)
    shutil.copy2(template, out / "inputs/events.csv.gz")
    shutil.copy2(qkc_path, out / "inputs/q_to_kc_set.json")

    cold = set(qs)
    d = out / "data/backbone"
    d.mkdir(parents=True)
    dst = d / "train_valid_sequences_quelevel.csv"
    removed = Counter()
    kept_rows = 0

    with raw.open(newline="", encoding="utf-8") as fi, dst.open(
        "w", newline="", encoding="utf-8"
    ) as fo:
        reader = csv.DictReader(fi)
        writer = csv.DictWriter(fo, fieldnames=reader.fieldnames)
        writer.writeheader()
        aligned = [
            k for k in (
                "questions", "concepts", "responses", "selectmasks",
                "timestamps", "usetimes", "is_repeat"
            ) if k in reader.fieldnames
        ]
        require(
            {"fold", "questions", "concepts", "responses", "selectmasks"}
            <= set(reader.fieldnames),
            "Missing sequence columns"
        )
        for n, row in enumerate(reader):
            z = {k: row[k].split(",") for k in aligned}
            require(
                len(set(map(len, z.values()))) == 1,
                f"Unaligned source row {n}"
            )
            q = list(map(int, z["questions"]))
            role = (
                "validation" if int(row["fold"]) == 3 else "training"
            )
            removed[role] += sum(v in cold for v in q)
            keep = [
                i for i, v in enumerate(q)
                if v >= 0 and v not in cold
            ]
            if len(keep) < 2:
                continue
            for k in aligned:
                row[k] = ",".join(
                    [z[k][i] for i in keep]
                    + ["-1"] * (len(q) - len(keep))
                )
            writer.writerow(row)
            kept_rows += 1

    counts, rows = scan(dst, cold, qkc)
    support = {
        str(q): int(n) for q, n in counts["training"].items()
    }
    support.update({str(q): 0 for q in cold})
    sp = d / "q_support_train_foldclean.json"
    write(sp, support)

    mapping = raw.parent / "keyid2idx.json"
    if mapping.is_file():
        shutil.copy2(mapping, d / mapping.name)

    m = dict(
        schema_version="shared_strict_teacher_v1",
        exclusion_scope="all_selected_items",
        outer_fold=-1,
        validation_user_fold=3,
        cold_qids=sorted(cold),
        cold_item_n=len(cold),
        cold_qid_sha256=cold_hash(cold),
        filtered_train_valid_csv=str(dst),
        q_support_train_json=str(sp),
        actual_csv_sha256=sha(dst),
        support_sha256=sha(sp),
        source_train_valid_csv=str(raw.resolve()),
        cold_interactions_remaining=0,
        cold_train_support_nonzero_n=0,
        checked_training_cold_interactions=0,
        checked_validation_cold_interactions=0,
        rows=dict(rows),
        removed_interactions=dict(removed),
        kept_rows=kept_rows,
        interactions={
            r: sum(c.values()) for r, c in counts.items()
        }
    )
    write(d / "foldclean_manifest_v2.json", m)

    support = legal_support(source, template, cold, qkc)
    with (out / "inputs/legal_event_support.csv").open(
        "w", newline="", encoding="utf-8"
    ) as f:
        w = csv.writer(f)
        w.writerow([
            "target_qid", "legal_event_n", "supports_k20_eval10"
        ])
        w.writerows(
            (q, support[q], int(support[q] >= 30))
            for q in sorted(cold)
        )
    require(
        all(support[q] > 0 for q in cold),
        "Some targets have no legal history; "
        "see inputs/legal_event_support.csv before training"
    )

    # Create a separate scorer. Keep its prediction formula unchanged.
    src = (
        code / "s12a_score_targetidfree_prior_v2.py"
    ).read_text(encoding="utf-8")
    left = (
        '    if int(man["outer_fold"]) != int(args.outer_fold):'
    )
    right = (
        '    if int(man.get("cold_interactions_remaining", 0)) != 0:'
    )
    require(
        src.count(left) == src.count(right) == 1,
        "Scorer version differs; stop"
    )
    i, j = src.index(left), src.index(right)
    replacement = '''    if man.get("exclusion_scope") != "all_selected_items":
        raise RuntimeError("Shared teacher must exclude all selected items")
    if set(map(int, man["cold_qids"])) != full_targets:
        raise RuntimeError("Shared teacher exclusion set differs from full target bank")
    if man["cold_qid_sha256"] != stable_hash(full_targets):
        raise RuntimeError("Shared teacher cold hash mismatch")
'''
    src = src[:i] + replacement + src[j:]
    for x, y in [
        ("if q in cold:", "if q in full_targets:"),
        (
            "if q in cold or q not in qkc:",
            "if q in full_targets or q not in qkc:"
        )
    ]:
        require(
            src.count(x) == 1,
            "History-filter anchor differs; stop"
        )
        src = src.replace(x, y)
    src = src.replace(
        '"s12a_targetidfree_prior_v2_canonical_event_repair"',
        '"s12a_shared_teacher_v1_canonical_event_repair"'
    )
    (out / "shared_scorer.py").write_text(
        src, encoding="utf-8"
    )
    compile(src, "shared_scorer.py", "exec")

    print(
        "PREPARE PASS: all 522 items absent from actual "
        "training/validation CSV",
        dict(removed), flush=True
    )
    print(
        "Targets supporting k=20 plus 10 evaluation events:",
        sum(support[q] >= 30 for q in cold),
        flush=True
    )
    write(out / "inputs/input_manifest.json", {
        "event_source_csv": str(source),
        "coordinate_source_sha256": sha(source),
        "frozen_inputs": {
            p.name: sha(p)
            for p in (out / "inputs").iterdir()
            if p.is_file()
        }
    })

def train(a, project, p3, out, code):
    d = out / "data/backbone"
    m, canonical = check_data(d)
    save = out / "models/shared_teacher"
    require(
        not save.exists(),
        f"Training directory already exists: {save}; "
        "do not reuse checkpoints"
    )
    save.mkdir()

    # Touch only caches in this new output tree.
    for p in d.glob("*.pkl"):
        require(not p.is_symlink(), "Unexpected cache symlink")
        p.unlink()

    ex = project / "examples"
    os.chdir(ex)
    sys.path[:0] = [str(project), str(ex)]
    import numpy as np
    import wandb_train as wt
    import pykt

    require(
        Path(pykt.__file__).resolve().parent == project / "pykt",
        "Imported a different PyKT installation"
    )
    original = wt.init_dataset4train
    module = importlib.import_module(original.__module__)
    original_ds = module.KTQueDataset
    calls = []

    def traced(*args, **kwargs):
        path = Path(
            args[0] if args else kwargs["file_path"]
        ).resolve()
        require(
            path == canonical,
            f"WRONG ACTUAL LOADER PATH: {path}"
        )
        ds = original_ds(*args, **kwargs)
        q = ds.dori["qseqs"].detach().cpu().numpy()
        require(
            not np.isin(q, m["cold_qids"]).any(),
            "Cold qid in actual loaded tensor"
        )
        require(
            ds.dori["cseqs"].ndim == 3,
            "Expected full-KC-set tensor"
        )
        folds = kwargs.get(
            "folds", args[2] if len(args) > 2 else None
        )
        calls.append({
            "path": str(path),
            "folds": sorted(map(int, folds)),
            "cold_interactions": 0
        })
        return ds

    module.KTQueDataset = traced

    def guarded(
        dataset_name, model_name, data_config,
        i, batch_size, **kwargs
    ):
        require(
            dataset_name == "xes3g5m"
            and model_name == "sqakt" and i == 3,
            "Unexpected training contract"
        )
        dc = data_config[dataset_name]
        require(
            Path(dc["dpath"]).resolve() == d
            and int(dc.get("sqakt_set_aware", 0)) == 1,
            "Set-aware loader required"
        )
        for key in (
            "sqakt_train_valid_file",
            "train_valid_file_quelevel",
            "train_valid_file"
        ):
            dc[key] = canonical.name
        loaders = original(
            dataset_name, model_name, data_config,
            i, batch_size, **kwargs
        )
        require(
            sorted(x["folds"] for x in calls)
            == [[0, 1, 2, 4], [3]],
            "Unexpected loader calls/folds"
        )
        write(d / "actual_loader_audit.json", {
            "status": "PASS",
            "calls": calls,
            "csv_sha256": sha(canonical)
        })
        return loaders

    wt.init_dataset4train = guarded

    qkc = read(out / "inputs/q_to_kc_set.json")
    maxc = max(len(set(v)) for v in qkc.values())
    args = [
        "--model_name", "sqakt",
        "--dataset_name", "xes3g5m",
        "--fold", "3",
        "--emb_type", "qid",
        "--seed", "42",
        "--backbone_type", "gru",
        "--d_model", "128",
        "--n_heads", "4",
        "--dropout", "0.2",
        "--learning_rate", "3e-4",
        "--batch_size", "64",
        "--num_epochs", str(a.epochs),
        "--dataset_dir_override", str(d),
        "--semantic_dataset_root_override", str(d),
        "--kc_set_input", "1",
        "--kc_pooling", "mean",
        "--kc_set_max_concepts", str(maxc),
        "--q_inject_mode", "none",
        "--q_item_parameterization", "id_only_cold_mask",
        "--q_id_gate_type", "cold_mask",
        "--q_support_path",
        str(d / "q_support_train_foldclean.json"),
        "--q_strict_cold_zero_id", "1",
        "--semantic_control_mode", "zero",
        "--save_dir", str(save)
    ]
    for k in (
        "use_v4_init", "use_q_sem", "use_c_sem",
        "use_q_structured_sem", "use_q_ref_sem",
        "use_q_ref_structured_sem", "use_q_content_arbitration",
        "use_q_support_gate", "use_q_calib_prior",
        "use_q_sem_delta", "use_c_sem_delta",
        "lambda_align_q", "lambda_align_c",
        "lambda_same", "lambda_smooth",
        "debug_q_align", "use_wandb", "add_uuid"
    ):
        args += ["--" + k, "0"]

    sys.argv = [str(ex / "wandb_sqakt_train.py")] + args
    runpy.run_path(sys.argv[0], run_name="__main__")

    runs = [
        p.parent for p in save.glob("*/qid_model.ckpt")
        if (p.parent / "config.json").is_file()
    ]
    require(
        len(runs) == 1 and len(calls) == 2,
        "Missing unique completed training run"
    )
    run = runs[0]
    cfg = read(run / "config.json")
    require(
        Path(cfg["data_config"]["dpath"]).resolve() == d,
        "Saved config points elsewhere"
    )
    require(
        all(
            cfg["data_config"][k] == canonical.name
            for k in (
                "sqakt_train_valid_file",
                "train_valid_file_quelevel",
                "train_valid_file"
            )
        ),
        "Saved loader keys differ"
    )
    check_data(d)
    receipt = {
        "status": "PASS",
        "excluded_item_n": 522,
        "run": str(run),
        "training_cold_interactions": 0,
        "validation_cold_interactions": 0,
        "csv_sha256": sha(canonical),
        "checkpoint_sha256": sha(run / "qid_model.ckpt"),
        "config_sha256": sha(run / "config.json"),
        "source_hashes": {
            str(p): sha(p) for p in (
                Path(wt.__file__),
                Path(module.__file__),
                project / "pykt/datasets/que_data_loader.py",
                project / "pykt/models/sqakt.py",
                ex / "wandb_sqakt_train.py",
                out / "shared_scorer.py",
                Path(__file__)
            )
        }
    }
    write(save / "training_receipt.json", receipt)
    print("TRAIN PASS", run, flush=True)

def score(a, project, p3, out, code):
    require(a.outer is not None, "Specify --outer")
    d = out / "data/backbone"
    check_data(d)
    r = read(
        out / "models/shared_teacher/training_receipt.json"
    )
    require(r["status"] == "PASS", "Training not audited")
    run = Path(r["run"])
    require(
        sha(run / "qid_model.ckpt") == r["checkpoint_sha256"]
        and sha(run / "config.json") == r["config_sha256"],
        "Model changed"
    )
    for p, h in r["source_hashes"].items():
        require(sha(p) == h, "Training/scoring source changed: " + p)

    dest = out / f"scores/outer_{a.outer}.csv"
    require(not dest.exists(), f"Scores already exist: {dest}")

    inputs = read(out / "inputs/input_manifest.json")
    source = inputs["event_source_csv"]
    require(
        sha(source) == inputs["coordinate_source_sha256"],
        "Event source changed"
    )
    for name, h in inputs["frozen_inputs"].items():
        require(
            sha(out / "inputs" / name) == h,
            "Frozen input changed: " + name
        )

    subprocess.run([
        sys.executable, str(out / "shared_scorer.py"),
        "--base", str(project),
        "--teacher_run_dir", str(run),
        "--dataset_root",
        str(project / "data/XES3G5M/question_level"),
        "--group_item_csv", str(out / "inputs/group.csv"),
        "--event_template_csv", str(out / "inputs/events.csv.gz"),
        "--q_to_kc_set_json",
        str(out / "inputs/q_to_kc_set.json"),
        "--event_source_csv", source,
        "--event_source_user_fold", "3",
        "--outer_fold", str(a.outer),
        "--out_csv", str(dest),
        "--expected_target_n", "522",
        "--required_qid", "277"
    ], check=True)

def finalize(a, project, p3, out, code):
    require(
        not (out / "clean").exists(),
        "Clean output already exists"
    )
    subprocess.run([
        sys.executable,
        str(code / "s12b_finalize_targetidfree_prior_v2.py"),
        "--parts_dir", str(out / "scores"),
        "--group_item_csv", str(out / "inputs/group.csv"),
        "--out_dir", str(out / "clean"),
        "--prior_strength", "8",
        "--expected_target_n", "522",
        "--required_qid", "277"
    ], check=True)

    import numpy as np
    import pandas as pd
    from sklearn.metrics import roc_auc_score

    new = pd.read_csv(
        out / "clean/teacher_aligned_event_baseline_targetidfree.csv.gz",
        dtype={"event_id": str}
    )
    old = pd.read_csv(
        p3 / (
            "s12_xes_targetidfree_prior_v2/clean/"
            "teacher_aligned_event_baseline_targetidfree.csv.gz"
        ),
        dtype={"event_id": str}
    )
    require(
        set(new.event_id) <= set(old.event_id),
        "New events must be a subset of old legal events"
    )
    old = old[
        old.event_id.isin(set(new.event_id))
    ].copy().reset_index(drop=True)
    paired = new.merge(
        old[["event_id", "label"]],
        on="event_id", suffixes=("", "_old"),
        validate="one_to_one"
    )
    require(
        (paired.label == paired.label_old).all(),
        "Evaluation labels changed"
    )

    records = []
    for name, ev in (
        ("old_leaked_teacher", old),
        ("new_strict_teacher", new)
    ):
        p = np.clip(
            ev.teacher_kc_uniform.to_numpy(float),
            1e-6, 1 - 1e-6
        )
        y = ev.label.to_numpy(float)
        loss = -(y * np.log(p) + (1 - y) * np.log1p(-p))
        records.append({
            "model": name,
            "event_n": len(ev),
            "target_n": ev.target_qid.nunique(),
            "pooled_auc_all_legal_events": roc_auc_score(y, p),
            "item_macro_nll_all_legal_events":
                pd.Series(loss).groupby(ev.target_qid).mean().mean()
        })
    pd.DataFrame(records).to_csv(
        out / "teacher_comparison.csv", index=False
    )
    write(out / "restart_audit.json", {
        "status": "PASS",
        "target_n": int(new.target_qid.nunique()),
        "event_n": len(new),
        "old_metrics_restricted_to_new_event_ids": True,
        "training": read(
            out / "models/shared_teacher/training_receipt.json"
        ),
        "metric_scope":
            "All legal events, before calibration-pool exclusion; "
            "no old method claim retained"
    })
    print("FINALIZE PASS", out / "teacher_comparison.csv")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "stage", choices=["prepare", "train", "score", "finalize"]
    )
    ap.add_argument(
        "--project",
        default="/home/dell/KT/KT_LLM_experiments/kt_main"
    )
    ap.add_argument("--out", default=None)
    ap.add_argument("--outer", type=int, choices=range(5))
    ap.add_argument("--epochs", type=int, default=200)
    a = ap.parse_args()

    project = Path(a.project).resolve()
    p3 = project / (
        "data/XES3G5M/question_level/teacher/rq1_priority0/"
        "fold_3/p3_strict_cold_v1"
    )
    out = (
        Path(a.out).resolve() if a.out
        else p3 / "s12_strict_shared_teacher_v1"
    )
    code = project / "examples/xes3g5m_rq1_priority0_1_code"
    globals()[a.stage](a, project, p3, out, code)

if __name__ == "__main__":
    main()
