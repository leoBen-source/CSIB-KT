#!/usr/bin/env python3
"""Read-only core-result, dependency and CPU inference checks for cleanup.
Inference probes are small synthetic inputs, not new experiment estimates.
"""
import argparse
import gc
import hashlib
import importlib.util
import json
import math
import os
import sys
from pathlib import Path


def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
    return m


def validate_results(root,policy):
    import numpy as np
    import pandas as pd
    from scipy.stats import spearmanr
    checks=[]
    result_root=root/policy['results']
    runs=[result_root/'primary'/m for m in ['sqakt','akt','simplekt','dkt']]
    runs += [result_root/'attribution/sqakt',result_root/'comparisons/sqakt']
    runs += [result_root/'external_known_kc'/d/'fit' for d in ['fa','dbe']]
    runs += [result_root/'training_seeds'/f'seed_{s}'/d for s in [43,44] for d in ['fit','comparisons']]
    runs += [result_root/'regularization_sensitivity_v5_2'/f'l2_{s}' for s in [10,1000]]
    for run in runs:
        done=json.loads((run/'completion.json').read_text())
        if done.get('status')!='PASS':raise RuntimeError('Unfinished paper result: '+str(run))
        curve=pd.read_csv(run/'learning_curve.csv')
        items=pd.read_csv(run/'seed_averaged_item_metrics.csv.gz')
        means=items.groupby(['budget','method']).item_nll.mean()
        err=max(abs(means.loc[(x.budget,x.method)]-x.item_macro_nll) for x in curve.itertuples())
        if err>1e-10:raise RuntimeError('Item/summary disagreement: '+str(run))
        pairs=pd.read_csv(run/'paired_nll_comparisons.csv')
        pair_err=max([abs(means.loc[(x.budget,x.baseline)]-means.loc[(x.budget,x.better)]-x.delta_nll) for x in pairs.itertuples()]+[0.])
        if pair_err>1e-10:raise RuntimeError('Paired difference disagreement: '+str(run))
        table=pd.read_csv(run/'main_table_k0_k5.csv')
        for x in table.itertuples():
            matched=curve[(curve.budget==x.budget)&(curve.method==x.method)]
            if len(matched)!=1 or abs(matched.iloc[0].pooled_auc-x.pooled_auc)>1e-10 or abs(means.loc[x.budget,x.method]-x.item_macro_nll)>1e-10:
                raise RuntimeError('Main table/curve disagreement: '+str(run))
        if (run/'rq2_item_predictions.csv').is_file():
            pts=pd.read_csv(run/'rq2_item_predictions.csv',float_precision='round_trip');summary=pd.read_csv(run/'rq2_summary.csv').iloc[0]
            rho=float(spearmanr(pts.criterion,pts.prior_mean)[0])
            delta=float(np.mean((pts.criterion-pts.reference_mean)**2)-np.mean((pts.criterion-pts.prior_mean)**2))
            if abs(rho-summary.spearman)>1e-9 or abs(delta-summary.delta_mse)>1e-9:
                raise RuntimeError('RQ2 disagreement: '+str(run))
        checks.append(dict(run=str(run.relative_to(root)),max_item_mean_error=float(err),max_paired_error=float(pair_err)))

    return checks


def main():
    os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project',required=True);ap.add_argument('--out',required=True)
    ap.add_argument('--policy');ap.add_argument('--baseline')
    a=ap.parse_args();root=Path(a.project).resolve()
    if a.policy:
        policy=json.loads(Path(a.policy).read_text())
    else:
        policy=json.loads((Path(__file__).parent/'retained_checks.json').read_text())
    sys.path[:0]=[str(root/'analysis/kt_ch4_followup_v4'),str(root/'examples'),str(root)]
    import numpy as np
    import pandas as pd
    from scipy.stats import spearmanr
    checks=[]
    for info in policy.get('hash_checks',[]):
        p=root/info['path']
        if not p.is_file() or sha(p)!=info['sha256']:
            raise RuntimeError('Required current input/checkpoint/source hash mismatch: '+str(p))
    for info in policy.get('source_snapshot',[]):
        p=root/info['path']
        if not p.is_file() or sha(p)!=info['sha256']:
            raise RuntimeError('Frozen retained source/config/provenance changed: '+str(p))
    checks=validate_results(root,policy)
    result_root=root/policy['results']

    # Exercise real model loading after removing unused assets and eager-import
    # support. All calculations stay on CPU and never update a weight.
    import torch
    torch.set_num_threads(1)
    if torch.cuda.is_available():raise RuntimeError('Cleanup checks must run with CUDA_VISIBLE_DEVICES empty')
    from pykt.models import load_model
    shared_root=root/policy['p3']/'s12_strict_shared_teacher_v1'
    helper=module(shared_root/'shared_scorer.py','cleanup_shared_scorer')
    probes=[]
    teachers=[shared_root]+[result_root/f'training_seeds/seed_{s}/teacher' for s in [43,44]]
    teachers += [result_root/f'external_known_kc/{d}/teacher' for d in ['fa','dbe']]
    for teacher in teachers:
        receipt=json.loads((teacher/'models/shared_teacher/training_receipt.json').read_text())
        run=Path(receipt['run']);cfg=json.loads((run/'config.json').read_text())
        mc=dict(cfg['model_config'])
        for k in ['use_wandb','learning_rate','add_uuid','l2','dataset_dir_override',
            'semantic_dataset_root_override','teacher_dir_override','num_epochs','batch_size']:mc.pop(k,None)
        dc=dict(cfg['data_config'])
        os.chdir(root/'examples')
        if (teacher/'data/geometry.json').is_file():
            net=load_model('sqakt',mc,dc,cfg['params']['emb_type'],str(run));net.eval()
        else:
            net,_=helper.load_teacher(root,str(run))
        if (teacher/'data/geometry.json').is_file():
            geom=json.loads((teacher/'data/geometry.json').read_text())
            qmap={int(k):int(v) for k,v in geom['qmap'].items()};kmap={int(k):int(v) for k,v in geom['kmap'].items()}
            qkc={int(k):list(map(int,v)) for k,v in geom['qkc'].items()}
            support=json.loads((teacher/'data/q_support_train_foldclean.json').read_text())
            hraw=next(q for q in qkc if int(support.get(str(qmap[q]),0))>0)
            query=int(pd.read_csv(teacher/'inputs/group.csv').target_qid.iloc[0])
            hq=qmap[hraw];qc=qmap[query];hc=[kmap[k] for k in qkc[hraw]];kc=[kmap[k] for k in qkc[query]]
        else:
            qkc={int(k):list(map(int,v)) for k,v in json.loads((teacher/'inputs/q_to_kc_set.json').read_text()).items()}
            support=json.loads((teacher/'data/backbone/q_support_train_foldclean.json').read_text())
            hq=next(int(q) for q,n in support.items() if int(n)>0 and int(q) in qkc)
            qc=int(pd.read_csv(teacher/'inputs/group.csv').target_qid.iloc[0]);hc=qkc[hq];kc=qkc[qc]
        maxc=int(getattr(net,'kc_set_max_concepts',0) or mc.get('kc_set_max_concepts',1))
        with torch.inference_mode():
            q=torch.tensor([[hq]],dtype=torch.long);c=torch.tensor([[helper.pad_kcs(hc,maxc)]],dtype=torch.long)
            r=torch.tensor([[1]],dtype=torch.long);valid=torch.ones((1,1),dtype=torch.bool)
            if teacher==result_root/'external_known_kc/fa/teacher':
                native=module(root/'analysis/kt_ch4_followup_v4/score_fa_native_v5_4.py','cleanup_fa_native')
                logit=native.official_prefix(torch,net,q,c,r,helper.pad_kcs(kc,maxc),qc)
            else:
                hist=helper.encode_hist(net,q,c,r,valid)
                logit=helper.score_one(net,hist,valid,0,qc,helper.pad_kcs(kc,maxc))
            value=float(torch.sigmoid(logit).item())
        if not math.isfinite(value):raise RuntimeError('Nonfinite SQAKT probe')
        probes.append({'run':str(run.relative_to(root)),'probability':value})
        del net;gc.collect()
    scorer=module(root/'analysis/xes_multibackbone_replay_v1/score.py','cleanup_multiscore')
    common_qkc={int(k):list(map(int,v)) for k,v in json.loads((shared_root/'inputs/q_to_kc_set.json').read_text()).items()}
    sup=json.loads((shared_root/'data/backbone/q_support_train_foldclean.json').read_text())
    hq=next(int(q) for q,n in sup.items() if int(n)>0 and int(q) in common_qkc)
    query=int(pd.read_csv(shared_root/'inputs/group.csv').target_qid.iloc[0])
    for name in ['akt','simplekt','dkt']:
        pointer=root/policy['p3']/f'xes_multibackbone_replay_v1/models/{name}/selected_run.txt'
        run=Path(pointer.read_text().strip());net,cfg=scorer.load_model(root,run)
        value=scorer.prob(net,name,[hq],[common_qkc[hq][0]],[1],query,common_qkc[query][0],torch.device('cpu'))
        probes.append({'run':str(run.relative_to(root)),'probability':value})
        del net;gc.collect()
    if a.baseline:
        baseline=json.loads(Path(a.baseline).read_text())
        old={p['run']:p['probability'] for p in baseline['cpu_inference_probes']}
        if set(old)!={p['run'] for p in probes}:raise RuntimeError('Probe run set changed')
        if any(abs(p['probability']-old[p['run']])>1e-9 for p in probes):
            raise RuntimeError('Inference changed after cleanup; rollback required')
    report={'status':'PASS','checked_result_runs':checks,'cpu_inference_probes':probes,
        'training_performed':False,'inference_probe_is_experiment_metric':False,
        'hash_check_count':len(policy.get('hash_checks',[])), 'frozen_source_metadata_count':len(policy.get('source_snapshot',[]))}
    Path(a.out).write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print('CORE_VERIFY_PASS',len(checks),'result suites',len(probes),'CPU model probes')


if __name__=='__main__':
    main()
